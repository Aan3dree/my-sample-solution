/* tslint:disable */
require("./GetData.module.css");
const styles = {
  getData: 'getData_ac07c81e',
  container: 'container_ac07c81e',
  row: 'row_ac07c81e',
  column: 'column_ac07c81e',
  'ms-Grid': 'ms-Grid_ac07c81e',
  title: 'title_ac07c81e',
  subTitle: 'subTitle_ac07c81e',
  description: 'description_ac07c81e',
  button: 'button_ac07c81e',
  label: 'label_ac07c81e'
};

export default styles;
/* tslint:enable */