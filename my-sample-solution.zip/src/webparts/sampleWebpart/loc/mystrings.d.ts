declare interface ISampleWebpartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SampleWebpartWebPartStrings' {
  const strings: ISampleWebpartWebPartStrings;
  export = strings;
}
