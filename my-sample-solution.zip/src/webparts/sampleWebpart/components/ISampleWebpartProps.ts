export interface ISampleWebpartProps {
  description: string;
}
