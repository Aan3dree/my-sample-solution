/* tslint:disable */
require("./JsWebPartWebPart.module.css");
const styles = {
  jsWebPart: 'jsWebPart_ba459f7a',
  container: 'container_ba459f7a',
  row: 'row_ba459f7a',
  column: 'column_ba459f7a',
  'ms-Grid': 'ms-Grid_ba459f7a',
  title: 'title_ba459f7a',
  subTitle: 'subTitle_ba459f7a',
  description: 'description_ba459f7a',
  button: 'button_ba459f7a',
  label: 'label_ba459f7a'
};

export default styles;
/* tslint:enable */