(window["webpackJsonpf1006a38_983e_4851_ba4a_70a12aaf94b8_0_1_0"] = window["webpackJsonpf1006a38_983e_4851_ba4a_70a12aaf94b8_0_1_0"] || []).push([["sp-multilingual-translationpanel"],{

/***/ "6zqf":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/TranslationPanel/TranslationPanel.module.css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ac_c_f298b284{font-size:20px;font-weight:600}.ae_c_f298b284 .af_c_f298b284{font-weight:400;margin:8px 0}.ae_c_f298b284 .ag_c_f298b284{margin:13px 0}.ae_c_f298b284 .ah_c_f298b284,.ae_c_f298b284 .b_c_f298b284{margin:8px 0}.ae_c_f298b284 .ai_c_f298b284{display:inline-block}.ae_c_f298b284 .aj_c_f298b284{margin:16px 0;display:block}.ae_c_f298b284 .ak_c_f298b284{margin:0 6px}.ae_c_f298b284 .al_c_f298b284{position:relative;font-size:12px;font-weight:400}.ae_c_f298b284 .al_c_f298b284 .am_c_f298b284{color:\"[theme:neutralPrimary, default: #323130]\"}.ae_c_f298b284 .al_c_f298b284 a{color:\"[theme:themeSecondary, default: #2b88d8]\";text-decoration:none}", ""]);


/***/ }),

/***/ "CJJt":
/*!**********************************************************!*\
  !*** ./lib/TranslationPanel/TranslationPanel.module.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./TranslationPanel.module.css */ "6zqf");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "EueJ":
/*!**************************************************************!*\
  !*** ./lib/TranslationPanel/TranslationPanel.module.scss.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./TranslationPanel.module.css */ "CJJt");
var styles = {
    headerIEOnly: 'ac_c_f298b284',
    TranslationField: 'ae_c_f298b284',
    informationHeader: 'af_c_f298b284',
    informationHeaderWrapper: 'ag_c_f298b284',
    informationField: 'ah_c_f298b284',
    spinner: 'b_c_f298b284',
    startForAllButtonWrapper: 'ai_c_f298b284',
    startForAllButton: 'aj_c_f298b284',
    linkInline: 'ak_c_f298b284',
    translationSubField: 'al_c_f298b284',
    translationDetail: 'am_c_f298b284'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "G/3B":
/*!****************************************************!*\
  !*** ./lib/TranslationPanel/TranslationPanel.resx ***!
  \****************************************************/
/*! exports provided: TranslationHeader, HeaderDescription, HeaderDescriptionViewMode, LearnMoreLabel, TranslationPageCreateViewPage, Draft, Version, NotStartedLabel, PublishedLabel, DraftSavedLabel, PublishedAndDraftSavedLabel, SeeThePageLink, StartForAllButton, StartForRestButton, CloseButtonAriaLabel, Start, FailToParseError, DefaultLanguageLabel, StartLinkToolTip, StartLinkToolTipNonDefault, missingLanguageWarning, trespassingLanguageWarning, listFormat, CheckedOutToUnknownUser, RepublishNeededWarning, CantCreatePendingApproval, CantCreateScheduledPublish, DefaultPageDeletedLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"TranslationHeader\":\"TranslationHeader\",\"HeaderDescription\":\"HeaderDescription\",\"HeaderDescriptionViewMode\":\"HeaderDescriptionViewMode\",\"LearnMoreLabel\":\"LearnMoreLabel\",\"TranslationPageCreateViewPage\":\"TranslationPageCreateViewPage\",\"Draft\":\"Draft\",\"Version\":\"Version\",\"NotStartedLabel\":\"NotStartedLabel\",\"PublishedLabel\":\"PublishedLabel\",\"DraftSavedLabel\":\"DraftSavedLabel\",\"PublishedAndDraftSavedLabel\":\"PublishedAndDraftSavedLabel\",\"SeeThePageLink\":\"SeeThePageLink\",\"StartForAllButton\":\"StartForAllButton\",\"StartForRestButton\":\"StartForRestButton\",\"CloseButtonAriaLabel\":\"CloseButtonAriaLabel\",\"Start\":\"Start\",\"FailToParseError\":\"FailToParseError\",\"DefaultLanguageLabel\":\"DefaultLanguageLabel\",\"StartLinkToolTip\":\"StartLinkToolTip\",\"StartLinkToolTipNonDefault\":\"StartLinkToolTipNonDefault\",\"missingLanguageWarning\":\"missingLanguageWarning\",\"trespassingLanguageWarning\":\"trespassingLanguageWarning\",\"listFormat\":\"listFormat\",\"CheckedOutToUnknownUser\":\"CheckedOutToUnknownUser\",\"RepublishNeededWarning\":\"RepublishNeededWarning\",\"CantCreatePendingApproval\":\"CantCreatePendingApproval\",\"CantCreateScheduledPublish\":\"CantCreateScheduledPublish\",\"DefaultPageDeletedLabel\":\"DefaultPageDeletedLabel\"}");

/***/ }),

/***/ "IDVf":
/*!**************************************************!*\
  !*** ./lib/TranslationPanel/TranslationPanel.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_page_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-page-context */ "X+PM");
/* harmony import */ var _microsoft_sp_page_context__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_page_context__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ms/sp-component-utilities */ "hiL/");
/* harmony import */ var _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! office-ui-fabric-react/lib/Panel */ "p6C6");
/* harmony import */ var _ms_i18n_utilities__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ms/i18n-utilities */ "Ycni");
/* harmony import */ var _ms_i18n_utilities__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_ms_i18n_utilities__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _dataProviders_TranslationsDataProvider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../dataProviders/TranslationsDataProvider */ "yy1a");
/* harmony import */ var _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./TranslationPanel.resx */ "G/3B");
var _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./TranslationPanel.resx */ "G/3B", 1);
/* harmony import */ var _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./TranslationPanel.module.scss */ "EueJ");
/* harmony import */ var _LanguageNames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../LanguageNames */ "qAjK");
/* harmony import */ var _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../models/IRawTranslation */ "CtQH");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../Constants */ "o1EW");
/* harmony import */ var _Killswitches__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../Killswitches */ "VZb/");
// @Copyright (c) Microsoft Corporation.  All rights reserved.


















var TranslationPanel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(TranslationPanel, _super);
    function TranslationPanel(props) {
        var _this = _super.call(this, props) || this;
        _this._cultureMap = new Map();
        _this._basePageUrl = '';
        _this._basePageVersion = 0;
        _this._defaultPageRemoved = false;
        _this._getDisplayDate = function (lastModified) {
            if (!lastModified) {
                return '';
            }
            var formattedDate = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPFlight"].isEnabled(631 /* ConvertLocaleToUTCInLastModified */)
                ? new Date(lastModified).toISOString()
                : lastModified;
            return _ms_i18n_utilities__WEBPACK_IMPORTED_MODULE_8__["LocaleFormat"].formatRelativeTimeApproximate(new Date(formattedDate));
        };
        _this._startAllTranslations = function () {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_EngagementLogger"].logEvent(_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX + "." + _Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].Panel + ".StartAllTranslations");
            _this.setState({ isLoading: true });
            _this._translationsDataProvider
                .startAllTranslations(_this._translationSourceItemId)
                .then(function (cultureData) {
                _this._updateCultureMap(cultureData);
                _this.setState({
                    isLoading: false,
                    createdTranslationsInMinorVersion: _this._isOnMinorVersionOfPublishedPage
                });
                _this._updateKnownTranslations();
            })
                .catch(function (error) {
                _this.setState({
                    isLoading: false,
                    errorMessage: _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["FailToParseError"]
                });
            });
        };
        _this._translationsDataProvider = new _dataProviders_TranslationsDataProvider__WEBPACK_IMPORTED_MODULE_10__["TranslationsDataProvider"]({
            serviceScope: props.serviceScope,
            listItemId: props.listItemId
        });
        _this._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogSource"].create('TranslationPanel');
        _this.props.serviceScope.whenFinished(function () {
            _this._pageContext = _this.props.serviceScope.consume(_microsoft_sp_page_context__WEBPACK_IMPORTED_MODULE_3__["PageContext"].serviceKey);
            _this._pageService = _this.props.serviceScope.consume(_ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__["PageService"].serviceKey);
            _this._baseCultureName = _this._pageContext.web.languageName.toLowerCase();
            _this.state = {
                isLoading: true,
                cultureInProgress: _this._pageContext.cultureInfo.currentCultureName.toLowerCase(),
                errorMessage: undefined,
                isEditMode: !!_this.props.isEditMode,
                isDefaultLanguage: false,
                createdTranslationsInMinorVersion: false,
                culturesMissingFromField: [],
                culturesTrespassingInField: [],
                reasonCantCreateTranslations: undefined
            };
        });
        return _this;
    }
    TranslationPanel.prototype.render = function () {
        var _a;
        var startAllDisabled = true;
        var startRest = false;
        this._cultureMap.forEach(function (culture) {
            // Have to use forEach because for(of) requires downlevelIteration compiler option
            if (culture.FileStatus === _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Invalid) {
                startAllDisabled = false;
            }
            else {
                startRest = true;
            }
        });
        var translateToAllButtonDisabled = startAllDisabled || !this.state.isEditMode;
        var createAllButton = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["PrimaryButton"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].startForAllButton, "data-automation-id": !translateToAllButtonDisabled && 'translateToAllEnabled', onClick: this._startAllTranslations, text: startRest ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["StartForRestButton"] : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["StartForAllButton"], disabled: translateToAllButtonDisabled }));
        // header text is causing known IE rendering issue with flex display
        // Hence we need to show header as a standalone label
        var isIE = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_BrowserDetection"].getBrowserInformation().browser === _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_Browser"].IE;
        var basePageUrl = this._baseCulture ? (_a = this._baseCulture.Path) === null || _a === void 0 ? void 0 : _a.DecodedUrl : this._basePageUrl;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__["Panel"], { isLightDismiss: true, isOpen: true, headerText: isIE ? undefined : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["TranslationHeader"], onDismiss: this.props.closeTranslationPanel, type: office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__["PanelType"].smallFixedFar, closeButtonAriaLabel: _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["CloseButtonAriaLabel"] },
            isIE && react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Label"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].headerIEOnly }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["TranslationHeader"]),
            this.state.errorMessage ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBar"], { messageBarType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBarType"].error }, this.state.errorMessage)) : this.state.isLoading ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Spinner"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].spinner })) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].TranslationField, "data-automation-id": 'translatePanelMain' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].informationHeaderWrapper },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, this.state.isEditMode ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["HeaderDescription"] : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["HeaderDescriptionViewMode"]),
                    this._getLearnMoreLinkInHeader()),
                !!this.state.culturesMissingFromField.length && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBar"], { messageBarType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBarType"].info }, _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["missingLanguageWarning"], this._getLanguageList(this.state.culturesMissingFromField)))),
                !!this.state.culturesTrespassingInField.length && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBar"], { messageBarType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBarType"].info }, _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["trespassingLanguageWarning"], this._getLanguageList(this.state.culturesTrespassingInField)))),
                this.state.createdTranslationsInMinorVersion && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBar"], { messageBarType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBarType"].warning },
                    _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["RepublishNeededWarning"],
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Link"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].linkInline, href: TranslationPanel.LEARN_MORE_REPUBLISH_URL, target: '_blank', "aria-label": _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["LearnMoreLabel"] }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["LearnMoreLabel"]))),
                this.state.isLoading ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Spinner"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].spinner })) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
                    this._defaultPageRemoved ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBar"], { messageBarType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["MessageBarType"].warning },
                        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["DefaultPageDeletedLabel"], _LanguageNames__WEBPACK_IMPORTED_MODULE_13__["LanguageNames"].getLocalizedName(this._baseCultureName)),
                        this._getLearnMoreLinkInHeader(TranslationPanel.LEARN_MORE_DEFAULT_REMOVED_URL))) : (this._getLanguageInformationField({
                        Culture: this._baseCultureName,
                        FileStatus: this._baseCulture
                            ? this._baseCulture.FileStatus
                            : this._getSPFileLevel(this._basePageVersion),
                        LastModified: '',
                        HasPublishedVersion: this._baseCulture
                            ? this._baseCulture.HasPublishedVersion
                            : this._basePageVersion >= 1.0,
                        Path: { DecodedUrl: basePageUrl + "?stay=true" }
                    }, true)),
                    this._wrapElementWithTooltip(react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].startForAllButtonWrapper }, createAllButton), !this.state.isEditMode),
                    this._translationGroupLinks))))));
    };
    TranslationPanel.prototype.componentDidMount = function () {
        var _this = this;
        var monitor = new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_QosMonitor"](_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX + ".TranslationPanelComponentDidMount");
        _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__["Multilingual"].getPageLanguage(this.props.serviceScope)
            .then(function (properties) {
            _this._translationSourceItemId = properties.SourceItemId;
            var getPageTranslationStatusPromise = _this._translationsDataProvider.getPageTranslationStatus({
                translationSourceItemId: _this._translationSourceItemId,
                listItemId: _this.props.listItemId
            });
            var getCurrentItemPromise = _this._pageService.getCurrentItem();
            var getPagePublishInfoPromise = _this._pageService.getPagePublishInfo();
            Promise.all([getPageTranslationStatusPromise, getCurrentItemPromise, getPagePublishInfoPromise])
                .then(function (allData) {
                var _a;
                var translationsResponse = allData[0], clientForm = allData[1], pagePublishInfo = allData[2];
                var _b = translationsResponse.Translations ||
                    translationsResponse, error = _b.error, Items = _b.Items, UntranslatedLanguages = _b.UntranslatedLanguages;
                // Validate all responses
                if (error) {
                    monitor.writeUnexpectedFailure('RetrieveTranslationsFailure');
                    throw new Error(error);
                }
                if (!(clientForm && clientForm.item && clientForm.item.properties)) {
                    monitor.writeUnexpectedFailure('RetrieveCurrentItemFailure');
                    throw new Error(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["FailToParseError"]);
                }
                _this._basePageUrl =
                    translationsResponse.Path &&
                        translationsResponse.Path.DecodedUrl;
                _this._basePageVersion = translationsResponse.Version;
                var pageProperties = clientForm.item
                    .properties;
                var checkoutUserData = clientForm.item
                    .properties;
                var isCheckedOutToOtherUser = false;
                var isDefaultLanguage = true;
                var isPendingApproval = false;
                var isScheduled = false;
                var defaultPageNotInItems = !Object(_Killswitches__WEBPACK_IMPORTED_MODULE_16__["useListItemIndependentAPIKSActive"])() &&
                    pageProperties &&
                    (pageProperties._SPIsTranslation === 'Yes' ||
                        (!Object(_Killswitches__WEBPACK_IMPORTED_MODULE_16__["useSPTranslationLanguageKSActive"])() && !!pageProperties._SPTranslationLanguage));
                var reasonCantCreateTranslations = undefined;
                for (var _i = 0, Items_1 = Items; _i < Items_1.length; _i++) {
                    var culture = Items_1[_i];
                    if (culture.Culture === _this._baseCultureName) {
                        // default page
                        defaultPageNotInItems = false;
                        _this._baseCulture = culture;
                        continue;
                    }
                    _this._cultureMap.set(culture.Culture, culture);
                }
                if (UntranslatedLanguages && UntranslatedLanguages.length > 0) {
                    _this._populateCultures(UntranslatedLanguages);
                }
                if (pageProperties) {
                    // See if the page is a page translation or the original-language page
                    if (pageProperties._SPIsTranslation === 'Yes' ||
                        (!Object(_Killswitches__WEBPACK_IMPORTED_MODULE_16__["useSPTranslationLanguageKSActive"])() && !!pageProperties._SPTranslationLanguage)) {
                        isDefaultLanguage = false;
                        reasonCantCreateTranslations = _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["StartLinkToolTipNonDefault"];
                    }
                    else {
                        // Check for other reasons we cannot modify the current page, since we're on the default language page
                        (_a = _this.ValidateCanCreateTranslations(checkoutUserData, pagePublishInfo), isCheckedOutToOtherUser = _a.isCheckedOutToOtherUser, reasonCantCreateTranslations = _a.reasonCantCreateTranslations, isPendingApproval = _a.isPendingApproval, isScheduled = _a.isScheduled);
                    }
                    _this._translatedLanguages = pageProperties._SPTranslatedLanguages || [];
                    _this._ensureConsistentFieldState(isDefaultLanguage);
                }
                _this._defaultPageRemoved = defaultPageNotInItems;
                _this.setState({
                    isLoading: false,
                    cultureInProgress: undefined,
                    isDefaultLanguage: isDefaultLanguage,
                    isEditMode: !isCheckedOutToOtherUser && !isPendingApproval && !isScheduled && isDefaultLanguage,
                    reasonCantCreateTranslations: reasonCantCreateTranslations
                });
                monitor.writeSuccess();
            })
                .catch(function (error) {
                _this._cultureMap.clear();
                _this.setState({
                    isLoading: false,
                    errorMessage: error.message
                });
                monitor.writeUnexpectedFailure('RetrieveDataFailure');
            });
        })
            .catch(function (error) {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logError(_this._logSource, error, 'GetPageLanguage');
            _this.setState({
                isLoading: false,
                errorMessage: error.message
            });
            monitor.writeUnexpectedFailure('RetrievePageLanguageFailure');
        });
    };
    TranslationPanel.prototype.componentDidUpdate = function (prevProps, prevState) {
        if (prevState.cultureInProgress && !this.state.cultureInProgress) {
            // focus on view button after create is clicked
            var id = "viewTranslation_" + prevState.cultureInProgress;
            var element = document.getElementById(id);
            if (element) {
                element.focus();
            }
        }
    };
    TranslationPanel.prototype.ValidateCanCreateTranslations = function (checkoutUserData, pagePublishInfo) {
        var isCheckedOutToOtherUser = false;
        var isPendingApproval = false;
        var isScheduled = false;
        var reasonCantCreateTranslations;
        if (checkoutUserData) {
            // Fix situation where CheckoutUser is an array of length 1, with the "user" being that first element
            var CheckoutUser = checkoutUserData.CheckoutUser;
            var checkoutUserArray = CheckoutUser;
            var isArray = CheckoutUser instanceof Array;
            var checkoutUser = isArray && checkoutUserArray.length > 0
                ? checkoutUserArray[0]
                : isArray && checkoutUserArray.length === 0
                    ? undefined
                    : CheckoutUser;
            if (checkoutUser && parseInt(checkoutUser.id, 10) !== this._pageContext.legacyPageContext.userId) {
                isCheckedOutToOtherUser = true;
                reasonCantCreateTranslations = _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["CheckedOutToUnknownUser"];
            }
        }
        if (pagePublishInfo.enableModeration &&
            (pagePublishInfo.saveStatus === _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__["PageSaveStatus"].Pending ||
                pagePublishInfo.saveStatus === _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__["PageSaveStatus"].SubmittedForApproval)) {
            isPendingApproval = true;
            reasonCantCreateTranslations = _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["CantCreatePendingApproval"];
        }
        else if (pagePublishInfo.saveStatus === _ms_sp_component_utilities__WEBPACK_IMPORTED_MODULE_6__["PageSaveStatus"].Scheduled) {
            isScheduled = true;
            reasonCantCreateTranslations = _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["CantCreateScheduledPublish"];
        }
        return { isCheckedOutToOtherUser: isCheckedOutToOtherUser, reasonCantCreateTranslations: reasonCantCreateTranslations, isPendingApproval: isPendingApproval, isScheduled: isScheduled };
    };
    /**
     * Compare the field values in this._translatedLanguages
     */
    TranslationPanel.prototype._ensureConsistentFieldState = function (isDefaultLanguage) {
        var _this = this;
        if (this.props.isEditMode && isDefaultLanguage) {
            var culturesMissingFromField_1 = [];
            var culturesTrespassingInField_1 = [];
            for (var _i = 0, _a = this._translatedLanguages; _i < _a.length; _i++) {
                var fieldCulture = _a[_i];
                var translation = this._cultureMap.get(fieldCulture);
                // If the server doesn't return this translation, or if it returns an invalid translation, it doesn't exist
                if (!translation || !translation.LastModified) {
                    culturesTrespassingInField_1.push(fieldCulture);
                }
            }
            this._cultureMap.forEach(function (culture) {
                if (culture && culture.LastModified && _this._translatedLanguages.indexOf(culture.Culture) === -1) {
                    culturesMissingFromField_1.push(culture.Culture);
                }
            });
            if (culturesMissingFromField_1.length || culturesTrespassingInField_1.length) {
                var monitor_1 = new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_QosMonitor"](_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX + ".TranslationPanelUpdateTranslationLanguages");
                _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_EngagementLogger"].logEventWithLogEntry(new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogEntry"](_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX, _Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].Panel + ".UpdateTranslationLanguages", _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogType"].Event, {
                    CulturesMissing: culturesMissingFromField_1.length.toString(),
                    CulturesTrespassing: culturesTrespassingInField_1.length.toString()
                }));
                this._translationsDataProvider
                    .updateTranslationLanguages()
                    .then(function () {
                    _this._updateKnownTranslations();
                    _this.setState({
                        culturesMissingFromField: culturesMissingFromField_1,
                        culturesTrespassingInField: culturesTrespassingInField_1
                    });
                    monitor_1.writeSuccess();
                })
                    .catch(function (error) {
                    monitor_1.writeUnexpectedFailure(_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX + ".TranslationPanelUpdateTranslationLanguagesUnknownError", error);
                });
            }
        }
    };
    Object.defineProperty(TranslationPanel.prototype, "_translationGroupLinks", {
        get: function () {
            var _this = this;
            var languageGroup = [];
            this._cultureMap.forEach(function (culture) {
                languageGroup.push(_this._getLanguageInformationField(culture));
            });
            return languageGroup;
        },
        enumerable: true,
        configurable: true
    });
    TranslationPanel.prototype._getLanguageInformationField = function (culture, isDefault) {
        var cultureDisplay = _LanguageNames__WEBPACK_IMPORTED_MODULE_13__["LanguageNames"].getLocalizedName(culture.Culture);
        var fileStatusMessage = culture.FileStatus === _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Published
            ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["PublishedLabel"]
            : culture.HasPublishedVersion
                ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["PublishedAndDraftSavedLabel"]
                : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["DraftSavedLabel"];
        var displayDate = this._getDisplayDate(culture.LastModified);
        fileStatusMessage = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(fileStatusMessage, displayDate);
        var automationId = isDefault
            ? 'viewMainLanguagePage'
            : 'viewTranslation_' + culture.Culture.toLowerCase();
        if (isDefault) {
            cultureDisplay = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["DefaultLanguageLabel"], cultureDisplay);
        }
        var viewLinkAriaLabel = this._getViewLinkAriaLabel(culture);
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].informationField },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Label"], { role: 'heading', "aria-level": 3 }, cultureDisplay),
            this.state.cultureInProgress === culture.Culture ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Spinner"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].spinner })) : culture.FileStatus ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].translationSubField },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].translationDetail }, fileStatusMessage),
                // If this is the default culture and we're on the default culture page, or
                // If we're on the same culture as this translation, don't show the see the page link
                !(isDefault && this.state.isDefaultLanguage) &&
                    !(this._translationLanguageCode && this._translationLanguageCode === culture.Culture) ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Link"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].linkInline, href: _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_9__["Uri"].concatenate(this._pageContext.web.absoluteUrl, culture.Path.DecodedUrl), target: '_blank', "data-interception": 'off', "data-automation-id": automationId, "aria-label": viewLinkAriaLabel, id: automationId }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["SeeThePageLink"])) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null)))) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].translationSubField },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].translationDetail }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["NotStartedLabel"]),
                this._getStartTranslationLink(this.state.isEditMode ? culture : undefined)))));
    };
    TranslationPanel.prototype._getViewLinkAriaLabel = function (culture) {
        return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["TranslationPageCreateViewPage"], _LanguageNames__WEBPACK_IMPORTED_MODULE_13__["LanguageNames"].getLocalizedName(culture.Culture), culture.FileStatus === _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Published ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["Version"] : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["Draft"]);
    };
    TranslationPanel.prototype._getLearnMoreLinkInHeader = function (url) {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Link"], { className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].linkInline, href: url || TranslationPanel.LEARN_MORE_URL, target: '_blank', "aria-label": _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["LearnMoreLabel"] }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["LearnMoreLabel"]));
    };
    /**
     * @param culture the culture that the link will lead to. Undefined culture will render a disabled link
     */
    TranslationPanel.prototype._getStartTranslationLink = function (culture) {
        return this._wrapElementWithTooltip(react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Link"], { onClick: culture ? this._startTranslation(culture) : undefined, className: _TranslationPanel_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].linkInline, disabled: !culture || !!this.state.cultureInProgress }, _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["Start"]), !culture);
    };
    TranslationPanel.prototype._wrapElementWithTooltip = function (element, tooltipOn) {
        return tooltipOn ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["TooltipHost"], { content: this.state.reasonCantCreateTranslations
                ? this.state.reasonCantCreateTranslations
                : this.state.isDefaultLanguage
                    ? _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["StartLinkToolTip"]
                    : _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["StartLinkToolTipNonDefault"] }, element)) : (element);
    };
    TranslationPanel.prototype._startTranslation = function (culture) {
        var _this = this;
        return function () {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_EngagementLogger"].logEventWithLogEntry(new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogEntry"](_Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].PREFIX, _Constants__WEBPACK_IMPORTED_MODULE_15__["Constants"].Panel + ".StartTranslation", _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogType"].Event, {
                Culture: culture.Culture
            }));
            _this.setState({ cultureInProgress: culture.Culture });
            _this._translationsDataProvider
                .startTranslation(culture, _this._translationSourceItemId)
                .then(function (cultureData) {
                _this._updateCultureMap(cultureData);
                _this.setState({
                    cultureInProgress: undefined,
                    createdTranslationsInMinorVersion: _this._isOnMinorVersionOfPublishedPage
                });
                _this._updateKnownTranslations();
            })
                .catch(function (error) {
                _this.setState({ errorMessage: _TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["FailToParseError"] });
            });
        };
    };
    TranslationPanel.prototype._updateKnownTranslations = function () {
        var _this = this;
        // Fix up translatedLanguages now
        this._translatedLanguages = [];
        this._cultureMap.forEach(function (culture) {
            if (culture && culture.LastModified) {
                _this._translatedLanguages.push(culture.Culture);
            }
        });
        this._pageService.updateCurrentItem().catch(function (error) {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logError(_this._logSource, error, 'UpdateKnownTranslationsError');
        });
    };
    Object.defineProperty(TranslationPanel.prototype, "_isOnMinorVersionOfPublishedPage", {
        /**
         * We know we're on a minor version of a published page if our version is > 1.0, and
         * we're either on a minor version or we're working on a draft
         */
        get: function () {
            return (this._basePageVersion >= 1.0 &&
                (!!this.props.isEditMode ||
                    this._getSPFileLevel(this._basePageVersion) === _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Draft ||
                    this._getSPFileLevel(this._basePageVersion) === _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Checkout));
        },
        enumerable: true,
        configurable: true
    });
    TranslationPanel.prototype._populateCultures = function (untranslatedLanguages) {
        for (var _i = 0, untranslatedLanguages_1 = untranslatedLanguages; _i < untranslatedLanguages_1.length; _i++) {
            var culture = untranslatedLanguages_1[_i];
            this._cultureMap.set(culture, {
                Culture: culture,
                FileStatus: _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Invalid,
                LastModified: '',
                HasPublishedVersion: false,
                Path: { DecodedUrl: '' }
            });
        }
    };
    TranslationPanel.prototype._updateCultureMap = function (cultureData) {
        for (var _i = 0, cultureData_1 = cultureData; _i < cultureData_1.length; _i++) {
            var culture = cultureData_1[_i];
            this._cultureMap.set(culture.Culture, culture);
        }
    };
    TranslationPanel.prototype._getSPFileLevel = function (version) {
        if (version >= 1.0 && version % 1 === 0) {
            return _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Published;
        }
        else {
            return _models_IRawTranslation__WEBPACK_IMPORTED_MODULE_14__["SPFileLevel"].Draft;
        }
    };
    // Gets a readable list of languages to present to the user
    // Assumes length > 0
    TranslationPanel.prototype._getLanguageList = function (cultures) {
        if (!cultures || cultures.length === 0) {
            return '';
        }
        var readableList = _LanguageNames__WEBPACK_IMPORTED_MODULE_13__["LanguageNames"].getLocalizedName(cultures[0]);
        var i;
        for (i = 1; i < cultures.length; i++) {
            readableList = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Text"].format(_TranslationPanel_resx__WEBPACK_IMPORTED_MODULE_11__["listFormat"], readableList, _LanguageNames__WEBPACK_IMPORTED_MODULE_13__["LanguageNames"].getLocalizedName(cultures[i]));
        }
        return readableList;
    };
    TranslationPanel.LEARN_MORE_URL = 'https://go.microsoft.com/fwlink/?linkid=2102167';
    TranslationPanel.LEARN_MORE_REPUBLISH_URL = 'https://go.microsoft.com/fwlink/?linkid=2115374';
    TranslationPanel.LEARN_MORE_DEFAULT_REMOVED_URL = 'https://go.microsoft.com/fwlink/?linkid=2133924';
    return TranslationPanel;
}(react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]));
/* harmony default export */ __webpack_exports__["default"] = (TranslationPanel);


/***/ })

}]);
//# sourceMappingURL=chunk.sp-multilingual-translationpanel_[locale].js.map