declare const styles: {
    hasHeader: string;
    belowHeader: string;
    hasCommandBar: string;
    content: string;
    canvasHost: string;
    NavPane: string;
};
export default styles;
//# sourceMappingURL=CanvasHost.module.scss.d.ts.map