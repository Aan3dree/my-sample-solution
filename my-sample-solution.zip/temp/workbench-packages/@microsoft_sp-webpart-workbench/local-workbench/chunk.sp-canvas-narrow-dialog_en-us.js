(window["webpackJsonp_85093aa7_8c12_4683_91aa_47cd5e2654db_2_5_0"] = window["webpackJsonp_85093aa7_8c12_4683_91aa_47cd5e2654db_2_5_0"] || []).push([["sp-canvas-narrow-dialog"],{

/***/ "HHXz":
/*!*****************************************************************************!*\
  !*** ./lib/sp-canvas/canvas/editChunk/narrowModeDialog/NarrowModeDialog.js ***!
  \*****************************************************************************/
/*! exports provided: NarrowModeDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NarrowModeDialog", function() { return NarrowModeDialog; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! office-ui-fabric-react/lib/Dialog */ "wPGM");
/* harmony import */ var _NarrowModeDialog_resx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./NarrowModeDialog.resx */ "XVhN");
var _NarrowModeDialog_resx__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./NarrowModeDialog.resx */ "XVhN", 1);



function NarrowModeDialog() {
    return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_1__["Dialog"], { hidden: false, dialogContentProps: {
            title: _NarrowModeDialog_resx__WEBPACK_IMPORTED_MODULE_2__["Title"],
            subText: _NarrowModeDialog_resx__WEBPACK_IMPORTED_MODULE_2__["Subtitle"]
        }, modalProps: {
            isBlocking: true
        } }));
}


/***/ }),

/***/ "XVhN":
/*!*******************************************************************************!*\
  !*** ./lib/sp-canvas/canvas/editChunk/narrowModeDialog/NarrowModeDialog.resx ***!
  \*******************************************************************************/
/*! exports provided: Title, Subtitle, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"Title\":\"Widen your browser window\",\"Subtitle\":\"Editing is not available in a narrow browser window. Make the window wider to continue editing.\"}");

/***/ })

}]);
//# sourceMappingURL=chunk.sp-canvas-narrow-dialog_[locale].js.map