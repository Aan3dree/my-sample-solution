export interface IGetDataProps {
  description: string;
}
