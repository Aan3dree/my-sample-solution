declare interface IJsWebPartWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'JsWebPartWebPartStrings' {
  const strings: IJsWebPartWebPartStrings;
  export = strings;
}
