declare interface IGetDataWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GetDataWebPartStrings' {
  const strings: IGetDataWebPartStrings;
  export = strings;
}
