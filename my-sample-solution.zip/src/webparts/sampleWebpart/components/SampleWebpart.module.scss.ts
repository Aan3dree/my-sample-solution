/* tslint:disable */
require("./SampleWebpart.module.css");
const styles = {
  sampleWebpart: 'sampleWebpart_6d0a06a9',
  container: 'container_6d0a06a9',
  row: 'row_6d0a06a9',
  column: 'column_6d0a06a9',
  'ms-Grid': 'ms-Grid_6d0a06a9',
  title: 'title_6d0a06a9',
  subTitle: 'subTitle_6d0a06a9',
  description: 'description_6d0a06a9',
  button: 'button_6d0a06a9',
  label: 'label_6d0a06a9'
};

export default styles;
/* tslint:enable */