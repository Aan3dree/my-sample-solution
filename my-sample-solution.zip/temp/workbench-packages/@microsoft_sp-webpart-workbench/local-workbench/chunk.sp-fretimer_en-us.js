(window["webpackJsonp_6da60671_741f_47c5_b35b_5078edaf312f_0_1_0"] = window["webpackJsonp_6da60671_741f_47c5_b35b_5078edaf312f_0_1_0"] || []).push([["sp-fretimer"],{

/***/ "0ptS":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/FirstRunExperience/Components/FREDataIcon.module.css ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".b_b_6e28872b{visibility:hidden;position:absolute;width:24px;height:24px;background-color:#fff;border-radius:12px;margin:auto;box-shadow:1px 1px 1px 1px rgba(0,0,0,.2);z-index:2;cursor:pointer}.b_b_6e28872b .c_b_6e28872b{position:absolute;color:teal;border:1px solid teal;border-radius:12px;box-sizing:border-box;margin:1px;font-size:12px;padding:4px}.b_b_6e28872b.e_b_6e28872b,.b_b_6e28872b .f_b_6e28872b{visibility:visible}", ""]);


/***/ }),

/***/ "JT+F":
/*!******************************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FREDataIcon.module.css ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./FREDataIcon.module.css */ "0ptS");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "LJQr":
/*!****************************************************!*\
  !*** ./lib/FirstRunExperience/loc/CanvasData.resx ***!
  \****************************************************/
/*! exports provided: Canvas_1_Headline, Canvas_1_Content_1, Canvas_2_Headline, Canvas_2_Content_1, Canvas_3_Headline, Canvas_3_Content_1, Canvas_3_Content_1_left, Canvas_3_Content_1_right, Canvas_4_Headline, Canvas_4_Content_1, Canvas_5_Headline, Canvas_5_Content_1, Canvas_6_Headline, Canvas_6_Content_1, Canvas_ProgressLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"Canvas_1_Headline\":\"Add or change sections\",\"Canvas_1_Content_1\":\"Select anywhere below the title area to display section borders and the section toolbar. Select the {0} to add a new section.\",\"Canvas_2_Headline\":\"Change the layout\",\"Canvas_2_Content_1\":\"Select the Edit section button {0}, then in the section pane on the right, choose the number of columns you want and even a section background color.\",\"Canvas_3_Headline\":\"Section layouts\",\"Canvas_3_Content_1\":\"When you make changes in the section pane, the updates are immediately reflected on your page. Select the {0} on the upper {1} to keep the changes and close the pane.\",\"Canvas_3_Content_1_left\":\"left\",\"Canvas_3_Content_1_right\":\"right\",\"Canvas_4_Headline\":\"Add a web part\",\"Canvas_4_Content_1\":\"Add content to your page with web parts. Select {0} to open the web part toolbox.\",\"Canvas_5_Headline\":\"Add a web part\",\"Canvas_5_Content_1\":\"Choose a web part for the kind of content you want to add. Scroll or use the search box to explore the types of web parts. Select the expand button {0} for a larger, categorized view of web parts.\",\"Canvas_6_Headline\":\"Edit your web part\",\"Canvas_6_Content_1\":\"Select the Edit button {0} to open the web part pane if you want to change settings.\",\"Canvas_ProgressLabel\":\"{0} of {1}\"}");

/***/ }),

/***/ "V0zg":
/*!******************************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FREComponentUtility.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);


var FREComponentUtility = /** @class */ (function () {
    function FREComponentUtility() {
    }
    /**
     * Each content string containing {LinkText} will have the text wrapped in {} bracket rendered as the link text with href from PROPS
     * Example: To learn more, read {Create and use modern pages on a SharePoint site} or {Visit our help center}.
     * Result: <p>To learn more, read <Link href={links[0]}>Create and use modern pages on a SharePoint site</Link> or <Link href={this.props.links[1]}>Visit our help center</Link>.<p>
     * @param contents - strings containing {} to be laid out as the content body
     * @param links - urls to replace the {} section to make anchors
     */
    FREComponentUtility.ContentWithLink = function (contents, links) {
        var _a;
        var linkIndex = 0;
        return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, (_a = contents) === null || _a === void 0 ? void 0 : _a.map(function (content, index) {
            var contentSegments = content.split(FREComponentUtility.LINK_REG);
            var linkMatchArray = content.match(FREComponentUtility.LINK_REG);
            return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", { key: index }, contentSegments.map(function (seg, segIndex) {
                if (linkMatchArray && linkMatchArray.length > segIndex && links) {
                    var linkText = linkMatchArray[segIndex].slice(1, linkMatchArray[segIndex].length - 1);
                    var href = links.length > linkIndex ? links[linkIndex++] : undefined;
                    return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
                        seg,
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Link"], { href: href, target: '_blank' }, linkText)));
                }
                else {
                    return seg;
                }
            })));
        })));
    };
    /**
     * Each content string containing <IconName> will have the tag wrapped in <> bracket rendered as IconNames
     * Example: Select the Edit button <Edit> to open the web part pane
     * Result: <p>Select the Edit button <Icon iconName='Edit'></Icon> to open the web part pane<p>
     * @param contents - strings containing <> to be laid out as the content body with Icon embedded
     * @param iconRef - iconReference string planted in the target element to show icon dynamically in callout
     */
    FREComponentUtility.ContentWithIcon = function (contents, iconRef) {
        var _a;
        return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, (_a = contents) === null || _a === void 0 ? void 0 : _a.map(function (content, index) {
            var contentSegments = content.split(FREComponentUtility.ICON_REG);
            var iconNames = content.match(FREComponentUtility.ICON_REG);
            return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", { key: index }, contentSegments.map(function (seg, segIndex) {
                var _a, _b, _c;
                if (iconNames && iconNames.length > segIndex) {
                    var iconName = iconNames[segIndex].slice(1, iconNames[segIndex].length - 1);
                    if (iconName === 'DYNAMIC') {
                        try {
                            var iconElementRef = (_a = document
                                .querySelector("[data-sp-fre-iconref=\"" + iconRef + "\"]")) === null || _a === void 0 ? void 0 : _a.getElementsByTagName('i')[0];
                            var fabricClassName = (_b = iconElementRef) === null || _b === void 0 ? void 0 : _b.getAttribute('class');
                            return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
                                seg,
                                react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Icon"], { className: (_c = fabricClassName) === null || _c === void 0 ? void 0 : _c.toString() })));
                        }
                        catch (_d) {
                            return seg;
                        }
                    }
                    else {
                        return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
                            seg,
                            react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Icon"], { iconName: iconName })));
                    }
                }
                else {
                    return seg;
                }
            })));
        })));
    };
    FREComponentUtility.LINK_REG = /\{[^{}]*\}/g;
    FREComponentUtility.ICON_REG = /\<[A-Z]*\>/gi;
    return FREComponentUtility;
}());
/* harmony default export */ __webpack_exports__["default"] = (FREComponentUtility);


/***/ }),

/***/ "XDt9":
/*!*********************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FRECallout.js ***!
  \*********************************************************/
/*! exports provided: FRECallout, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FRECallout", function() { return FRECallout; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var office_ui_fabric_react_lib_components_Dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/Dialog */ "/C2V");
/* harmony import */ var _FREComponentUtility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FREComponentUtility */ "V0zg");
/* harmony import */ var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../loc/Components.resx */ "oeX7");
var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../loc/Components.resx */ "oeX7", 1);






var FRECallout = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(FRECallout, _super);
    function FRECallout(props) {
        var _this = _super.call(this, props) || this;
        _this._getStyles = function (theme, isRTL) {
            return Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["mergeStyleSets"])({
                callout: {
                    maxWidth: 300
                },
                header: [
                    theme.fonts.xLarge,
                    {
                        flex: '1 1 auto',
                        color: theme.palette.neutralPrimary,
                        display: 'flex',
                        fontWeight: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["FontWeights"].semibold,
                        padding: !isRTL ? '12px 12px 14px 24px' : '12px 24px 14px 12px'
                    }
                ],
                inner: {
                    height: '100%',
                    padding: '0 24px 20px',
                    selectors: {
                        p: { margin: 0 }
                    }
                },
                linkPrimary: [
                    theme.fonts.medium,
                    {
                        color: theme.palette.themePrimary
                    }
                ],
                linkSecondary: [
                    theme.fonts.medium,
                    {
                        color: theme.palette.neutralPrimary
                    }
                ],
                actions: {
                    position: 'relative',
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginTop: 20,
                    width: '100%',
                    borderTop: "1px solid " + theme.palette.themeLight
                }
            });
        };
        _this._hideCallout = function () {
            _this.setState({ hidden: true });
        };
        _this._showCallout = function () {
            _this.setState({ hidden: false });
        };
        _this._onKeyDownHandler = function (ev) {
            if (ev.key === 'Escape') {
                _this._hideCallout();
            }
        };
        _this._toggleHideDialog = function () {
            _this.setState({
                dialogHidden: !_this.state.dialogHidden
            });
        };
        _this.state = {
            hidden: false,
            dialogHidden: true
        };
        return _this;
    }
    FRECallout.prototype.componentDidMount = function () {
        this.props.calloutProps.target.addEventListener('click', this._showCallout);
        document.addEventListener('keydown', this._onKeyDownHandler);
    };
    FRECallout.prototype.componentWillUnmount = function () {
        this.props.calloutProps.target.removeEventListener('click', this._showCallout);
        document.removeEventListener('keydown', this._onKeyDownHandler);
    };
    FRECallout.prototype.render = function () {
        var _a, _b;
        var theme = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getTheme"])();
        var isRTL = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getRTL"])();
        var styles = this._getStyles(theme, isRTL);
        var primaryButton = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Label"], { className: styles.linkPrimary }, this.props.primaryButtonLabel));
        var secondaryButton = ( // End tour
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Link"], { className: styles.linkSecondary, onClick: this._toggleHideDialog }, this.props.secondaryButtonLabel || _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["SecondaryButtonTextDefault"]));
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Callout"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ className: styles.callout, gapSpace: 4, isBeakVisible: true, beakWidth: 8, calloutWidth: 300, setInitialFocus: false, doNotLayer: this.props.doNotLayer, hidden: this.state.hidden, onDismiss: this._hideCallout }, this.props.calloutProps),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: styles.header },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, this.props.headline),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["IconButton"], { styles: {
                            root: {
                                color: theme.palette.neutralPrimary,
                                marginLeft: !isRTL ? 'auto' : '2px',
                                marginRight: !isRTL ? '2px' : 'auto'
                            },
                            rootHovered: {
                                color: theme.palette.neutralDark
                            }
                        }, iconProps: { iconName: 'ChromeMinimize' }, ariaLabel: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["CloseButtonText"], onClick: this._hideCallout })),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: styles.inner },
                    _FREComponentUtility__WEBPACK_IMPORTED_MODULE_4__["default"].ContentWithIcon(this.props.content, this.props.iconRef),
                    this.props.tips && react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("i", null, this.props.tips),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: styles.actions },
                        primaryButton,
                        secondaryButton))),
            this.props.finalDialogProps && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_components_Dialog__WEBPACK_IMPORTED_MODULE_3__["Dialog"], { hidden: this.state.dialogHidden, onDismiss: this._toggleHideDialog, dialogContentProps: {
                    type: office_ui_fabric_react_lib_components_Dialog__WEBPACK_IMPORTED_MODULE_3__["DialogType"].close,
                    title: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["FinalDialogTitle"],
                    closeButtonAriaLabel: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["CloseButtonText"]
                } },
                _FREComponentUtility__WEBPACK_IMPORTED_MODULE_4__["default"].ContentWithLink((_a = this.props.finalDialogProps) === null || _a === void 0 ? void 0 : _a.content, (_b = this.props.finalDialogProps) === null || _b === void 0 ? void 0 : _b.links),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_components_Dialog__WEBPACK_IMPORTED_MODULE_3__["DialogFooter"], null,
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["PrimaryButton"], { onClick: this.props.onSecondaryButtonClicked, text: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["SecondaryButtonTextDefault"] }),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["DefaultButton"], { onClick: this._toggleHideDialog, text: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_5__["FinalDialogCancel"] }))))));
    };
    return FRECallout;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

/* harmony default export */ __webpack_exports__["default"] = (FRECallout);


/***/ }),

/***/ "aNW4":
/*!*********************************************!*\
  !*** ./lib/FirstRunExperience/FREImages.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var FREImages = /** @class */ (function () {
    function FREImages() {
    }
    FREImages.sprout = {
        src: __webpack_require__(/*! @ms/odsp-media/dist/media/images/firstrunexperience/Sprout.svg */ "KcOF"),
        width: 38,
        height: 61
    };
    FREImages.tree = {
        src: __webpack_require__(/*! @ms/odsp-media/dist/media/images/firstrunexperience/Tree.svg */ "z7PP"),
        width: 134,
        height: 66
    };
    FREImages.modal0 = __webpack_require__(/*! @ms/odsp-media/dist/media/images/sitePages/authoringFirstRun/modal-0.png */ "6VY4");
    FREImages.modal1 = __webpack_require__(/*! @ms/odsp-media/dist/media/images/sitePages/authoringFirstRun/modal-1.png */ "n0OV");
    FREImages.modal2 = __webpack_require__(/*! @ms/odsp-media/dist/media/images/sitePages/authoringFirstRun/modal-2.png */ "XrD0");
    FREImages.modal3 = __webpack_require__(/*! @ms/odsp-media/dist/media/images/sitePages/authoringFirstRun/modal-3.svg */ "j0oQ");
    return FREImages;
}());
/* harmony default export */ __webpack_exports__["default"] = (FREImages);


/***/ }),

/***/ "hAKU":
/*!**********************************************!*\
  !*** ./lib/FirstRunExperience/FREDataMap.js ***!
  \**********************************************/
/*! exports provided: FRE_USER_DISPLAYNAME, FRE_FINAL_DIALOG, FRE_DATAMAP */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FRE_USER_DISPLAYNAME", function() { return FRE_USER_DISPLAYNAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FRE_FINAL_DIALOG", function() { return FRE_FINAL_DIALOG; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FRE_DATAMAP", function() { return FRE_DATAMAP; });
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./loc/TitleRegionData.resx */ "huqC");
var _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./loc/TitleRegionData.resx */ "huqC", 1);
/* harmony import */ var _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./loc/CanvasData.resx */ "LJQr");
var _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./loc/CanvasData.resx */ "LJQr", 1);
/* harmony import */ var _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./loc/ModalData.resx */ "l6aI");
var _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./loc/ModalData.resx */ "l6aI", 1);
/* harmony import */ var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./loc/Components.resx */ "oeX7");
var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_4___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./loc/Components.resx */ "oeX7", 1);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _FREImages__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./FREImages */ "aNW4");







var TITLEREGION_TOTAL = 5;
var CANVAS_TOTAL = 6;
var INTRO_CHOICE_IMG_WIDTH = Math.max(_FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].sprout.width, _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].tree.width);
var INTRO_CHOICE_IMG_HEIGHT = Math.max(_FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].sprout.height, _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].tree.height);
var FRE_USER_DISPLAYNAME = undefined;
var FRE_FINAL_DIALOG = {
    headline: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_4__["FinalDialogTitle"],
    content: [
        _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_Components_resx__WEBPACK_IMPORTED_MODULE_4__["Final_Dialog_Content_1"], "{" + _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Link_0"] + "}", "{" + _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Link_1"] + "}")
    ],
    links: [
        'https://go.microsoft.com/fwlink/?linkid=2109333',
        'https://go.microsoft.com/fwlink/?linkid=2143678'
    ]
};
var FRE_DATAMAP = new Map([
    [
        'sp-fre-modal-intro',
        {
            isModal: true,
            /* VSO#945201 - PageContext user dynamic displayName FRE modals */
            headline: !FRE_USER_DISPLAYNAME
                ? _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Headline_Default"]
                : _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Headline"], FRE_USER_DISPLAYNAME),
            choices: [
                {
                    key: 'onPrimaryButtonClicked',
                    imageSrc: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].sprout.src,
                    selectedImageSrc: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].sprout.src,
                    imageSize: { width: INTRO_CHOICE_IMG_WIDTH, height: INTRO_CHOICE_IMG_HEIGHT },
                    title: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Text_1"],
                    text: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Subtext_1"],
                    id: 'AuthoringFRE.OptIn'
                },
                {
                    key: 'onSecondaryButtonClicked',
                    imageSrc: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].tree.src,
                    selectedImageSrc: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].tree.src,
                    imageSize: { width: INTRO_CHOICE_IMG_WIDTH, height: INTRO_CHOICE_IMG_HEIGHT },
                    title: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Text_2"],
                    text: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Subtext_2"],
                    id: 'AuthoringFRE.OptOut'
                }
            ],
            primaryButtonLabel: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_Intro_Primary"]
        }
    ],
    [
        'sp-fre-modal-0',
        {
            isModal: true,
            headline: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Headline"],
            subHeadline: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Content_1"],
            content: [
                _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Content_2"],
                _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Content_3"],
                _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Content_4"]
            ],
            primaryButtonLabel: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_0_Primary"],
            imageUrl: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].modal0
        }
    ],
    [
        'sp-fre-titleregion-1',
        {
            headline: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_1_Headline"],
            content: [_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_1_Content_1"]],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_ProgressLabel"], 1, TITLEREGION_TOTAL),
            directionalHint: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].rightCenter,
            directionalHintForRTL: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].leftCenter
        }
    ],
    [
        'sp-fre-titleregion-2',
        {
            headline: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_2_Headline"],
            content: [_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_2_Content_1"]],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_ProgressLabel"], 2, TITLEREGION_TOTAL),
            directionalHint: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].rightCenter,
            directionalHintForRTL: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].leftCenter
        }
    ],
    [
        'sp-fre-titleregion-3',
        {
            headline: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_3_Headline"],
            content: [_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_3_Content_1"]],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_ProgressLabel"], 3, TITLEREGION_TOTAL)
        }
    ],
    [
        'sp-fre-titleregion-4',
        {
            headline: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_4_Headline"],
            content: [_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_4_Content_1"]],
            tips: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_4_Content_2"],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_ProgressLabel"], 4, TITLEREGION_TOTAL),
            doNotLayer: true
        }
    ],
    [
        'sp-fre-titleregion-5',
        {
            headline: _loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_5_Headline"],
            content: [_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_5_Content_1"]],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_TitleRegionData_resx__WEBPACK_IMPORTED_MODULE_1__["TitleRegion_ProgressLabel"], 5, TITLEREGION_TOTAL)
        }
    ],
    [
        'sp-fre-modal-1',
        {
            isModal: true,
            headline: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Headline"],
            contentAbove: [_loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Content_Above_1"], _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Content_Above_2"]],
            subHeadline: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Content_1"],
            content: [_loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Content_2"], _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Content_3"]],
            secondaryButtonLabel: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Secondary"],
            primaryButtonLabel: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_1_Primary"],
            imageUrl: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].modal1
        }
    ],
    [
        'sp-fre-canvas-1',
        {
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_1_Headline"],
            content: [_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_1_Content_1"], '<Add>')],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 1, CANVAS_TOTAL)
        }
    ],
    [
        'sp-fre-canvas-2',
        {
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_2_Headline"],
            content: [_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_2_Content_1"], '<DYNAMIC>')],
            iconRef: 'sp-fre-canvas-2',
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 2, CANVAS_TOTAL)
        }
    ],
    [
        'sp-fre-canvas-3',
        {
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_3_Headline"],
            content: [
                _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_3_Content_1"], '<Cancel>', Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["getRTL"])() ? _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_3_Content_1_left"] : _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_3_Content_1_right"])
            ],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 3, CANVAS_TOTAL),
            directionalHint: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].leftCenter,
            directionalHintForRTL: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].rightCenter
        }
    ],
    [
        'sp-fre-canvas-4',
        {
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_4_Headline"],
            content: [_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_4_Content_1"], '<CirclePlus>')],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 4, CANVAS_TOTAL)
        }
    ],
    [
        'sp-fre-canvas-5',
        {
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_5_Headline"],
            content: [_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_5_Content_1"], '<FullScreen>')],
            primaryButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 5, CANVAS_TOTAL),
            doNotLayer: true
        }
    ],
    [
        'sp-fre-canvas-6',
        {
            isOptional: true,
            headline: _loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_6_Headline"],
            content: [_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_6_Content_1"], '<FullWidthEdit>')],
            secondaryprimaryButtonLabelButtonLabel: _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_CanvasData_resx__WEBPACK_IMPORTED_MODULE_2__["Canvas_ProgressLabel"], 6, CANVAS_TOTAL)
        }
    ],
    [
        'sp-fre-modal-2',
        {
            isModal: true,
            headline: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Headline"],
            content: [
                _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Content_1"],
                _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Content_2"], "{" + _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Link_Publish"] + "}"),
                _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_0__["Text"].format(_loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Content_3"], "{" + _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Link_0"] + "}", "{" + _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Link_1"] + "}")
            ],
            primaryButtonLabel: _loc_ModalData_resx__WEBPACK_IMPORTED_MODULE_3__["Modal_2_Primary"],
            imageUrl: _FREImages__WEBPACK_IMPORTED_MODULE_6__["default"].modal2,
            links: [
                'https://go.microsoft.com/fwlink/?linkid=2146636',
                'https://go.microsoft.com/fwlink/?linkid=2109333',
                'https://go.microsoft.com/fwlink/?linkid=2143678'
            ]
        }
    ]
]);


/***/ }),

/***/ "huqC":
/*!*********************************************************!*\
  !*** ./lib/FirstRunExperience/loc/TitleRegionData.resx ***!
  \*********************************************************/
/*! exports provided: TitleRegion_1_Headline, TitleRegion_1_Content_1, TitleRegion_2_Headline, TitleRegion_2_Content_1, TitleRegion_3_Headline, TitleRegion_3_Content_1, TitleRegion_4_Headline, TitleRegion_4_Content_1, TitleRegion_4_Content_2, TitleRegion_5_Headline, TitleRegion_5_Content_1, TitleRegion_ProgressLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"TitleRegion_1_Headline\":\"Choose your template\",\"TitleRegion_1_Content_1\":\"Start with a blank template or with one that\\u0027s already laid out with text and images. Select the template you like and then double-click it or select the Create page button below.\",\"TitleRegion_2_Headline\":\"Add a name\",\"TitleRegion_2_Content_1\":\"This is the title area where you add a name. Both pages and news posts need to have a name before they can be saved or published. A descriptive name can make the page easier to find in search.\",\"TitleRegion_3_Headline\":\"Change your title image\",\"TitleRegion_3_Content_1\":\"Add or change the title image. An image adds visual interest and engages your readers.\",\"TitleRegion_4_Headline\":\"Select an image\",\"TitleRegion_4_Content_1\":\"Select a location to get your image from, select an image, and then select Insert.\",\"TitleRegion_4_Content_2\":\"Tip: Stock images provided by Microsoft are the right size and resolution to always look great.\",\"TitleRegion_5_Headline\":\"Adjust the focal point\",\"TitleRegion_5_Content_1\":\"The focal point is the part of the image you want to focus on. Drag the focal point icon to move the image within the title area.\",\"TitleRegion_ProgressLabel\":\"{0} of {1}\"}");

/***/ }),

/***/ "l6aI":
/*!***************************************************!*\
  !*** ./lib/FirstRunExperience/loc/ModalData.resx ***!
  \***************************************************/
/*! exports provided: Modal_Intro_Headline, Modal_Intro_Headline_Default, Modal_Intro_Text_1, Modal_Intro_Subtext_1, Modal_Intro_Text_2, Modal_Intro_Subtext_2, Modal_Intro_Primary, Modal_0_Headline, Modal_0_Content_1, Modal_0_Content_2, Modal_0_Content_3, Modal_0_Content_4, Modal_0_Primary, Modal_1_Headline, Modal_1_Content_Above_1, Modal_1_Content_Above_2, Modal_1_Content_1, Modal_1_Content_2, Modal_1_Content_3, Modal_1_Secondary, Modal_1_Primary, Modal_2_Headline, Modal_2_Content_1, Modal_2_Content_2, Modal_2_Content_3, Modal_2_Primary, Modal_2_Link_Publish, Modal_2_Link_0, Modal_2_Link_1, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"Modal_Intro_Headline\":\"Welcome, {0}!\",\"Modal_Intro_Headline_Default\":\"Welcome!\",\"Modal_Intro_Text_1\":\"I\\u0027m new at this\",\"Modal_Intro_Subtext_1\":\"If you\\u0027re creating a page or a news post for the first time, you\\u0027ll learn the basics in this interactive tour\",\"Modal_Intro_Text_2\":\"I\\u0027ve done this before\",\"Modal_Intro_Subtext_2\":\"Skip the tour and go straight to creating your page or news post\",\"Modal_Intro_Primary\":\"Let\\u0027s go\",\"Modal_0_Headline\":\"Let\\u0027s get started!\",\"Modal_0_Content_1\":\"Here\\u0027s what we\\u0027ll do in this part of the tour:\",\"Modal_0_Content_2\":\"Choose a template\",\"Modal_0_Content_3\":\"Add a name\",\"Modal_0_Content_4\":\"Select an image for the title area\",\"Modal_0_Primary\":\"Let\\u0027s go\",\"Modal_1_Headline\":\"Success!\",\"Modal_1_Content_Above_1\":\"You\\u0027ve finished the first section of this tour!\",\"Modal_1_Content_Above_2\":\"You chose a template, named your page, and added a title image. Let\\u0027s keep going and learn more.\",\"Modal_1_Content_1\":\"In the next section of the tour, you will learn how to\",\"Modal_1_Content_2\":\"Change the layout by adding sections\",\"Modal_1_Content_3\":\"Add content using web parts\",\"Modal_1_Secondary\":\"End tour\",\"Modal_1_Primary\":\"Continue\",\"Modal_2_Headline\":\"You\\u0027ve finished the tour! What\\u0027s next?\",\"Modal_2_Content_1\":\"You can continue editing this page or news post until it\\u0027s just the way you want it. Or save it as a draft and continue editing later.\",\"Modal_2_Content_2\":\"When you are ready {0} to make it visible to everyone who can access your site.\",\"Modal_2_Content_3\":\"To learn more, read {0} or {1}.\",\"Modal_2_Primary\":\"Finish the tour\",\"Modal_2_Link_Publish\":\"you can publish the page\",\"Modal_2_Link_0\":\"Create and use modern pages on a SharePoint site\",\"Modal_2_Link_1\":\"Visit our help center\"}");

/***/ }),

/***/ "lJtf":
/*!*******************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FREModal.js ***!
  \*******************************************************/
/*! exports provided: FREModal, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FREModal", function() { return FREModal; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var office_ui_fabric_react_lib_ChoiceGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/ChoiceGroup */ "HVOw");
/* harmony import */ var office_ui_fabric_react_lib_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Modal */ "Vr3T");
/* harmony import */ var _FREComponentUtility__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./FREComponentUtility */ "V0zg");
/* harmony import */ var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../loc/Components.resx */ "oeX7");
var _loc_Components_resx__WEBPACK_IMPORTED_MODULE_7___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../loc/Components.resx */ "oeX7", 1);








var FREModal = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(FREModal, _super);
    function FREModal(props) {
        var _this = _super.call(this, props) || this;
        _this._choiceGroupKey = 'onPrimaryButtonClicked';
        _this._getStyles = function () {
            var theme = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getTheme"])();
            var isRTL = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getRTL"])();
            return Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["mergeStyleSets"])({
                container: {
                    display: 'flex',
                    flexFlow: 'column nowrap',
                    alignItems: 'stretch'
                },
                header: [
                    theme.fonts.xLarge,
                    {
                        flex: '1 1 auto',
                        borderTop: "4px solid " + theme.palette.themePrimary,
                        color: theme.palette.neutralPrimary,
                        display: 'flex',
                        fontWeight: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["FontWeights"].semibold,
                        padding: !isRTL ? '24px 12px 24px 24px' : '24px 24px 24px 12px',
                        selectors: {
                            'span:only-child': { margin: 'auto' }
                        }
                    }
                ],
                body: {
                    flex: '4 4 auto',
                    padding: '0 24px',
                    overflowY: 'hidden',
                    maxWidth: '540px',
                    minHeight: '420px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    selectors: {
                        img: {
                            maxWidth: '100%',
                            maxHeight: '240px'
                        },
                        p: { margin: '14px 0' },
                        'p:first-child': { marginTop: 0 },
                        'p:last-child': { marginBottom: 0 }
                    }
                },
                inner: {
                    height: '100%',
                    padding: '0 24px 20px',
                    color: theme.palette.neutralSecondary
                },
                subHeadline: {
                    textAlign: 'center'
                },
                illustration: {
                    textAlign: 'center'
                },
                link: [
                    theme.fonts.medium,
                    {
                        color: theme.palette.neutralPrimary,
                        selectors: {
                            ':only-child': { margin: 'auto' }
                        }
                    }
                ],
                actions: {
                    position: 'relative',
                    display: 'flex',
                    justifyContent: 'center',
                    margin: '20px 0',
                    width: '100%',
                    selectors: {
                        button: { margin: '0 18px' }
                    }
                },
                choiceTitle: [
                    theme.fonts.medium,
                    {
                        padding: '10px'
                    }
                ],
                choiceText: [
                    theme.fonts.small,
                    {
                        padding: '10px'
                    }
                ]
            });
        };
        _this._onKeyDownHandler = function (ev) {
            if (ev.key === 'Escape') {
                if (_this.props.modalProps.onDismissed) {
                    _this.props.modalProps.onDismissed();
                }
            }
        };
        _this._onPrimaryButtonClick = function () {
            if (_this.props.choices) {
                _this.props[_this._choiceGroupKey]();
                for (var i = 0; i < _this.props.choices.length; i++) {
                    if (_this.props.choices[i].key === _this._choiceGroupKey) {
                        _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_3__["_EngagementLogger"].logEvent("FirstRunExp." + _this.props.choices[i].id);
                    }
                }
            }
            else if (_this.props.onPrimaryButtonClicked) {
                _this.props.onPrimaryButtonClicked();
            }
        };
        _this._onChoiceGroupChanged = function (ev, options) {
            _this._choiceGroupKey = options.key;
        };
        _this.state = {
            isModalOpen: true
        };
        return _this;
    }
    FREModal.prototype.componentDidMount = function () {
        document.addEventListener('keydown', this._onKeyDownHandler);
    };
    FREModal.prototype.componentWillUnmount = function () {
        document.removeEventListener('keydown', this._onKeyDownHandler);
    };
    FREModal.prototype.render = function () {
        var _a;
        var theme = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getTheme"])();
        var isRTL = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getRTL"])();
        var contentStyles = this._getStyles();
        var secondaryButton = this.props.secondaryButtonLabel ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["DefaultButton"], { onClick: this.props.onSecondaryButtonClicked }, this.props.secondaryButtonLabel)) : undefined;
        var primaryButton = this.props.primaryButtonLabel ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["PrimaryButton"], { onClick: this._onPrimaryButtonClick }, this.props.primaryButtonLabel)) : undefined;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Modal__WEBPACK_IMPORTED_MODULE_5__["Modal"], { isOpen: true, isBlocking: false, containerClassName: contentStyles.container, onDismissed: this.props.modalProps.onDismissed },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: contentStyles.header },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, this.props.headline),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["IconButton"], { styles: {
                        root: {
                            color: theme.palette.neutralPrimary,
                            marginLeft: !isRTL ? 'auto' : '2px',
                            marginRight: !isRTL ? '2px' : 'auto'
                        },
                        rootHovered: {
                            color: theme.palette.neutralDark
                        }
                    }, iconProps: { iconName: 'Cancel' }, ariaLabel: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_7__["CloseButtonText"], onClick: this.props.modalProps.onDismissed })),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: contentStyles.body },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: contentStyles.inner },
                    this.props.subHeadlineAbove && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: contentStyles.subHeadline },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("b", null, this.props.subHeadlineAbove))),
                    _FREComponentUtility__WEBPACK_IMPORTED_MODULE_6__["default"].ContentWithLink(this.props.contentAbove, this.props.links),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: contentStyles.illustration }, this.props.imageUrl && react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("img", { src: this.props.imageUrl, alt: _loc_Components_resx__WEBPACK_IMPORTED_MODULE_7__["MainImageAlt"] })),
                    this.props.subHeadline && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: contentStyles.subHeadline },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("b", null, this.props.subHeadline))),
                    _FREComponentUtility__WEBPACK_IMPORTED_MODULE_6__["default"].ContentWithLink(this.props.content, this.props.links),
                    this.props.choices && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ChoiceGroup__WEBPACK_IMPORTED_MODULE_4__["ChoiceGroup"], { defaultSelectedKey: 'onPrimaryButtonClicked', options: (_a = this.props.choices) === null || _a === void 0 ? void 0 : _a.map(function (choice, index) {
                            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ onRenderLabel: function (props, render) {
                                    var _a, _b;
                                    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
                                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: contentStyles.choiceTitle },
                                            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("b", null, (_a = props) === null || _a === void 0 ? void 0 : _a.title)),
                                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: contentStyles.choiceText }, (_b = props) === null || _b === void 0 ? void 0 : _b.text)));
                                }, styles: {
                                    choiceFieldWrapper: {
                                        width: '240px',
                                        backgroundColor: theme.palette.white,
                                        selectors: {
                                            'label:before': {
                                                display: 'none'
                                            },
                                            'label:after': {
                                                display: 'none'
                                            }
                                        }
                                    },
                                    labelWrapper: {
                                        height: 'auto',
                                        maxWidth: '240px',
                                        minHeight: '96px',
                                        margin: '24px'
                                    }
                                } }, choice);
                        }), onChange: this._onChoiceGroupChanged })))),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: contentStyles.actions }, !this.props.swapButtonPositions ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
                secondaryButton,
                primaryButton)) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
                primaryButton,
                secondaryButton)))));
    };
    return FREModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

/* harmony default export */ __webpack_exports__["default"] = (FREModal);


/***/ }),

/***/ "oeX7":
/*!****************************************************!*\
  !*** ./lib/FirstRunExperience/loc/Components.resx ***!
  \****************************************************/
/*! exports provided: CloseButtonText, MoveText, MainImageAlt, SecondaryButtonTextDefault, FinalDialogTitle, FinalDialogCancel, Final_Dialog_Content_1, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"CloseButtonText\":\"Close\",\"MoveText\":\"Close\",\"MainImageAlt\":\"Main image\",\"SecondaryButtonTextDefault\":\"End tour\",\"FinalDialogTitle\":\"End the tour?\",\"FinalDialogCancel\":\"Go back to tour\",\"Final_Dialog_Content_1\":\"Learn more about creating and publishing pages by reading {0} or {1}.\"}");

/***/ }),

/***/ "qGq9":
/*!********************************************!*\
  !*** ./lib/FirstRunExperience/FRETimer.js ***!
  \********************************************/
/*! exports provided: default, firstRunReactivated, allowAdvancedDismissActivated, isFirstRunExperimentKSActivated */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "firstRunReactivated", function() { return firstRunReactivated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allowAdvancedDismissActivated", function() { return allowAdvancedDismissActivated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFirstRunExperimentKSActivated", function() { return isFirstRunExperimentKSActivated; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _FREDataMap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./FREDataMap */ "hAKU");
/* harmony import */ var _Components_FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Components/FREDataIcon.module.scss */ "wAbL");
/* harmony import */ var _Components_FREModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Components/FREModal */ "lJtf");
/* harmony import */ var _Components_FRECallout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Components/FRECallout */ "XDt9");
/* harmony import */ var _Components_FREDataIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Components/FREDataIcon */ "r8mQ");
/* harmony import */ var _FRECacheManager_FRECacheManager__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../FRECacheManager/FRECacheManager */ "vMcr");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Constants */ "OHGd");

/**
 * @copyright Microsoft Corporation. All rights reserved.
 */












var FRETimer = /** @class */ (function () {
    function FRETimer() {
        var _this = this;
        this._dismissFRECallout = function (e) {
            var dataTag = e.detail.dataTag;
            if (dataTag) {
                if (!allowAdvancedDismissActivated()) {
                    _this._ignoredIdSet.add(dataTag);
                }
                if (dataTag === _this._currentDataTag) {
                    _this._progressDataTag();
                }
            }
            else {
                FRETimer.endFRETimer();
            }
        };
        this._removeCurrentTarget = function () {
            var _a, _b;
            if (_this._currentTarget) {
                // remove the data icon
                var iconPlaceHolder = _this._currentTarget.parentElement;
                if (iconPlaceHolder && react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"](iconPlaceHolder)) {
                    var iconPlaceHolderParent = iconPlaceHolder.parentNode;
                    react_dom__WEBPACK_IMPORTED_MODULE_2__["unmountComponentAtNode"](iconPlaceHolder);
                    (_a = iconPlaceHolderParent) === null || _a === void 0 ? void 0 : _a.removeChild(iconPlaceHolder);
                    _this._currentTarget = undefined;
                }
            }
            if (_this._hostElement && react_dom__WEBPACK_IMPORTED_MODULE_2__["findDOMNode"](_this._hostElement)) {
                // remove the callout or modal dialog
                react_dom__WEBPACK_IMPORTED_MODULE_2__["unmountComponentAtNode"](_this._hostElement);
                (_b = _this._hostElement.parentElement) === null || _b === void 0 ? void 0 : _b.removeChild(_this._hostElement);
            }
        };
        this._progressDataTag = function () {
            _this._removeCurrentTarget();
            var nextDataTag;
            if (!allowAdvancedDismissActivated()) {
                do {
                    nextDataTag = FRETimer.instance._dataTags.next();
                    _this._currentDataTag = nextDataTag.value;
                } while (!nextDataTag.done && _this._ignoredIdSet.has(_this._currentDataTag));
            }
            else {
                nextDataTag = FRETimer.instance._dataTags.next();
                _this._currentDataTag = nextDataTag.value;
            }
            if (!nextDataTag.done) {
                FRETimer.instance._isActive = false;
            }
            else {
                FRETimer.endFRETimer();
                _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_EngagementLogger"].logEvent("FirstRunExp.ExperienceCompleted." + _this._currentDataTag);
            }
        };
        this._scanForNextTarget = function () {
            var _a;
            _this._hydrateDataIcons();
            var dataProps = _this._dataMap.get(_this._currentDataTag);
            var target = _this._calloutTargets.get(_this._currentDataTag);
            if (!dataProps || (!target && dataProps.isOptional)) {
                _this._progressDataTag();
                return;
            }
            if (dataProps && !_this._isActive) {
                if ((_a = dataProps) === null || _a === void 0 ? void 0 : _a.isModal) {
                    _this._surface = react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Components_FREModal__WEBPACK_IMPORTED_MODULE_8__["default"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ modalProps: {
                            onDismissed: _this._progressDataTag
                        }, onPrimaryButtonClicked: _this._progressDataTag, onSecondaryButtonClicked: FRETimer.endFRETimer }, dataProps));
                    react_dom__WEBPACK_IMPORTED_MODULE_2__["render"](_this._surface, _this.hostElement);
                    _this._isActive = true;
                }
                else if (target && target.getClientRects().length > 0) {
                    _this._currentTarget = target;
                    target.classList.add(_Components_FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].isActive);
                    var freProps = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ calloutProps: {
                            target: target,
                            directionalHint: dataProps.directionalHint || _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_3__["DirectionalHint"].topLeftEdge,
                            directionalHintForRTL: dataProps.directionalHintForRTL || _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_3__["DirectionalHint"].topRightEdge,
                            preventDismissOnLostFocus: true
                            // onDismiss will only minize callout internally, real progression happens with Primary Button
                        }, onPrimaryButtonClicked: _this._progressDataTag, onSecondaryButtonClicked: FRETimer.endFRETimer, finalDialogProps: _FREDataMap__WEBPACK_IMPORTED_MODULE_6__["FRE_FINAL_DIALOG"] }, dataProps);
                    _this._surface = react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Components_FRECallout__WEBPACK_IMPORTED_MODULE_9__["default"], freProps);
                    react_dom__WEBPACK_IMPORTED_MODULE_2__["render"](_this._surface, dataProps.doNotLayer ? target.lastElementChild /* layer container */ : _this.hostElement);
                    _this._isActive = true;
                }
            }
        };
        this._calloutTargets = new Map();
        this._dataMap = _FREDataMap__WEBPACK_IMPORTED_MODULE_6__["FRE_DATAMAP"];
        this._dataTags = this._dataMap.keys();
        this._currentDataTag = this._dataTags.next().value;
        this._ignoredIdSet = new Set();
        document.addEventListener(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].DISMISS_FRE_CALLOUT_EVENT, this._dismissFRECallout.bind(this));
    }
    Object.defineProperty(FRETimer, "isFirstRunExperimentOn", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPExperiment"].getVariantAndLogExposure(90035 /* InteractiveFRE experiment */) !== 0;
        },
        enumerable: true,
        configurable: true
    });
    FRETimer.isDataTagDuplicated = function (dataTag) {
        return FRETimer.instance._calloutTargets.has(dataTag);
    };
    Object.defineProperty(FRETimer, "instance", {
        get: function () {
            if (!FRETimer._instance) {
                FRETimer._instance = new FRETimer();
            }
            return FRETimer._instance;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FRETimer.prototype, "hostElement", {
        get: function () {
            if (!this._hostElement) {
                this._hostElement = document.createElement('div');
            }
            return this._hostElement;
        },
        enumerable: true,
        configurable: true
    });
    FRETimer.prototype._hydrateDataIcons = function () {
        var _this = this;
        var iconTargets = document.querySelectorAll("[" + _Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].SP_FRE_DATA_TAG + "]");
        iconTargets.forEach(function (element) {
            var dataTag = element.getAttribute(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].SP_FRE_DATA_TAG);
            if (dataTag === _this._currentDataTag && !_this._calloutTargets.has(dataTag)) {
                var dataIcon = react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Components_FREDataIcon__WEBPACK_IMPORTED_MODULE_10__["default"], {
                    dataTag: dataTag,
                    offsetLeft: element.getAttribute(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].SP_FRE_OFFSET_LEFT) || '',
                    offsetTop: element.getAttribute(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].SP_FRE_OFFSET_TOP) || ''
                });
                react_dom__WEBPACK_IMPORTED_MODULE_2__["render"](dataIcon, element, function () { return _this._registerTarget(dataTag, element); });
            }
        });
    };
    FRETimer.prototype._registerTarget = function (dataTag, element) {
        if (element.firstElementChild) {
            this._calloutTargets.set(dataTag, element.firstElementChild);
        }
    };
    FRETimer._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_LogSource"].create('FRETimer');
    FRETimer.DEFAULT_INTERVAL = 1000;
    FRETimer._isFirstRunExperimentFPSLogged = false;
    FRETimer.startFRETimer = function (serviceScope, forceStart) {
        if (isFirstRunExperimentKSActivated() && !_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPFlight"].isEnabled(1787 /* Force First Run Experience */)) {
            return;
        }
        if (!isFirstRunExperimentKSActivated()) {
            if (!FRETimer._isFirstRunExperimentFPSLogged) {
                var flights = [];
                if (FRETimer.isFirstRunExperimentOn) {
                    flights.push('90035_1'); // Treatment
                }
                else {
                    flights.push('90035_0'); // Control
                }
                var event_1 = new CustomEvent('UpdateFlightsForOfficeFeedback', {
                    detail: {
                        flights: flights
                    }
                });
                document.dispatchEvent(event_1);
                FRETimer._isFirstRunExperimentFPSLogged = true;
            }
            if (!FRETimer.isFirstRunExperimentOn) {
                return;
            }
        }
        /* VSO#945201 - PageContext user dynamic displayName FRE modals
          serviceScope.whenFinished(() => {
            const pageContext: PageContext = serviceScope.consume(PageContext.serviceKey);
            FRE_USER_DISPLAYNAME = pageContext.displayName;
          });
        */
        _FRECacheManager_FRECacheManager__WEBPACK_IMPORTED_MODULE_11__["default"].instance.serviceScope = serviceScope;
        _FRECacheManager_FRECacheManager__WEBPACK_IMPORTED_MODULE_11__["default"].instance
            .readCacheResult()
            .then(function () {
            var dismissedVersion = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Version"].parse(_FRECacheManager_FRECacheManager__WEBPACK_IMPORTED_MODULE_11__["default"].instance.getVersion(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].FIRST_RUN_LOCALSTORAGE_KEY) || _Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].VERSION_ZERO);
            if (forceStart ||
                firstRunReactivated() ||
                !dismissedVersion.greaterThan(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["Version"].parse(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].VERSION_ZERO))) {
                if (forceStart) {
                    FRETimer.instance._freTimer = 0;
                }
                if (!FRETimer.instance._freTimer) {
                    FRETimer._instance._hydrateDataIcons();
                    _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logVerbose(FRETimer._logSource, "FRETimer " + FRETimer.instance._freTimer + " started with interval of " + FRETimer.DEFAULT_INTERVAL + ".");
                    FRETimer.instance._freTimer = setInterval(FRETimer.instance._scanForNextTarget, FRETimer.DEFAULT_INTERVAL);
                    try {
                        window.sessionStorage.setItem(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].FIRSTRUN_SESSION_KEY, String(FRETimer.instance._freTimer));
                    }
                    catch (error) {
                        _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logError(FRETimer._logSource, error, "FRETimer.sessionStorage");
                    }
                }
            }
        })
            .catch(function (error) {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logError(FRETimer._logSource, error, 'UnableToStartFRE');
        });
    };
    FRETimer.endFRETimer = function () {
        if (FRETimer.instance._freTimer) {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logVerbose(FRETimer._logSource, "FRETimer " + FRETimer.instance._freTimer + " terminated.");
            FRETimer.instance._removeCurrentTarget();
            clearInterval(FRETimer.instance._freTimer);
            _FRECacheManager_FRECacheManager__WEBPACK_IMPORTED_MODULE_11__["default"].instance.markFeatureCompletion(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].FIRST_RUN_LOCALSTORAGE_KEY, _Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].FRE_CURRENT_VERSION);
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_EngagementLogger"].logEvent("FirstRunExp.ExperienceTerminated." + FRETimer.instance._currentDataTag);
            try {
                window.sessionStorage.removeItem(_Constants__WEBPACK_IMPORTED_MODULE_12__["Constants"].FIRSTRUN_SESSION_KEY);
            }
            catch (error) {
                _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_5__["_TraceLogger"].logError(FRETimer._logSource, error, "FRETimer.sessionStorage");
            }
        }
    };
    return FRETimer;
}());
/* harmony default export */ __webpack_exports__["default"] = (FRETimer);
function firstRunReactivated() {
    return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPKillSwitch"].isActivated('8c47f5d7-8488-4f33-8109-51be5f2f37b3'
    /* 9/22/2020 , 'First Run Experience always on when activated' */
    );
}
function allowAdvancedDismissActivated() {
    return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPKillSwitch"].isActivated('081db8ab-43e1-4ec6-9100-db335d7d942a'
    /* 10/26/2020 , 'Allow dimiss of FRE components before render' */
    );
}
function isFirstRunExperimentKSActivated() {
    return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_4__["_SPKillSwitch"].isActivated('45a6aa47-384c-4bb5-95d9-33b5058662f0'
    /* '11/16/2020', 'Use FRE flight over AB Experiment' */
    );
}


/***/ }),

/***/ "r8mQ":
/*!**********************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FREDataIcon.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FREDataIcon.module.scss */ "wAbL");





var FREDataIcon = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(FREDataIcon, _super);
    function FREDataIcon(props) {
        var _this = _super.call(this, props) || this;
        _this._flightEnabled = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_3__["_SPFlight"].isEnabled(1787 /* New First Run Experience */);
        _this._isRTL = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["getRTL"])();
        return _this;
    }
    FREDataIcon.prototype.render = function () {
        if (!this._flightEnabled) {
            return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null);
        }
        var left = this.props.offsetLeft;
        var top = this.props.offsetTop;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].FREDataIcon, style: {
                left: this._isRTL ? undefined : left,
                right: this._isRTL ? left : undefined,
                top: top
            } },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_2__["Icon"], { className: _FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].dataIcon, iconName: 'Info2' }),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _FREDataIcon_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].layerContainer })));
    };
    return FREDataIcon;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));
/* harmony default export */ __webpack_exports__["default"] = (FREDataIcon);


/***/ }),

/***/ "vMcr":
/*!************************************************!*\
  !*** ./lib/FRECacheManager/FRECacheManager.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_sp_mysitecache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/sp-mysitecache */ "ZVdo");
/* harmony import */ var _ms_sp_mysitecache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_sp_mysitecache__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__);



var FRECacheManager = /** @class */ (function () {
    function FRECacheManager() {
        this._cacheEnabled = _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_1__["_SPFlight"].isEnabled(1348 /* CoachmarksWithLKG */);
    }
    Object.defineProperty(FRECacheManager, "instance", {
        get: function () {
            // Lazy initialize the singleton
            if (this._instance === undefined) {
                this._instance = new FRECacheManager();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FRECacheManager.prototype, "serviceScope", {
        get: function () {
            return this._serviceScope;
        },
        set: function (serviceScope) {
            if (!this._serviceScope) {
                this._serviceScope = serviceScope;
            }
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_TraceLogger"].logVerbose(FRECacheManager._logSource, 'ServiceScopeAlreadySetForFRE');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FRECacheManager.prototype, "mySiteCacheManager", {
        get: function () {
            if (this._mySiteCacheManager === undefined) {
                this._mySiteCacheManager = this.serviceScope.consume(_ms_sp_mysitecache__WEBPACK_IMPORTED_MODULE_0__["mySiteCacheManagerServiceKey"]);
                this._mySiteCacheManager.setCacheConfiguration({
                    folderPath: FRECacheManager.MYSITE_CACHE_PATH
                });
            }
            return this._mySiteCacheManager;
        },
        enumerable: true,
        configurable: true
    });
    FRECacheManager.prototype.readCacheResult = function () {
        var _this = this;
        if (this._cacheEnabled) {
            return this._getMySiteCachePromise
                .then(function (result) {
                var _a;
                if (result && ((_a = result) === null || _a === void 0 ? void 0 : _a.value)) {
                    _this._cacheResultMap = new Map();
                    result.value.forEach(function (value) {
                        _this.writeToLocalStorage(value.CacheKey, JSON.parse(value.CacheValue).version);
                    });
                    if (_this._readCacheQosMonitor) {
                        _this._readCacheQosMonitor.writeSuccess();
                    }
                }
            })
                .catch(function (error) {
                _this._cacheResultMap = undefined;
                if (_this._readCacheQosMonitor) {
                    _this._readCacheQosMonitor.writeUnexpectedFailure('UnableToReadCache');
                }
                _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_TraceLogger"].logError(FRECacheManager._logSource, error, 'UnableToReadCache');
            });
        }
        else {
            return Promise.resolve();
        }
    };
    FRECacheManager.prototype.markFeatureCompletion = function (storageKey, versionString) {
        this.writeToLocalStorage(storageKey, versionString);
        if (this._cacheEnabled) {
            var writeCacheQosMonitor_1 = new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_QosMonitor"]('CoachmarkUtility.WriteMySiteCache');
            this.mySiteCacheManager
                .setCachedData(storageKey, {
                version: versionString,
                lastDismissedTime: new Date().toISOString()
            }, undefined /* cacheOptions */)
                .then(function () {
                writeCacheQosMonitor_1.writeSuccess();
            })
                .catch(function (error) {
                writeCacheQosMonitor_1.writeUnexpectedFailure('UnabledToWriteCache', error);
            });
        }
    };
    FRECacheManager.prototype.writeToLocalStorage = function (key, value) {
        var _a;
        (_a = this._cacheResultMap) === null || _a === void 0 ? void 0 : _a.set(key, value);
        try {
            window.localStorage.setItem(key, value);
        }
        catch (error) {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_TraceLogger"].logError(FRECacheManager._logSource, error, 'CoachmarkUtility.localStorageSetItem');
        }
    };
    FRECacheManager.prototype.getVersion = function (key) {
        var _a;
        return ((_a = this._cacheResultMap) === null || _a === void 0 ? void 0 : _a.get(key)) || window.localStorage.getItem(key) || undefined;
    };
    Object.defineProperty(FRECacheManager.prototype, "_getMySiteCachePromise", {
        get: function () {
            if (!this.serviceScope) {
                return Promise.reject('ServiceScope not provided');
            }
            else if (this._cacheResultMap) {
                return Promise.resolve(undefined);
            }
            else {
                this._readCacheQosMonitor = new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_QosMonitor"]('CoachmarkUtility.GetMySiteCache');
                return this.mySiteCacheManager.getCachedDataByFolder(FRECacheManager.MYSITE_CACHE_PATH);
            }
        },
        enumerable: true,
        configurable: true
    });
    FRECacheManager.MYSITE_CACHE_PATH = 'FRE_Cached_Data';
    FRECacheManager._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_LogSource"].create('FRECacheManager');
    return FRECacheManager;
}());
/* harmony default export */ __webpack_exports__["default"] = (FRECacheManager);


/***/ }),

/***/ "wAbL":
/*!**********************************************************************!*\
  !*** ./lib/FirstRunExperience/Components/FREDataIcon.module.scss.js ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./FREDataIcon.module.css */ "JT+F");
var styles = {
    FREDataIcon: 'b_b_6e28872b',
    dataIcon: 'c_b_6e28872b',
    isActive: 'e_b_6e28872b',
    layerContainer: 'f_b_6e28872b'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ })

}]);
//# sourceMappingURL=chunk.sp-fretimer_[locale].js.map