import * as React from 'react';
import { useState } from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'SampleWebpartWebPartStrings';
import SampleWebpart from './components/SampleWebpart';
import { ISampleWebpartProps } from './components/ISampleWebpartProps';

import api from './api';

export interface ISampleWebpartWebPartProps {
  description: string;
}

export default class SampleWebpartWebPart extends BaseClientSideWebPart<ISampleWebpartWebPartProps> {

  public render(): void {

    const [filmes, setFilmes] = useState();

    api.get('')
      .then(function (response) {
        this.setFilmes({response})
        console.log(response);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
      
    const element: React.ReactElement<ISampleWebpartProps> = React.createElement(
      SampleWebpart,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
