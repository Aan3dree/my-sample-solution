(window["webpackJsonp_1e2cdec9_1360_4295_b73c_98d6f51866d5_0_1_0"] = window["webpackJsonp_1e2cdec9_1360_4295_b73c_98d6f51866d5_0_1_0"] || []).push([["vendors~spcx-panels"],{

/***/ "+RYZ":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-0.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-0\"",
            src: "url('" + baseUrl + "fabric-icons-0-467ee27f.woff') format('woff')"
        },
        icons: {
            'PageLink': '\uE302',
            'CommentSolid': '\uE30E',
            'ChangeEntitlements': '\uE310',
            'Installation': '\uE311',
            'WebAppBuilderModule': '\uE313',
            'WebAppBuilderFragment': '\uE314',
            'WebAppBuilderSlot': '\uE315',
            'BullseyeTargetEdit': '\uE319',
            'WebAppBuilderFragmentCreate': '\uE31B',
            'PageData': '\uE31C',
            'PageHeaderEdit': '\uE31D',
            'ProductList': '\uE31E',
            'UnpublishContent': '\uE31F',
            'DependencyAdd': '\uE344',
            'DependencyRemove': '\uE345',
            'EntitlementPolicy': '\uE346',
            'EntitlementRedemption': '\uE347',
            'SchoolDataSyncLogo': '\uE34C',
            'PinSolid12': '\uE352',
            'PinSolidOff12': '\uE353',
            'AddLink': '\uE35E',
            'SharepointAppIcon16': '\uE365',
            'DataflowsLink': '\uE366',
            'TimePicker': '\uE367',
            'UserWarning': '\uE368',
            'ComplianceAudit': '\uE369',
            'InternetSharing': '\uE704',
            'Brightness': '\uE706',
            'MapPin': '\uE707',
            'Airplane': '\uE709',
            'Tablet': '\uE70A',
            'QuickNote': '\uE70B',
            'Video': '\uE714',
            'People': '\uE716',
            'Phone': '\uE717',
            'Pin': '\uE718',
            'Shop': '\uE719',
            'Stop': '\uE71A',
            'Link': '\uE71B',
            'AllApps': '\uE71D',
            'Zoom': '\uE71E',
            'ZoomOut': '\uE71F',
            'Microphone': '\uE720',
            'Camera': '\uE722',
            'Attach': '\uE723',
            'Send': '\uE724',
            'FavoriteList': '\uE728',
            'PageSolid': '\uE729',
            'Forward': '\uE72A',
            'Back': '\uE72B',
            'Refresh': '\uE72C',
            'Lock': '\uE72E',
            'ReportHacked': '\uE730',
            'EMI': '\uE731',
            'MiniLink': '\uE732',
            'Blocked': '\uE733',
            'ReadingMode': '\uE736',
            'Favicon': '\uE737',
            'Remove': '\uE738',
            'Checkbox': '\uE739',
            'CheckboxComposite': '\uE73A',
            'CheckboxFill': '\uE73B',
            'CheckboxIndeterminate': '\uE73C',
            'CheckboxCompositeReversed': '\uE73D',
            'BackToWindow': '\uE73F',
            'FullScreen': '\uE740',
            'Print': '\uE749',
            'Up': '\uE74A',
            'Down': '\uE74B',
            'OEM': '\uE74C',
            'Save': '\uE74E',
            'ReturnKey': '\uE751',
            'Cloud': '\uE753',
            'Flashlight': '\uE754',
            'CommandPrompt': '\uE756',
            'Sad': '\uE757',
            'RealEstate': '\uE758',
            'SIPMove': '\uE759',
            'EraseTool': '\uE75C',
            'GripperTool': '\uE75E',
            'Dialpad': '\uE75F',
            'PageLeft': '\uE760',
            'PageRight': '\uE761',
            'MultiSelect': '\uE762',
            'KeyboardClassic': '\uE765',
            'Play': '\uE768',
            'Pause': '\uE769',
            'InkingTool': '\uE76D',
            'Emoji2': '\uE76E',
            'GripperBarHorizontal': '\uE76F',
            'System': '\uE770',
            'Personalize': '\uE771',
            'SearchAndApps': '\uE773',
            'Globe': '\uE774',
            'EaseOfAccess': '\uE776',
            'ContactInfo': '\uE779',
            'Unpin': '\uE77A',
            'Contact': '\uE77B',
            'Memo': '\uE77C',
            'IncomingCall': '\uE77E'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-0.js.map

/***/ }),

/***/ "+W9d":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingLinkKind.js ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: SharingLinkKind */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingLinkKind", function() { return SharingLinkKind; });
var SharingLinkKind;
(function (SharingLinkKind) {
    SharingLinkKind[SharingLinkKind["uninitialized"] = 0] = "uninitialized";
    SharingLinkKind[SharingLinkKind["direct"] = 1] = "direct";
    SharingLinkKind[SharingLinkKind["organizationView"] = 2] = "organizationView";
    SharingLinkKind[SharingLinkKind["organizationEdit"] = 3] = "organizationEdit";
    SharingLinkKind[SharingLinkKind["anonymousView"] = 4] = "anonymousView";
    SharingLinkKind[SharingLinkKind["anonymousEdit"] = 5] = "anonymousEdit";
    SharingLinkKind[SharingLinkKind["flexible"] = 6] = "flexible";
})(SharingLinkKind || (SharingLinkKind = {}));
//# sourceMappingURL=SharingLinkKind.js.map

/***/ }),

/***/ "0A++":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipList/GroupMembershipList.scss.js ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-groupMemberList-spinner{overflow:hidden}\n" }]);
//# sourceMappingURL=GroupMembershipList.scss.js.map

/***/ }),

/***/ "0Gja":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-11.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-11\"",
            src: "url('" + baseUrl + "fabric-icons-11-2a8393d6.woff') format('woff')"
        },
        icons: {
            'BoxAdditionSolid': '\uF2D4',
            'BoxMultiplySolid': '\uF2D5',
            'BoxPlaySolid': '\uF2D6',
            'BoxCheckmarkSolid': '\uF2D7',
            'CirclePauseSolid': '\uF2D8',
            'CirclePause': '\uF2D9',
            'MSNVideosSolid': '\uF2DA',
            'CircleStopSolid': '\uF2DB',
            'CircleStop': '\uF2DC',
            'NavigateBack': '\uF2DD',
            'NavigateBackMirrored': '\uF2DE',
            'NavigateForward': '\uF2DF',
            'NavigateForwardMirrored': '\uF2E0',
            'UnknownSolid': '\uF2E1',
            'UnknownMirroredSolid': '\uF2E2',
            'CircleAddition': '\uF2E3',
            'CircleAdditionSolid': '\uF2E4',
            'FilePDB': '\uF2E5',
            'FileTemplate': '\uF2E6',
            'FileSQL': '\uF2E7',
            'FileJAVA': '\uF2E8',
            'FileASPX': '\uF2E9',
            'FileCSS': '\uF2EA',
            'FileSass': '\uF2EB',
            'FileLess': '\uF2EC',
            'FileHTML': '\uF2ED',
            'JavaScriptLanguage': '\uF2EE',
            'CSharpLanguage': '\uF2EF',
            'CSharp': '\uF2F0',
            'VisualBasicLanguage': '\uF2F1',
            'VB': '\uF2F2',
            'CPlusPlusLanguage': '\uF2F3',
            'CPlusPlus': '\uF2F4',
            'FSharpLanguage': '\uF2F5',
            'FSharp': '\uF2F6',
            'TypeScriptLanguage': '\uF2F7',
            'PythonLanguage': '\uF2F8',
            'PY': '\uF2F9',
            'CoffeeScript': '\uF2FA',
            'MarkDownLanguage': '\uF2FB',
            'FullWidth': '\uF2FE',
            'FullWidthEdit': '\uF2FF',
            'Plug': '\uF300',
            'PlugSolid': '\uF301',
            'PlugConnected': '\uF302',
            'PlugDisconnected': '\uF303',
            'UnlockSolid': '\uF304',
            'Variable': '\uF305',
            'Parameter': '\uF306',
            'CommentUrgent': '\uF307',
            'Storyboard': '\uF308',
            'DiffInline': '\uF309',
            'DiffSideBySide': '\uF30A',
            'ImageDiff': '\uF30B',
            'ImagePixel': '\uF30C',
            'FileBug': '\uF30D',
            'FileCode': '\uF30E',
            'FileComment': '\uF30F',
            'BusinessHoursSign': '\uF310',
            'FileImage': '\uF311',
            'FileSymlink': '\uF312',
            'AutoFillTemplate': '\uF313',
            'WorkItem': '\uF314',
            'WorkItemBug': '\uF315',
            'LogRemove': '\uF316',
            'ColumnOptions': '\uF317',
            'Packages': '\uF318',
            'BuildIssue': '\uF319',
            'AssessmentGroup': '\uF31A',
            'VariableGroup': '\uF31B',
            'FullHistory': '\uF31C',
            'Wheelchair': '\uF31F',
            'SingleColumnEdit': '\uF321',
            'DoubleColumnEdit': '\uF322',
            'TripleColumnEdit': '\uF323',
            'ColumnLeftTwoThirdsEdit': '\uF324',
            'ColumnRightTwoThirdsEdit': '\uF325',
            'StreamLogo': '\uF329',
            'PassiveAuthentication': '\uF32A',
            'AlertSolid': '\uF331',
            'MegaphoneSolid': '\uF332',
            'TaskSolid': '\uF333',
            'ConfigurationSolid': '\uF334',
            'BugSolid': '\uF335',
            'CrownSolid': '\uF336',
            'Trophy2Solid': '\uF337',
            'QuickNoteSolid': '\uF338',
            'ConstructionConeSolid': '\uF339',
            'PageListSolid': '\uF33A',
            'PageListMirroredSolid': '\uF33B',
            'StarburstSolid': '\uF33C',
            'ReadingModeSolid': '\uF33D',
            'SadSolid': '\uF33E',
            'HealthSolid': '\uF33F',
            'ShieldSolid': '\uF340',
            'GiftBoxSolid': '\uF341',
            'ShoppingCartSolid': '\uF342',
            'MailSolid': '\uF343',
            'ChatSolid': '\uF344',
            'RibbonSolid': '\uF345'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-11.js.map

/***/ }),

/***/ "0m3a":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingLinkType.js ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: SharingLinkType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingLinkType", function() { return SharingLinkType; });
// OneDrive:IgnoreCodeCoverage
var SharingLinkType;
(function (SharingLinkType) {
    SharingLinkType[SharingLinkType["Network"] = 1] = "Network";
    SharingLinkType[SharingLinkType["Embed"] = 3] = "Embed";
    SharingLinkType[SharingLinkType["App"] = 4] = "App";
    SharingLinkType[SharingLinkType["View"] = 5] = "View";
    SharingLinkType[SharingLinkType["Edit"] = 6] = "Edit";
    SharingLinkType[SharingLinkType["Form"] = 7] = "Form";
    SharingLinkType[SharingLinkType["Direct"] = 8] = "Direct";
    SharingLinkType[SharingLinkType["Organization"] = 9] = "Organization";
    SharingLinkType[SharingLinkType["AppAccess"] = 10] = "AppAccess";
    SharingLinkType[SharingLinkType["RequestAccess"] = 11] = "RequestAccess";
})(SharingLinkType || (SharingLinkType = {}));
//# sourceMappingURL=SharingLinkType.js.map

/***/ }),

/***/ "1EGi":
/*!********************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/getFileTypeIconProps.js ***!
  \********************************************************************************************************************************************************************************************/
/*! exports provided: DEFAULT_ICON_SIZE, getFileTypeIconProps, getFileTypeIconNameFromExtensionOrType, getFileTypeIconSuffix */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_ICON_SIZE", function() { return DEFAULT_ICON_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconProps", function() { return getFileTypeIconProps; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconNameFromExtensionOrType", function() { return getFileTypeIconNameFromExtensionOrType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconSuffix", function() { return getFileTypeIconSuffix; });
/* harmony import */ var _FileTypeIconMap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FileTypeIconMap */ "ntSI");
/* harmony import */ var _FileIconType__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FileIconType */ "ALXe");


var _extensionToIconName;
var GENERIC_FILE = 'genericfile';
var FOLDER = 'folder';
var SHARED_FOLDER = 'sharedfolder';
var DOCSET_FOLDER = 'docset';
var LIST_ITEM = 'listitem';
var LIST = 'splist';
var MULTIPLE_ITEMS = 'multiple';
var NEWS = 'sponews';
var STREAM = 'stream';
var DESKTOP_FOLDER = 'desktopfolder';
var DOCUMENTS_FOLDER = 'documentfolder';
var PICTURES_FOLDER = 'picturesfolder';
var LINKED_FOLDER = 'linkedfolder';
var DEFAULT_ICON_SIZE = 16;
/**
 * This function returns properties for a file type icon given the IFileTypeIconOptions.
 * It accounts for different device pixel ratios. For example,
 * getFileTypeIconProps({extension: 'doc', size: 16, imageFileType: 'png'})
 * will return { iconName: 'docx16_2x_png' } if the devicePixelRatio is 2.
 *
 * @param options
 */
function getFileTypeIconProps(options) {
    // First, obtain the base name of the icon using the extension or type.
    var iconBaseName;
    var extension = options.extension, type = options.type, size = options.size, imageFileType = options.imageFileType;
    iconBaseName = getFileTypeIconNameFromExtensionOrType(extension, type);
    // Next, obtain the suffix using the icon size, user's device pixel ratio, and
    // preference for svg or png
    var _size = size || DEFAULT_ICON_SIZE;
    var suffix = getFileTypeIconSuffix(_size, imageFileType);
    return { iconName: iconBaseName + suffix };
}
function getFileTypeIconNameFromExtensionOrType(extension, type) {
    var iconBaseName;
    if (extension) {
        if (!_extensionToIconName) {
            _extensionToIconName = {};
            for (var iconName in _FileTypeIconMap__WEBPACK_IMPORTED_MODULE_0__["FileTypeIconMap"]) {
                if (_FileTypeIconMap__WEBPACK_IMPORTED_MODULE_0__["FileTypeIconMap"].hasOwnProperty(iconName)) {
                    var extensions = _FileTypeIconMap__WEBPACK_IMPORTED_MODULE_0__["FileTypeIconMap"][iconName].extensions;
                    if (extensions) {
                        for (var i = 0; i < extensions.length; i++) {
                            _extensionToIconName[extensions[i]] = iconName;
                        }
                    }
                }
            }
        }
        // Strip periods, force lowercase.
        extension = extension.replace('.', '').toLowerCase();
        return _extensionToIconName[extension] || GENERIC_FILE;
    }
    else if (type) {
        switch (type) {
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].docset:
                iconBaseName = DOCSET_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].folder:
                iconBaseName = FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].listItem:
                iconBaseName = LIST_ITEM;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].sharedFolder:
                iconBaseName = SHARED_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].stream:
                iconBaseName = STREAM;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].multiple:
                iconBaseName = MULTIPLE_ITEMS;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].news:
                iconBaseName = NEWS;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].desktopFolder:
                iconBaseName = DESKTOP_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].documentsFolder:
                iconBaseName = DOCUMENTS_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].picturesFolder:
                iconBaseName = PICTURES_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].linkedFolder:
                iconBaseName = LINKED_FOLDER;
                break;
            case _FileIconType__WEBPACK_IMPORTED_MODULE_1__["FileIconType"].list:
                iconBaseName = LIST;
                break;
        }
    }
    return iconBaseName || GENERIC_FILE;
}
function getFileTypeIconSuffix(size, imageFileType) {
    if (imageFileType === void 0) { imageFileType = 'svg'; }
    var devicePixelRatio = window.devicePixelRatio;
    var devicePixelRatioSuffix = ''; // Default is 1x
    // SVGs scale well, so you can generally use the default image.
    // 1.5x is a special case where SVGs need a different image.
    if (imageFileType === 'svg' && devicePixelRatio > 1 && devicePixelRatio <= 1.5) {
        // Currently missing 1.5x SVGs at size 20, snap to 1x for now
        if (size !== 20) {
            devicePixelRatioSuffix = '_1.5x';
        }
    }
    else if (imageFileType === 'png') {
        // To look good, PNGs should use a different image for higher device pixel ratios
        if (devicePixelRatio > 1 && devicePixelRatio <= 1.5) {
            // Currently missing 1.5x icons for size 20, snap to 2x for now
            devicePixelRatioSuffix = size === 20 ? '_2x' : '_1.5x';
        }
        else if (devicePixelRatio > 1.5 && devicePixelRatio <= 2) {
            devicePixelRatioSuffix = '_2x';
        }
        else if (devicePixelRatio > 2 && devicePixelRatio <= 3) {
            devicePixelRatioSuffix = '_3x';
        }
        else if (devicePixelRatio > 3) {
            devicePixelRatioSuffix = '_4x';
        }
    }
    return size + devicePixelRatioSuffix + '_' + imageFileType;
}
//# sourceMappingURL=getFileTypeIconProps.js.map

/***/ }),

/***/ "1XQB":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissionsPanel/SitePermissionsPanel.scss.js ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-SitePermPanel-Pivot{right:20px;margin:8px 0px 8px}.ms-sitePermPanel-buttonArea{max-width:150px;max-height:40px;margin-bottom:16px}.ms-SitePermPanel-PeoplePicker{margin-bottom:16px}.ms-SitePermPanel-ShareSiteEmail-message-div{margin-bottom:24px}.ms-SitePermPanelButton{margin-bottom:24px}.ms-SitePermPanel-Link{outline:transparent;position:relative;color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": ";text-decoration:none;display:inline-block}.ms-SitePermPanel-Link::-moz-focus-inner{border:0}.ms-Fabric--isFocusVisible .ms-SitePermPanel-Link:focus:after{content:'';position:absolute;top:0;right:0;bottom:0;left:0;pointer-events:none;border:1px solid " }, { "theme": "neutralSecondary", "defaultValue": "#605e5c" }, { "rawString": "}@media screen and (-ms-high-contrast: active){.ms-Fabric--isFocusVisible .ms-SitePermPanel-Link:focus:after{border-color:ActiveBorder}}.ms-SitePermPanel-Link.is-disabled{color:" }, { "theme": "neutralTertiary", "defaultValue": "#a19f9d" }, { "rawString": "}.ms-SitePermPanel-Link:hover,.ms-SitePermPanel-Link:focus{color:" }, { "theme": "themeDarker", "defaultValue": "#004578" }, { "rawString": "}.ms-SitePermPanel-Link:active{color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": "}.ms-sitePermPanel-TextArea{margin:8px 0px 16px}.ms-SitePermPanel-AdvancedPerm{margin:28px 0px 24px}.ms-SitePermPanel-HubPivotDiv{margin:8px 0px 24px}.ms-SitePermPanel-HubPivot-permissions{left:16px;position:absolute}.ms-SitePermPanel-SharePanel{margin-top:36px}.ms-SitePermPanelButton-container{padding:0px 4px}.ms-SitePermPanel{color:" }, { "theme": "black", "defaultValue": "#000000" }, { "rawString": "}.ms-SitePermPanel .ms-Panel-navigation{height:18px;display:block}.ms-SitePermPanel-ShareSiteEmail{margin-bottom:30px}.ms-SitePermPanel-ShareSiteEmail-checkbox{margin-bottom:8px}.ms-SitePermPanel-PeoplePicker-warning,.ms-SitePermPanel-PeoplePicker-error{margin-top:8px}.ms-SitePermPanel-sectionTitle{font-weight:600;padding:0 0 10px}.ms-SitePermPanel-UserExpiration{margin-bottom:24px}.ms-SitePermPanel-HubPivot-helperText{font-weight:400;margin-bottom:24px}.ms-SitePermPanel-SharingSettings{margin:12px 0px 24px}.ms-SitePermPanel-NavigationContent{margin-top:18px;display:-webkit-box;display:-ms-flexbox;display:flex;width:100%;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.ms-SitePermPanel-NavigationContent .ms-Panel-closeButton{margin-top:7px}.ms-SitePermPanel-BackIcon{color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": ";position:absolute;left:8px;margin-top:0px}.ms-SitePermPanel-Title{font-size:" }, { "theme": "xLargeFontSize", "defaultValue": "20px" }, { "rawString": ";font-weight:" }, { "theme": "xLargeFontWeight", "defaultValue": "600" }, { "rawString": ";position:absolute;left:50px;margin-top:0px}.ms-SitePermPanel-NavigationContentDismiss{display:-webkit-box;display:-ms-flexbox;display:flex;width:100%;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.ms-SitePermPanel-NavigationContentDismiss .ms-Panel-closeButton{margin-top:25px}.ms-AccessRequests-link{margin-bottom:18px}\n" }]);
//# sourceMappingURL=SitePermissionsPanel.scss.js.map

/***/ }),

/***/ "2h7V":
/*!***********************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/utilities-strings@1.0.1/node_modules/@ms/utilities-strings/lib/index.js ***!
  \***********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Loading @ms/utilities-strings/./lib/index.js
var pkg = __webpack_require__(/*! @ms/odsp-core-bundle */ "K9kD");
module.exports = pkg.StringHelper;

/***/ }),

/***/ "2mns":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequestsDialog.js ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestsDialog */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsDialog", function() { return AccessRequestsDialog; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/Dialog */ "wPGM");
/* harmony import */ var office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/Stack */ "N28N");
/* harmony import */ var _AccessRequestsDialog_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./AccessRequestsDialog.scss */ "DkMg");
/* harmony import */ var _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./AccessRequests.resx */ "AAtU");
/* harmony import */ var _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _AccessRequestsList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./AccessRequestsList */ "ek0/");
/* harmony import */ var _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ms/odsp-datasources/lib/AccessRequests */ "Vdfb");
/* harmony import */ var office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! office-ui-fabric-react/lib/Link */ "F3Wv");
/* harmony import */ var office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! office-ui-fabric-react/lib/Pivot */ "wD6F");










/**
 * @public
 * Dialog allowing users to view and act on their pending access requests for the current site.
 */
var AccessRequestsDialog = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(AccessRequestsDialog, _super);
    function AccessRequestsDialog(props) {
        var _this = _super.call(this, props) || this;
        _this.handlePivotClick = function (item) {
            if (item.props.itemKey === 'all') {
                // filter by all requests
                _this.setState({
                    currentFilter: 'all'
                });
            }
            else if (item.props.itemKey === 'internal') {
                // filter only for internal requests
                _this.setState({
                    currentFilter: 'internal'
                });
            }
            else if (item.props.itemKey === 'external') {
                // filter only for external requests
                _this.setState({
                    currentFilter: 'external'
                });
            }
        };
        _this.state = {
            currentFilter: 'all'
        };
        return _this;
    }
    AccessRequestsDialog.prototype.render = function () {
        var listPageSize = 10;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_2__["Dialog"], { hidden: !this.props.showAccessRequestDialog, onDismiss: this.props.onDismiss, containerClassName: 'ms-dialogMainOverride ms-AccessRequestsDialogContainer', dialogContentProps: {
                type: office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_2__["DialogType"].normal,
                showCloseButton: true,
                className: 'ms-AccessRequestsDialogContent',
                styles: {
                    header: {
                        className: 'ms-AccessRequestsDialogHeader'
                    },
                    inner: {
                        className: 'ms-AccessRequestsDialog-inner'
                    },
                    content: {
                        className: 'ms-AccessRequestsDialog-content'
                    }
                }
            }, modalProps: {
                isBlocking: true,
                isDarkOverlay: false
            } },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_3__["Stack"], { horizontal: true, disableShrink: true },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_3__["Stack"].Item, { order: 1 },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsDialogHeader' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsDialogTitle' }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default.a.AccessRequests))),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_3__["Stack"].Item, { order: 2 }, this.renderPivot())),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsDialogListContainer' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_AccessRequestsList__WEBPACK_IMPORTED_MODULE_6__["AccessRequestsList"], { pageSize: listPageSize, accessRequestsEnabled: true, accessRequestsProvider: new _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_7__["AccessRequestsProvider"]({
                        dataSource: new _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_7__["AccessRequestsDataSource"]({ pageContext: this.props.pageContext })
                    }), peoplePickerDataSource: this.props.peoplePickerDataSource, pageContext: this.props.pageContext, currentFilter: this.state.currentFilter })),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsDialog-Footer' }, this.renderClassicLink())));
    };
    AccessRequestsDialog.prototype.renderClassicLink = function () {
        var classicLink = this.props.pageContext.webAbsoluteUrl + '/Access%20Requests/pendingreq.aspx?mbypass=1';
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_8__["Link"], { href: classicLink, className: 'ms-AccessRequestsDialog-ClassicExperience-link', "data-automationid": 'SitePermissionsPanelAccessRequestsDialogClassicLink', target: '_blank' }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default.a.ClassicExperience));
    };
    AccessRequestsDialog.prototype.renderPivot = function () {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_9__["Pivot"], { "aria-label": 'Filtering between all, internal, and external only users', onLinkClick: this.handlePivotClick, headersOnly: true },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_9__["PivotItem"], { headerText: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default.a.All, itemKey: 'all' }),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_9__["PivotItem"], { headerText: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default.a.Internal, itemKey: 'internal' }),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_9__["PivotItem"], { headerText: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_5___default.a.External, itemKey: 'external' }))));
    };
    return AccessRequestsDialog;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=AccessRequestsDialog.js.map

/***/ }),

/***/ "2w7h":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissions/SitePermissions.scss.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-sitePerm-body{-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;position:relative;margin-left:27px;margin-bottom:16px}.ms-sitePerm-Title{font-weight:bold}.ms-sitePerm-itemBtn{height:20px;width:32px;vertical-align:middle;text-align:center;padding:10px;border-radius:50%;vertical-align:top;display:table-row;cursor:pointer}[dir='ltr'] .ms-sitePerm-itemBtn{margin-right:4px}[dir='rtl'] .ms-sitePerm-itemBtn{margin-left:4px}.ms-sitePerm-itemBtn-title{position:relative;font-size:" }, { "theme": "mediumFontSize", "defaultValue": "14px" }, { "rawString": ";font-weight:" }, { "theme": "mediumFontWeight", "defaultValue": "400" }, { "rawString": ";font-weight:600}[dir='ltr'] .ms-sitePerm-itemBtn-title{left:-12px}[dir='rtl'] .ms-sitePerm-itemBtn-title{right:-12px}.ms-sitePerm-personName{white-space:nowrap;text-overflow:ellipsis}.ms-sitePerm-personName>div{outline:transparent;position:relative;margin-top:10px;margin-bottom:10px}.ms-sitePerm-personName>div::-moz-focus-inner{border:0}.ms-Fabric--isFocusVisible .ms-sitePerm-personName>div:focus:after{content:'';position:absolute;top:0;right:0;bottom:0;left:0;pointer-events:none;border:1px solid " }, { "theme": "neutralSecondary", "defaultValue": "#605e5c" }, { "rawString": "}@media screen and (-ms-high-contrast: active){.ms-Fabric--isFocusVisible .ms-sitePerm-personName>div:focus:after{border-color:ActiveBorder}}.ms-sitePerm-PersonaContextMenu .ms-ContextualMenu.ms-FocusZone{position:relative}.ms-sitePerm-buttonArea{max-width:95px;max-height:40px;cursor:pointer;font-size:12px}.ms-sitePerm-noButtonArea{max-width:95px;max-height:40px;font-size:" }, { "theme": "smallFontSize", "defaultValue": "12px" }, { "rawString": "}.ms-sitePerm-linkText{width:100%}.ms-sitePerm-chevron{position:relative;line-height:20px;font-size:" }, { "theme": "smallFontSize", "defaultValue": "12px" }, { "rawString": ";-webkit-transition:-webkit-transform 0.1s linear;transition:-webkit-transform 0.1s linear;transition:transform 0.1s linear;transition:transform 0.1s linear, -webkit-transform 0.1s linear}[dir='ltr'] .ms-sitePerm-chevron{left:-27px}[dir='rtl'] .ms-sitePerm-chevron{right:-27px}.ms-sitePermMenu-chevron{line-height:20px;font-size:" }, { "theme": "smallFontSize", "defaultValue": "12px" }, { "rawString": ";-webkit-transition:-webkit-transform 0.1s linear;transition:-webkit-transform 0.1s linear;transition:transform 0.1s linear;transition:transform 0.1s linear, -webkit-transform 0.1s linear}[dir='ltr'] .ms-sitePermMenu-chevron{left:15px}[dir='rtl'] .ms-sitePermMenu-chevron{right:15px}[dir='ltr'] .ms-sitePermMenu-chevron.has-permLevelTitle{margin-left:8px}[dir='rtl'] .ms-sitePermMenu-chevron.has-permLevelTitle{margin-right:8px}.ms-sitePerm-chevron.is-expanded{-webkit-transform:rotate(-180deg);transform:rotate(-180deg)}.ms-sitePerm-personaContainer{margin-bottom:20px}.ms-sitePerm-emptyGroupText{color:#666666}.ms-sitePerm-Persona .sp-deferredLivePersonaCard-root{display:block}.ms-sitePerm-Persona .sp-deferredLivePersonaCard-root .ms-TooltipHost{display:block;overflow:hidden;text-overflow:ellipsis}\n" }]);
//# sourceMappingURL=SitePermissions.scss.js.map

/***/ }),

/***/ "3+om":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissionsPanel/index.js ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissionsPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SitePermissionsPanel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SitePermissionsPanel */ "pfuc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsPanel", function() { return _SitePermissionsPanel__WEBPACK_IMPORTED_MODULE_0__["SitePermissionsPanel"]; });


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "3/jV":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-5.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-5\"",
            src: "url('" + baseUrl + "fabric-icons-5-f95ba260.woff') format('woff')"
        },
        icons: {
            'Certificate': '\uEB95',
            'FastForward': '\uEB9D',
            'Rewind': '\uEB9E',
            'Photo2': '\uEB9F',
            'OpenSource': '\uEBC2',
            'Movers': '\uEBCD',
            'CloudDownload': '\uEBD3',
            'Family': '\uEBDA',
            'WindDirection': '\uEBE6',
            'Bug': '\uEBE8',
            'SiteScan': '\uEBEC',
            'BrowserScreenShot': '\uEBED',
            'F12DevTools': '\uEBEE',
            'CSS': '\uEBEF',
            'JS': '\uEBF0',
            'DeliveryTruck': '\uEBF4',
            'ReminderPerson': '\uEBF7',
            'ReminderGroup': '\uEBF8',
            'ReminderTime': '\uEBF9',
            'TabletMode': '\uEBFC',
            'Umbrella': '\uEC04',
            'NetworkTower': '\uEC05',
            'CityNext': '\uEC06',
            'CityNext2': '\uEC07',
            'Section': '\uEC0C',
            'OneNoteLogoInverse': '\uEC0D',
            'ToggleFilled': '\uEC11',
            'ToggleBorder': '\uEC12',
            'SliderThumb': '\uEC13',
            'ToggleThumb': '\uEC14',
            'Documentation': '\uEC17',
            'Badge': '\uEC1B',
            'Giftbox': '\uEC1F',
            'VisualStudioLogo': '\uEC22',
            'HomeGroup': '\uEC26',
            'ExcelLogoInverse': '\uEC28',
            'WordLogoInverse': '\uEC29',
            'PowerPointLogoInverse': '\uEC2A',
            'Cafe': '\uEC32',
            'SpeedHigh': '\uEC4A',
            'Commitments': '\uEC4D',
            'ThisPC': '\uEC4E',
            'MusicNote': '\uEC4F',
            'MicOff': '\uEC54',
            'PlaybackRate1x': '\uEC57',
            'EdgeLogo': '\uEC60',
            'CompletedSolid': '\uEC61',
            'AlbumRemove': '\uEC62',
            'MessageFill': '\uEC70',
            'TabletSelected': '\uEC74',
            'MobileSelected': '\uEC75',
            'LaptopSelected': '\uEC76',
            'TVMonitorSelected': '\uEC77',
            'DeveloperTools': '\uEC7A',
            'Shapes': '\uEC7C',
            'InsertTextBox': '\uEC7D',
            'LowerBrightness': '\uEC8A',
            'WebComponents': '\uEC8B',
            'OfflineStorage': '\uEC8C',
            'DOM': '\uEC8D',
            'CloudUpload': '\uEC8E',
            'ScrollUpDown': '\uEC8F',
            'DateTime': '\uEC92',
            'Event': '\uECA3',
            'Cake': '\uECA4',
            'Org': '\uECA6',
            'PartyLeader': '\uECA7',
            'DRM': '\uECA8',
            'CloudAdd': '\uECA9',
            'AppIconDefault': '\uECAA',
            'Photo2Add': '\uECAB',
            'Photo2Remove': '\uECAC',
            'Calories': '\uECAD',
            'POI': '\uECAF',
            'AddTo': '\uECC8',
            'RadioBtnOff': '\uECCA',
            'RadioBtnOn': '\uECCB',
            'ExploreContent': '\uECCD',
            'Product': '\uECDC',
            'ProgressLoopInner': '\uECDE',
            'ProgressLoopOuter': '\uECDF',
            'Blocked2': '\uECE4',
            'FangBody': '\uECEB',
            'Toolbox': '\uECED',
            'PageHeader': '\uECEE',
            'ChatInviteFriend': '\uECFE',
            'Brush': '\uECFF',
            'Shirt': '\uED00',
            'Crown': '\uED01',
            'Diamond': '\uED02',
            'ScaleUp': '\uED09',
            'QRCode': '\uED14',
            'Feedback': '\uED15',
            'SharepointLogoInverse': '\uED18',
            'YammerLogo': '\uED19',
            'Hide': '\uED1A',
            'Uneditable': '\uED1D',
            'ReturnToSession': '\uED24',
            'OpenFolderHorizontal': '\uED25',
            'CalendarMirrored': '\uED28'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-5.js.map

/***/ }),

/***/ "3r9+":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/initializeFileTypeIcons.js ***!
  \***********************************************************************************************************************************************************************************************/
/*! exports provided: DEFAULT_BASE_URL, ICON_SIZES, initializeFileTypeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_BASE_URL", function() { return DEFAULT_BASE_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ICON_SIZES", function() { return ICON_SIZES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeFileTypeIcons", function() { return initializeFileTypeIcons; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
/* harmony import */ var _FileTypeIconMap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FileTypeIconMap */ "ntSI");



var PNG_SUFFIX = '_png';
var SVG_SUFFIX = '_svg';
var DEFAULT_BASE_URL = 'https://spoprod-a.akamaihd.net/files/fabric-cdn-prod_20201125.001/assets/item-types/';
var ICON_SIZES = [16, 20, 24, 32, 40, 48, 64, 96];
function initializeFileTypeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = DEFAULT_BASE_URL; }
    ICON_SIZES.forEach(function (size) {
        _initializeIcons(baseUrl, size, options);
    });
}
function _initializeIcons(baseUrl, size, options) {
    var iconTypes = Object.keys(_FileTypeIconMap__WEBPACK_IMPORTED_MODULE_2__["FileTypeIconMap"]);
    var fileTypeIcons = {};
    iconTypes.forEach(function (type) {
        var baseUrlSizeType = baseUrl + size + '/' + type;
        fileTypeIcons[type + size + PNG_SUFFIX] = react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrlSizeType + '.png', alt: "" });
        fileTypeIcons[type + size + SVG_SUFFIX] = react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrlSizeType + '.svg', alt: "" });
        // For high resolution screens, register additional versions
        // Apply height=100% and width=100% to force image to fit into containing element
        // SVGs scale well, so you can generally use the default image.
        // 1.5x is a special case where both SVGs and PNGs need a different image.
        fileTypeIcons[type + size + '_1.5x' + PNG_SUFFIX] = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrl + size + '_1.5x/' + type + '.png', height: "100%", width: "100%" }));
        fileTypeIcons[type + size + '_1.5x' + SVG_SUFFIX] = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrl + size + '_1.5x/' + type + '.svg', height: "100%", width: "100%" }));
        fileTypeIcons[type + size + '_2x' + PNG_SUFFIX] = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrl + size + '_2x/' + type + '.png', height: "100%", width: "100%" }));
        fileTypeIcons[type + size + '_3x' + PNG_SUFFIX] = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrl + size + '_3x/' + type + '.png', height: "100%", width: "100%" }));
        fileTypeIcons[type + size + '_4x' + PNG_SUFFIX] = (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("img", { src: baseUrl + size + '_4x/' + type + '.png', height: "100%", width: "100%" }));
    });
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_1__["registerIcons"])({
        fontFace: {},
        style: {
            width: size,
            height: size,
            overflow: 'hidden',
        },
        icons: fileTypeIcons,
    }, options);
}
//# sourceMappingURL=initializeFileTypeIcons.js.map

/***/ }),

/***/ "5SA5":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/BaseButton.js ***!
  \***********************************************************************************************************************************************************************************************/
/*! exports provided: BaseButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BaseButton", function() { return BaseButton; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Utilities */ "mkpW");
/* harmony import */ var _uifabric_utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @uifabric/utilities */ "P2cQ");
/* harmony import */ var _uifabric_utilities__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_uifabric_utilities__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../Icon */ "56LG");
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Icon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _common_DirectionalHint__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../common/DirectionalHint */ "EE7g");
/* harmony import */ var _ContextualMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../ContextualMenu */ "u4xd");
/* harmony import */ var _BaseButton_classNames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./BaseButton.classNames */ "KCw9");
/* harmony import */ var _SplitButton_SplitButton_classNames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SplitButton/SplitButton.classNames */ "wXdL");
/* harmony import */ var _KeytipData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../KeytipData */ "iaSa");










var TouchIdleDelay = 500; /* ms */
var COMPONENT_NAME = 'BaseButton';
/**
 * {@docCategory Button}
 */
var BaseButton = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(BaseButton, _super);
    function BaseButton(props) {
        var _this = _super.call(this, props) || this;
        _this._buttonElement = react__WEBPACK_IMPORTED_MODULE_1__["createRef"]();
        _this._splitButtonContainer = react__WEBPACK_IMPORTED_MODULE_1__["createRef"]();
        _this._mergedRef = Object(_uifabric_utilities__WEBPACK_IMPORTED_MODULE_3__["createMergedRef"])();
        _this._renderedVisibleMenu = false;
        _this._getMemoizedMenuButtonKeytipProps = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["memoizeFunction"])(function (keytipProps) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, keytipProps), { hasMenu: true });
        });
        _this._onRenderIcon = function (buttonProps, defaultRender) {
            var iconProps = _this.props.iconProps;
            if (iconProps && (iconProps.iconName !== undefined || iconProps.imageProps)) {
                var className = iconProps.className, imageProps = iconProps.imageProps, rest = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"])(iconProps, ["className", "imageProps"]);
                // If the styles prop is specified as part of iconProps, fall back to regular Icon as FontIcon and ImageIcon
                // do not have this prop.
                if (iconProps.styles) {
                    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Icon__WEBPACK_IMPORTED_MODULE_4__["Icon"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ className: Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["css"])(_this._classNames.icon, className), imageProps: imageProps }, rest));
                }
                if (iconProps.iconName) {
                    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Icon__WEBPACK_IMPORTED_MODULE_4__["FontIcon"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ className: Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["css"])(_this._classNames.icon, className) }, rest));
                }
                if (imageProps) {
                    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Icon__WEBPACK_IMPORTED_MODULE_4__["ImageIcon"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ className: Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["css"])(_this._classNames.icon, className), imageProps: imageProps }, rest));
                }
            }
            return null;
        };
        _this._onRenderTextContents = function () {
            var _a = _this.props, text = _a.text, children = _a.children, 
            // eslint-disable-next-line deprecation/deprecation
            _b = _a.secondaryText, 
            // eslint-disable-next-line deprecation/deprecation
            secondaryText = _b === void 0 ? _this.props.description : _b, _c = _a.onRenderText, onRenderText = _c === void 0 ? _this._onRenderText : _c, _d = _a.onRenderDescription, onRenderDescription = _d === void 0 ? _this._onRenderDescription : _d;
            if (text || typeof children === 'string' || secondaryText) {
                return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: _this._classNames.textContainer },
                    onRenderText(_this.props, _this._onRenderText),
                    onRenderDescription(_this.props, _this._onRenderDescription)));
            }
            return [onRenderText(_this.props, _this._onRenderText), onRenderDescription(_this.props, _this._onRenderDescription)];
        };
        _this._onRenderText = function () {
            var text = _this.props.text;
            var children = _this.props.children;
            // For backwards compat, we should continue to take in the text content from children.
            if (text === undefined && typeof children === 'string') {
                text = children;
            }
            if (_this._hasText()) {
                return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { key: _this._labelId, className: _this._classNames.label, id: _this._labelId }, text));
            }
            return null;
        };
        _this._onRenderChildren = function () {
            var children = _this.props.children;
            // If children is just a string, either it or the text will be rendered via onRenderLabel
            // If children is another component, it will be rendered after text
            if (typeof children === 'string') {
                return null;
            }
            return children;
        };
        _this._onRenderDescription = function (props) {
            // eslint-disable-next-line deprecation/deprecation
            var _a = props.secondaryText, secondaryText = _a === void 0 ? _this.props.description : _a;
            // ms-Button-description is only shown when the button type is compound.
            // In other cases it will not be displayed.
            return secondaryText ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { key: _this._descriptionId, className: _this._classNames.description, id: _this._descriptionId }, secondaryText)) : null;
        };
        _this._onRenderAriaDescription = function () {
            var ariaDescription = _this.props.ariaDescription;
            // If ariaDescription is given, descriptionId will be assigned to ariaDescriptionSpan,
            // otherwise it will be assigned to descriptionSpan.
            return ariaDescription ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: _this._classNames.screenReaderText, id: _this._ariaDescriptionId }, ariaDescription)) : null;
        };
        _this._onRenderMenuIcon = function (props) {
            var menuIconProps = _this.props.menuIconProps;
            return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Icon__WEBPACK_IMPORTED_MODULE_4__["FontIcon"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ iconName: "ChevronDown" }, menuIconProps, { className: _this._classNames.menuIcon }));
        };
        _this._onRenderMenu = function (menuProps) {
            var persistMenu = _this.props.persistMenu;
            var menuHidden = _this.state.menuHidden;
            var MenuType = _this.props.menuAs || _ContextualMenu__WEBPACK_IMPORTED_MODULE_6__["ContextualMenu"];
            // the accessible menu label (accessible name) has a relationship to the button.
            // If the menu props do not specify an explicit value for aria-label or aria-labelledBy,
            // AND the button has text, we'll set the menu aria-labelledBy to the text element id.
            if (!menuProps.ariaLabel && !menuProps.labelElementId && _this._hasText()) {
                menuProps = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, menuProps), { labelElementId: _this._labelId });
            }
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](MenuType, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ id: _this._labelId + '-menu', directionalHint: _common_DirectionalHint__WEBPACK_IMPORTED_MODULE_5__["DirectionalHint"].bottomLeftEdge }, menuProps, { shouldFocusOnContainer: _this._menuShouldFocusOnContainer, shouldFocusOnMount: _this._menuShouldFocusOnMount, hidden: persistMenu ? menuHidden : undefined, className: Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["css"])('ms-BaseButton-menuhost', menuProps.className), target: _this._isSplitButton ? _this._splitButtonContainer.current : _this._buttonElement.current, onDismiss: _this._onDismissMenu })));
        };
        _this._onDismissMenu = function (ev) {
            var menuProps = _this.props.menuProps;
            if (menuProps && menuProps.onDismiss) {
                menuProps.onDismiss(ev);
            }
            if (!ev || !ev.defaultPrevented) {
                _this._dismissMenu();
            }
        };
        _this._dismissMenu = function () {
            _this._menuShouldFocusOnMount = undefined;
            _this._menuShouldFocusOnContainer = undefined;
            _this.setState({ menuHidden: true });
        };
        _this._openMenu = function (shouldFocusOnContainer, shouldFocusOnMount) {
            if (shouldFocusOnMount === void 0) { shouldFocusOnMount = true; }
            if (_this.props.menuProps) {
                _this._menuShouldFocusOnContainer = shouldFocusOnContainer;
                _this._menuShouldFocusOnMount = shouldFocusOnMount;
                _this._renderedVisibleMenu = true;
                _this.setState({ menuHidden: false });
            }
        };
        _this._onToggleMenu = function (shouldFocusOnContainer) {
            var shouldFocusOnMount = true;
            if (_this.props.menuProps && _this.props.menuProps.shouldFocusOnMount === false) {
                shouldFocusOnMount = false;
            }
            _this.state.menuHidden ? _this._openMenu(shouldFocusOnContainer, shouldFocusOnMount) : _this._dismissMenu();
        };
        _this._onSplitContainerFocusCapture = function (ev) {
            var container = _this._splitButtonContainer.current;
            // If the target is coming from the portal we do not need to set focus on the container.
            if (!container || (ev.target && Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["portalContainsElement"])(ev.target, container))) {
                return;
            }
            // We should never be able to focus the individual buttons in a split button. Focus
            // should always remain on the container.
            container.focus();
        };
        _this._onSplitButtonPrimaryClick = function (ev) {
            if (!_this.state.menuHidden) {
                _this._dismissMenu();
            }
            if (!_this._processingTouch && _this.props.onClick) {
                _this.props.onClick(ev);
            }
            else if (_this._processingTouch) {
                _this._onMenuClick(ev);
            }
        };
        _this._onKeyDown = function (ev) {
            // explicity cancelling event so click won't fire after this
            if (_this.props.disabled && (ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].enter || ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].space)) {
                ev.preventDefault();
                ev.stopPropagation();
            }
            else if (!_this.props.disabled) {
                if (_this.props.menuProps) {
                    _this._onMenuKeyDown(ev);
                }
                else if (_this.props.onKeyDown !== undefined) {
                    _this.props.onKeyDown(ev); // not cancelling event because it's not disabled
                }
            }
        };
        _this._onKeyUp = function (ev) {
            if (!_this.props.disabled && _this.props.onKeyUp !== undefined) {
                _this.props.onKeyUp(ev); // not cancelling event because it's not disabled
            }
        };
        _this._onKeyPress = function (ev) {
            if (!_this.props.disabled && _this.props.onKeyPress !== undefined) {
                _this.props.onKeyPress(ev); // not cancelling event because it's not disabled
            }
        };
        _this._onMouseUp = function (ev) {
            if (!_this.props.disabled && _this.props.onMouseUp !== undefined) {
                _this.props.onMouseUp(ev); // not cancelling event because it's not disabled
            }
        };
        _this._onMouseDown = function (ev) {
            if (!_this.props.disabled && _this.props.onMouseDown !== undefined) {
                _this.props.onMouseDown(ev); // not cancelling event because it's not disabled
            }
        };
        _this._onClick = function (ev) {
            if (!_this.props.disabled) {
                if (_this.props.menuProps) {
                    _this._onMenuClick(ev);
                }
                else if (_this.props.onClick !== undefined) {
                    _this.props.onClick(ev); // not cancelling event because it's not disabled
                }
            }
        };
        _this._onSplitButtonContainerKeyDown = function (ev) {
            if (ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].enter || ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].space) {
                if (_this._buttonElement.current) {
                    _this._buttonElement.current.click();
                    ev.preventDefault();
                    ev.stopPropagation();
                }
            }
            else {
                _this._onMenuKeyDown(ev);
            }
        };
        _this._onMenuKeyDown = function (ev) {
            if (_this.props.disabled) {
                return;
            }
            if (_this.props.onKeyDown) {
                _this.props.onKeyDown(ev);
            }
            var isUp = ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].up;
            var isDown = ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].down;
            if (!ev.defaultPrevented && _this._isValidMenuOpenKey(ev)) {
                var onMenuClick = _this.props.onMenuClick;
                if (onMenuClick) {
                    onMenuClick(ev, _this.props);
                }
                _this._onToggleMenu(false);
                ev.preventDefault();
                ev.stopPropagation();
            }
            if (!(ev.altKey || ev.metaKey) && (isUp || isDown)) {
                // Suppose a menu, with shouldFocusOnMount: false, is open, and user wants to keyboard to the menu items
                // We need to re-render the menu with shouldFocusOnMount as true.
                if (!_this.state.menuHidden && _this.props.menuProps) {
                    var currentShouldFocusOnMount = _this._menuShouldFocusOnMount !== undefined
                        ? _this._menuShouldFocusOnMount
                        : _this.props.menuProps.shouldFocusOnMount;
                    if (!currentShouldFocusOnMount) {
                        ev.preventDefault();
                        ev.stopPropagation();
                        _this._menuShouldFocusOnMount = true;
                        _this.forceUpdate();
                    }
                }
            }
        };
        _this._onTouchStart = function () {
            if (_this._isSplitButton &&
                _this._splitButtonContainer.current &&
                !('onpointerdown' in _this._splitButtonContainer.current)) {
                _this._handleTouchAndPointerEvent();
            }
        };
        _this._onMenuClick = function (ev) {
            var onMenuClick = _this.props.onMenuClick;
            if (onMenuClick) {
                onMenuClick(ev, _this.props);
            }
            if (!ev.defaultPrevented) {
                // When Edge + Narrator are used together (regardless of if the button is in a form or not), pressing
                // "Enter" fires this method and not _onMenuKeyDown. Checking ev.nativeEvent.detail differentiates
                // between a real click event and a keypress event (detail should be the number of mouse clicks).
                // ...Plot twist! For a real click event in IE 11, detail is always 0 (Edge sets it properly to 1).
                // So we also check the pointerType property, which both Edge and IE set to "mouse" for real clicks
                // and "" for pressing "Enter" with Narrator on.
                var shouldFocusOnContainer = ev.nativeEvent.detail !== 0 || ev.nativeEvent.pointerType === 'mouse';
                _this._onToggleMenu(shouldFocusOnContainer);
                ev.preventDefault();
                ev.stopPropagation();
            }
        };
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["initializeComponentRef"])(_this);
        _this._async = new _Utilities__WEBPACK_IMPORTED_MODULE_2__["Async"](_this);
        _this._events = new _Utilities__WEBPACK_IMPORTED_MODULE_2__["EventGroup"](_this);
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["warnConditionallyRequiredProps"])(COMPONENT_NAME, props, ['menuProps', 'onClick'], 'split', _this.props.split);
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["warnDeprecations"])(COMPONENT_NAME, props, {
            rootProps: undefined,
            description: 'secondaryText',
            toggled: 'checked',
        });
        _this._labelId = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["getId"])();
        _this._descriptionId = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["getId"])();
        _this._ariaDescriptionId = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["getId"])();
        _this.state = {
            menuHidden: true,
        };
        return _this;
    }
    Object.defineProperty(BaseButton.prototype, "_isSplitButton", {
        get: function () {
            return !!this.props.menuProps && !!this.props.onClick && this.props.split === true;
        },
        enumerable: true,
        configurable: true
    });
    BaseButton.prototype.render = function () {
        var _a;
        var _b = this.props, ariaDescription = _b.ariaDescription, ariaLabel = _b.ariaLabel, ariaHidden = _b.ariaHidden, className = _b.className, disabled = _b.disabled, allowDisabledFocus = _b.allowDisabledFocus, primaryDisabled = _b.primaryDisabled, 
        // eslint-disable-next-line deprecation/deprecation
        _c = _b.secondaryText, 
        // eslint-disable-next-line deprecation/deprecation
        secondaryText = _c === void 0 ? this.props.description : _c, href = _b.href, iconProps = _b.iconProps, menuIconProps = _b.menuIconProps, styles = _b.styles, checked = _b.checked, variantClassName = _b.variantClassName, theme = _b.theme, toggle = _b.toggle, getClassNames = _b.getClassNames, role = _b.role;
        var menuHidden = this.state.menuHidden;
        // Button is disabled if the whole button (in case of splitButton is disabled) or if the primary action is disabled
        var isPrimaryButtonDisabled = disabled || primaryDisabled;
        this._classNames = getClassNames
            ? getClassNames(theme, className, variantClassName, iconProps && iconProps.className, menuIconProps && menuIconProps.className, isPrimaryButtonDisabled, checked, !menuHidden, !!this.props.menuProps, this.props.split, !!allowDisabledFocus)
            : Object(_BaseButton_classNames__WEBPACK_IMPORTED_MODULE_7__["getBaseButtonClassNames"])(theme, styles, className, variantClassName, iconProps && iconProps.className, menuIconProps && menuIconProps.className, isPrimaryButtonDisabled, !!this.props.menuProps, checked, !menuHidden, this.props.split);
        var _d = this, _ariaDescriptionId = _d._ariaDescriptionId, _labelId = _d._labelId, _descriptionId = _d._descriptionId;
        // Anchor tag cannot be disabled hence in disabled state rendering
        // anchor button as normal button
        var renderAsAnchor = !isPrimaryButtonDisabled && !!href;
        var tag = renderAsAnchor ? 'a' : 'button';
        var nativeProps = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["getNativeProps"])(
        // eslint-disable-next-line deprecation/deprecation
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["assign"])(renderAsAnchor ? {} : { type: 'button' }, this.props.rootProps, this.props), renderAsAnchor ? _Utilities__WEBPACK_IMPORTED_MODULE_2__["anchorProperties"] : _Utilities__WEBPACK_IMPORTED_MODULE_2__["buttonProperties"], [
            'disabled',
        ]);
        // Check for ariaLabel passed in via Button props, and fall back to aria-label passed in via native props
        var resolvedAriaLabel = ariaLabel || nativeProps['aria-label'];
        // Check for ariaDescription, secondaryText or aria-describedby in the native props to determine source of
        // aria-describedby. Otherwise default to undefined so property does not appear in output.
        var ariaDescribedBy = undefined;
        if (ariaDescription) {
            ariaDescribedBy = _ariaDescriptionId;
        }
        else if (secondaryText && this.props.onRenderDescription !== _Utilities__WEBPACK_IMPORTED_MODULE_2__["nullRender"]) {
            // for buttons like CompoundButton with a valid onRenderDescription, we need to set an ariaDescribedBy
            // for buttons that do not render anything (via nullRender), we should not set an ariaDescribedBy
            ariaDescribedBy = _descriptionId;
        }
        else if (nativeProps['aria-describedby']) {
            ariaDescribedBy = nativeProps['aria-describedby'];
        }
        // If an explicit ariaLabel is given, use that as the label and we're done.
        // If an explicit aria-labelledby is given, use that and we're done.
        // If any kind of description is given (which will end up as an aria-describedby attribute),
        // set the labelledby element. Otherwise, the button is labeled implicitly by the descendent
        // text on the button (if it exists). Never set both aria-label and aria-labelledby.
        var ariaLabelledBy = undefined;
        if (!resolvedAriaLabel) {
            if (nativeProps['aria-labelledby']) {
                ariaLabelledBy = nativeProps['aria-labelledby'];
            }
            else if (ariaDescribedBy) {
                ariaLabelledBy = this._hasText() ? _labelId : undefined;
            }
        }
        var dataIsFocusable = this.props['data-is-focusable'] === false || (disabled && !allowDisabledFocus) || this._isSplitButton
            ? false
            : true;
        var isCheckboxTypeRole = role === 'menuitemcheckbox' || role === 'checkbox';
        // if isCheckboxTypeRole, always return a checked value.
        // Otherwise only return checked value if toggle is set to true.
        // This is because role="checkbox" always needs to have an aria-checked value
        // but our checked prop only sets aria-pressed if we mark the button as a toggle="true"
        var checkedOrPressedValue = isCheckboxTypeRole ? !!checked : toggle === true ? !!checked : undefined;
        var buttonProps = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["assign"])(nativeProps, (_a = {
                className: this._classNames.root,
                // eslint-disable-next-line deprecation/deprecation
                ref: this._mergedRef(this.props.elementRef, this._buttonElement),
                disabled: isPrimaryButtonDisabled && !allowDisabledFocus,
                onKeyDown: this._onKeyDown,
                onKeyPress: this._onKeyPress,
                onKeyUp: this._onKeyUp,
                onMouseDown: this._onMouseDown,
                onMouseUp: this._onMouseUp,
                onClick: this._onClick,
                'aria-label': resolvedAriaLabel,
                'aria-labelledby': ariaLabelledBy,
                'aria-describedby': ariaDescribedBy,
                'aria-disabled': isPrimaryButtonDisabled,
                'data-is-focusable': dataIsFocusable
            },
            // aria-pressed attribute should only be present for toggle buttons
            // aria-checked attribute should only be present for toggle buttons with checkbox type role
            _a[isCheckboxTypeRole ? 'aria-checked' : 'aria-pressed'] = checkedOrPressedValue,
            _a));
        if (ariaHidden) {
            buttonProps['aria-hidden'] = true;
        }
        if (this._isSplitButton) {
            return this._onRenderSplitButtonContent(tag, buttonProps);
        }
        else if (this.props.menuProps) {
            Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["assign"])(buttonProps, {
                'aria-expanded': !menuHidden,
                'aria-owns': !menuHidden ? this._labelId + '-menu' : null,
                'aria-haspopup': true,
            });
        }
        return this._onRenderContent(tag, buttonProps);
    };
    BaseButton.prototype.componentDidMount = function () {
        // For split buttons, touching anywhere in the button should drop the dropdown, which should contain the
        // primary action. This gives more hit target space for touch environments. We're setting the onpointerdown here,
        // because React does not support Pointer events yet.
        if (this._isSplitButton && this._splitButtonContainer.current) {
            if ('onpointerdown' in this._splitButtonContainer.current) {
                this._events.on(this._splitButtonContainer.current, 'pointerdown', this._onPointerDown, true);
            }
            if ('onpointerup' in this._splitButtonContainer.current && this.props.onPointerUp) {
                this._events.on(this._splitButtonContainer.current, 'pointerup', this.props.onPointerUp, true);
            }
        }
    };
    BaseButton.prototype.componentDidUpdate = function (prevProps, prevState) {
        // If Button's menu was closed, run onAfterMenuDismiss.
        if (this.props.onAfterMenuDismiss && !prevState.menuHidden && this.state.menuHidden) {
            this.props.onAfterMenuDismiss();
        }
    };
    BaseButton.prototype.componentWillUnmount = function () {
        this._async.dispose();
        this._events.dispose();
    };
    BaseButton.prototype.focus = function () {
        if (this._isSplitButton && this._splitButtonContainer.current) {
            this._splitButtonContainer.current.focus();
        }
        else if (this._buttonElement.current) {
            this._buttonElement.current.focus();
        }
    };
    BaseButton.prototype.dismissMenu = function () {
        this._dismissMenu();
    };
    BaseButton.prototype.openMenu = function (shouldFocusOnContainer, shouldFocusOnMount) {
        this._openMenu(shouldFocusOnContainer, shouldFocusOnMount);
    };
    BaseButton.prototype._onRenderContent = function (tag, buttonProps) {
        var _this = this;
        var props = this.props;
        var Tag = tag;
        var menuIconProps = props.menuIconProps, menuProps = props.menuProps, _a = props.onRenderIcon, onRenderIcon = _a === void 0 ? this._onRenderIcon : _a, _b = props.onRenderAriaDescription, onRenderAriaDescription = _b === void 0 ? this._onRenderAriaDescription : _b, _c = props.onRenderChildren, onRenderChildren = _c === void 0 ? this._onRenderChildren : _c, 
        // eslint-disable-next-line deprecation/deprecation
        _d = props.onRenderMenu, 
        // eslint-disable-next-line deprecation/deprecation
        onRenderMenu = _d === void 0 ? this._onRenderMenu : _d, _e = props.onRenderMenuIcon, onRenderMenuIcon = _e === void 0 ? this._onRenderMenuIcon : _e, disabled = props.disabled;
        var keytipProps = props.keytipProps;
        if (keytipProps && menuProps) {
            keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
        }
        var Button = function (keytipAttributes) { return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](Tag, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, buttonProps, keytipAttributes),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: _this._classNames.flexContainer, "data-automationid": "splitbuttonprimary" },
                onRenderIcon(props, _this._onRenderIcon),
                _this._onRenderTextContents(),
                onRenderAriaDescription(props, _this._onRenderAriaDescription),
                onRenderChildren(props, _this._onRenderChildren),
                !_this._isSplitButton &&
                    (menuProps || menuIconProps || _this.props.onRenderMenuIcon) &&
                    onRenderMenuIcon(_this.props, _this._onRenderMenuIcon),
                menuProps &&
                    !menuProps.doNotLayer &&
                    _this._shouldRenderMenu() &&
                    onRenderMenu(menuProps, _this._onRenderMenu)))); };
        var Content = keytipProps ? (
        // If we're making a split button, we won't put the keytip here
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_KeytipData__WEBPACK_IMPORTED_MODULE_9__["KeytipData"], { keytipProps: !this._isSplitButton ? keytipProps : undefined, ariaDescribedBy: buttonProps['aria-describedby'], disabled: disabled }, function (keytipAttributes) { return Button(keytipAttributes); })) : (Button());
        if (menuProps && menuProps.doNotLayer) {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { style: { display: 'inline-block' } },
                Content,
                this._shouldRenderMenu() && onRenderMenu(menuProps, this._onRenderMenu)));
        }
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null,
            Content,
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_Utilities__WEBPACK_IMPORTED_MODULE_2__["FocusRects"], null)));
    };
    /**
     * Method to help determine if the menu's component tree should
     * be rendered. It takes into account whether the menu is expanded,
     * whether it is a persisted menu and whether it has been shown to the user.
     */
    BaseButton.prototype._shouldRenderMenu = function () {
        var menuHidden = this.state.menuHidden;
        // eslint-disable-next-line deprecation/deprecation
        var _a = this.props, persistMenu = _a.persistMenu, renderPersistedMenuHiddenOnMount = _a.renderPersistedMenuHiddenOnMount;
        if (!menuHidden) {
            // Always should render a menu when it is expanded
            return true;
        }
        else if (persistMenu && (this._renderedVisibleMenu || renderPersistedMenuHiddenOnMount)) {
            // _renderedVisibleMenu ensures that the first rendering of
            // the menu happens on-screen, as edge's scrollbar calculations are off if done while hidden.
            return true;
        }
        return false;
    };
    BaseButton.prototype._hasText = function () {
        // _onRenderTextContents and _onRenderText do not perform the same checks. Below is parity with what _onRenderText
        // used to have before the refactor that introduced this function. _onRenderTextContents does not require props.
        // text to be undefined in order for props.children to be used as a fallback.
        // Purely a code maintainability/reuse issue, but logged as Issue #4979.
        return this.props.text !== null && (this.props.text !== undefined || typeof this.props.children === 'string');
    };
    BaseButton.prototype._onRenderSplitButtonContent = function (tag, buttonProps) {
        var _this = this;
        var _a = this.props, _b = _a.styles, styles = _b === void 0 ? {} : _b, disabled = _a.disabled, allowDisabledFocus = _a.allowDisabledFocus, checked = _a.checked, getSplitButtonClassNames = _a.getSplitButtonClassNames, primaryDisabled = _a.primaryDisabled, menuProps = _a.menuProps, toggle = _a.toggle, role = _a.role, primaryActionButtonProps = _a.primaryActionButtonProps;
        var keytipProps = this.props.keytipProps;
        var menuHidden = this.state.menuHidden;
        var classNames = getSplitButtonClassNames
            ? getSplitButtonClassNames(!!disabled, !menuHidden, !!checked, !!allowDisabledFocus)
            : styles && Object(_SplitButton_SplitButton_classNames__WEBPACK_IMPORTED_MODULE_8__["getSplitButtonClassNames"])(styles, !!disabled, !menuHidden, !!checked, !!primaryDisabled);
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["assign"])(buttonProps, {
            onClick: undefined,
            onPointerDown: undefined,
            onPointerUp: undefined,
            tabIndex: -1,
            'data-is-focusable': false,
        });
        if (keytipProps && menuProps) {
            keytipProps = this._getMemoizedMenuButtonKeytipProps(keytipProps);
        }
        var containerProps = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["getNativeProps"])(buttonProps, [], ['disabled']);
        // Add additional props to apply on primary action button
        if (primaryActionButtonProps) {
            Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["assign"])(buttonProps, primaryActionButtonProps);
        }
        var SplitButton = function (keytipAttributes) { return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, containerProps, { "data-ktp-target": keytipAttributes ? keytipAttributes['data-ktp-target'] : undefined, role: role ? role : 'button', "aria-disabled": disabled, "aria-haspopup": true, "aria-expanded": !menuHidden, "aria-pressed": toggle ? !!checked : undefined, "aria-describedby": Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["mergeAriaAttributeValues"])(buttonProps['aria-describedby'], keytipAttributes ? keytipAttributes['aria-describedby'] : undefined), className: classNames && classNames.splitButtonContainer, onKeyDown: _this._onSplitButtonContainerKeyDown, onTouchStart: _this._onTouchStart, ref: _this._splitButtonContainer, "data-is-focusable": true, onClick: !disabled && !primaryDisabled ? _this._onSplitButtonPrimaryClick : undefined, tabIndex: !disabled || allowDisabledFocus ? 0 : undefined, "aria-roledescription": buttonProps['aria-roledescription'], onFocusCapture: _this._onSplitContainerFocusCapture }),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { style: { display: 'flex' } },
                _this._onRenderContent(tag, buttonProps),
                _this._onRenderSplitButtonMenuButton(classNames, keytipAttributes),
                _this._onRenderSplitButtonDivider(classNames)))); };
        return keytipProps ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_KeytipData__WEBPACK_IMPORTED_MODULE_9__["KeytipData"], { keytipProps: keytipProps, disabled: disabled }, function (keytipAttributes) { return SplitButton(keytipAttributes); })) : (SplitButton());
    };
    BaseButton.prototype._onRenderSplitButtonDivider = function (classNames) {
        if (classNames && classNames.divider) {
            var onClick = function (ev) {
                ev.stopPropagation();
            };
            return react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: classNames.divider, "aria-hidden": true, onClick: onClick });
        }
        return null;
    };
    BaseButton.prototype._onRenderSplitButtonMenuButton = function (classNames, keytipAttributes) {
        var _a = this.props, allowDisabledFocus = _a.allowDisabledFocus, checked = _a.checked, disabled = _a.disabled, splitButtonMenuProps = _a.splitButtonMenuProps, splitButtonAriaLabel = _a.splitButtonAriaLabel;
        var menuHidden = this.state.menuHidden;
        var menuIconProps = this.props.menuIconProps;
        if (menuIconProps === undefined) {
            menuIconProps = {
                iconName: 'ChevronDown',
            };
        }
        var splitButtonProps = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, splitButtonMenuProps), { styles: classNames, checked: checked, disabled: disabled, allowDisabledFocus: allowDisabledFocus, onClick: this._onMenuClick, menuProps: undefined, iconProps: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, menuIconProps), { className: this._classNames.menuIcon }), ariaLabel: splitButtonAriaLabel, 'aria-haspopup': true, 'aria-expanded': !menuHidden, 'data-is-focusable': false });
        // Add data-ktp-execute-target to the split button if the keytip is defined
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](BaseButton, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, splitButtonProps, { "data-ktp-execute-target": keytipAttributes ? keytipAttributes['data-ktp-execute-target'] : keytipAttributes, onMouseDown: this._onMouseDown, tabIndex: -1 })));
    };
    BaseButton.prototype._onPointerDown = function (ev) {
        var onPointerDown = this.props.onPointerDown;
        if (onPointerDown) {
            onPointerDown(ev);
        }
        if (ev.pointerType === 'touch') {
            this._handleTouchAndPointerEvent();
            ev.preventDefault();
            ev.stopImmediatePropagation();
        }
    };
    BaseButton.prototype._handleTouchAndPointerEvent = function () {
        var _this = this;
        // If we already have an existing timeout from a previous touch and pointer event
        // cancel that timeout so we can set a new one.
        if (this._lastTouchTimeoutId !== undefined) {
            this._async.clearTimeout(this._lastTouchTimeoutId);
            this._lastTouchTimeoutId = undefined;
        }
        this._processingTouch = true;
        this._lastTouchTimeoutId = this._async.setTimeout(function () {
            _this._processingTouch = false;
            _this._lastTouchTimeoutId = undefined;
            // Touch and pointer events don't focus the button naturally,
            // so adding an imperative focus call to guarantee this behavior.
            _this.focus();
        }, TouchIdleDelay);
    };
    /**
     * Returns if the user hits a valid keyboard key to open the menu
     * @param ev - the keyboard event
     * @returns True if user clicks on custom trigger key if enabled or alt + down arrow if not. False otherwise.
     */
    BaseButton.prototype._isValidMenuOpenKey = function (ev) {
        if (this.props.menuTriggerKeyCode) {
            return ev.which === this.props.menuTriggerKeyCode;
        }
        else if (this.props.menuProps) {
            return ev.which === _Utilities__WEBPACK_IMPORTED_MODULE_2__["KeyCodes"].down && (ev.altKey || ev.metaKey);
        }
        // Note: When enter is pressed, we will let the event continue to propagate
        // to trigger the onClick event on the button
        return false;
    };
    BaseButton.defaultProps = {
        baseClassName: 'ms-Button',
        styles: {},
        split: false,
    };
    return BaseButton;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=BaseButton.js.map

/***/ }),

/***/ "5s0Y":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequestsList.scss.js ***!
  \*******************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-accessRequestsList-ScrollablePane{height:525px;position:relative;background-color:white}.ms-accessRequestsButtons{height:48px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch}.ms-AccessRequest-AccessRequestList{height:100%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;overflow-y:hidden;overflow-x:hidden}.ms-AccessRequestsList-CheckBoxRoot{min-height:64px;vertical-align:top;padding-top:11px;padding-bottom:11px}.ms-AccessRequestsList-ColumnText{font-size:14px;vertical-align:top;padding-top:8.5px}.ms-accessRequestsList{display:inline}.ms-AccessRequestsDialogListContainer{display:inline}.ms-AccessRequest-AccessRequestListHeader{padding-right:0px;padding-left:0px}.ms-AccessRequestsList-card{min-width:48px}.ms-AccessRequestsList-card:active{pointer-events:none}.ms-AccessRequestsList-Column{padding-left:0px;padding-right:0px}.ms-AccessRequestsList-NameColumn{min-width:230px}.ms-AccessRequestsList-IconColumn{min-width:36px;max-width:36px;margin-top:10px;font-size:15px}.ms-AccessRequestsList-ItemColumn{max-width:308px;min-width:308px}.ms-AccessRequestsList-RequestDateColumn{min-width:144px;max-width:144px;margin-top:11px}.ms-AccessRequestsList-PermissionsColumn{min-width:156px;max-width:156px;margin-top:6px}.ms-AccessRequestsList-CommentColumn{min-width:78px;max-width:78px;margin-top:9px}.ms-AccessRequestsList-Comment{overflow:hidden;word-break:break-all}.ms-AccessRequestsList-CompletedStatus{color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": "}.ms-AccessRequestsList-Link{color:" }, { "theme": "neutralPrimary", "defaultValue": "#323130" }, { "rawString": "}.ms-AccessRequestsList-RequestDate{color:" }, { "theme": "neutralPrimary", "defaultValue": "#323130" }, { "rawString": "}.ms-accessRequestsList-ErrorMessage{background-color:" }, { "theme": "errorBackground", "defaultValue": "#FDE7E9" }, { "rawString": ";font-size:14}.ms-accessRequestsList-Blocked{padding-top:8px;color:#a4262c}.ms-accessRequestsList-Cancel{font-size:14px}.ms-accessRequestsList-ErrorText{padding-top:5px}\n" }]);
//# sourceMappingURL=AccessRequestsList.scss.js.map

/***/ }),

/***/ "66MK":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissions/SitePermissionsMenu.js ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissionsMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsMenu", function() { return SitePermissionsMenu; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SitePermissions_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SitePermissions.scss */ "2w7h");
/* harmony import */ var office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/ContextualMenu */ "u4xd");
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/FocusZone */ "NMYH");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! office-ui-fabric-react/lib/Icon */ "56LG");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__);







/**
 * sitePermissions displays properties
 */
var SitePermissionsMenu = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SitePermissionsMenu, _super);
    function SitePermissionsMenu(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this._onClick = function () {
            _this.setState({
                isContextualMenuVisible: !_this.state.isContextualMenuVisible
            });
        };
        _this._onDismiss = function (ev) {
            _this.setState({
                isContextualMenuVisible: false
            });
            ev.stopPropagation();
            ev.preventDefault();
        };
        _this._resolveMenu = function (el) { return (_this.menu = el); };
        _this.state = {
            isContextualMenuVisible: false
        };
        return _this;
    }
    SitePermissionsMenu.prototype.render = function () {
        if (!this.props.menuItems) {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-noButtonArea', "data-automationid": 'SitePermissionsNoButtonArea' }, this.props.permLevelTitle));
        }
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-ContextMenuButton', "data-automationid": 'SitePermissionsPersonaContextMenuButton' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_5__["FocusZone"], { direction: office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_5__["FocusZoneDirection"].horizontal },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-buttonArea', ref: this._resolveMenu },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-sitePerm-linkText', onClick: this._onClick, "data-is-focusable": true, role: 'button', "aria-haspopup": true, "data-automationid": 'SitePermissionsPersonaContextMenuButton', "aria-expanded": this.state.isContextualMenuVisible ? true : false },
                        this.props.permLevelTitle,
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__["Icon"], { iconName: 'ChevronDown', className: Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_4__["css"])('ms-sitePermMenu-chevron', this.props.permLevelTitle && 'has-permLevelTitle') }))),
                this.state.isContextualMenuVisible && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__["ContextualMenu"], { className: 'ms-sitePerm-PersonaContextMenu', items: this.props.menuItems, isBeakVisible: false, target: this.menu, directionalHint: office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__["DirectionalHint"].bottomLeftEdge, onDismiss: this._onDismiss, gapSpace: 0 })))));
    };
    return SitePermissionsMenu;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=SitePermissionsMenu.js.map

/***/ }),

/***/ "6ByR":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SiteSharingSettingsPanel/SiteSharingSettingsPanel.resx.js ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"siteSharingSettingsPanelHeader":"Site sharing settings","siteSharingSettingsPanelDescription":"Control how things in this site can be shared and how request access works.","membersCanShareHeader":"Sharing permissions","tenantAdminMembersCanShareMessage":"Sharing permissions are managed by your organization.","membersCanShareChoiceFileFolderSite":"Site owners and members can share files, folders, and the site. People with Edit permissions can share files and folders.","membersCanShareChoiceFileFolder":"Site owners and members, and people with Edit permissions can share files and folders, but only site owners can share the site.","membersCanShareChoiceNone":"Only site owners can share files, folders, and the site.","accessRequestHeader":"Access requests","accessRequestToggleLabel":"Allow access requests","accessRequestChoicesDescription":"Choose who will receive access requests for this site: ","accessRequestOwnersGroupRadioButtonLabel":"Owners group","accessRequestEmailRadioButtonLabel":"Specific email","accessRequestSiteDescriptionLabel":"Add a custom message to the request access page: ","accessRequestSiteDescriptionPlaceholder":"For example: Please allow three days for us to review your request.","toggleOnText":"On","toggleOffText":"Off","saveButtonText":"Save","discardButtonText":"Discard","closeButtonAriaLabel":"Close","selectedPersonNoEmailError":"Selected user doesn\u0027t have a valid email address.","saveFailureMessage":"The server was unable to save the settings at this time. Please try again.","dialogTitleText":"Do you want to save your changes before leaving?"};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "6MNw":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-14.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-14\"",
            src: "url('" + baseUrl + "fabric-icons-14-5cf58db8.woff') format('woff')"
        },
        icons: {
            'Snooze': '\uF4BD',
            'WaffleOffice365': '\uF4E0',
            'ImageSearch': '\uF4E8',
            'NewsSearch': '\uF4E9',
            'VideoSearch': '\uF4EA',
            'R': '\uF4EB',
            'FontColorA': '\uF4EC',
            'FontColorSwatch': '\uF4ED',
            'LightWeight': '\uF4EE',
            'NormalWeight': '\uF4EF',
            'SemiboldWeight': '\uF4F0',
            'GroupObject': '\uF4F1',
            'UngroupObject': '\uF4F2',
            'AlignHorizontalLeft': '\uF4F3',
            'AlignHorizontalCenter': '\uF4F4',
            'AlignHorizontalRight': '\uF4F5',
            'AlignVerticalTop': '\uF4F6',
            'AlignVerticalCenter': '\uF4F7',
            'AlignVerticalBottom': '\uF4F8',
            'HorizontalDistributeCenter': '\uF4F9',
            'VerticalDistributeCenter': '\uF4FA',
            'Ellipse': '\uF4FB',
            'Line': '\uF4FC',
            'Octagon': '\uF4FD',
            'Hexagon': '\uF4FE',
            'Pentagon': '\uF4FF',
            'RightTriangle': '\uF500',
            'HalfCircle': '\uF501',
            'QuarterCircle': '\uF502',
            'ThreeQuarterCircle': '\uF503',
            '6PointStar': '\uF504',
            '12PointStar': '\uF505',
            'ArrangeBringToFront': '\uF506',
            'ArrangeSendToBack': '\uF507',
            'ArrangeSendBackward': '\uF508',
            'ArrangeBringForward': '\uF509',
            'BorderDash': '\uF50A',
            'BorderDot': '\uF50B',
            'LineStyle': '\uF50C',
            'LineThickness': '\uF50D',
            'WindowEdit': '\uF50E',
            'HintText': '\uF50F',
            'MediaAdd': '\uF510',
            'AnchorLock': '\uF511',
            'AutoHeight': '\uF512',
            'ChartSeries': '\uF513',
            'ChartXAngle': '\uF514',
            'ChartYAngle': '\uF515',
            'Combobox': '\uF516',
            'LineSpacing': '\uF517',
            'Padding': '\uF518',
            'PaddingTop': '\uF519',
            'PaddingBottom': '\uF51A',
            'PaddingLeft': '\uF51B',
            'PaddingRight': '\uF51C',
            'NavigationFlipper': '\uF51D',
            'AlignJustify': '\uF51E',
            'TextOverflow': '\uF51F',
            'VisualsFolder': '\uF520',
            'VisualsStore': '\uF521',
            'PictureCenter': '\uF522',
            'PictureFill': '\uF523',
            'PicturePosition': '\uF524',
            'PictureStretch': '\uF525',
            'PictureTile': '\uF526',
            'Slider': '\uF527',
            'SliderHandleSize': '\uF528',
            'DefaultRatio': '\uF529',
            'NumberSequence': '\uF52A',
            'GUID': '\uF52B',
            'ReportAdd': '\uF52C',
            'DashboardAdd': '\uF52D',
            'MapPinSolid': '\uF52E',
            'WebPublish': '\uF52F',
            'PieSingleSolid': '\uF530',
            'BlockedSolid': '\uF531',
            'DrillDown': '\uF532',
            'DrillDownSolid': '\uF533',
            'DrillExpand': '\uF534',
            'DrillShow': '\uF535',
            'SpecialEvent': '\uF536',
            'OneDriveFolder16': '\uF53B',
            'FunctionalManagerDashboard': '\uF542',
            'BIDashboard': '\uF543',
            'CodeEdit': '\uF544',
            'RenewalCurrent': '\uF545',
            'RenewalFuture': '\uF546',
            'SplitObject': '\uF547',
            'BulkUpload': '\uF548',
            'DownloadDocument': '\uF549',
            'GreetingCard': '\uF54B',
            'Flower': '\uF54E',
            'WaitlistConfirm': '\uF550',
            'WaitlistConfirmMirrored': '\uF551',
            'LaptopSecure': '\uF552',
            'DragObject': '\uF553',
            'EntryView': '\uF554',
            'EntryDecline': '\uF555',
            'ContactCardSettings': '\uF556',
            'ContactCardSettingsMirrored': '\uF557'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-14.js.map

/***/ }),

/***/ "7CEq":
/*!****************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons.js ***!
  \****************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none',
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons\"",
            src: "url('" + baseUrl + "fabric-icons-a13498cf.woff') format('woff')",
        },
        icons: {
            GlobalNavButton: '\uE700',
            ChevronDown: '\uE70D',
            ChevronUp: '\uE70E',
            Edit: '\uE70F',
            Add: '\uE710',
            Cancel: '\uE711',
            More: '\uE712',
            Settings: '\uE713',
            Mail: '\uE715',
            Filter: '\uE71C',
            Search: '\uE721',
            Share: '\uE72D',
            BlockedSite: '\uE72F',
            FavoriteStar: '\uE734',
            FavoriteStarFill: '\uE735',
            CheckMark: '\uE73E',
            Delete: '\uE74D',
            ChevronLeft: '\uE76B',
            ChevronRight: '\uE76C',
            Calendar: '\uE787',
            Megaphone: '\uE789',
            Undo: '\uE7A7',
            Flag: '\uE7C1',
            Page: '\uE7C3',
            Pinned: '\uE840',
            View: '\uE890',
            Clear: '\uE894',
            Download: '\uE896',
            Upload: '\uE898',
            Folder: '\uE8B7',
            Sort: '\uE8CB',
            AlignRight: '\uE8E2',
            AlignLeft: '\uE8E4',
            Tag: '\uE8EC',
            AddFriend: '\uE8FA',
            Info: '\uE946',
            SortLines: '\uE9D0',
            List: '\uEA37',
            CircleRing: '\uEA3A',
            Heart: '\uEB51',
            HeartFill: '\uEB52',
            Tiles: '\uECA5',
            Embed: '\uECCE',
            Glimmer: '\uECF4',
            Ascending: '\uEDC0',
            Descending: '\uEDC1',
            SortUp: '\uEE68',
            SortDown: '\uEE69',
            SyncToPC: '\uEE6E',
            LargeGrid: '\uEECB',
            SkypeCheck: '\uEF80',
            SkypeClock: '\uEF81',
            SkypeMinus: '\uEF82',
            ClearFilter: '\uEF8F',
            Flow: '\uEF90',
            StatusCircleCheckmark: '\uF13E',
            MoreVertical: '\uF2BC',
        },
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons.js.map

/***/ }),

/***/ "86Ak":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-9.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-9\"",
            src: "url('" + baseUrl + "fabric-icons-9-c6162b42.woff') format('woff')"
        },
        icons: {
            'AddFavoriteFill': '\uF0C9',
            'BufferTimeBefore': '\uF0CF',
            'BufferTimeAfter': '\uF0D0',
            'BufferTimeBoth': '\uF0D1',
            'PublishContent': '\uF0D4',
            'ClipboardList': '\uF0E3',
            'ClipboardListMirrored': '\uF0E4',
            'CannedChat': '\uF0F2',
            'SkypeForBusinessLogo': '\uF0FC',
            'TabCenter': '\uF100',
            'PageCheckedin': '\uF104',
            'PageList': '\uF106',
            'ReadOutLoud': '\uF112',
            'CaretBottomLeftSolid8': '\uF121',
            'CaretBottomRightSolid8': '\uF122',
            'FolderHorizontal': '\uF12B',
            'MicrosoftStaffhubLogo': '\uF130',
            'GiftboxOpen': '\uF133',
            'StatusCircleOuter': '\uF136',
            'StatusCircleInner': '\uF137',
            'StatusCircleRing': '\uF138',
            'StatusTriangleOuter': '\uF139',
            'StatusTriangleInner': '\uF13A',
            'StatusTriangleExclamation': '\uF13B',
            'StatusCircleExclamation': '\uF13C',
            'StatusCircleErrorX': '\uF13D',
            'StatusCircleInfo': '\uF13F',
            'StatusCircleBlock': '\uF140',
            'StatusCircleBlock2': '\uF141',
            'StatusCircleQuestionMark': '\uF142',
            'StatusCircleSync': '\uF143',
            'Toll': '\uF160',
            'ExploreContentSingle': '\uF164',
            'CollapseContent': '\uF165',
            'CollapseContentSingle': '\uF166',
            'InfoSolid': '\uF167',
            'GroupList': '\uF168',
            'ProgressRingDots': '\uF16A',
            'CaloriesAdd': '\uF172',
            'BranchFork': '\uF173',
            'MuteChat': '\uF17A',
            'AddHome': '\uF17B',
            'AddWork': '\uF17C',
            'MobileReport': '\uF18A',
            'ScaleVolume': '\uF18C',
            'HardDriveGroup': '\uF18F',
            'FastMode': '\uF19A',
            'ToggleLeft': '\uF19E',
            'ToggleRight': '\uF19F',
            'TriangleShape': '\uF1A7',
            'RectangleShape': '\uF1A9',
            'CubeShape': '\uF1AA',
            'Trophy2': '\uF1AE',
            'BucketColor': '\uF1B6',
            'BucketColorFill': '\uF1B7',
            'Taskboard': '\uF1C2',
            'SingleColumn': '\uF1D3',
            'DoubleColumn': '\uF1D4',
            'TripleColumn': '\uF1D5',
            'ColumnLeftTwoThirds': '\uF1D6',
            'ColumnRightTwoThirds': '\uF1D7',
            'AccessLogoFill': '\uF1DB',
            'AnalyticsLogo': '\uF1DE',
            'AnalyticsQuery': '\uF1DF',
            'NewAnalyticsQuery': '\uF1E0',
            'AnalyticsReport': '\uF1E1',
            'WordLogo': '\uF1E3',
            'WordLogoFill': '\uF1E4',
            'ExcelLogo': '\uF1E5',
            'ExcelLogoFill': '\uF1E6',
            'OneNoteLogo': '\uF1E7',
            'OneNoteLogoFill': '\uF1E8',
            'OutlookLogo': '\uF1E9',
            'OutlookLogoFill': '\uF1EA',
            'PowerPointLogo': '\uF1EB',
            'PowerPointLogoFill': '\uF1EC',
            'PublisherLogo': '\uF1ED',
            'PublisherLogoFill': '\uF1EE',
            'ScheduleEventAction': '\uF1EF',
            'FlameSolid': '\uF1F3',
            'ServerProcesses': '\uF1FE',
            'Server': '\uF201',
            'SaveAll': '\uF203',
            'LinkedInLogo': '\uF20A',
            'Decimals': '\uF218',
            'SidePanelMirrored': '\uF221',
            'ProtectRestrict': '\uF22A',
            'Blog': '\uF22B',
            'UnknownMirrored': '\uF22E',
            'PublicContactCardMirrored': '\uF230',
            'GridViewSmall': '\uF232',
            'GridViewMedium': '\uF233',
            'GridViewLarge': '\uF234',
            'Step': '\uF241',
            'StepInsert': '\uF242',
            'StepShared': '\uF243',
            'StepSharedAdd': '\uF244',
            'StepSharedInsert': '\uF245',
            'ViewDashboard': '\uF246',
            'ViewList': '\uF247'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-9.js.map

/***/ }),

/***/ "8DW8":
/*!****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingRole.js ***!
  \****************************************************************************************************************************************************************************************************/
/*! exports provided: SharingRole */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingRole", function() { return SharingRole; });
// OneDrive:IgnoreCodeCoverage
var SharingRole;
(function (SharingRole) {
    SharingRole[SharingRole["Owner"] = 0] = "Owner";
    SharingRole[SharingRole["View"] = 1] = "View";
    SharingRole[SharingRole["Edit"] = 2] = "Edit";
    SharingRole[SharingRole["Submitter"] = 3] = "Submitter";
    SharingRole[SharingRole["CoOwner"] = 4] = "CoOwner";
    SharingRole[SharingRole["None"] = 5] = "None";
    SharingRole[SharingRole["Review"] = 6] = "Review";
    SharingRole[SharingRole["Custom"] = 7] = "Custom";
})(SharingRole || (SharingRole = {}));
//# sourceMappingURL=SharingRole.js.map

/***/ }),

/***/ "90b+":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissions/SitePermissions.resx.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"emptyGroupText":"None","cannotViewMembersText":"You do not have permission to view the membership of the group."};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "926j":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/shared-react-people-picker@1.1.20_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/shared-react-people-picker/lib/PeoplePickerItemWithMenu.js ***!
  \**********************************************************************************************************************************************************************************************************/
/*! exports provided: PeoplePickerItemWithMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PeoplePickerItemWithMenu", function() { return PeoplePickerItemWithMenu; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/Persona */ "UXmd");
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/Icon */ "56LG");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Button */ "epn0");
/* harmony import */ var office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! office-ui-fabric-react/lib/ContextualMenu */ "u4xd");
/* harmony import */ var office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! office-ui-fabric-react/lib/FocusZone */ "NMYH");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _PeoplePicker_resx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PeoplePicker.resx */ "Pvlj");
/* harmony import */ var _PeoplePicker_resx__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_PeoplePicker_resx__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _PeoplePickerItemWithMenu_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./PeoplePickerItemWithMenu.scss */ "ScP4");


/* tslint:enable */









var PeoplePickerItemWithMenu = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(PeoplePickerItemWithMenu, _super);
    function PeoplePickerItemWithMenu(props) {
        var _this = _super.call(this, props) || this;
        _this._onClick = function () {
            _this.setState({
                isContextualMenuVisible: !_this.state.isContextualMenuVisible
            });
        };
        // tslint:disable-next-line:no-any
        _this._onDismiss = function (ev) {
            _this.setState({
                isContextualMenuVisible: false
            });
            ev.stopPropagation();
            ev.preventDefault();
        };
        _this.state = { isContextualMenuVisible: false };
        return _this;
    }
    PeoplePickerItemWithMenu.prototype.render = function () {
        var _a = this.props, item = _a.item, onRemoveItem = _a.onRemoveItem, index = _a.index, selected = _a.selected;
        var personaProps = this._convertIPersonToIPersonaProps(item);
        var pickerPersonaId = 'PickerPersonaId' + Math.floor(Math.random() * 10000);
        var removeButtonAriaLabel = _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_8__["format"](_PeoplePicker_resx__WEBPACK_IMPORTED_MODULE_9___default.a.removeButtonDefaultArialLabel, item.name);
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_3__["css"])('ms-PickerPersonaMenu-container', {
                'is-selected': !!selected
            }), "data-selection-index": index, key: index, "data-is-focusable": true, "aria-labelledby": pickerPersonaId },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_7__["FocusZone"], { className: 'ms-PickerPersona-item' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-PickerPersona-content' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_2__["Persona"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ id: pickerPersonaId }, personaProps, { presence: office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_2__["PersonaPresence"].none, size: office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_2__["PersonaSize"].small, secondaryText: this.props.menuTitle && !this.props.menuItems ? this.props.menuTitle : undefined }), this.props.menuTitle && this.props.menuItems && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-ContextMenu' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-buttonArea', ref: this._resolveRef('_buttonTarget') },
                            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-sitePerm-linkText', onClick: this._onClick, "data-is-focusable": true, role: 'button', "aria-haspopup": true },
                                this.props.menuTitle,
                                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_4__["Icon"], { iconName: 'ChevronDown', className: 'ms-sitePermMenu-chevron' }))),
                        this.state.isContextualMenuVisible && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__["ContextualMenu"], { items: this.props.menuItems, isBeakVisible: false, target: this._buttonTarget, directionalHint: office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__["DirectionalHint"].bottomLeftEdge, onDismiss: this._onDismiss, gapSpace: 0 })))))),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-PickerItem-sideContent' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["IconButton"], { onClick: onRemoveItem, iconProps: { iconName: 'Cancel' }, className: 'ms-PickerItem-content', ariaLabel: removeButtonAriaLabel })))));
    };
    PeoplePickerItemWithMenu.prototype._convertIPersonToIPersonaProps = function (person) {
        return {
            text: person.name ? person.name : '',
            imageUrl: person.image ? person.image : '',
            tertiaryText: person.email ? person.email : '',
            secondaryText: person.job ? person.job : '',
            imageInitials: ''
        };
    };
    return PeoplePickerItemWithMenu;
}(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_3__["BaseComponent"]));

//# sourceMappingURL=PeoplePickerItemWithMenu.js.map

/***/ }),

/***/ "AAtU":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequests.resx.js ***!
  \***************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"AccessRequests":"Access requests","NoRequests":"Nothing, up to date.","NoInternalRequests":"No pending internal requests, up to date.","NoExternalRequests":"No pending external requests, up to date.","Refresh":"Refresh","ApproveAll":"Approve all","Approve":"Approve","Approved":"Approved","DeclineAll":"Decline all","Decline":"Decline","Declined":"Declined","IgnoreAll":"Ignore all","Ignore":"Ignore","Ignored":"Ignored","IgnoreTitle":"Ignoring will remove requests without notifying the requester.","Edit":"Edit","Member":"Member","View":"View","Visitor":"Visitor","SelectPermissions":"Select permissions","AdvancedSettingsEntry":"Advanced settings","Name":"      Name","RequestDate":"Request date","Item":"Item","Permissions":"Permission","Internal":"Internal","External":"External","All":"All","SelectionAriaLabel":"Toggle Selection","SelectAllAriaLabel":"Select all","MessageTitle":"Comment","UserNotInOrg":"User not in your organization.","ClassicExperience":"Return to classic view","ErrorInSelection":"Your selection includes request(s) that have already been addressed.  To make a new action, remove such requests from your selection."};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "ALXe":
/*!************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/FileIconType.js ***!
  \************************************************************************************************************************************************************************************/
/*! exports provided: FileIconType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileIconType", function() { return FileIconType; });
/**
 * Enumerates special file type icons that do not map to any file extensions.
 * For example, the 'pptx' icon maps to the extensions 'ppt', 'pptm', 'pptx',
 * but the 'folder' icon does not map to any extensions and should be obtained
 * via this enum.
 */
var FileIconType;
(function (FileIconType) {
    FileIconType[FileIconType["docset"] = 1] = "docset";
    FileIconType[FileIconType["folder"] = 2] = "folder";
    FileIconType[FileIconType["genericFile"] = 3] = "genericFile";
    FileIconType[FileIconType["listItem"] = 4] = "listItem";
    FileIconType[FileIconType["sharedFolder"] = 5] = "sharedFolder";
    FileIconType[FileIconType["multiple"] = 6] = "multiple";
    FileIconType[FileIconType["stream"] = 7] = "stream";
    FileIconType[FileIconType["news"] = 8] = "news";
    FileIconType[FileIconType["desktopFolder"] = 9] = "desktopFolder";
    FileIconType[FileIconType["documentsFolder"] = 10] = "documentsFolder";
    FileIconType[FileIconType["picturesFolder"] = 11] = "picturesFolder";
    FileIconType[FileIconType["linkedFolder"] = 12] = "linkedFolder";
    FileIconType[FileIconType["list"] = 13] = "list";
})(FileIconType || (FileIconType = {}));
//# sourceMappingURL=FileIconType.js.map

/***/ }),

/***/ "BVxC":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/utilities/peoplepicker/PeoplePickerHelper.resx.js ***!
  \****************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"and":"and","outsideOfYourOrgPlural":"{0} are outside of your organization.","outsideOfYourOrgSingular":"{0} is outside of your organization.","oneGroupInvited":"1 group will be invited.","multipleGroupsInvited":"{0} groups will be invited.","groupsMemberCountLargeLabel":"(That\u0027s more than 1,000 people.)","groupsMemberCountLabel":"(That\u0027s about {0} people.)","noExactMatch":"We couldn\u0027t find an exact match.","peoplePickerErrorCsl":"This link won\u0027t work for people outside of your organization.","peoplePickerErrorDLNotSupported":"Distribution Lists are currently unsupported.","insufficientPermissionsError":"The recipient you entered doesn\u0027t have permission to access the item.","insufficientPermissionsErrorPlural":"Some of the recipients you entered don\u0027t have permission to access the item.","PolicyTipNotifyAndBlock":"This item contains sensitive information. It can\u0027t be shared with people outside your organization.","ViewPolicyTip":"View policy tip"};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "CRDm":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/SplitButton/SplitButton.styles.js ***!
  \*******************************************************************************************************************************************************************************************************************/
/*! exports provided: getStyles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyles", function() { return getStyles; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Styling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../Styling */ "PL71");
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../Utilities */ "mkpW");



var getStyles = Object(_Utilities__WEBPACK_IMPORTED_MODULE_2__["memoizeFunction"])(function (theme, customStyles) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    var effects = theme.effects, palette = theme.palette, semanticColors = theme.semanticColors;
    var buttonHighContrastFocus = {
        left: -2,
        top: -2,
        bottom: -2,
        right: -2,
        border: 'none',
    };
    var splitButtonDividerBaseStyles = {
        position: 'absolute',
        width: 1,
        right: 31,
        top: 8,
        bottom: 8,
    };
    var splitButtonStyles = {
        splitButtonContainer: [
            Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["getFocusStyle"])(theme, { highContrastStyle: buttonHighContrastFocus, inset: 2 }),
            {
                display: 'inline-flex',
                selectors: {
                    '.ms-Button--default': {
                        borderTopRightRadius: '0',
                        borderBottomRightRadius: '0',
                        borderRight: 'none',
                    },
                    '.ms-Button--primary': {
                        borderTopRightRadius: '0',
                        borderBottomRightRadius: '0',
                        border: 'none',
                        selectors: (_a = {},
                            _a[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                                color: 'WindowText',
                                backgroundColor: 'Window',
                                border: '1px solid WindowText',
                                borderRightWidth: '0',
                                MsHighContrastAdjust: 'none',
                            },
                            _a),
                    },
                    '.ms-Button--primary + .ms-Button': {
                        border: 'none',
                        selectors: (_b = {},
                            _b[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                                border: '1px solid WindowText',
                                borderLeftWidth: '0',
                            },
                            _b),
                    },
                },
            },
        ],
        splitButtonContainerHovered: {
            selectors: {
                '.ms-Button--primary': {
                    selectors: (_c = {},
                        _c[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                            color: 'Window',
                            backgroundColor: 'Highlight',
                        },
                        _c),
                },
                '.ms-Button.is-disabled': {
                    color: semanticColors.buttonTextDisabled,
                    selectors: (_d = {},
                        _d[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                            color: 'GrayText',
                            borderColor: 'GrayText',
                            backgroundColor: 'Window',
                        },
                        _d),
                },
            },
        },
        splitButtonContainerChecked: {
            selectors: {
                '.ms-Button--primary': {
                    selectors: (_e = {},
                        _e[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                            color: 'Window',
                            backgroundColor: 'WindowText',
                            MsHighContrastAdjust: 'none',
                        },
                        _e),
                },
            },
        },
        splitButtonContainerCheckedHovered: {
            selectors: {
                '.ms-Button--primary': {
                    selectors: (_f = {},
                        _f[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                            color: 'Window',
                            backgroundColor: 'WindowText',
                            MsHighContrastAdjust: 'none',
                        },
                        _f),
                },
            },
        },
        splitButtonContainerFocused: {
            outline: 'none!important',
        },
        splitButtonMenuButton: {
            padding: 6,
            height: 'auto',
            boxSizing: 'border-box',
            borderRadius: 0,
            borderTopRightRadius: effects.roundedCorner2,
            borderBottomRightRadius: effects.roundedCorner2,
            border: "1px solid " + palette.neutralSecondaryAlt,
            borderLeft: 'none',
            outline: 'transparent',
            userSelect: 'none',
            display: 'inline-block',
            textDecoration: 'none',
            textAlign: 'center',
            cursor: 'pointer',
            verticalAlign: 'top',
            width: 32,
            marginLeft: -1,
            marginTop: 0,
            marginRight: 0,
            marginBottom: 0,
        },
        splitButtonDivider: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, splitButtonDividerBaseStyles), { selectors: (_g = {},
                _g[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                    backgroundColor: 'WindowText',
                },
                _g) }),
        splitButtonDividerDisabled: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, splitButtonDividerBaseStyles), { selectors: (_h = {},
                _h[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                    backgroundColor: 'GrayText',
                },
                _h) }),
        splitButtonMenuButtonDisabled: {
            pointerEvents: 'none',
            border: 'none',
            selectors: (_j = {
                    ':hover': {
                        cursor: 'default',
                    },
                    '.ms-Button--primary': {
                        selectors: (_k = {},
                            _k[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                                color: 'GrayText',
                                borderColor: 'GrayText',
                                backgroundColor: 'Window',
                            },
                            _k),
                    },
                    '.ms-Button-menuIcon': {
                        selectors: (_l = {},
                            _l[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                                color: 'GrayText',
                            },
                            _l),
                    }
                },
                _j[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                    color: 'GrayText',
                    border: '1px solid GrayText',
                    backgroundColor: 'Window',
                },
                _j),
        },
        splitButtonFlexContainer: {
            display: 'flex',
            height: '100%',
            flexWrap: 'nowrap',
            justifyContent: 'center',
            alignItems: 'center',
        },
        splitButtonContainerDisabled: {
            outline: 'none',
            border: 'none',
            selectors: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])((_m = {}, _m[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                color: 'GrayText',
                borderColor: 'GrayText',
                backgroundColor: 'Window',
            }, _m), Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["getEdgeChromiumNoHighContrastAdjustSelector"])()),
        },
    };
    return Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["concatStyleSets"])(splitButtonStyles, customStyles);
});
//# sourceMappingURL=SplitButton.styles.js.map

/***/ }),

/***/ "CgVw":
/*!************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/containers/SitePermissions/SitePermissionsStateManager.js ***!
  \************************************************************************************************************************************************************************************************************************/
/*! exports provided: PermissionLevel, SitePermissionsPanelStateManager, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PermissionLevel", function() { return PermissionLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsPanelStateManager", function() { return SitePermissionsPanelStateManager; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ms_odsp_datasources_lib_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-datasources/lib/interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_datasources_lib_SitePermissions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-datasources/lib/SitePermissions */ "h827");
/* harmony import */ var _ms_odsp_datasources_lib_dataSources_hub_HubDataSource__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-datasources/lib/dataSources/hub/HubDataSource */ "Zean");
/* harmony import */ var _ms_odsp_datasources_lib_dataSources_site_SiteDataSource__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-datasources/lib/dataSources/site/SiteDataSource */ "6GcD");
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ms/odsp-datasources/lib/Permissions */ "jH+c");
/* harmony import */ var _ms_odsp_datasources_lib_Sharing__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms/odsp-datasources/lib/Sharing */ "ERuR");
/* harmony import */ var _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/SitePermissionsPanel/SitePermissionsPanel.resx */ "kGUQ");
/* harmony import */ var _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/Features */ "8G1T");
// OneDrive:IgnoreCodeCoverage
var _a, _b, _c, _d, _e, _f;












var SYSTEM_ACCOUNT_LOGIN = 'SHAREPOINT\\system';
var GROUP_CLAIM_LOGIN_SUBSTRING = 'federateddirectoryclaimprovider';
var GROUP_OWNER_CLAIM_LOGIN_SUBSTRING = '_o';
var HubSitePermissionSyncExperience = { ODB: 1145 };
/**
 * @public
 */
var PermissionLevel;
(function (PermissionLevel) {
    PermissionLevel[PermissionLevel["Limited"] = 0] = "Limited";
    PermissionLevel[PermissionLevel["FullControl"] = 1] = "FullControl";
    PermissionLevel[PermissionLevel["Edit"] = 2] = "Edit";
    PermissionLevel[PermissionLevel["Read"] = 3] = "Read";
})(PermissionLevel || (PermissionLevel = {}));
var ROLE_PERMISSION_MAP = (_a = {},
    _a[1 /* Guest */] = PermissionLevel.Limited,
    _a[2 /* Reader */] = PermissionLevel.Read,
    _a[3 /* Contributor */] = PermissionLevel.Edit,
    _a[4 /* WebDesigner */] = PermissionLevel.Edit,
    _a[6 /* Edit */] = PermissionLevel.Edit,
    _a[5 /* Administrator */] = PermissionLevel.FullControl,
    _a);
var DEFAULT_PERMISSION_ID = {
    FullControl: 1073741829,
    Edit: 1073741830,
    Read: 1073741826
};
var ROLE_TYPE_PERMISSION_ID_MAP = (_b = {},
    _b[5 /* Administrator */] = DEFAULT_PERMISSION_ID.FullControl,
    _b[6 /* Edit */] = DEFAULT_PERMISSION_ID.Edit,
    _b[2 /* Reader */] = DEFAULT_PERMISSION_ID.Read,
    _b);
var DEFAULT_PERMISSION_ORDER = {
    FullControl: 1,
    Edit: 48,
    Read: 128,
    Customized: 2147483647
};
var ROLE_TYPE_PERMISSION_ORDER_MAP = (_c = {},
    _c[5 /* Administrator */] = DEFAULT_PERMISSION_ORDER.FullControl,
    _c[6 /* Edit */] = DEFAULT_PERMISSION_ORDER.Edit,
    _c[2 /* Reader */] = DEFAULT_PERMISSION_ORDER.Read,
    _c);
var PERMISSION_STRINGS = (_d = {},
    _d[PermissionLevel.Edit] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.edit,
    _d[PermissionLevel.FullControl] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.fullControl,
    _d[PermissionLevel.Read] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.read,
    _d);
var GROUP_NAME_STRINGS = (_e = {},
    _e[PermissionLevel.FullControl] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.siteOwners,
    _e[PermissionLevel.Edit] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.siteMembers,
    _e[PermissionLevel.Read] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.siteVisitors,
    _e);
var HUB_GROUP_NAME_STRINGS = (_f = {},
    _f[PermissionLevel.Read] = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.hubVisitors,
    _f);
/**
 * This class manages the state of the SitePermissionsPanel component.
 * @public
 */
var SitePermissionsPanelStateManager = /** @class */ (function () {
    function SitePermissionsPanelStateManager(params) {
        var _this = this;
        this._permissionGroups = {};
        this._shareSite = function (users, shouldSendEmail, emailMessage) {
            var permissionGroups = _this._assignUsersToPermssionGroup(users);
            var shareSitePromises = [];
            if (!_this._sharingSiteProvider) {
                _this._sharingSiteProvider = new _ms_odsp_datasources_lib_Sharing__WEBPACK_IMPORTED_MODULE_9__["SharingSiteProvider"]({ pageContext: _this._pageContext });
            }
            for (var key in permissionGroups) {
                if (permissionGroups[key] && permissionGroups[key].length > 0) {
                    // Sharing for external user only work with empty roleValue until VSO: 933525 fixed.
                    var roleVaue = _this._pageContext.isExternalGuestUser &&
                        _this._permissionLevelOfCurrentUser !== PermissionLevel.FullControl
                        ? ''
                        : "group:" + _this._permissionGroups[key];
                    shareSitePromises.push(_this._sharingSiteProvider.shareSite(permissionGroups[key], {
                        siteUrl: _this._pageContext.webAbsoluteUrl,
                        roleValue: roleVaue,
                        sendEmail: _this._params.isEmailSharingEnabled && shouldSendEmail,
                        message: emailMessage,
                        requireSignIn: true
                    }));
                }
            }
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_5__["default"].all(shareSitePromises).then(function (results) {
                _this._setState({ showShareSiteOnly: !!_this._params.shouldLoadSharePanelOnly });
                _this._fetchUpdatedPermissions();
                return true;
            });
        };
        this._onCancel = function () {
            if (!_this._params.shouldLoadSharePanelOnly) {
                _this._setState({ showShareSiteOnly: false });
            }
            else {
                _this._setState({ shouldDismissPanel: true });
            }
            _this._fetchUpdatedPermissions();
        };
        this._saveHubPermissionSync = function (enabled) {
            _this._setState({
                showHubSyncToggleSpinner: true
            });
            var updateSyncSettingPromise = undefined;
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__["Engagement"].logData({
                name: enabled ? 'SitePermissionsPanel.EnableHubPermSync' : 'SitePermissionsPanel.DisableHubPermSync',
                extraData: {
                    isHubSite: _this._pageContext.isHubSite
                }
            });
            if (_this._pageContext.isHubSite) {
                // fetch fresh hub site data and patch in property value
                updateSyncSettingPromise = _this._hubDataSource
                    .getHubSite(_this._pageContext.hubSiteId)
                    .then(function (hubSite) {
                    return _this._hubDataSource.updateHubSite(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, hubSite), { description: hubSite.description || '', enablePermissionsSync: enabled }));
                });
            }
            else {
                updateSyncSettingPromise = _this._siteDataSource.setCanSyncHubSitePermissionsProperty(enabled);
            }
            if (updateSyncSettingPromise) {
                updateSyncSettingPromise.then(function () {
                    // reload hub site permissions after setting change
                    _this._fetchHubPermissions();
                }, function (error) {
                    _this._setState({
                        hubPivotErrorString: _this._getErrorString(error),
                        showHubSyncToggleSpinner: false
                    });
                });
            }
        };
        this._addHubUser = function (user) {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__["Engagement"].logData({ name: 'SitePermissions.AddHubUser' });
            _this._setState({
                showHubSyncToggleSpinner: true
            });
            // there is only one hub group for now and it is always the visitor group
            var visitorGroup = _this._hubSiteGroups && _this._hubSiteGroups[0];
            if (visitorGroup && user) {
                _this._sitePermissionsDataSource
                    .ensureUser(user.userId)
                    .then(function (webUser) {
                    return _this._sitePermissionsDataSource.addUserToGroup(String(visitorGroup.id), webUser.loginName);
                })
                    .then(function () {
                    // reload the groups
                    _this._fetchHubPermissions();
                }, function (error) {
                    _this._setState({
                        hubPivotErrorString: _this._getErrorString(error),
                        showHubSyncToggleSpinner: false
                    });
                });
            }
        };
        this._shareSiteOnlyOnClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__["Engagement"].logData({ name: 'SitePermissions.ShareSiteOnlyClick' });
            _this._setState({
                showShareSiteOnly: !_this._params.sitePermissionsPanelContainer.state.showShareSiteOnly,
                showSavingSpinner: false
            });
        };
        this._goToOutlookClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__["Engagement"].logData({ name: 'SitePermissions.GoToOutlookClick' });
            _this._params.goToOutlookOnClick();
        };
        var pageContext = params.pageContext;
        this._params = params;
        this._pageContext = pageContext;
        this._sitePermissionsProvider = new _ms_odsp_datasources_lib_SitePermissions__WEBPACK_IMPORTED_MODULE_2__["SitePermissionsProvider"](pageContext);
        this._sitePermissionsDataSource = new _ms_odsp_datasources_lib_SitePermissions__WEBPACK_IMPORTED_MODULE_2__["SitePermissionsDataSource"](pageContext);
        this._sharingSiteProvider = new _ms_odsp_datasources_lib_Sharing__WEBPACK_IMPORTED_MODULE_9__["SharingSiteProvider"]({ pageContext: pageContext });
        this._hubDataSource = new _ms_odsp_datasources_lib_dataSources_hub_HubDataSource__WEBPACK_IMPORTED_MODULE_3__["HubDataSource"](pageContext);
        this._siteDataSource = new _ms_odsp_datasources_lib_dataSources_site_SiteDataSource__WEBPACK_IMPORTED_MODULE_4__["SiteDataSource"](pageContext);
        this._permissionLevelOfCurrentUser = this._getPermissionLevelOfCurrentUser();
        this._isGroup = Object(_ms_odsp_datasources_lib_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__["isGroupWebContext"])(this._pageContext);
        this._isHubSitePermSyncEnabled =
            _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_11__["default"].isFeatureEnabled(HubSitePermissionSyncExperience) && pageContext.isSiteAdmin;
    }
    SitePermissionsPanelStateManager.prototype.componentDidMount = function () {
        var _this = this;
        this._fetchUpdatedPermissions();
        this._getPickerSettings().then(function () {
            _this._params.sitePermissionsPanelContainer.setState({
                pickerSettings: _this._pickerSettings
            });
        });
    };
    SitePermissionsPanelStateManager.prototype.componentWillUnmount = function () {
        // Leave it here until we remove it from SitePermissionsPanelContainer in odsp-next and sp-client to avoid break change.
    };
    SitePermissionsPanelStateManager.prototype.getRenderProps = function (lpcModuleLoader, lpcModuleCustomWaiter) {
        var params = this._params;
        var state = params.sitePermissionsPanelContainer.state;
        var strings = _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a;
        var enablePermissionsSync = state && state.hubSite && state.hubSite.enablePermissionsSync;
        var enableHubPermissionsSync = undefined;
        if (this._isHubSitePermSyncEnabled) {
            if (this._pageContext.isHubSite) {
                enableHubPermissionsSync = enablePermissionsSync;
            }
            else {
                enableHubPermissionsSync = state && state.canSyncHubSitePermissions;
            }
        }
        return {
            sitePermissions: state && state.sitePermissions,
            showShareSiteOnly: !!(state && state.showShareSiteOnly),
            showSavingSpinner: !!(state && state.showSavingSpinner),
            menuItems: this._getPanelAddMenu(),
            pageContext: this._pageContext,
            onSave: this._shareSite,
            onCancel: this._onCancel,
            saveButton: params.shouldLoadSharePanelOnly ? strings.share : strings.addButton,
            advancedPermSettingsUrl: params.advancedPermSettingsUrl,
            permissionStrings: PERMISSION_STRINGS,
            sitePermissionsContextualMenuItems: this._getSitePermissionsContextualMenuItems(),
            goToOutlookOnClick: params.goToOutlookOnClick,
            addMemberDefaultPermissionLevel: params.addMemberDefaultPermissionLevel,
            sitePreviewLoader: params.sitePreviewLoader,
            shouldDismissPanel: state && state.shouldDismissPanel,
            shouldLoadSharePanelOnly: params.shouldLoadSharePanelOnly,
            onShareSiteCallback: this._shareSiteOnlyOnClick.bind(this),
            permissionLevelOfCurrentUser: this._permissionLevelOfCurrentUser,
            isEmailSharingEnabled: params.isEmailSharingEnabled,
            pickerSettings: state && state.pickerSettings,
            hasCustomizedGroups: state && state.hasCustomizedGroups,
            lpcModuleLoader: lpcModuleLoader,
            lpcModuleCustomWaiter: lpcModuleCustomWaiter,
            strings: strings,
            peoplePickerDataSource: params.peoplePickerDataSource,
            isDefaultPermissionsChanged: state && state.isDefaultPermissionsChanged,
            showHubSyncToggleSpinner: state && state.showHubSyncToggleSpinner,
            // hub site pivot render props
            showHubPivot: this._isHubSitePermSyncEnabled && (this._pageContext.isHubSite || enablePermissionsSync),
            onSaveHubPermissionSync: this._saveHubPermissionSync,
            enableHubPermissionsSync: enableHubPermissionsSync,
            isHubSite: this._pageContext.isHubSite,
            hubSiteTitle: state && state.hubSite && state.hubSite.name,
            hubSyncControlsAreDisabled: state && state.hubSite && !this._pageContext.isHubSite && !state.hubSite.enablePermissionsSync,
            hubSitePermissions: state && state.hubSitePermissions,
            onAddHubUserCallback: this._addHubUser,
            hubPivotErrorString: state && state.hubPivotErrorString
        };
    };
    SitePermissionsPanelStateManager.prototype._setState = function (state) {
        this._params.sitePermissionsPanelContainer.setState(state);
    };
    SitePermissionsPanelStateManager.prototype._fetchUpdatedPermissions = function () {
        var _this = this;
        this._sitePermissionsProvider
            .getAssociatedPermissionGroups()
            .then(function (permGroups) {
            _this._associatedGroups = permGroups;
        })
            .then(function () {
            return _this._checkIfDefaultPermissionsChanged(_this._associatedGroups);
        })
            .then(function (isDefaultPermissionsChanged) {
            _this._isDefaultPermissionsChanged = isDefaultPermissionsChanged;
            if (isDefaultPermissionsChanged) {
                _this._setState({
                    sitePermissions: undefined,
                    menuItems: _this._getPanelAddMenu(),
                    isDefaultPermissionsChanged: true,
                    hasCustomizedGroups: _this._hasCustomizedGroups
                });
            }
            else {
                _this._sitePermissionsProvider
                    .getSiteGroupsAndUsersWithPermissions(_this._associatedGroups)
                    .then(function (groupsAndUsers) {
                    if (!groupsAndUsers || !groupsAndUsers.length) {
                        return;
                    }
                    for (var _i = 0, groupsAndUsers_1 = groupsAndUsers; _i < groupsAndUsers_1.length; _i++) {
                        var group = groupsAndUsers_1[_i];
                        var permission = ROLE_PERMISSION_MAP[group.roleType];
                        _this._permissionGroups[permission] = group.id;
                    }
                    var sitePermissionsProps = groupsAndUsers.map(function (group) {
                        var permission = ROLE_PERMISSION_MAP[group.roleType];
                        return {
                            personas: _this._getPersona(group),
                            title: GROUP_NAME_STRINGS[permission] || '',
                            permLevel: permission,
                            permLevelTitle: _this._permissionLevelOfCurrentUser !== PermissionLevel.FullControl
                                ? ''
                                : PERMISSION_STRINGS[permission] || '',
                            emptyGroupText: _this._params.emptyGroupText
                        };
                    });
                    _this._setState({
                        sitePermissions: sitePermissionsProps,
                        menuItems: _this._getPanelAddMenu(),
                        isDefaultPermissionsChanged: false,
                        hasCustomizedGroups: _this._hasCustomizedGroups
                    });
                });
            }
        });
        this._fetchHubPermissions();
    };
    SitePermissionsPanelStateManager.prototype._fetchHubPermissions = function () {
        var _this = this;
        if (this._isHubSitePermSyncEnabled && this._pageContext.hubSiteId) {
            this._setState({
                showHubSyncToggleSpinner: true
            });
            var allPromises = [];
            var hubSiteResult_1;
            var isSyncEnabledResult_1;
            var sitePermissionsPropsResult_1;
            var getHubSitePromise = this._hubDataSource
                .getHubSite(this._pageContext.hubSiteId)
                .then(function (hubSite) {
                hubSiteResult_1 = hubSite;
            });
            allPromises.push(getHubSitePromise);
            if (!this._pageContext.isHubSite) {
                // this site is associated to a hub site, also retrieve the sync opt-in flag from SPSite.CanSyncHubSitePermissions
                var getSyncOptInPromise = this._siteDataSource
                    .getCanSyncHubSitePermissionsProperty(true /*forceRefresh*/)
                    .then(function (isSyncEnabled) {
                    isSyncEnabledResult_1 = isSyncEnabled;
                });
                allPromises.push(getSyncOptInPromise);
            }
            var getHubGroupsPromise = this._sitePermissionsProvider
                .getHubSitePermissionGroups()
                .then(function (permGroups) {
                _this._hubSiteGroups = permGroups;
                return _this._sitePermissionsProvider
                    .getSiteGroupsAndUsersWithPermissions(permGroups)
                    .then(function (groupsAndUsers) {
                    if (!groupsAndUsers || !groupsAndUsers.length) {
                        return;
                    }
                    sitePermissionsPropsResult_1 = groupsAndUsers.map(function (group) {
                        var permission = ROLE_PERMISSION_MAP[group.roleType];
                        return {
                            personas: _this._getPersona(group, true /*isHubUser*/),
                            title: HUB_GROUP_NAME_STRINGS[permission] || '',
                            permLevel: permission,
                            permLevelTitle: PERMISSION_STRINGS[permission] || '',
                            emptyGroupText: _this._params.emptyGroupText,
                            hideHeader: true
                        };
                    });
                });
            });
            allPromises.push(getHubGroupsPromise);
            _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_5__["default"].all(allPromises).then(function () {
                _this._setState({
                    hubSite: hubSiteResult_1,
                    canSyncHubSitePermissions: isSyncEnabledResult_1,
                    hubSitePermissions: sitePermissionsPropsResult_1,
                    showHubSyncToggleSpinner: false,
                    hubPivotErrorString: undefined
                });
            }, function (error) {
                _this._setState({
                    hubPivotErrorString: _this._getErrorString(error),
                    showHubSyncToggleSpinner: false
                });
            });
        }
    };
    SitePermissionsPanelStateManager.prototype._checkIfDefaultPermissionsChanged = function (permGroups) {
        var _this = this;
        // Only doing this check when flight is on and current user has full control or managePermissions
        if (this._permissionLevelOfCurrentUser === PermissionLevel.FullControl ||
            _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].hasPermission(this._pageContext.webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].managePermissions)) {
            var isDefaultPermissionChangedForGroup_1 = function (permGroup, roleAssignments) {
                //No need to check for group site, the default permission can't be changed for group site.
                if (_this._isGroup) {
                    return false;
                }
                var roleDefinitionBindings = roleAssignments[permGroup.id];
                var hasDefaultRole = false;
                var hasHigherPermissionRoleOrCustomizedRole = false;
                for (var _i = 0, roleDefinitionBindings_1 = roleDefinitionBindings; _i < roleDefinitionBindings_1.length; _i++) {
                    var roleDefinition = roleDefinitionBindings_1[_i];
                    var defaultPermissionId = ROLE_TYPE_PERMISSION_ID_MAP[permGroup.roleType];
                    if (roleDefinition.id === defaultPermissionId) {
                        hasDefaultRole = true;
                    }
                    else if (roleDefinition.order < ROLE_TYPE_PERMISSION_ORDER_MAP[permGroup.roleType] ||
                        roleDefinition.order === DEFAULT_PERMISSION_ORDER.Customized) {
                        // If the roleDefinition is not default value, check if the role permission is higher than default permission.
                        // The lower the number the higher the permission:
                        // FullControl: 1
                        // Design: 32
                        // Edit: 48
                        // Contribute: 64
                        // Read: 128
                        // LimitedAccess: 160
                        // Customized: 2147483647
                        hasHigherPermissionRoleOrCustomizedRole = true;
                        break;
                    }
                }
                // The default permission is considering changed, if there is no default role, or there is higher permission role or customized permission role.
                // In the case that lower permission role and default permission role co-exist, the default permission stands.
                return !hasDefaultRole || hasHigherPermissionRoleOrCustomizedRole;
            };
            return this._sitePermissionsProvider
                .getRoleAssignments()
                .then(function (roleAssignments) {
                if (!roleAssignments) {
                    return false;
                }
                // If the role assignments larger than 3, it means there are additional groups or people.
                _this._hasCustomizedGroups = Object.keys(roleAssignments).length > 3 ? true : false;
                // Do this check only when flight is on.
                for (var _i = 0, permGroups_1 = permGroups; _i < permGroups_1.length; _i++) {
                    var permGroup = permGroups_1[_i];
                    if (isDefaultPermissionChangedForGroup_1(permGroup, roleAssignments)) {
                        return true;
                    }
                }
                return false;
            })
                .catch(function (error) {
                return false;
            });
        }
        else {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_5__["default"].wrap(false);
        }
    };
    SitePermissionsPanelStateManager.prototype._getPersona = function (spUser, isHubUser) {
        if (isHubUser === void 0) { isHubUser = false; }
        var personas = [];
        if (spUser.users) {
            for (var _i = 0, _a = spUser.users; _i < _a.length; _i++) {
                var user = _a[_i];
                var isGroupLoginName = this._isGroupLoginName(user.loginName);
                if (user.loginName !== SYSTEM_ACCOUNT_LOGIN) {
                    var permissionLevel = this._permissionLevelOfCurrentUser;
                    personas.push({
                        name: this._getUserTitle(user),
                        email: user.email,
                        imageUrl: user.urlImage,
                        initialsColor: user.initialsColor,
                        imageInitials: user.imageInitials,
                        groupId: isGroupLoginName && this._parseGroupId(user.loginName),
                        type: isGroupLoginName && 2 /* group */,
                        // Only displays the permission change context meanu when the persona is for the user isn't group claim owner and one of the two conditions satisfied:
                        // 1. the permission level of current user is FullControl
                        // 2. the permission level of current user is Edit and persona is for a user has edit permission role (Becasue the current user with Edit permission can only add or remove users with edit role).
                        menuItems: !this._isGroupClaimOwner(user.loginName) &&
                            (permissionLevel === PermissionLevel.FullControl ||
                                (permissionLevel === PermissionLevel.Edit &&
                                    ROLE_PERMISSION_MAP[user.roleType] === PermissionLevel.Edit))
                            ? this._getUserPermissions(user, spUser, isHubUser)
                            : undefined
                    });
                }
            }
        }
        else if (spUser.currentUserCannotViewMembers) {
            personas.push({
                currentUserCannotViewMembers: true
            });
        }
        return personas;
    };
    // TODO: localize strings and filter out the current role
    SitePermissionsPanelStateManager.prototype._getUserPermissions = function (user, group, isHubUser) {
        var _this = this;
        if (isHubUser === void 0) { isHubUser = false; }
        var menuItems = [];
        if (isHubUser && !!this._pageContext.hubSiteId && !this._pageContext.isHubSite) {
            // if associated site then this is read-only, hide menu items
            return null;
        }
        if (!isHubUser) {
            menuItems = this._getSitePermissionsContextualMenuItems().filter(function (item) { return item.permissionLevel !== ROLE_PERMISSION_MAP[group.roleType]; });
            var _loop_1 = function (menuItem) {
                menuItem.onClick = function () { return _this._updatePerm(user, menuItem.permissionLevel); };
            };
            for (var _i = 0, menuItems_1 = menuItems; _i < menuItems_1.length; _i++) {
                var menuItem = menuItems_1[_i];
                _loop_1(menuItem);
            }
        }
        if (!this._isGroupClaim(user.loginName)) {
            menuItems.push({
                name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.remove,
                key: 'remove',
                onClick: function (onClick) { return _this._removePerm(user); }
            });
        }
        return menuItems && menuItems.length > 0 ? menuItems : undefined;
    };
    SitePermissionsPanelStateManager.prototype._getSitePermissionsContextualMenuItems = function () {
        var _this = this;
        var menuItems = [
            { name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.read, key: 'read', permissionLevel: PermissionLevel.Read },
            {
                name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.fullControl,
                key: 'full',
                permissionLevel: PermissionLevel.FullControl
            },
            { name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.edit, key: 'edit', permissionLevel: PermissionLevel.Edit }
        ];
        if (this._permissionLevelOfCurrentUser === PermissionLevel.Edit) {
            // If current user has Edit permission, the menu can only contain Edit permission.
            menuItems = [menuItems[2]];
        }
        else if (this._permissionLevelOfCurrentUser === PermissionLevel.Read) {
            // If current user has Read permission, the menu can only contain Read permission.
            menuItems = [menuItems[0]];
        }
        // Remove the groups that may have been deleted.
        return menuItems.filter(function (item) { return _this._permissionGroups[item.permissionLevel]; });
    };
    SitePermissionsPanelStateManager.prototype._updatePerm = function (spUser, permissionLevel) {
        var _this = this;
        var newRoleId = this._permissionGroups[permissionLevel];
        this._sitePermissionsDataSource.addUserToGroup(newRoleId, spUser.loginName).then(function () {
            _this._sitePermissionsDataSource
                .removeFromGroupById(spUser.principalId.toString(), spUser.id.toString())
                .then(function () {
                _this._fetchUpdatedPermissions();
            });
        });
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_6__["Engagement"].logData({ name: 'SitePermissionsPanel.UpdatePermTo' + PermissionLevel[permissionLevel] });
    };
    SitePermissionsPanelStateManager.prototype._removePerm = function (spUser) {
        var _this = this;
        this._sitePermissionsDataSource
            .removeFromGroupById(spUser.principalId.toString(), spUser.id.toString())
            .then(function () {
            _this._fetchUpdatedPermissions();
        });
    };
    SitePermissionsPanelStateManager.prototype._getUserTitle = function (user) {
        return this._isGroupClaim(user.loginName)
            ? this._isGroupClaimOwner(user.loginName)
                ? _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_7__["format"](_components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.groupOwners, this._pageContext.webTitle)
                : _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_7__["format"](_components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.groupMembers, this._pageContext.webTitle)
            : user.title;
    };
    SitePermissionsPanelStateManager.prototype._isGroupLoginName = function (loginName) {
        return loginName && loginName.indexOf(GROUP_CLAIM_LOGIN_SUBSTRING) !== -1;
    };
    SitePermissionsPanelStateManager.prototype._isGroupClaim = function (loginName) {
        return this._isGroupLoginName(loginName) && loginName.indexOf(this._pageContext.groupId) !== -1;
    };
    SitePermissionsPanelStateManager.prototype._isGroupClaimOwner = function (loginName) {
        return this._isGroupClaim(loginName) && loginName.indexOf(GROUP_OWNER_CLAIM_LOGIN_SUBSTRING) !== -1;
    };
    SitePermissionsPanelStateManager.prototype._parseGroupId = function (loginName) {
        var groupId;
        if (this._isGroupClaim(loginName)) {
            groupId = this._pageContext.groupId;
        }
        else if (this._isGroupLoginName(loginName)) {
            var startIndex = loginName.indexOf(GROUP_CLAIM_LOGIN_SUBSTRING) + GROUP_CLAIM_LOGIN_SUBSTRING.length + 1;
            groupId = loginName.substring(startIndex, startIndex + 36);
        }
        return groupId;
    };
    SitePermissionsPanelStateManager.prototype._getPanelAddMenu = function () {
        var menuItems = [];
        if (this._isGroup) {
            menuItems.push({
                name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.addMembersToGroup,
                key: 'addToGroup',
                onClick: this._goToOutlookClick,
                className: 'SitePermissionsPanel-addToGroup' // using in lieu of data-automationid
            });
        }
        if (!this._isDefaultPermissionsChanged) {
            menuItems.push({
                name: _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.shareSiteOnly,
                key: 'shareSiteOnly',
                onClick: this._shareSiteOnlyOnClick,
                className: 'SitePermissionsPanel-shareSiteOnly' // using in lieu of data-automationid
            });
        }
        return menuItems.length > 0 ? menuItems : undefined;
    };
    SitePermissionsPanelStateManager.prototype._getPermissionLevelOfCurrentUser = function () {
        var webPermMasks = this._pageContext.webPermMasks;
        if (_ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].hasPermission(webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].manageWeb)) {
            return PermissionLevel.FullControl;
        }
        else if (_ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].hasPermission(webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].editListItems)) {
            return PermissionLevel.Edit;
        }
        else if (_ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].hasPermission(webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_8__["PermissionMask"].viewPages)) {
            return PermissionLevel.Read;
        }
        return undefined;
    };
    SitePermissionsPanelStateManager.prototype._assignUsersToPermssionGroup = function (users) {
        var _a;
        var permissionGroups = (_a = {},
            _a[PermissionLevel.FullControl] = [],
            _a[PermissionLevel.Edit] = [],
            _a[PermissionLevel.Read] = [],
            _a);
        for (var _i = 0, users_1 = users; _i < users_1.length; _i++) {
            var user = users_1[_i];
            var defaultPermission = this._params.addMemberDefaultPermissionLevel;
            var availablePermissions = this._getSitePermissionsContextualMenuItems().map(function (value) { return value.permissionLevel; });
            var currentPermissionLevel = user.permissionLevel;
            // Assign the default permission level based on defaultPermission and availablePermissions, if currentPermissionLevel is not exist for this user.
            if (!currentPermissionLevel) {
                if (defaultPermission &&
                    this._permissionGroups[defaultPermission] &&
                    availablePermissions.indexOf(defaultPermission) > -1) {
                    currentPermissionLevel = defaultPermission;
                }
                else if (this._permissionGroups[PermissionLevel.Edit] &&
                    availablePermissions.indexOf(PermissionLevel.Edit) > -1) {
                    currentPermissionLevel = PermissionLevel.Edit;
                }
                else if (this._permissionGroups[PermissionLevel.Read] &&
                    availablePermissions.indexOf(PermissionLevel.Read) > -1) {
                    currentPermissionLevel = PermissionLevel.Read;
                }
                else {
                    currentPermissionLevel = PermissionLevel.FullControl;
                }
            }
            if (permissionGroups[currentPermissionLevel]) {
                permissionGroups[currentPermissionLevel].push(user);
            }
        }
        return permissionGroups;
    };
    SitePermissionsPanelStateManager.prototype._getPickerSettings = function () {
        var _this = this;
        return this._sharingSiteProvider
            .getSharingSettings()
            .then(function (sharingSettings) {
            _this._pickerSettings = sharingSettings.pickerProperties;
        })
            .catch(function (error) {
            // cause promise to recover so Promise.all() will succeed
            _this._pickerSettings = undefined;
        });
    };
    SitePermissionsPanelStateManager.prototype._getErrorString = function (error) {
        // safely get error message if available (or a generic message)
        if (error && error.message) {
            return String(error.message.value || error.message);
        }
        return _components_SitePermissionsPanel_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_10___default.a.genericHubPivotError;
    };
    return SitePermissionsPanelStateManager;
}());

/* harmony default export */ __webpack_exports__["default"] = (SitePermissionsPanelStateManager);
//# sourceMappingURL=SitePermissionsStateManager.js.map

/***/ }),

/***/ "DRdk":
/*!******************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/WebTemplateType.js ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: WebTemplateType, isTeamSiteLike, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebTemplateType", function() { return WebTemplateType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isTeamSiteLike", function() { return isTeamSiteLike; });
// OneDrive:IgnoreCodeCoverage
/**
 * SharePoint SPWeb (subsite) template values, from WebTemplate in sts\stsom\Core\spwebtemplate.cs
 */
var WebTemplateType;
(function (WebTemplateType) {
    WebTemplateType[WebTemplateType["invalid"] = -1] = "invalid";
    /** Team collaboration site */
    WebTemplateType[WebTemplateType["teamSite"] = 1] = "teamSite";
    /** Meeting workspace site */
    WebTemplateType[WebTemplateType["meetings"] = 2] = "meetings";
    WebTemplateType[WebTemplateType["centralAdmin"] = 3] = "centralAdmin";
    WebTemplateType[WebTemplateType["wiki"] = 4] = "wiki";
    WebTemplateType[WebTemplateType["documentCenter"] = 7] = "documentCenter";
    WebTemplateType[WebTemplateType["blog"] = 9] = "blog";
    WebTemplateType[WebTemplateType["tenantAdmin"] = 16] = "tenantAdmin";
    WebTemplateType[WebTemplateType["app"] = 17] = "app";
    WebTemplateType[WebTemplateType["appCatalog"] = 18] = "appCatalog";
    /** Mysite personal web */
    WebTemplateType[WebTemplateType["mySite"] = 21] = "mySite";
    WebTemplateType[WebTemplateType["subgroup"] = 39] = "subgroup";
    WebTemplateType[WebTemplateType["publishingPortal"] = 52] = "publishingPortal";
    WebTemplateType[WebTemplateType["mySiteHost"] = 54] = "mySiteHost";
    WebTemplateType[WebTemplateType["enterpriseWiki"] = 56] = "enterpriseWiki";
    WebTemplateType[WebTemplateType["group"] = 64] = "group";
    /** POINTPUBLISHINGPERSONAL#1 aka Blog site */
    WebTemplateType[WebTemplateType["pointPublishingPersonal"] = 66] = "pointPublishingPersonal";
    /** SITEPAGEPUBLISHING#0 aka Communications site */
    WebTemplateType[WebTemplateType["sitePagePublishing"] = 68] = "sitePagePublishing";
    WebTemplateType[WebTemplateType["teamChannel"] = 69] = "teamChannel";
    WebTemplateType[WebTemplateType["projectWebAppSite"] = 6221] = "projectWebAppSite";
    WebTemplateType[WebTemplateType["contentCenter"] = 6001] = "contentCenter";
})(WebTemplateType || (WebTemplateType = {}));
/**
 * Returns true if the SPWeb Site is not ODB or Group site.
 */
function isTeamSiteLike(template) {
    'use strict';
    var templateEnum = Number(template);
    return templateEnum !== WebTemplateType.mySite && templateEnum !== WebTemplateType.group;
}
/* harmony default export */ __webpack_exports__["default"] = (WebTemplateType);
//# sourceMappingURL=WebTemplateType.js.map

/***/ }),

/***/ "DkMg":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequestsDialog.scss.js ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-AccessRequestsDialogContainer{max-width:100%;width:1082px;max-height:100%;height:750px}.ms-AccessRequestsDialogListContainer{display:inline}.ms-AccessRequestsDialog-inner{display:inline-block;height:90%;max-height:80%}.ms-AccessRequestsDialog-content{display:inline}.ms-AccessRequestsDialogContent{max-width:100%;width:1082px;max-height:100%;height:750px;overflow-x:hidden;overflow-y:hidden;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.ms-AccessRequestsDialogHeader{margin-top:5px;padding-right:60px}[dir='ltr'] .ms-AccessRequestsDialogHeader{margin-left:30px}[dir='rtl'] .ms-AccessRequestsDialogHeader{margin-right:30px}.ms-AccessRequestsDialogTitle{font-size:20px;font-weight:600}.ms-AccessReqestsDialogListContainer{margin-top:50px;height:100%}.ms-AccessRequestsList-FileIcon{vertical-align:middle;max-height:32px;max-width:32px}.ms-AccessRequestsDialog-ContactContainer{margin-top:20px;font-size:14px}[dir='ltr'] .ms-AccessRequestsDialog-ContactContainer{margin-left:20px}[dir='rtl'] .ms-AccessRequestsDialog-ContactContainer{margin-right:20px}[dir='ltr'] .ms-AccessRequestsDialog-ContactIcon{margin-right:8px}[dir='rtl'] .ms-AccessRequestsDialog-ContactIcon{margin-left:8px}.ms-AccessRequestsDialog-ContactLine{margin-bottom:8px}.ms-AccessRequestsDialog-TopLine{margin-top:16px}.ms-AccessRequestsDialogHeader{max-width:1150px}.ms-AccessRequestsDialog-Footer{max-height:16px}.ms-AccessRequestsDialog-AdvancedSettings-link{position:relative;float:left}.ms-AccessRequestsDialog-ClassicExperience-link{position:relative;float:right}\n" }]);
//# sourceMappingURL=AccessRequestsDialog.scss.js.map

/***/ }),

/***/ "ERuR":
/*!***********************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/Sharing.js ***!
  \***********************************************************************************************************************************************************************/
/*! exports provided: UpdatePermissionsRole, SharingLinkKind, SharingLinkType, SharingInfoType, SharingRole, AccessStatus, ClientId, Error, Category, Mode, SharePermission, SharingAudience, SharingAudienceTemplates, SharingRoleV3, SharingLinkExpressOptions, SharingLinkStatus, SharingScope, SharingSiteProvider, EDIT_ROLE, VIEW_ROLE, OWNER_ROLE, HasInheritedLinksUI, SharingDataSource, parseSharingLinkInfo, SharingProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./interfaces/sharing/SharingInterfaces */ "dR+P");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UpdatePermissionsRole", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["UpdatePermissionsRole"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkKind", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingLinkKind"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkType", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingLinkType"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingInfoType", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingInfoType"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingRole", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingRole"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AccessStatus", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["AccessStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ClientId", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["ClientId"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Error", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["Error"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["Category"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Mode", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["Mode"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharePermission", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharePermission"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingAudience", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingAudience"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingAudienceTemplates", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingAudienceTemplates"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingRoleV3", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingRoleV3"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkExpressOptions", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingLinkExpressOptions"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkStatus", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingLinkStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingScope", function() { return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_0__["SharingScope"]; });

/* harmony import */ var _providers_sharing_SharingSiteProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./providers/sharing/SharingSiteProvider */ "mLh3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingSiteProvider", function() { return _providers_sharing_SharingSiteProvider__WEBPACK_IMPORTED_MODULE_1__["SharingSiteProvider"]; });

/* harmony import */ var _interfaces_sharing_enums_SharingInfoType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./interfaces/sharing/enums/SharingInfoType */ "wN6/");
/* empty/unused harmony star reexport *//* harmony import */ var _interfaces_sharing_enums_SharingLinkKind__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./interfaces/sharing/enums/SharingLinkKind */ "+W9d");
/* empty/unused harmony star reexport *//* harmony import */ var _interfaces_sharing_enums_SharingLinkType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./interfaces/sharing/enums/SharingLinkType */ "0m3a");
/* empty/unused harmony star reexport *//* harmony import */ var _interfaces_sharing_enums_SharingRole__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./interfaces/sharing/enums/SharingRole */ "8DW8");
/* empty/unused harmony star reexport *//* harmony import */ var _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dataSources/sharing/SharingDataSource */ "wZUW");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "EDIT_ROLE", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["EDIT_ROLE"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "VIEW_ROLE", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["VIEW_ROLE"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OWNER_ROLE", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["OWNER_ROLE"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HasInheritedLinksUI", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["HasInheritedLinksUI"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingDataSource", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["SharingDataSource"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "parseSharingLinkInfo", function() { return _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_6__["parseSharingLinkInfo"]; });

/* harmony import */ var _providers_sharing_SharingProvider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./providers/sharing/SharingProvider */ "OFQw");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingProvider", function() { return _providers_sharing_SharingProvider__WEBPACK_IMPORTED_MODULE_7__["SharingProvider"]; });









//# sourceMappingURL=Sharing.js.map

/***/ }),

/***/ "FAc7":
/*!************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-utilities@29.7.9_5d977624104b06c7bcaa2de974ff51f1/node_modules/@ms/odsp-utilities/lib/icons/ItemType.js ***!
  \************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-core-bundle */ "K9kD");
/* harmony import */ var _ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ms_odsp_core_bundle__WEBPACK_IMPORTED_MODULE_0__["ItemType"]; });

// Loading @ms/odsp-utilities/./lib/icons/ItemType.js



/***/ }),

/***/ "G4wV":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-utilities@29.7.9_5d977624104b06c7bcaa2de974ff51f1/node_modules/@ms/odsp-utilities/lib/path/Path.js ***!
  \*******************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
// Loading @ms/odsp-utilities/./lib/path/Path.js


/***/ }),

/***/ "HGZC":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-2.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-2\"",
            src: "url('" + baseUrl + "fabric-icons-2-63c99abf.woff') format('woff')"
        },
        icons: {
            'Picture': '\uE8B9',
            'ChromeClose': '\uE8BB',
            'ShowResults': '\uE8BC',
            'Message': '\uE8BD',
            'CalendarDay': '\uE8BF',
            'CalendarWeek': '\uE8C0',
            'MailReplyAll': '\uE8C2',
            'Read': '\uE8C3',
            'Cut': '\uE8C6',
            'PaymentCard': '\uE8C7',
            'Copy': '\uE8C8',
            'Important': '\uE8C9',
            'MailReply': '\uE8CA',
            'GotoToday': '\uE8D1',
            'Font': '\uE8D2',
            'FontColor': '\uE8D3',
            'FolderFill': '\uE8D5',
            'Permissions': '\uE8D7',
            'DisableUpdates': '\uE8D8',
            'Unfavorite': '\uE8D9',
            'Italic': '\uE8DB',
            'Underline': '\uE8DC',
            'Bold': '\uE8DD',
            'MoveToFolder': '\uE8DE',
            'Dislike': '\uE8E0',
            'Like': '\uE8E1',
            'AlignCenter': '\uE8E3',
            'OpenFile': '\uE8E5',
            'ClearSelection': '\uE8E6',
            'FontDecrease': '\uE8E7',
            'FontIncrease': '\uE8E8',
            'FontSize': '\uE8E9',
            'CellPhone': '\uE8EA',
            'RepeatOne': '\uE8ED',
            'RepeatAll': '\uE8EE',
            'Calculator': '\uE8EF',
            'Library': '\uE8F1',
            'PostUpdate': '\uE8F3',
            'NewFolder': '\uE8F4',
            'CalendarReply': '\uE8F5',
            'UnsyncFolder': '\uE8F6',
            'SyncFolder': '\uE8F7',
            'BlockContact': '\uE8F8',
            'Accept': '\uE8FB',
            'BulletedList': '\uE8FD',
            'Preview': '\uE8FF',
            'News': '\uE900',
            'Chat': '\uE901',
            'Group': '\uE902',
            'World': '\uE909',
            'Comment': '\uE90A',
            'DockLeft': '\uE90C',
            'DockRight': '\uE90D',
            'Repair': '\uE90F',
            'Accounts': '\uE910',
            'Street': '\uE913',
            'RadioBullet': '\uE915',
            'Stopwatch': '\uE916',
            'Clock': '\uE917',
            'WorldClock': '\uE918',
            'AlarmClock': '\uE919',
            'Photo': '\uE91B',
            'ActionCenter': '\uE91C',
            'Hospital': '\uE91D',
            'Timer': '\uE91E',
            'FullCircleMask': '\uE91F',
            'LocationFill': '\uE920',
            'ChromeMinimize': '\uE921',
            'ChromeRestore': '\uE923',
            'Annotation': '\uE924',
            'Fingerprint': '\uE928',
            'Handwriting': '\uE929',
            'ChromeFullScreen': '\uE92D',
            'Completed': '\uE930',
            'Label': '\uE932',
            'FlickDown': '\uE935',
            'FlickUp': '\uE936',
            'FlickLeft': '\uE937',
            'FlickRight': '\uE938',
            'MiniExpand': '\uE93A',
            'MiniContract': '\uE93B',
            'Streaming': '\uE93E',
            'MusicInCollection': '\uE940',
            'OneDriveLogo': '\uE941',
            'CompassNW': '\uE942',
            'Code': '\uE943',
            'LightningBolt': '\uE945',
            'CalculatorMultiply': '\uE947',
            'CalculatorAddition': '\uE948',
            'CalculatorSubtract': '\uE949',
            'CalculatorPercentage': '\uE94C',
            'CalculatorEqualTo': '\uE94E',
            'PrintfaxPrinterFile': '\uE956',
            'StorageOptical': '\uE958',
            'Communications': '\uE95A',
            'Headset': '\uE95B',
            'Health': '\uE95E',
            'Webcam2': '\uE960',
            'FrontCamera': '\uE96B',
            'ChevronUpSmall': '\uE96D'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-2.js.map

/***/ }),

/***/ "JEr8":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/IconButton/IconButton.styles.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: getStyles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyles", function() { return getStyles; });
/* harmony import */ var _Styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../Styling */ "PL71");
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../Utilities */ "mkpW");
/* harmony import */ var _BaseButton_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../BaseButton.styles */ "RO1u");
/* harmony import */ var _SplitButton_SplitButton_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../SplitButton/SplitButton.styles */ "CRDm");




var getStyles = Object(_Utilities__WEBPACK_IMPORTED_MODULE_1__["memoizeFunction"])(function (theme, customStyles) {
    var _a;
    var baseButtonStyles = Object(_BaseButton_styles__WEBPACK_IMPORTED_MODULE_2__["getStyles"])(theme);
    var splitButtonStyles = Object(_SplitButton_SplitButton_styles__WEBPACK_IMPORTED_MODULE_3__["getStyles"])(theme);
    var palette = theme.palette, semanticColors = theme.semanticColors;
    var iconButtonStyles = {
        root: {
            padding: '0 4px',
            width: '32px',
            height: '32px',
            backgroundColor: 'transparent',
            border: 'none',
            color: semanticColors.link,
        },
        rootHovered: {
            color: palette.themeDarkAlt,
            backgroundColor: palette.neutralLighter,
            selectors: (_a = {},
                _a[_Styling__WEBPACK_IMPORTED_MODULE_0__["HighContrastSelector"]] = {
                    borderColor: 'Highlight',
                    color: 'Highlight',
                },
                _a),
        },
        rootHasMenu: {
            width: 'auto',
        },
        rootPressed: {
            color: palette.themeDark,
            backgroundColor: palette.neutralLight,
        },
        rootExpanded: {
            color: palette.themeDark,
            backgroundColor: palette.neutralLight,
        },
        rootChecked: {
            color: palette.themeDark,
            backgroundColor: palette.neutralLight,
        },
        rootCheckedHovered: {
            color: palette.themeDark,
            backgroundColor: palette.neutralQuaternaryAlt,
        },
        rootDisabled: {
            color: palette.neutralTertiaryAlt,
        },
    };
    return Object(_Styling__WEBPACK_IMPORTED_MODULE_0__["concatStyleSets"])(baseButtonStyles, iconButtonStyles, splitButtonStyles, customStyles);
});
//# sourceMappingURL=IconButton.styles.js.map

/***/ }),

/***/ "Jdg/":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/providers/sitePermissions/SitePermissionsProvider.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissionsProvider, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsProvider", function() { return SitePermissionsProvider; });
/* harmony import */ var _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../dataSources/roleAssignments/SitePermissionsDataSource */ "S+Lk");
/* harmony import */ var _dataSources_siteHeader_AcronymAndColorDataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../dataSources/siteHeader/AcronymAndColorDataSource */ "l+sn");
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");



/**
 * Site Permissions provider
 */
var SitePermissionsProvider = /** @class */ (function () {
    function SitePermissionsProvider(context) {
        this._context = context;
        this._dataSource = new _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_0__["SitePermissionsDataSource"](this._context);
        this._siteHeaderLogoAcronymDataSource = new _dataSources_siteHeader_AcronymAndColorDataSource__WEBPACK_IMPORTED_MODULE_1__["default"](this._context);
    }
    SitePermissionsProvider.prototype.getAssociatedPermissionGroups = function () {
        return this._dataSource.associatedPermissionGroups();
    };
    SitePermissionsProvider.prototype.getHubSitePermissionGroups = function () {
        return this._dataSource.hubSitePermissionGroups();
    };
    /**
     * @inheritdoc
     */
    SitePermissionsProvider.prototype.getSiteGroupsAndUsersWithPermissions = function (permGroups) {
        var _this = this;
        var groupsAndUsers = [];
        if (permGroups) {
            var promises = [];
            for (var key in permGroups) {
                var promise = this._getSiteGroupAndUsersById(permGroups[key], key, groupsAndUsers);
                promises.push(promise);
            }
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].all(promises).then(function () {
                return _this._fixUsersImage(groupsAndUsers);
            });
        }
        else {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].resolve(undefined);
        }
    };
    /**
     * @inheritdoc
     */
    SitePermissionsProvider.prototype.getSiteGroupsAndUsers = function (doNotExpandUsers) {
        return this._dataSource.getSiteGroupsAndUsers(doNotExpandUsers);
    };
    SitePermissionsProvider.prototype.getRoleAssignments = function () {
        return this._dataSource.getRoleAssignments().catch(function (error) {
            return undefined;
        });
    };
    SitePermissionsProvider.prototype._fixUsersImage = function (groups) {
        var incompleteUsers = [];
        if (groups && groups.length > 0) {
            groups.forEach(function (groupOrUser) {
                if (groupOrUser.users && groupOrUser.users.length > 0) {
                    groupOrUser.users.forEach(function (user) {
                        if (!user.urlImage) {
                            incompleteUsers.push(user);
                        }
                    });
                }
            });
            if (incompleteUsers && incompleteUsers.length > 0) {
                return this._siteHeaderLogoAcronymDataSource
                    .getAcronyms(incompleteUsers.map(function (user) { return user.title; }))
                    .then(function (acronyms) {
                    if (acronyms && acronyms.length > 0) {
                        for (var i = 0; i < acronyms.length; i++) {
                            incompleteUsers[i].imageInitials = acronyms[i].acronym;
                            incompleteUsers[i].initialsColor = _dataSources_siteHeader_AcronymAndColorDataSource__WEBPACK_IMPORTED_MODULE_1__["default"].decodeAcronymColor(acronyms[i].color);
                        }
                    }
                    return groups;
                }, function () {
                    return groups;
                } /*onReject*/);
            }
        }
        return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].resolve(groups);
    };
    SitePermissionsProvider.prototype._getSiteGroupAndUsersById = function (permGroup, key, groupsAndUsers) {
        return this._dataSource
            .getSiteGroupAndUsersById(permGroup.id)
            .then(function (group) {
            group.roleType = permGroup.roleType;
            if (group.users && group.users.length > 0) {
                group.users.forEach(function (user) {
                    user.roleType = group.roleType;
                });
            }
            groupsAndUsers[key] = group;
        })
            .catch(function (error) {
            if (error.status === 403 /* Access denied */) {
                permGroup.currentUserCannotViewMembers = true;
                groupsAndUsers[key] = permGroup;
            }
            else {
                throw error;
            }
        });
    };
    return SitePermissionsProvider;
}());

/* harmony default export */ __webpack_exports__["default"] = (SitePermissionsProvider);
//# sourceMappingURL=SitePermissionsProvider.js.map

/***/ }),

/***/ "LtPq":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/getFileTypeIconAsHTMLString.js ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: getFileTypeIconAsHTMLString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconAsHTMLString", function() { return getFileTypeIconAsHTMLString; });
/* harmony import */ var _initializeFileTypeIcons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./initializeFileTypeIcons */ "3r9+");
/* harmony import */ var _getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getFileTypeIconProps */ "1EGi");


/**
 * Given the `fileTypeIconOptions`, this function returns the DOM element for the `FileTypeIcon`
 * as an HTML string. Similar to `getFileTypeIconProps`, this also accepts the same type of object
 * but rather than returning the `iconName`, this returns the entire DOM element as a string.
 * @param options
 * @param baseUrl - optionally provide a custom CDN base url to fetch icons from
 */
function getFileTypeIconAsHTMLString(options, baseUrl) {
    if (baseUrl === void 0) { baseUrl = _initializeFileTypeIcons__WEBPACK_IMPORTED_MODULE_0__["DEFAULT_BASE_URL"]; }
    var extension = options.extension, _a = options.size, size = _a === void 0 ? _getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__["DEFAULT_ICON_SIZE"] : _a, type = options.type, imageFileType = options.imageFileType;
    var baseIconName = Object(_getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__["getFileTypeIconNameFromExtensionOrType"])(extension, type); // eg: docx
    var baseSuffix = Object(_getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__["getFileTypeIconSuffix"])(size, imageFileType); // eg: 96_3x_svg or 96_png
    var suffixArray = baseSuffix.split('_'); // eg: ['96', '3x', 'svg']
    var src;
    if (suffixArray.length === 3) {
        /** suffix is of type 96_3x_svg  - it has a pixel ratio > 1*/
        src = "" + baseUrl + size + "_" + suffixArray[1] + "/" + baseIconName + "." + suffixArray[2];
        return "<img src=\"" + src + "\" height=\"100%\" width=\"100%\" />";
    }
    else if (suffixArray.length === 2) {
        /** suffix is of type 96_svg  - it has a pixel ratio of 1*/
        src = "" + baseUrl + size + "/" + baseIconName + "." + suffixArray[1];
        return "<img src=\"" + src + "\" alt=\"\" />";
    }
}
//# sourceMappingURL=getFileTypeIconAsHTMLString.js.map

/***/ }),

/***/ "M4X7":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/index.js ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipPanel, GroupMembershipMenu, GroupMembershipList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GroupMembershipPanel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GroupMembershipPanel */ "Z+E6");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipPanel", function() { return _GroupMembershipPanel__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipPanel"]; });

/* harmony import */ var _GroupMembershipMenu_GroupMembershipMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./GroupMembershipMenu/GroupMembershipMenu */ "zlrR");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipMenu", function() { return _GroupMembershipMenu_GroupMembershipMenu__WEBPACK_IMPORTED_MODULE_1__["GroupMembershipMenu"]; });

/* harmony import */ var _GroupMembershipList_GroupMembershipList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GroupMembershipList/GroupMembershipList */ "dnCp");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipList", function() { return _GroupMembershipList_GroupMembershipList__WEBPACK_IMPORTED_MODULE_2__["GroupMembershipList"]; });




//# sourceMappingURL=index.js.map

/***/ }),

/***/ "N28N":
/*!************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/Stack.js ***!
  \************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
// Loading office-ui-fabric-react/./lib/Stack.js


/***/ }),

/***/ "N96U":
/*!**************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/GroupMembershipPanel.js ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipPanel, GroupMembershipMenu, GroupMembershipList, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_GroupMembershipPanel_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/GroupMembershipPanel/index */ "M4X7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipPanel", function() { return _components_GroupMembershipPanel_index__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipPanel"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipMenu", function() { return _components_GroupMembershipPanel_index__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipMenu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipList", function() { return _components_GroupMembershipPanel_index__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipList"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _components_GroupMembershipPanel_index__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipPanel"]; });



//# sourceMappingURL=GroupMembershipPanel.js.map

/***/ }),

/***/ "OFQw":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/providers/sharing/SharingProvider.js ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: SharingProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingProvider", function() { return SharingProvider; });
/* harmony import */ var _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../dataSources/sharing/SharingDataSource */ "wZUW");

/**
 * SharingProvider to support V3 sharing in the list web part.
 */
var SharingProvider = /** @class */ (function () {
    function SharingProvider(params) {
        this._dataSource =
            params.sharingDataSource ||
                new _dataSources_sharing_SharingDataSource__WEBPACK_IMPORTED_MODULE_0__["SharingDataSource"]({
                    getParentListId: params.getParentListId,
                    pageContext: params.pageContext
                });
        this._itemProvider = params.itemProvider;
    }
    SharingProvider.prototype.getSharingInformation = function (item, expandPermissionsInformation, sharingLinkTemplates, baseUrl, addressBarLinkSettings) {
        return this._dataSource.getSharingInformation(item, expandPermissionsInformation, sharingLinkTemplates, baseUrl, addressBarLinkSettings);
    };
    SharingProvider.prototype.shareLink = function (context) {
        var _this = this;
        return this._dataSource.shareLink(context).then(function (sharingLink) {
            _this._invalidateItem(context.items[0]);
            return sharingLink;
        });
    };
    SharingProvider.prototype.unshareLink = function (context) {
        var _this = this;
        return this._dataSource.unshareLink(context).then(function (success) {
            _this._invalidateItem(context.item);
            return success;
        });
    };
    SharingProvider.prototype.updatePermissions2 = function (person, item, role) {
        var _this = this;
        return this._dataSource
            .updatePermissions2(person, item, role)
            .then(function (response) {
            _this._invalidateItem(item);
            return response;
        });
    };
    SharingProvider.prototype.updatePermissionsMultiple = function (people, item, role, notify, message) {
        var _this = this;
        return this._dataSource
            .updatePermissionsMultiple(people, item, role, notify, message)
            .then(function (response) {
            _this._invalidateItem(item);
            return response;
        });
    };
    SharingProvider.prototype.getClientId = function () {
        return this._dataSource.getClientId();
    };
    SharingProvider.prototype.parseRawSharingInformation = function (rawSharingInformation) {
        return this._dataSource.parseRawSharingInformation(rawSharingInformation);
    };
    SharingProvider.prototype.emailWithoutPermissioning = function (recipients, item, message, subject) {
        return this._dataSource
            .emailWithoutPermissioning(recipients, item, message, subject)
            .then(function (result) {
            return result;
        });
    };
    SharingProvider.prototype.checkPermissions = function (recipients, item) {
        return this._dataSource.checkPermissions(recipients, item);
    };
    SharingProvider.prototype.share = function (people, context, viaV3) {
        return this._dataSource.share(people, context).then(function (result) {
            return result;
        });
    };
    SharingProvider.prototype.setAddressBarLinkCapability = function (listItem, enable) {
        return this._dataSource.setAddressBarLinkCapability(listItem, enable);
    };
    SharingProvider.prototype._invalidateItem = function (item) {
        if (this._itemProvider && item && item.parent && item.parent.key) {
            this._itemProvider.invalidateItem(item.parent.key);
        }
    };
    return SharingProvider;
}());

//# sourceMappingURL=SharingProvider.js.map

/***/ }),

/***/ "Oz68":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-13.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-13\"",
            src: "url('" + baseUrl + "fabric-icons-13-c3989a02.woff') format('woff')"
        },
        icons: {
            'RectangularClipping': '\uF407',
            'TeamsLogo16': '\uF40A',
            'TeamsLogoFill16': '\uF40B',
            'Spacer': '\uF40D',
            'SkypeLogo16': '\uF40E',
            'SkypeForBusinessLogo16': '\uF40F',
            'SkypeForBusinessLogoFill16': '\uF410',
            'FilterSolid': '\uF412',
            'MailUndelivered': '\uF415',
            'MailTentative': '\uF416',
            'MailTentativeMirrored': '\uF417',
            'MailReminder': '\uF418',
            'ReceiptUndelivered': '\uF419',
            'ReceiptTentative': '\uF41A',
            'ReceiptTentativeMirrored': '\uF41B',
            'Inbox': '\uF41C',
            'IRMReply': '\uF41D',
            'IRMReplyMirrored': '\uF41E',
            'IRMForward': '\uF41F',
            'IRMForwardMirrored': '\uF420',
            'VoicemailIRM': '\uF421',
            'EventAccepted': '\uF422',
            'EventTentative': '\uF423',
            'EventTentativeMirrored': '\uF424',
            'EventDeclined': '\uF425',
            'IDBadge': '\uF427',
            'BackgroundColor': '\uF42B',
            'OfficeFormsLogoInverse16': '\uF433',
            'OfficeFormsLogo': '\uF434',
            'OfficeFormsLogoFill': '\uF435',
            'OfficeFormsLogo16': '\uF436',
            'OfficeFormsLogoFill16': '\uF437',
            'OfficeFormsLogoInverse24': '\uF43A',
            'OfficeFormsLogo24': '\uF43B',
            'OfficeFormsLogoFill24': '\uF43C',
            'PageLock': '\uF43F',
            'NotExecuted': '\uF440',
            'NotImpactedSolid': '\uF441',
            'FieldReadOnly': '\uF442',
            'FieldRequired': '\uF443',
            'BacklogBoard': '\uF444',
            'ExternalBuild': '\uF445',
            'ExternalTFVC': '\uF446',
            'ExternalXAML': '\uF447',
            'IssueSolid': '\uF448',
            'DefectSolid': '\uF449',
            'LadybugSolid': '\uF44A',
            'NugetLogo': '\uF44C',
            'TFVCLogo': '\uF44D',
            'ProjectLogo32': '\uF47E',
            'ProjectLogoFill32': '\uF47F',
            'ProjectLogo16': '\uF480',
            'ProjectLogoFill16': '\uF481',
            'SwayLogo32': '\uF482',
            'SwayLogoFill32': '\uF483',
            'SwayLogo16': '\uF484',
            'SwayLogoFill16': '\uF485',
            'ClassNotebookLogo32': '\uF486',
            'ClassNotebookLogoFill32': '\uF487',
            'ClassNotebookLogo16': '\uF488',
            'ClassNotebookLogoFill16': '\uF489',
            'ClassNotebookLogoInverse32': '\uF48A',
            'ClassNotebookLogoInverse16': '\uF48B',
            'StaffNotebookLogo32': '\uF48C',
            'StaffNotebookLogoFill32': '\uF48D',
            'StaffNotebookLogo16': '\uF48E',
            'StaffNotebookLogoFill16': '\uF48F',
            'StaffNotebookLogoInverted32': '\uF490',
            'StaffNotebookLogoInverted16': '\uF491',
            'KaizalaLogo': '\uF492',
            'TaskLogo': '\uF493',
            'ProtectionCenterLogo32': '\uF494',
            'GallatinLogo': '\uF496',
            'Globe2': '\uF49A',
            'Guitar': '\uF49B',
            'Breakfast': '\uF49C',
            'Brunch': '\uF49D',
            'BeerMug': '\uF49E',
            'Vacation': '\uF49F',
            'Teeth': '\uF4A0',
            'Taxi': '\uF4A1',
            'Chopsticks': '\uF4A2',
            'SyncOccurence': '\uF4A3',
            'UnsyncOccurence': '\uF4A4',
            'GIF': '\uF4A9',
            'PrimaryCalendar': '\uF4AE',
            'SearchCalendar': '\uF4AF',
            'VideoOff': '\uF4B0',
            'MicrosoftFlowLogo': '\uF4B1',
            'BusinessCenterLogo': '\uF4B2',
            'ToDoLogoBottom': '\uF4B3',
            'ToDoLogoTop': '\uF4B4',
            'EditSolid12': '\uF4B5',
            'EditSolidMirrored12': '\uF4B6',
            'UneditableSolid12': '\uF4B7',
            'UneditableSolidMirrored12': '\uF4B8',
            'UneditableMirrored': '\uF4B9',
            'AdminALogo32': '\uF4BA',
            'AdminALogoFill32': '\uF4BB',
            'ToDoLogoInverse': '\uF4BC'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-13.js.map

/***/ }),

/***/ "PgVY":
/*!*****************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/utilities-date-time@1.2.0/node_modules/@ms/utilities-date-time/lib/helpers.js ***!
  \*****************************************************************************************************************************************/
/*! exports provided: ONE_SECOND, ONE_MINUTE, TWO_MINUTES, ONE_HOUR, TWO_HOURS, ONE_DAY, TWO_DAYS, ONE_WEEK, ONE_MONTH, isSameDay, isSameMonth, isSameYear, isThisWeek, isLastWeek, getLastDayOfMonth, toLocaleDateString, toLocaleTimeString, isLastAFewDays, convert24Timeto00Format */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_SECOND", function() { return ONE_SECOND; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_MINUTE", function() { return ONE_MINUTE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TWO_MINUTES", function() { return TWO_MINUTES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_HOUR", function() { return ONE_HOUR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TWO_HOURS", function() { return TWO_HOURS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_DAY", function() { return ONE_DAY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TWO_DAYS", function() { return TWO_DAYS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_WEEK", function() { return ONE_WEEK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ONE_MONTH", function() { return ONE_MONTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSameDay", function() { return isSameDay; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSameMonth", function() { return isSameMonth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSameYear", function() { return isSameYear; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isThisWeek", function() { return isThisWeek; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isLastWeek", function() { return isLastWeek; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastDayOfMonth", function() { return getLastDayOfMonth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toLocaleDateString", function() { return toLocaleDateString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toLocaleTimeString", function() { return toLocaleTimeString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isLastAFewDays", function() { return isLastAFewDays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convert24Timeto00Format", function() { return convert24Timeto00Format; });
// number of milliseconds for the given timespan
var ONE_SECOND = 1000;
var ONE_MINUTE = 60 * ONE_SECOND;
var TWO_MINUTES = 2 * ONE_MINUTE;
var ONE_HOUR = 60 * ONE_MINUTE;
var TWO_HOURS = 2 * ONE_HOUR;
var ONE_DAY = 24 * ONE_HOUR;
var TWO_DAYS = 2 * ONE_DAY;
var ONE_WEEK = 7 * ONE_DAY;
// This is for friendly estimates.
var ONE_MONTH = 32 * ONE_DAY;
/**
 * True if the given dates have the same day month and year.
 */
function isSameDay(a, b) {
    return a.getDate() === b.getDate() && Math.abs(b.getTime() - a.getTime()) < ONE_DAY;
}
/**
 * True if the given dates have the same month and year.
 */
function isSameMonth(a, b) {
    return a.getFullYear() === b.getFullYear() && b.getMonth() === a.getMonth();
}
function isSameYear(a, b) {
    return a.getFullYear() === b.getFullYear();
}
/**
 * True if the date is on or between the first and last day of the current week. This uses the Date function getDay()
 * which returns the day of the week for the specified date according to local time, where 0 represents Sunday.
 * You can optionally specify the date to use as the current date/time.
 */
function isThisWeek(pastTime, now) {
    now = now || new Date();
    var start = new Date(now.getTime() - now.getDay() * ONE_DAY);
    var end = new Date(start.getTime() + ONE_WEEK - ONE_DAY);
    return start.getTime() <= pastTime.getTime() && pastTime.getTime() <= end.getTime();
}
/**
 * True if the date is on or between the first and last day of the previous week. This uses the Date function getDay()
 * which returns the day of the week for the specified date according to local time, where 0 represents Sunday.
 * You can optionally specify the date to use as the current date/time.
 */
function isLastWeek(pastTime, now) {
    now = now || new Date();
    var start = new Date(now.getTime() - now.getDay() * ONE_DAY - ONE_WEEK);
    var end = new Date(start.getTime() + ONE_WEEK - ONE_DAY);
    return start.getTime() <= pastTime.getTime() && pastTime.getTime() <= end.getTime();
}
/**
 * get the last day of the month based on the input date
 */
function getLastDayOfMonth(date) {
    var lastDay = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1, 0, 0, 0, 0));
    // To get the last day of the month we will increment the month
    lastDay.setUTCMonth(lastDay.getUTCMonth() + 1);
    // Then subtract a day
    lastDay.setUTCDate(lastDay.getUTCDate() - 1);
    // Then set the time to be the last second of the day
    lastDay.setUTCHours(23, 59, 59, 999);
    return lastDay;
}
/**
 * Gets a string of the given date in the given locale, falling back to the browser's
 * current/default locale if needed.
 */
function toLocaleDateString(date, language, options) {
    if (!date) {
        return undefined;
    }
    try {
        return date.toLocaleDateString(language, options);
    }
    catch (e) {
        // in case 'lang' is invalid for browser, let browser use its own logic for determining language
        return date.toLocaleDateString([], options);
    }
}
/**
 * Gets a string of the given time in the given locale, falling back to the browser's
 * current/default locale if needed.
 */
function toLocaleTimeString(date, language, options) {
    if (!date) {
        return undefined;
    }
    try {
        return date.toLocaleTimeString(language, options);
    }
    catch (e) {
        // in case 'lang' is invalid for browser, let browser use its own logic for determining language
        return date.toLocaleTimeString([], options);
    }
}
/**
 * True if the date is in the range of last a few days specified.
 * You can optionally specify the date to use as the current date/time.
 */
function isLastAFewDays(pastTime, duration, now) {
    now = now || new Date();
    var start = new Date(now.getTime() - ONE_DAY * duration);
    return start.getTime() <= pastTime.getTime() && pastTime.getTime() <= now.getTime();
}
/**
 * toLocaleTimeString defaults to display 24hr time as times 1:00 - 24:59
 * Converts 24:-- times to 00:--
 * Ideally, we'd use hourCycle to specify 'h23', but DateTimeFormatOptions does not yet support it
 * See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/DateTimeFormat
 */
function convert24Timeto00Format(time) {
    if (time.indexOf('24:') !== -1) {
        return time.replace('24:', '00:');
    }
    return time;
}
//# sourceMappingURL=helpers.js.map

/***/ }),

/***/ "QTSG":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/Error.js ***!
  \**********************************************************************************************************************************************************************************************/
/*! exports provided: Category, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return Category; });
var Error;
(function (Error) {
    Error[Error["authFailure"] = 1] = "authFailure";
    Error[Error["serverFailure"] = 2] = "serverFailure";
    Error[Error["invalidItem"] = 3] = "invalidItem";
    Error[Error["invalidWebAbsoluteUrl"] = 4] = "invalidWebAbsoluteUrl";
    Error[Error["generic"] = 5] = "generic";
    Error[Error["objectNotSupported"] = 6] = "objectNotSupported";
    Error[Error["invalidEmail"] = 7] = "invalidEmail";
    Error[Error["linkNoLongerAvailable"] = 8] = "linkNoLongerAvailable";
})(Error || (Error = {}));
/**
 * Which operation/API returned an error.
 */
var Category;
(function (Category) {
    Category[Category["generic"] = 0] = "generic";
    Category[Category["getSharingInformation"] = 1] = "getSharingInformation";
    Category[Category["shareLink"] = 2] = "shareLink";
    Category[Category["shareObject"] = 3] = "shareObject";
    Category[Category["permissions"] = 4] = "permissions";
    Category[Category["item"] = 5] = "item";
    Category[Category["me"] = 6] = "me";
    Category[Category["drive"] = 7] = "drive";
    Category[Category["invite"] = 8] = "invite";
})(Category || (Category = {}));
/* harmony default export */ __webpack_exports__["default"] = (Error);
//# sourceMappingURL=Error.js.map

/***/ }),

/***/ "QVZ7":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipPanel.resx.js ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"suggestionsAvailableAlertText":"Contact suggestions available.","peoplePickerToAddMembers":"People picker to add members"};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "Qcoe":
/*!*******************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/version.js ***!
  \*******************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _uifabric_set_version__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/set-version */ "Eyzw");
// Do not modify this file; it is generated as part of publish.
// The checked in version is a placeholder only and will not be updated.

Object(_uifabric_set_version__WEBPACK_IMPORTED_MODULE_0__["setVersion"])('@uifabric/file-type-icons', '7.6.23');
//# sourceMappingURL=version.js.map

/***/ }),

/***/ "RO1u":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/BaseButton.styles.js ***!
  \******************************************************************************************************************************************************************************************************/
/*! exports provided: getStyles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyles", function() { return getStyles; });
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Utilities */ "mkpW");
/* harmony import */ var _Styling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../Styling */ "PL71");


var noOutline = {
    outline: 0,
};
var iconStyle = function (fontSize) {
    return {
        fontSize: fontSize,
        margin: '0 4px',
        height: '16px',
        lineHeight: '16px',
        textAlign: 'center',
        flexShrink: 0,
    };
};
/**
 * Gets the base button styles. Note: because it is a base class to be used with the `mergeRules`
 * helper, it should have values for all class names in the interface. This let `mergeRules` optimize
 * mixing class names together.
 */
var getStyles = Object(_Utilities__WEBPACK_IMPORTED_MODULE_0__["memoizeFunction"])(function (theme) {
    var _a, _b;
    var semanticColors = theme.semanticColors, effects = theme.effects, fonts = theme.fonts;
    var border = semanticColors.buttonBorder;
    var disabledBackground = semanticColors.disabledBackground;
    var disabledText = semanticColors.disabledText;
    var buttonHighContrastFocus = {
        left: -2,
        top: -2,
        bottom: -2,
        right: -2,
        outlineColor: 'ButtonText',
    };
    return {
        root: [
            Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["getFocusStyle"])(theme, { inset: 1, highContrastStyle: buttonHighContrastFocus, borderColor: 'transparent' }),
            theme.fonts.medium,
            {
                boxSizing: 'border-box',
                border: '1px solid ' + border,
                userSelect: 'none',
                display: 'inline-block',
                textDecoration: 'none',
                textAlign: 'center',
                cursor: 'pointer',
                padding: '0 16px',
                borderRadius: effects.roundedCorner2,
                selectors: {
                    // IE11 workaround for preventing shift of child elements of a button when active.
                    ':active > *': {
                        position: 'relative',
                        left: 0,
                        top: 0,
                    },
                },
            },
        ],
        rootDisabled: [
            Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["getFocusStyle"])(theme, { inset: 1, highContrastStyle: buttonHighContrastFocus, borderColor: 'transparent' }),
            {
                backgroundColor: disabledBackground,
                borderColor: disabledBackground,
                color: disabledText,
                cursor: 'default',
                pointerEvents: 'none',
                selectors: {
                    ':hover': noOutline,
                    ':focus': noOutline,
                },
            },
        ],
        iconDisabled: {
            color: disabledText,
            selectors: (_a = {},
                _a[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                    color: 'GrayText',
                },
                _a),
        },
        menuIconDisabled: {
            color: disabledText,
            selectors: (_b = {},
                _b[_Styling__WEBPACK_IMPORTED_MODULE_1__["HighContrastSelector"]] = {
                    color: 'GrayText',
                },
                _b),
        },
        flexContainer: {
            display: 'flex',
            height: '100%',
            flexWrap: 'nowrap',
            justifyContent: 'center',
            alignItems: 'center',
        },
        description: {
            display: 'block',
        },
        textContainer: {
            flexGrow: 1,
            display: 'block',
        },
        icon: iconStyle(fonts.mediumPlus.fontSize),
        menuIcon: iconStyle(fonts.small.fontSize),
        label: {
            margin: '0 4px',
            lineHeight: '100%',
            display: 'block',
        },
        screenReaderText: _Styling__WEBPACK_IMPORTED_MODULE_1__["hiddenContentStyle"],
    };
});
//# sourceMappingURL=BaseButton.styles.js.map

/***/ }),

/***/ "RbLw":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SiteSharingSettingsPanel/SiteSharingSettingsPanel.scss.js ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-siteSharingSettingsPanel-toggle label,.ms-siteSharingSettingsPanel-textField label{font-weight:600}.ms-siteSharingSettingsPanel-container{margin-bottom:1px}.ms-siteSharingSettingsPanel-tenantAdminMembersCanShareMessage{font-size:12px;font-style:italic}[dir='ltr'] .ms-siteSharingSettingsPanel-discardButton{margin-left:8px}[dir='rtl'] .ms-siteSharingSettingsPanel-discardButton{margin-right:8px}.ms-siteSharingSettingsPanel-peoplePicker-error{margin:8px 0 0 0}[dir='rtl'] .ms-siteSharingSettingsPanel-peoplePicker-error{margin:8px 0 0 0}.ms-siteSharingSettingsPanel-sectionHeaderLabel{font-weight:600;font-size:16px}.ms-siteSharingSettings-BackButton{color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": ";position:absolute;left:16px;margin-top:7px}.SiteSharingSettingsPanelDescription{margin:8px 0px 16px}.ms-siteSharingSettingsPanel-Content{margin-bottom:4px}.ms-siteSharingSettingsPanel-Content [class^='applicationRole'],.ms-siteSharingSettingsPanel-Content [class*=' applicationRole']{margin-bottom:0}.ms-siteSharingSettingsPanel{margin-bottom:1px}.ms-siteSharingSettingsPanel .ms-Panel-closeButton{margin-top:20px}.ms-siteSharingSettingsPanel-Title-Container{margin-top:8px}.ms-siteSharingSettingsPanel-content{margin-bottom:1px}.ms-siteSharingSettingsPanel-Header{margin-bottom:1px}.ms-siteSharingSettingsPanel-Title{font-size:" }, { "theme": "xLargeFontSize", "defaultValue": "20px" }, { "rawString": ";font-weight:" }, { "theme": "xLargeFontWeight", "defaultValue": "600" }, { "rawString": ";position:absolute;left:58px;margin-top:9px}.ms-siteSharingSettingsPanel-HeaderText{font-size:" }, { "theme": "mediumFontSize", "defaultValue": "14px" }, { "rawString": "}.ms-siteSharingSettingsPanel-SharingPermissionsChoiceGroup{margin-bottom:24px}.ms-siteSharingSettingsPanel-AccessRequestsChoiceGroup{margin-bottom:24px}\n" }]);
//# sourceMappingURL=SiteSharingSettingsPanel.scss.js.map

/***/ }),

/***/ "S+Lk":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/roleAssignments/SitePermissionsDataSource.js ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: AssociatedPermGroups, HubSitePermGroups, SitePermissionsDataSource, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssociatedPermGroups", function() { return AssociatedPermGroups; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HubSitePermGroups", function() { return HubSitePermGroups; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsDataSource", function() { return SitePermissionsDataSource; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _base_DataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../base/DataSource */ "AfY0");
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/alternativeUrls/SPAlternativeUrls */ "vmDi");
/* harmony import */ var _ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__);
// OneDrive:IgnoreCodeCoverage





var NUMBER_OF_RETRIES = 3;
var addRoleAssignmentUrlTemplate = 'web/RoleAssignments/addroleassignment(principalid={0},roledefid={1})';
var removeRoleAssignmentUrlTemplate = 'web/RoleAssignments/removeroleassignment(principalid={0},roledefid={1})';
var removeFromGroupByIdUrlTemplate = 'web/sitegroups(id={0})/users/removebyid(id={1})';
var addUserToGroupUrlTemplate = 'web/sitegroups(id={0})/users';
var ensureUserUrlTemplate = "web/ensureUser";
var expandUserString = '$expand=Users';
/**
 * The enum of assciated permission groups, which get from associatedPermissionGroups().
 * The order is the important, this is the we want to render in UI.
 */
var AssociatedPermGroups;
(function (AssociatedPermGroups) {
    AssociatedPermGroups[AssociatedPermGroups["Owners"] = 0] = "Owners";
    AssociatedPermGroups[AssociatedPermGroups["Members"] = 1] = "Members";
    AssociatedPermGroups[AssociatedPermGroups["Vistors"] = 2] = "Vistors";
})(AssociatedPermGroups || (AssociatedPermGroups = {}));
/**
 * The enum of hub site permission groups, which get from hubSitePermissionGroups().
 * The order is the important, this is the we want to render in UI.
 */
var HubSitePermGroups;
(function (HubSitePermGroups) {
    HubSitePermGroups[HubSitePermGroups["Vistors"] = 0] = "Vistors";
})(HubSitePermGroups || (HubSitePermGroups = {}));
var SitePermissionsDataSource = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SitePermissionsDataSource, _super);
    function SitePermissionsDataSource(pageContext) {
        return _super.call(this, {
            dataSourceName: 'SitePermissionsDataSource'
        }, {
            pageContext: pageContext
        }) || this;
    }
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.getSiteGroupsAndUsers = function (doNotExpandUsers) {
        var _this = this;
        var expandUsersQueryString = doNotExpandUsers ? '' : '?' + expandUserString;
        return this.getData(function () { return _this._getUrl('web/SiteGroups' + expandUsersQueryString); }, function (responseText) {
            return _this._parseSiteGroupsAndUsers(responseText);
        }, 'GetSiteGroupsAndUsers', undefined, 'GET');
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.getSiteGroupAndUsersById = function (id) {
        var _this = this;
        return this.dataRequestor.getData({
            url: this._getUrl("web/SiteGroups/GetById(id=" + id + ")?" + expandUserString),
            parseResponse: function (responseText) {
                return _this._parseSiteGroupAndUsers(responseText);
            },
            qosName: 'GetSiteGroupAndUsersById',
            method: 'GET',
            noRedirect: true
        });
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.associatedPermissionGroups = function () {
        var _this = this;
        return this.getData(function () {
            return Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__["getSafeWebServerRelativeUrl"])(_this._pageContext) +
                '/_api/web?$expand=AssociatedOwnerGroup,AssociatedMemberGroup,AssociatedVisitorGroup';
        }, function (responseText) {
            return _this._parseAssociatedPermissionGroups(responseText);
        }, 'associatedPermissionGroups', undefined, 'GET');
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.hubSitePermissionGroups = function () {
        var _this = this;
        return this.getData(function () {
            return Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__["getSafeWebServerRelativeUrl"])(_this._pageContext) +
                '/_api/site?$expand=HubSiteSynchronizableVisitorGroup';
        }, function (responseText) {
            return _this._parseHubSitePermissionGroups(responseText);
        }, 'hubSitePermissionGroups', undefined, 'GET');
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.addRoleAssignment = function (principalid, roledefid) {
        var _this = this;
        var restUrl = function () {
            return _this._getUrl(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__["format"](addRoleAssignmentUrlTemplate, principalid, roledefid));
        };
        return this.getData(restUrl, undefined, 'AddRoleAssignment', undefined, 'POST', undefined, undefined, NUMBER_OF_RETRIES);
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.removeRoleAssignment = function (principalid, roledefid) {
        var _this = this;
        var restUrl = function () {
            return _this._getUrl(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__["format"](removeRoleAssignmentUrlTemplate, principalid, roledefid));
        };
        return this.getData(restUrl, undefined, 'RemoveRoleAssignment', undefined, 'POST', undefined, undefined, NUMBER_OF_RETRIES);
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.addUserToGroup = function (groupId, loginName) {
        var _this = this;
        var restUrl = function () {
            return _this._getUrl(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__["format"](addUserToGroupUrlTemplate, groupId));
        };
        var postBody = {
            __metadata: {
                type: 'SP.User'
            },
            LoginName: loginName
        };
        return this.getData(restUrl, undefined, 'addToGroupById', function () { return JSON.stringify(postBody); }, 'POST', undefined, undefined, NUMBER_OF_RETRIES);
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.removeFromGroupById = function (groupId, userId) {
        var _this = this;
        var restUrl = function () {
            return _this._getUrl(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_4__["format"](removeFromGroupByIdUrlTemplate, groupId, userId));
        };
        return this.getData(restUrl, undefined, 'removeFromGroupById', undefined, 'POST', undefined, undefined, NUMBER_OF_RETRIES);
    };
    /**
     * @inheritdoc
     */
    SitePermissionsDataSource.prototype.ensureUser = function (loginName) {
        var _this = this;
        var restUrl = function () {
            return _this._getUrl(ensureUserUrlTemplate);
        };
        var postBody = {
            logonName: loginName
        };
        return this.getData(restUrl, function (responseText) {
            return _this._parseSiteGroupAndUsers(responseText);
        }, 'ensureUser', function () { return JSON.stringify(postBody); }, 'POST', undefined /*additionalHeaders*/, undefined /*contentType*/, NUMBER_OF_RETRIES, true /*noRedirect*/);
    };
    SitePermissionsDataSource.prototype.getRoleAssignments = function () {
        var _this = this;
        return this.dataRequestor.getData({
            url: Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__["getSafeWebServerRelativeUrl"])(this._pageContext) +
                '/_api/web/RoleAssignments?$expand=RoleDefinitionBindings',
            parseResponse: function (responseText) {
                return _this._parseRoleAssignments(responseText);
            },
            qosName: 'GetRoleAssignments',
            method: 'GET',
            noRedirect: true
        });
    };
    /**
     * Parses and returns ISPUser objects
     */
    SitePermissionsDataSource.prototype._parseSiteGroupsAndUsers = function (responseText) {
        var _this = this;
        var src = JSON.parse(responseText);
        return src && src.d && src.d.results && src.d.results.length > 0
            ? src.d.results.map(function (o) {
                return _this._parseSPUser(o);
            })
            : responseText;
    };
    /**
     * Parses and returns one ISPUser object
     */
    SitePermissionsDataSource.prototype._parseSiteGroupAndUsers = function (responseText) {
        var src = JSON.parse(responseText);
        return src && src.d ? this._parseSPUser(src.d) : undefined;
    };
    SitePermissionsDataSource.prototype._parseSPUser = function (o) {
        var _this = this;
        return {
            id: o.Id,
            loginName: o.LoginName,
            principalType: o.PrincipalType,
            title: o.Title,
            email: o.Email,
            allowMembersEditMembership: o.AllowMembersEditMembership,
            allowRequestToJoinLeave: o.AllowRequestToJoinLeave,
            autoAcceptRequestToJoinLeave: o.AutoAcceptRequestToJoinLeave,
            description: o.Description,
            users: o.Users && o.Users.results && o.Users.results.length > 0
                ? o.Users.results.map(function (u) {
                    return {
                        id: u.Id,
                        principalId: o.Id,
                        email: u.Email,
                        loginName: u.LoginName,
                        isSiteAdmin: u.IsSiteAdmin,
                        principalType: u.PrincipalType,
                        title: u.Title,
                        urlImage: _this._fixUserImage(u)
                    };
                })
                : undefined
        };
    };
    /**
     * Parses and returns an array containing ISPUser objects
     */
    SitePermissionsDataSource.prototype._parseAssociatedPermissionGroups = function (responseText) {
        var src = JSON.parse(responseText);
        var associatedGroups = [];
        if (src &&
            src.d &&
            src.d.AssociatedMemberGroup &&
            src.d.AssociatedOwnerGroup &&
            src.d.AssociatedVisitorGroup) {
            associatedGroups[0 /* Owners */] = this._getSPUserFromAssociatedGroup(src.d.AssociatedOwnerGroup, 5 /* Administrator */);
            associatedGroups[1 /* Members */] = this._getSPUserFromAssociatedGroup(src.d.AssociatedMemberGroup, 6 /* Edit */);
            associatedGroups[2 /* Vistors */] = this._getSPUserFromAssociatedGroup(src.d.AssociatedVisitorGroup, 2 /* Reader */);
        }
        return associatedGroups;
    };
    /**
     * Parses and returns an array containing ISPUser objects
     */
    SitePermissionsDataSource.prototype._parseHubSitePermissionGroups = function (responseText) {
        var src = JSON.parse(responseText);
        var associatedGroups = [];
        if (src &&
            src.d &&
            src.d.HubSiteSynchronizableVisitorGroup &&
            src.d.HubSiteSynchronizableVisitorGroup.LoginName) {
            associatedGroups[0 /* Vistors */] = this._getSPUserFromAssociatedGroup(src.d.HubSiteSynchronizableVisitorGroup, 2 /* Reader */);
        }
        return associatedGroups;
    };
    SitePermissionsDataSource.prototype._getSPUserFromAssociatedGroup = function (associatedGroup, roleType) {
        var group = {
            id: associatedGroup.Id,
            loginName: associatedGroup.LoginName,
            principalType: associatedGroup.PrincipalType,
            title: associatedGroup.Title,
            roleType: roleType
        };
        return group;
    };
    SitePermissionsDataSource.prototype._parseRoleAssignments = function (responseText) {
        var roleAssignments = {};
        var src = JSON.parse(responseText);
        if (src && src.d && src.d.results && src.d.results.length > 0) {
            var results = src.d.results;
            for (var key in results) {
                var principalId = results[key] && results[key].PrincipalId;
                var roleDefinitionBindings = [];
                if (results[key] &&
                    results[key].RoleDefinitionBindings &&
                    results[key].RoleDefinitionBindings.results) {
                    var roleDefinitionBindingsResults = results[key].RoleDefinitionBindings.results;
                    for (var roleDefinitionKey in roleDefinitionBindingsResults) {
                        var roleDefinitionValue = roleDefinitionBindingsResults[roleDefinitionKey];
                        if (roleDefinitionValue) {
                            var spRoleDefinition = {
                                id: roleDefinitionValue.Id,
                                name: roleDefinitionValue.Name,
                                basePermissions: {
                                    High: roleDefinitionValue.BasePermissions.High,
                                    Low: roleDefinitionValue.BasePermissions.Low
                                },
                                description: roleDefinitionValue.Description,
                                hidden: roleDefinitionValue.Hidden,
                                order: roleDefinitionValue.Order,
                                roleTypeKind: roleDefinitionValue.RoleTypeKind
                            };
                            roleDefinitionBindings.push(spRoleDefinition);
                        }
                    }
                }
                roleAssignments[principalId] = roleDefinitionBindings;
            }
        }
        return roleAssignments;
    };
    SitePermissionsDataSource.prototype._fixUserImage = function (u) {
        if (u.PrincipalType === 1 && u.Email) {
            return Object(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_3__["getUserPhotoUrl"])(u.Email);
        }
        return undefined;
    };
    SitePermissionsDataSource.prototype._getUrl = function (op) {
        return this._pageContext.webAbsoluteUrl + "/_api/" + op;
    };
    return SitePermissionsDataSource;
}(_base_DataSource__WEBPACK_IMPORTED_MODULE_1__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (SitePermissionsDataSource);
//# sourceMappingURL=SitePermissionsDataSource.js.map

/***/ }),

/***/ "ScP4":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/shared-react-people-picker@1.1.20_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/shared-react-people-picker/lib/PeoplePickerItemWithMenu.scss.js ***!
  \***************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-PickerPersonaMenu-container{cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;margin-top:10px}.ms-PickerPersonaMenu-container .ms-PickerPersona-item{width:100%;display:-webkit-inline-box;display:-ms-inline-flexbox;display:inline-flex;vertical-align:top;margin:1px;white-space:nowrap;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.ms-PickerPersonaMenu-container .ms-PickerPersona-item:hover{background:#edebe9}.ms-PickerPersonaMenu-container .ms-PickerPersona-item .ms-PickerItem-sideContent{-webkit-box-flex:0;-ms-flex-positive:0;flex-grow:0;display:inline-block}.ms-PickerPersonaMenu-container .ms-PickerPersona-item .ms-PickerPersona-content{-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;vertical-align:middle;min-width:50px}.ms-PickerPersonaMenu-container .ms-PickerPersona-item .ms-PickerPersona-content .ms-Persona{height:auto}.ms-PickerPersonaMenu-container .ms-PickerPersona-item .ms-PickerPersona-content .ms-sitePerm-ContextMenu{line-height:0px}.ms-PickerPersonaMenu-container .ms-PickerPersona-item .ms-Persona-primaryText{margin-bottom:2px}\n" }]);
//# sourceMappingURL=PeoplePickerItemWithMenu.scss.js.map

/***/ }),

/***/ "T5Dc":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SiteSharingSettingsPanel/SiteSharingSettingsPanel.styles.js ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: getStyles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyles", function() { return getStyles; });
var getStyles = function (props) {
    return {
        root: [],
        label: {}
    };
};
//# sourceMappingURL=SiteSharingSettingsPanel.styles.js.map

/***/ }),

/***/ "T9Ft":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/sharing/SharingDataSourceHelper.js ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utilities_path_Path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities/path/Path */ "wIBa");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/Features */ "8G1T");



var SharingDataSourceHelper = /** @class */ (function () {
    function SharingDataSourceHelper(params) {
        this._itemUrlHelper = params.itemUrlHelper;
        this._sharingContextInformation = params.sharingContextInformation;
    }
    /**
     * Generates a URL for the item being referenced. Following types of references are supported:
     * 1. When "_sharingContextInformation" is passed in @see ISharingDataSourceHelperParams
     *  - `webAbsoluteUrl`, `listId` + `isListSharing = true`, if a list is being referenced
     *  - `webAbsoluteUrl`, `uniqueId` + `isFolder` flag
     *  - `webAbsoluteUrl`, `listId` + `uniqueId`
     *  - `webAbsoluteUrl`, `itemUrl`
     *  - `webAbsoluteUrl`, `listId`, `listItemId`
     *  - `listUrl`, `serverRelativeItemUrl`
     * 2. When "_sharingContextInformation" is used is NOT passed in @see ISharingDataSourceHelperParams,
     *    the URL is constructed based on the properties of @param item and @param  parentListId
     */
    SharingDataSourceHelper.prototype.getApiRoot = function (apiUrlHelper, item, parentListId) {
        // If this._sharingContextInformation exists, use that object to build API root.
        if (this._sharingContextInformation) {
            var _a = this._sharingContextInformation, isFolder = _a.isFolder, isListSharing = _a.isListSharing, itemUrl = _a.itemUrl, listId = _a.listId, listItemId = _a.listItemId, listUrl = _a.listUrl, resourceId = _a.resourceId, serverRelativeItemUrl = _a.serverRelativeItemUrl, uniqueId = _a.uniqueId, webAbsoluteUrl = _a.webAbsoluteUrl;
            // If list sharing needs to happen then expect to have the listId
            if (!this.isListSharingKillswitchActive() && isListSharing) {
                return apiUrlHelper
                    .build()
                    .webByUrl({
                    webUrl: webAbsoluteUrl
                })
                    .method('Lists', listId);
            }
            if (uniqueId) {
                // Files and folders can be referenced with their uniqueId
                if (listId) {
                    return apiUrlHelper
                        .build()
                        .webByUrl({ webUrl: webAbsoluteUrl })
                        .segment('lists')
                        .method('getbyid', listId)
                        .method('GetItemByUniqueId', uniqueId);
                }
                var apiName = isFolder ? 'GetFolderById' : 'GetFileById';
                var guidParam = { guid: uniqueId };
                return apiUrlHelper
                    .build()
                    .webByUrl({ webUrl: webAbsoluteUrl })
                    .method(apiName, guidParam)
                    .segment('ListItemAllFields');
            }
            else if (listUrl) {
                // If host passed listUrl + serverRelativeItemUrl, use those values to build root.
                return apiUrlHelper
                    .build()
                    .webByUrl({
                    listUrl: listUrl
                })
                    .method('GetListItem', serverRelativeItemUrl);
            }
            else if (itemUrl) {
                return (apiUrlHelper
                    .build()
                    .webByUrl({
                    webUrl: webAbsoluteUrl
                })
                    // ItemUrl in sharingContextInformation should always be decoded by the time it reaches here
                    .method('GetFileByUrl', this._encodingFixEnabled() ? itemUrl : _utilities_path_Path__WEBPACK_IMPORTED_MODULE_0__["canonicalizeUrl"](itemUrl))
                    .segment('ListItemAllFields'));
            }
            else if (listId && listItemId) {
                return apiUrlHelper
                    .build()
                    .webByUrl({
                    webUrl: webAbsoluteUrl
                })
                    .method('Lists', listId)
                    .method('GetItemById', listItemId);
            }
            else {
                /* webAbsoluteUrl */
                // Sync client must've passed a resource ID if the above references modes are not present.
                return apiUrlHelper
                    .build()
                    .webByUrl({
                    webUrl: webAbsoluteUrl
                })
                    .method('GetListItemByResourceId', resourceId);
            }
        }
        var itemUrlParts;
        if (item.properties.path) {
            itemUrlParts = this._itemUrlHelper.getUrlParts({
                path: item.properties.path
            });
        }
        else {
            itemUrlParts = this._itemUrlHelper.getItemUrlParts(item.key);
        }
        var apiUrl = apiUrlHelper.build().webByItemUrl(itemUrlParts).method('Lists', parentListId);
        if (!this.isListSharingKillswitchActive()) {
            if (!item.isRootFolder) {
                // Search results don't have ID, so use uniqueId.
                if (item.properties.ID) {
                    apiUrl = apiUrl.method('GetItemById', item.properties.ID);
                }
                else {
                    apiUrl = apiUrl.method('GetItemByUniqueId', item.properties.uniqueId);
                }
            }
        }
        else {
            // Search results don't have ID, so use uniqueId.
            if (item.properties.ID) {
                apiUrl = apiUrl.method('GetItemById', item.properties.ID);
            }
            else {
                apiUrl = apiUrl.method('GetItemByUniqueId', item.properties.uniqueId);
            }
        }
        return apiUrl;
    };
    SharingDataSourceHelper.prototype.getFileUrl = function (item) {
        return this._itemUrlHelper.getItemUrlParts(item.key).fullItemUrl;
    };
    /**
     * Ensures that the item has the required properties necessary to use
     * the securable sharing APIs.
     * @param item The item that's being shared.
     */
    SharingDataSourceHelper.prototype.canUseSecurable = function (item) {
        var properties = item.properties;
        // Obviously can't use if we have no properties.
        if (!properties) {
            return false;
        }
        // Need ID or unique ID to identify the item.
        // If its a root folder then make sure that it has the list uiqueId.
        var hasRequiredProperties;
        if (!this.isListSharingKillswitchActive()) {
            if (!item.isRootFolder) {
                hasRequiredProperties = !!properties.ID || !!properties.uniqueId;
            }
            else {
                hasRequiredProperties = !!item.list && !!item.list.id;
            }
        }
        else {
            hasRequiredProperties = !!properties.ID || !!properties.uniqueId;
        }
        return hasRequiredProperties;
    };
    /** Dedupes the list of principals based on loginName */
    SharingDataSourceHelper.getUniqueSharingPrincipals = function (principals) {
        if (!principals) {
            return undefined;
        }
        var seen = new Set();
        return principals.filter(function (principal) {
            if (seen.has(principal.loginName)) {
                return false;
            }
            // Note: In IE, Set.add() returns undefined.
            seen.add(principal.loginName);
            return true;
        });
    };
    SharingDataSourceHelper.prototype.isListSharingKillswitchActive = function () {
        return _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_1__["Killswitch"].isActivated('0d6f4387-b53c-48b9-aab6-66369291541d', '03/27/2020', 'List sharing changes in odsp-datasources');
    };
    SharingDataSourceHelper.prototype._encodingFixEnabled = function () {
        return _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_2__["default"].isFeatureEnabled({ ODB: 1331 });
    };
    return SharingDataSourceHelper;
}());
/* harmony default export */ __webpack_exports__["default"] = (SharingDataSourceHelper);
//# sourceMappingURL=SharingDataSourceHelper.js.map

/***/ }),

/***/ "UeHE":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/utilities/peoplePicker/GraphPeoplePickerHelper.js ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: PeoplePickerGraph, GraphPeoplePickerHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PeoplePickerGraph", function() { return PeoplePickerGraph; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GraphPeoplePickerHelper", function() { return GraphPeoplePickerHelper; });
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _ms_odsp_utilities_lib_features_FeatureOverrides__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/FeatureOverrides */ "iVgB");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Qos_event__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Qos.event */ "c09w");
/* harmony import */ var _ms_odsp_utilities_lib_models_store_BaseDataStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/models/store/BaseDataStore */ "18dJ");
/* harmony import */ var _ms_odsp_utilities_lib_models_store_DataStoreCachingType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-utilities/lib/models/store/DataStoreCachingType */ "EjJ3");





var PeoplePickerGraph = { ODB: 387 };
var STORE_KEY = 'PeoplePicker';
var DISABLE_GRAPH_KEY = 'DisableGraph';
var GraphPeoplePickerHelper = /** @class */ (function () {
    function GraphPeoplePickerHelper(params, dependencies) {
        this._pageContext = dependencies.pageContext;
        this._sharingContextInformation = dependencies.sharingContextInformation;
        this._oAuthTokenProvider = dependencies.oAuthTokenProvider;
        if (this._sharingContextInformation && this._sharingContextInformation.additionalTokens) {
            this._graphToken = this._sharingContextInformation.additionalTokens.graphToken;
        }
        this.initializeDataStore();
    }
    /**
     * Returns whether or not we are able to use Graph for people search. Graph calls can be disabled if the OAuth call
     * previously failed, if we are token authenticated (Acquire only supports cookie auth), or if the user isn't in the
     * A/B experiment to use Graph.
     */
    GraphPeoplePickerHelper.prototype.canUseGraph = function () {
        if (this._graphToken) {
            return true;
        }
        // We can't call Graph On-Prem
        if (this._pageContext && !this._pageContext.isSPO) {
            return false;
        }
        // Disable Graph if we're authenticated with an access token. Currently, Graph calls are only supported with cookie auth.
        if (this._pageContext && !!this._pageContext.authToken) {
            return false;
        }
        var canUseGraph = this._pageContext && this._oAuthTokenProvider && _ms_odsp_utilities_lib_features_FeatureOverrides__WEBPACK_IMPORTED_MODULE_1__["default"].isFeatureEnabled(PeoplePickerGraph);
        if (this._dataStore) {
            canUseGraph =
                canUseGraph && !this._dataStore.getValue(DISABLE_GRAPH_KEY, _ms_odsp_utilities_lib_models_store_DataStoreCachingType__WEBPACK_IMPORTED_MODULE_4__["default"].session);
        }
        return canUseGraph;
    };
    /**
     * Store flag to disable Graph calls in session storage so we don't keep making OAuth token calls that will error.
     * The calls are expensive and if the user is unable to call Graph we shouldn't keep trying. Since some errors are
     * recoverable outside the session, don't scope to something as long-lived as local storage.
     */
    GraphPeoplePickerHelper.prototype.disableGraphCallsForPicker = function () {
        this.initializeDataStore();
        this._dataStore.setValue(DISABLE_GRAPH_KEY, true, _ms_odsp_utilities_lib_models_store_DataStoreCachingType__WEBPACK_IMPORTED_MODULE_4__["default"].session);
    };
    /**
     * Retrieves an access token for calling MS Graph.
     */
    GraphPeoplePickerHelper.prototype.getGraphToken = function () {
        var _this = this;
        if (this._graphToken) {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__["default"].resolve(this._graphToken);
        }
        if (this._oAuthTokenProvider) {
            /**
             * OAuthTokenProvider already logs QOS events for its calls but we want to measure retrieving Graph tokens from within the people picker
             * separately. This allows us to track how often users are forced into the fallback logic scenario.
             */
            var qos_1 = new _ms_odsp_utilities_lib_logging_events_Qos_event__WEBPACK_IMPORTED_MODULE_2__["Qos"]({ name: 'PeoplePicker.GetGraphToken' });
            return this._oAuthTokenProvider.getToken('https://graph.microsoft.com').then(function (oAuthToken) {
                qos_1.end({
                    resultType: _ms_odsp_utilities_lib_logging_events_Qos_event__WEBPACK_IMPORTED_MODULE_2__["ResultTypeEnum"].Success
                });
                return oAuthToken;
            }, function (error) {
                if (_ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__["default"].isCanceled(error)) {
                    qos_1.end({
                        resultType: _ms_odsp_utilities_lib_logging_events_Qos_event__WEBPACK_IMPORTED_MODULE_2__["ResultTypeEnum"].ExpectedFailure,
                        resultCode: 'Canceled'
                    });
                    return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__["default"].reject(error);
                }
                else {
                    qos_1.end({
                        resultCode: 'PeoplePicker.GetGraphTokenError',
                        resultType: _ms_odsp_utilities_lib_logging_events_Qos_event__WEBPACK_IMPORTED_MODULE_2__["ResultTypeEnum"].Failure,
                        extraData: {
                            serverErrorCode: error['_serverErrorCode'],
                            message: error.message
                        }
                    });
                    // If the Acquire call fails, disable future attempts to retrieve the Graph token for the current session.
                    _this.disableGraphCallsForPicker();
                }
                return null;
            });
        }
        return null;
    };
    GraphPeoplePickerHelper.prototype.initializeDataStore = function () {
        if (!this._dataStore) {
            this._dataStore = new _ms_odsp_utilities_lib_models_store_BaseDataStore__WEBPACK_IMPORTED_MODULE_3__["default"](STORE_KEY, _ms_odsp_utilities_lib_models_store_DataStoreCachingType__WEBPACK_IMPORTED_MODULE_4__["default"].session);
        }
    };
    return GraphPeoplePickerHelper;
}());

//# sourceMappingURL=GraphPeoplePickerHelper.js.map

/***/ }),

/***/ "Vdfb":
/*!******************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/AccessRequests.js ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestStatus, AccessRequestsDataSource, AccessRequestsProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dataSources_AccessRequests_IAccessRequestsDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dataSources/AccessRequests/IAccessRequestsDataSource */ "zLRY");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AccessRequestStatus", function() { return _dataSources_AccessRequests_IAccessRequestsDataSource__WEBPACK_IMPORTED_MODULE_0__["AccessRequestStatus"]; });

/* harmony import */ var _dataSources_AccessRequests_AccessRequestsDataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dataSources/AccessRequests/AccessRequestsDataSource */ "ZduO");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsDataSource", function() { return _dataSources_AccessRequests_AccessRequestsDataSource__WEBPACK_IMPORTED_MODULE_1__["AccessRequestsDataSource"]; });

/* harmony import */ var _providers_AccessRequests_AccessRequestsProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./providers/AccessRequests/AccessRequestsProvider */ "aCgj");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsProvider", function() { return _providers_AccessRequests_AccessRequestsProvider__WEBPACK_IMPORTED_MODULE_2__["AccessRequestsProvider"]; });




//# sourceMappingURL=AccessRequests.js.map

/***/ }),

/***/ "WJGS":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-6.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-6\"",
            src: "url('" + baseUrl + "fabric-icons-6-ef6fd590.woff') format('woff')"
        },
        icons: {
            'SwayLogoInverse': '\uED29',
            'OutOfOffice': '\uED34',
            'Trophy': '\uED3F',
            'ReopenPages': '\uED50',
            'EmojiTabSymbols': '\uED58',
            'AADLogo': '\uED68',
            'AccessLogo': '\uED69',
            'AdminALogoInverse32': '\uED6A',
            'AdminCLogoInverse32': '\uED6B',
            'AdminDLogoInverse32': '\uED6C',
            'AdminELogoInverse32': '\uED6D',
            'AdminLLogoInverse32': '\uED6E',
            'AdminMLogoInverse32': '\uED6F',
            'AdminOLogoInverse32': '\uED70',
            'AdminPLogoInverse32': '\uED71',
            'AdminSLogoInverse32': '\uED72',
            'AdminYLogoInverse32': '\uED73',
            'DelveLogoInverse': '\uED76',
            'ExchangeLogoInverse': '\uED78',
            'LyncLogo': '\uED79',
            'OfficeVideoLogoInverse': '\uED7A',
            'SocialListeningLogo': '\uED7C',
            'VisioLogoInverse': '\uED7D',
            'Balloons': '\uED7E',
            'Cat': '\uED7F',
            'MailAlert': '\uED80',
            'MailCheck': '\uED81',
            'MailLowImportance': '\uED82',
            'MailPause': '\uED83',
            'MailRepeat': '\uED84',
            'SecurityGroup': '\uED85',
            'Table': '\uED86',
            'VoicemailForward': '\uED87',
            'VoicemailReply': '\uED88',
            'Waffle': '\uED89',
            'RemoveEvent': '\uED8A',
            'EventInfo': '\uED8B',
            'ForwardEvent': '\uED8C',
            'WipePhone': '\uED8D',
            'AddOnlineMeeting': '\uED8E',
            'JoinOnlineMeeting': '\uED8F',
            'RemoveLink': '\uED90',
            'PeopleBlock': '\uED91',
            'PeopleRepeat': '\uED92',
            'PeopleAlert': '\uED93',
            'PeoplePause': '\uED94',
            'TransferCall': '\uED95',
            'AddPhone': '\uED96',
            'UnknownCall': '\uED97',
            'NoteReply': '\uED98',
            'NoteForward': '\uED99',
            'NotePinned': '\uED9A',
            'RemoveOccurrence': '\uED9B',
            'Timeline': '\uED9C',
            'EditNote': '\uED9D',
            'CircleHalfFull': '\uED9E',
            'Room': '\uED9F',
            'Unsubscribe': '\uEDA0',
            'Subscribe': '\uEDA1',
            'HardDrive': '\uEDA2',
            'RecurringTask': '\uEDB2',
            'TaskManager': '\uEDB7',
            'TaskManagerMirrored': '\uEDB8',
            'Combine': '\uEDBB',
            'Split': '\uEDBC',
            'DoubleChevronUp': '\uEDBD',
            'DoubleChevronLeft': '\uEDBE',
            'DoubleChevronRight': '\uEDBF',
            'TextBox': '\uEDC2',
            'TextField': '\uEDC3',
            'NumberField': '\uEDC4',
            'Dropdown': '\uEDC5',
            'PenWorkspace': '\uEDC6',
            'BookingsLogo': '\uEDC7',
            'ClassNotebookLogoInverse': '\uEDC8',
            'DelveAnalyticsLogo': '\uEDCA',
            'DocsLogoInverse': '\uEDCB',
            'Dynamics365Logo': '\uEDCC',
            'DynamicSMBLogo': '\uEDCD',
            'OfficeAssistantLogo': '\uEDCE',
            'OfficeStoreLogo': '\uEDCF',
            'OneNoteEduLogoInverse': '\uEDD0',
            'PlannerLogo': '\uEDD1',
            'PowerApps': '\uEDD2',
            'Suitcase': '\uEDD3',
            'ProjectLogoInverse': '\uEDD4',
            'CaretLeft8': '\uEDD5',
            'CaretRight8': '\uEDD6',
            'CaretUp8': '\uEDD7',
            'CaretDown8': '\uEDD8',
            'CaretLeftSolid8': '\uEDD9',
            'CaretRightSolid8': '\uEDDA',
            'CaretUpSolid8': '\uEDDB',
            'CaretDownSolid8': '\uEDDC',
            'ClearFormatting': '\uEDDD',
            'Superscript': '\uEDDE',
            'Subscript': '\uEDDF',
            'Strikethrough': '\uEDE0',
            'Export': '\uEDE1',
            'ExportMirrored': '\uEDE2'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-6.js.map

/***/ }),

/***/ "WkNf":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/containers/groupMembershipPanel/GroupMembershipStateManager.js ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipPanelStateManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipPanelStateManager", function() { return GroupMembershipPanelStateManager; });
/* harmony import */ var _ms_odsp_datasources_lib_Groups__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-datasources/lib/Groups */ "b0jF");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/Features */ "8G1T");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _ms_odsp_utilities_lib_encoding_UriEncoding__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ms/odsp-utilities/lib/encoding/UriEncoding */ "+35T");







/** The largest group for which we can currently load all members */
var LARGE_GROUP_CUTOFF = 100;
/**
 * This class manages the state of the GroupMembershipPanel component.
 * @public
 */
var GroupMembershipPanelStateManager = /** @class */ (function () {
    function GroupMembershipPanelStateManager(params) {
        var _this = this;
        /**
         * When the user dismisses the panel, reload membership to refresh member count and facepile
         * in the site header, or any other components tracking the source change event.
         */
        this._onDismiss = function () {
            if (_this._membershipCountChanged) {
                _this._groupsProvider.group.membership.loadWithOptions(4 /*force skip cache*/);
            }
        };
        /**
         * Loads the next page of group members.
         * The GroupMembersList component will call this function when a user has scrolled to the bottom of all the members loaded so far,
         * but there are still more members we need to show.
         */
        this._onLoadMoreMembers = function () {
            // Do not request the next page if it is already loading.
            // If the user scrolls up and then back down again, _onLoadMoreMembers will be triggered twice, but we do not want to request the same page twice.
            if (_this._getNextMembershipPage && !_this._isPageLoading) {
                _this._isPageLoading = true;
                _this._currentMembershipPagePromise = _this._getNextMembershipPage();
                _this._currentMembershipPagePromise.then(function (membershipPage) {
                    var state = _this._params.groupMembershipPanelContainer.state;
                    var currentGroupMembershipPersonas = state && state.personas ? state.personas : [];
                    var nextGroupMembershipPersonas = _this._getGroupMemberPersonas(membershipPage.page, currentGroupMembershipPersonas.length);
                    var groupMembershipPersonas = currentGroupMembershipPersonas.concat(nextGroupMembershipPersonas);
                    _this._getNextMembershipPage = membershipPage.getNextPagePromise;
                    _this._isPageLoading = false;
                    // Only update total number of members if we have a new value
                    if (state.totalNumberOfMembers === _this._membershipPager.totalNumberOfMembers) {
                        _this.setState({
                            personas: groupMembershipPersonas
                        });
                    }
                    else {
                        _this.setState({
                            personas: groupMembershipPersonas,
                            numberOfMembersText: _this._getNumberOfMembersText(_this._membershipPager.totalNumberOfMembers),
                            totalNumberOfMembers: _this._membershipPager.totalNumberOfMembers
                        });
                    }
                }, function (error) {
                    _this._isPageLoading = false;
                    // If the page load was cancelled intentionally, do not show an error message
                    if (!_ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].isCanceled(error)) {
                        _this.setState({
                            errorMessageText: _this._params.strings.loadingMembersErrorText
                        });
                        _this._getNextMembershipPage = undefined;
                    }
                });
            }
        };
        this._closeConfirmationDialog = function () {
            _this.setState({
                showConfirmationDialog: false
            });
        };
        this._onSave = function (selectedMembers) {
            _this._membershipCountChanged = true;
            var selectedMemberNames = selectedMembers
                ? selectedMembers.map(function (member) {
                    return member.name;
                })
                : [];
            var selectedMemberPrincipalNames = selectedMembers
                ? selectedMembers.map(function (member) {
                    return _this._extractPrincipalName(member.userId);
                })
                : [];
            return _this._groupsProvider
                .addUsersToGroup(_this._pageContext.groupId, null /* owners (by GUID) */, null /* members (by GUID) */, null /* ownersPrincipalName */, selectedMemberPrincipalNames /* members (by principalName)*/)
                .then(function (result) {
                _this._updateGroupInformation();
                return;
            }, function (error) {
                _this._setAddMembersErrorMessage(error, [], selectedMemberNames);
                return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].reject(error);
            });
        };
        this._clearErrorMessage = function () {
            _this.setState({
                errorMessageText: undefined
            });
        };
        this._params = params;
        this._pageContext = params.pageContext;
        this._isAddRemoveGuestsFeatureEnabled = _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_4__["default"].isFeatureEnabled(
        /* EnableAddRemoveGuests */
        { ODB: 208, ODC: null, Fallback: false });
        this._membershipCountChanged = false;
    }
    GroupMembershipPanelStateManager.prototype.componentDidMount = function () {
        var _this = this;
        // Get the group properties from GroupsProvider.
        this._params.getGroupsProvider().done(function (groupsProvider) {
            // getGroupsProvider returns null if we are not in a group
            if (!groupsProvider) {
                throw new Error('GroupMembershipStateManager fatal error: Groups provider not available.');
            }
            _this._groupsProvider = groupsProvider;
            if (!_this._groupsProvider.group) {
                throw new Error('GroupMembershipStateManager fatal error: Groups provider does not have an observed group.');
            }
            _this._isMembershipDynamic =
                !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_5__["Killswitch"].isActivated('56213E86-E001-42AD-B118-4A79CA1A90B4') &&
                    _this._groupsProvider.group.isDynamic === true;
            _this._checkOwnersCanAddGuests().then(function (addRemoveGuestsEnabled) {
                _this._ownersCanAddGuests = addRemoveGuestsEnabled;
                // Check that currentUser is available to avoid subtle bug
                if (!_this._groupsProvider.currentUser) {
                    _this._groupsProvider.getCurrentUser().then(function () {
                        _this._updateGroupInformation(true);
                    }, function (error) {
                        _this._setErrorMessage(error);
                    });
                }
                else {
                    _this._updateGroupInformation(true);
                }
            });
        });
    };
    GroupMembershipPanelStateManager.prototype.componentWillUnmount = function () {
        // The old contents of this method have been removed.
        // Leaving an empty method to avoid breaking change with odsp-next and sp-client.
    };
    GroupMembershipPanelStateManager.prototype.getRenderProps = function (lpcModuleLoader, lpcModuleCustomWaiter) {
        // Render the current state. If that is missing, use the initial parameters
        var params = this._params;
        var pageContext = this._pageContext;
        var state = params.groupMembershipPanelContainer.state;
        var guestsMessageKillSwitchOff = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_5__["Killswitch"].isActivated('E3ECD103-34DE-4ECA-9914-74D9110BB09C');
        return {
            // Properties for the members list
            title: state !== null ? state.title : params.strings.title,
            onDismiss: this._onDismiss,
            personas: state !== null ? state.personas : null,
            onLoadMoreMembers: this._onLoadMoreMembers,
            canAddMembers: !this._isMembershipDynamic &&
                ((state && state.currentUserIsOwner) ||
                    (pageContext && pageContext.groupType && pageContext.groupType === "Public" /* public */)),
            canAddGuests: !this._isMembershipDynamic &&
                state &&
                state.currentUserIsOwner &&
                this._ownersCanAddGuests &&
                this._isAddRemoveGuestsFeatureEnabled,
            showGuestsMessage: !this._isMembershipDynamic &&
                state &&
                state.currentUserIsOwner &&
                this._ownersCanAddGuests &&
                guestsMessageKillSwitchOff,
            canChangeMemberStatus: !this._isMembershipDynamic && state && state.currentUserIsOwner,
            numberOfMembersText: state !== null ? state.numberOfMembersText : undefined,
            totalNumberOfMembers: state != null ? state.totalNumberOfMembers : undefined,
            largeGroupMessage: state != null ? state.largeGroupMessage : undefined,
            membersUrl: this._groupsProvider ? this._groupsProvider.group.membersUrl : undefined,
            outlookLinkText: params.strings.searchLinkText,
            showConfirmationDialog: state !== null ? state.showConfirmationDialog : false,
            onApproveConfirmationDialog: state != null ? state.onApproveConfirmationDialog : undefined,
            onCloseConfirmationDialog: this._closeConfirmationDialog,
            okButtonText: params.strings.okButtonText,
            confirmationText: params.strings.confirmationText,
            //LPC related properties
            lpcModuleLoader: lpcModuleLoader,
            lpcModuleCustomWaiter: lpcModuleCustomWaiter,
            // Properties for the add members UX
            pageContext: this._pageContext,
            addMembersText: params.strings.addMembersText,
            doneButtonText: params.strings.doneButtonText,
            cancelButtonText: params.strings.cancelButtonText,
            addMembersInstructionsText: params.strings.addMembersInstructionsText,
            addMembersOrGuestsInstructionsText: params.strings.addMembersOrGuestsInstructionsText,
            addGuestsLinkText: params.strings.addGuestsLinkText,
            peoplePickerPlaceholderText: params.strings.peoplePickerPlaceholderText,
            onSave: this._onSave,
            addingGuestText: params.strings.addingGuestText,
            // Properties for both
            closeButtonAriaLabel: params.strings.closeButtonAriaLabel,
            dismissErrorMessageAriaLabel: params.strings.dismissErrorMessageAriaLabel,
            errorMessageText: state !== null ? state.errorMessageText : undefined,
            clearErrorMessage: this._clearErrorMessage,
            peoplePickerDataSource: params.peoplePickerDataSource
        };
    };
    /**
     * Load new group membership information from the server and update the component state.
     *
     * @param {boolean} updateMembershipBeforeLoadComplete - If true, display any group membership information you already have before the load from the server completes.
     * Defaults to false.
     */
    GroupMembershipPanelStateManager.prototype._updateGroupInformation = function (updateMembershipBeforeLoadComplete) {
        var _this = this;
        if (updateMembershipBeforeLoadComplete === void 0) { updateMembershipBeforeLoadComplete = false; }
        var group = this._groupsProvider.group;
        if (updateMembershipBeforeLoadComplete) {
            if (group.membership.source !== _ms_odsp_datasources_lib_Groups__WEBPACK_IMPORTED_MODULE_0__["SourceType"].None) {
                this.setState({
                    title: this._params.strings.title,
                    // Do not update personas until load is complete
                    currentUserIsOwner: !!group.membership.isOwner,
                    numberOfMembersText: this._getNumberOfMembersText(group.membership.totalNumberOfMembers),
                    errorMessageText: undefined
                });
            }
        }
        // The list of group members uses a paging mechanism.
        // Start by cancelling any page loads currently in progress.
        if (this._isPageLoading && this._currentMembershipPagePromise) {
            this._currentMembershipPagePromise.cancel();
            this._isPageLoading = false;
        }
        this._membershipPager = this._groupsProvider.getMembershipPager( /*Default paging options*/);
        this._membershipPager.loadPage(0 /*first page*/).then(function (membershipPage) {
            var groupMembershipPersonas = _this._getGroupMemberPersonas(membershipPage.page, 0);
            _this._getNextMembershipPage = membershipPage.getNextPagePromise;
            _this.setState({
                title: _this._params.strings.title,
                personas: groupMembershipPersonas,
                currentUserIsOwner: _this._membershipPager.isOwner,
                numberOfMembersText: _this._getNumberOfMembersText(_this._membershipPager.totalNumberOfMembers),
                totalNumberOfMembers: _this._membershipPager.totalNumberOfMembers,
                totalNumberOfOwners: _this._membershipPager.totalNumberOfOwners,
                largeGroupMessage: _this._getLargeGroupMessage(_this._membershipPager.totalNumberOfMembers),
                errorMessageText: undefined
            });
        }, function (error) {
            _this.setState({
                errorMessageText: _this._params.strings.loadingMembersErrorText
            });
        });
    };
    /**
     * Determines whether the current group allows owners to add and remove guest members.
     * Guests are allowed if both of the following are true:
     * (1) Guests are allowed at the group level
     * (2) Guests are allowed at the tenant level
     */
    GroupMembershipPanelStateManager.prototype._checkOwnersCanAddGuests = function () {
        if (this._groupsProvider.group.allowToAddGuests && this._params.getGroupSiteProvider) {
            // Use the GroupSiteProvider to check if guests are allowed at the tenant level.
            // This requires another call to FBI, so only do it if all other requirements to allow guests have been met.
            return this._params
                .getGroupSiteProvider()
                .then(function (groupSiteProvider) {
                var groupCreationContextPromise;
                if (groupSiteProvider) {
                    groupCreationContextPromise = groupSiteProvider.getGroupCreationContext();
                }
                return groupCreationContextPromise;
            })
                .then(function (groupCreationContext) {
                var allowToAddGuests;
                if (groupCreationContext) {
                    allowToAddGuests = groupCreationContext.allowToAddGuests;
                }
                return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].resolve(allowToAddGuests);
            }, function (error) {
                // If an error occurs, play it safe and do not allow adding guests
                return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].resolve(false);
            });
        }
        else {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_2__["default"].resolve(false);
        }
    };
    /**
     * Transforms the IPerson array returned from the data source into a format we can display in the panel.
     * Adds contextual menu title and items.
     *
     * @param {IPerson[]} members The array of members returned from the server.
     * @param {number} indexOffset If the array is a page to be appended to the existing members list, include the number of preceding members.
     * This allows us to mark each member with the correct index.
     */
    GroupMembershipPanelStateManager.prototype._getGroupMemberPersonas = function (members, indexOffset) {
        var _this = this;
        var groupMemberPersonas = members.map(function (member, index) {
            return {
                name: member.name,
                email: member.email,
                imageUrl: member.image,
                isGroupOwner: member.isOwnerOfCurrentGroup,
                memberStatusMenuItems: _this._getMemberStatusMenuItems(member, index + indexOffset),
                contextualMenuTitle: _this._getContextualMenuTitle(member)
            };
        });
        return groupMemberPersonas;
    };
    /**
     * Get the text to display for the total number of group members
     */
    GroupMembershipPanelStateManager.prototype._getNumberOfMembersText = function (totalNumberOfMembers) {
        var localizedCountFormat = _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["getLocalizedCountValue"](this._params.strings.membersCountText, this._params.strings.membersCountIntervalsText, totalNumberOfMembers);
        return _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](localizedCountFormat, totalNumberOfMembers);
    };
    /**
     * Get the message to display if the group has a large number of members.
     * If the number of members does not exceed the chosen cutoff, returns undefined.
     * If virtual members list is enabled, the message will appear at the top of the list and direct users to search.
     * If the virtual members list is disabled, the message will appear at the bottom of the list and direct users to
     * view the full members list in OWA.
     */
    GroupMembershipPanelStateManager.prototype._getLargeGroupMessage = function (totalNumberOfMembers) {
        if (totalNumberOfMembers > LARGE_GROUP_CUTOFF) {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__["Engagement"].logData({
                name: 'GroupMembershipPanel.RenderLargeGroup',
                extraData: { numberOfMembers: totalNumberOfMembers }
            });
            return this._params.strings.searchMembersMessage;
        }
        else {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__["Engagement"].logData({
                name: 'GroupMembershipPanel.RenderSmallGroup',
                extraData: { numberOfMembers: totalNumberOfMembers }
            });
            return undefined;
        }
    };
    /**
     * Get the contextual menu title for a user. Can be either Owner, Guest, or Member.
     *
     * @param {IPerson} member - the member for whom we are getting the contextual menu title
     */
    GroupMembershipPanelStateManager.prototype._getContextualMenuTitle = function (member) {
        if (member.isOwnerOfCurrentGroup) {
            return this._params.strings.ownerText;
        }
        else if (member.entityType === 1 /* EntityType.externalUser */) {
            return this._params.strings.guestText;
        }
        else {
            return this._params.strings.memberText;
        }
    };
    /**
     * Get the contextual menu options for the dropdown on each group member
     */
    GroupMembershipPanelStateManager.prototype._getMemberStatusMenuItems = function (member, index) {
        var _this = this;
        var memberStatusMenuItems = [];
        if (member.entityType !== 1 /* EntityType.externalUser */) {
            // Non-guest members show all options
            memberStatusMenuItems.push({
                name: this._params.strings.memberText,
                key: 'member',
                onClick: function (onClick) {
                    _this._makeMember(member, index);
                },
                canCheck: true,
                checked: !member.isOwnerOfCurrentGroup
            }, {
                name: this._params.strings.ownerText,
                key: 'owner',
                onClick: function (onClick) {
                    _this._makeOwner(member, index);
                },
                canCheck: true,
                checked: !!member.isOwnerOfCurrentGroup
            }, {
                name: this._params.strings.removeFromGroupText,
                key: 'remove',
                onClick: function (onClick) {
                    _this._removeFromGroup(member, index);
                },
                canCheck: false,
                checked: false
            });
        }
        else if (this._ownersCanAddGuests && this._isAddRemoveGuestsFeatureEnabled) {
            // Can remove guests, but not promote them to owner
            memberStatusMenuItems.push({
                name: this._params.strings.removeFromGroupText,
                key: 'remove',
                onClick: function (onClick) {
                    _this._removeFromGroup(member, index);
                },
                canCheck: false,
                checked: false
            });
        }
        return memberStatusMenuItems;
    };
    /**
     * Makes a user into a member.
     * Does nothing if they were already a member, but removes from group ownership if they were an owner.
     */
    GroupMembershipPanelStateManager.prototype._makeMember = function (member, index) {
        var _this = this;
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__["Engagement"].logData({ name: 'GroupMembershipPanel.MakeMember.Click' });
        if (member.isOwnerOfCurrentGroup) {
            // If trying to remove last owner, show error message and do not change status
            var removingLastOwner = this._params.groupMembershipPanelContainer.state &&
                this._params.groupMembershipPanelContainer.state.totalNumberOfOwners < 2;
            if (removingLastOwner) {
                this.setState({
                    errorMessageText: this._params.strings.demoteLastOwnerErrorText
                });
                // If user is trying to demote themselves to member, give them a confirmation dialog to be sure
            }
            else if (member.userId === this._groupsProvider.currentUser.userId) {
                this._launchConfirmationDialog(function () {
                    _this.setState({ showConfirmationDialog: false });
                    _this._changeGroupOwnerToMember(member, index);
                });
            }
            else {
                this._changeGroupOwnerToMember(member, index);
            }
        }
    };
    /**
     * Removes a user from the owners list of a group.
     * If the user is changing themselves from owner to member, they must approve confirmation dialog before this is called.
     */
    GroupMembershipPanelStateManager.prototype._changeGroupOwnerToMember = function (member, index) {
        var _this = this;
        // Set member status to updating
        var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas;
        var oldContextualMenuTitle = updatingPersonas[index].contextualMenuTitle;
        var oldMemberStatusMenuItems = updatingPersonas[index].memberStatusMenuItems;
        this._setMemberStatusToUpdating(index);
        this._groupsProvider.removeUserFromGroupOwnership(this._pageContext.groupId, member.userId).then(function () {
            _this._updateGroupInformation();
        }, function (error) {
            _this._setErrorMessage(error);
            // If an error occurred, undo setting the member status to updating
            _this._undoSetMemberStatusToUpdating(index, oldContextualMenuTitle, oldMemberStatusMenuItems);
        });
    };
    GroupMembershipPanelStateManager.prototype._launchConfirmationDialog = function (onApproveConfirmationDialog) {
        this.setState({
            showConfirmationDialog: true,
            onApproveConfirmationDialog: onApproveConfirmationDialog
        });
    };
    /**
     * Makes a group member into an owner
     */
    GroupMembershipPanelStateManager.prototype._makeOwner = function (member, index) {
        var _this = this;
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__["Engagement"].logData({ name: 'GroupMembershipPanel.MakeOwner.Click' });
        if (!member.isOwnerOfCurrentGroup) {
            // Set member status to updating
            var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas;
            var oldContextualMenuTitle_1 = updatingPersonas[index].contextualMenuTitle;
            var oldMemberStatusMenuItems_1 = updatingPersonas[index].memberStatusMenuItems;
            this._setMemberStatusToUpdating(index);
            this._groupsProvider.addUserToGroupOwnership(this._pageContext.groupId, member.userId).then(function () {
                _this._updateGroupInformation();
            }, function (error) {
                _this._setErrorMessage(error);
                // If an error occurred, undo setting the member status to updating
                _this._undoSetMemberStatusToUpdating(index, oldContextualMenuTitle_1, oldMemberStatusMenuItems_1);
            });
        }
    };
    /**
     * Removes a user from the group
     */
    GroupMembershipPanelStateManager.prototype._removeFromGroup = function (member, index) {
        var _this = this;
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_3__["Engagement"].logData({ name: 'GroupMembershipPanel.RemovePerson.Click' });
        if (member.isOwnerOfCurrentGroup) {
            // If trying to remove last owner, show error message and do not remove
            var removingLastOwner = this._params.groupMembershipPanelContainer.state &&
                this._params.groupMembershipPanelContainer.state.totalNumberOfOwners < 2;
            if (removingLastOwner) {
                this.setState({
                    errorMessageText: this._params.strings.removeLastOwnerErrorText
                });
                // If an owner is trying to remove themselves from the group, must approve confirmation dialog
            }
            else if (member.userId === this._groupsProvider.currentUser.userId) {
                this._launchConfirmationDialog(function () {
                    _this.setState({ showConfirmationDialog: false });
                    _this._removeOwnerFromGroup(member, index);
                });
            }
            else {
                this._removeOwnerFromGroup(member, index);
            }
        }
        else {
            this._removeMemberFromGroup(member, index);
        }
    };
    /**
     * Removes an owner from the group entirely.
     * If the owner is trying to remove themselves from the group, they must approve confirmation dialog before this is called.
     */
    GroupMembershipPanelStateManager.prototype._removeOwnerFromGroup = function (member, index) {
        var _this = this;
        // Set member status to updating
        var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas;
        var oldContextualMenuTitle = updatingPersonas[index].contextualMenuTitle;
        var oldMemberStatusMenuItems = updatingPersonas[index].memberStatusMenuItems;
        this._setMemberStatusToUpdating(index);
        // If member is an owner, should remove from the owners list first
        this._groupsProvider.removeUserFromGroupOwnership(this._pageContext.groupId, member.userId).then(function () {
            _this._groupsProvider.removeUserFromGroupMembership(_this._pageContext.groupId, member.userId).then(function () {
                _this._processingAfterRemoveMember(member.userId);
            }, function (error) {
                _this._setErrorMessage(error);
                _this._undoSetMemberStatusToUpdating(index, oldContextualMenuTitle, oldMemberStatusMenuItems);
            });
        }, function (error) {
            _this._setErrorMessage(error);
            _this._undoSetMemberStatusToUpdating(index, oldContextualMenuTitle, oldMemberStatusMenuItems);
        });
    };
    /**
     * Removes a member (not an owner) from the group entirely.
     */
    GroupMembershipPanelStateManager.prototype._removeMemberFromGroup = function (member, index) {
        var _this = this;
        // Set member status to updating
        var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas;
        var oldContextualMenuTitle = updatingPersonas[index].contextualMenuTitle;
        var oldMemberStatusMenuItems = updatingPersonas[index].memberStatusMenuItems;
        this._setMemberStatusToUpdating(index);
        // If member is not an owner, only remove from members list
        this._groupsProvider.removeUserFromGroupMembership(this._pageContext.groupId, member.userId).then(function () {
            _this._processingAfterRemoveMember(member.userId);
        }, function (error) {
            _this._setErrorMessage(error);
            _this._undoSetMemberStatusToUpdating(index, oldContextualMenuTitle, oldMemberStatusMenuItems);
        });
    };
    /**
     * Called to indicate that a persona is currently updating.
     * Changes menu title to "updating," removes contextual menu options, and re-renders personas.
     *
     * @param {number} memberIndex - the index in the personas list of the member that is being updated
     */
    GroupMembershipPanelStateManager.prototype._setMemberStatusToUpdating = function (memberIndex) {
        // Use .concat to create distinct array. This is necessary to trigger re-rendering of the members list.
        var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas.concat([]);
        updatingPersonas[memberIndex].showSpinner = true;
        updatingPersonas[memberIndex].contextualMenuTitle = this._params.strings.updatingText;
        updatingPersonas[memberIndex].memberStatusMenuItems = undefined;
        this.setState({
            personas: updatingPersonas
        });
    };
    /**
     * Called in the event of an error to undo the indication that a persona is currently updating.
     * Reverses the changes to the menu title and options.
     *
     * @param {number} memberIndex - the index in the personas list of the member that was being updated
     * @param {string} oldContextualMenuTitle - the previous menu title that you want to put back on the persona
     * @param {IContextualMenuItem[]} - the previous contextual menu options that you want to put back on the persona
     */
    GroupMembershipPanelStateManager.prototype._undoSetMemberStatusToUpdating = function (memberIndex, oldContextualMenuTitle, oldMemberStatusMenuItems) {
        // Use .concat to create distinct array. This is necessary to trigger re-rendering of the members list.
        var updatingPersonas = this._params.groupMembershipPanelContainer.state.personas.concat([]);
        updatingPersonas[memberIndex].showSpinner = false;
        updatingPersonas[memberIndex].contextualMenuTitle = oldContextualMenuTitle;
        updatingPersonas[memberIndex].memberStatusMenuItems = oldMemberStatusMenuItems;
        this.setState({
            personas: updatingPersonas
        });
    };
    /**
     * Decide what to do after removing a group member. Handles the edge case when the owner of a private group
     * removes him/herself from the group.
     *
     * @param {string} removedMemberId - the userId of the member who was just removed from the group
     */
    GroupMembershipPanelStateManager.prototype._processingAfterRemoveMember = function (removedMemberId) {
        // If the current user just removed him/herself from a private group, he/she will no longer have group access.
        // Navigate away to avoid getting into a peculiar state.
        this._membershipCountChanged = true;
        if (removedMemberId === this._groupsProvider.currentUser.userId &&
            this._pageContext.groupType !== "Public" /* public */) {
            this._navigateOnRemoveMember();
        }
        else {
            this._updateGroupInformation();
        }
    };
    /**
     * If onMemberRemoved is present, navigate to the customized place.
     * Otherwise, navigate to SharePoint home page by default.
     */
    GroupMembershipPanelStateManager.prototype._navigateOnRemoveMember = function () {
        if (this._params.onMemberRemoved) {
            this._params.onMemberRemoved();
        }
        else {
            window.open(this._getSharePointHomePageUrl(), '_self');
        }
    };
    // TODO: Use SuiteNavDataSource to get this url after msilver moves the SuiteNavDataSource to odsp-datasources (currently in odsp-next)
    GroupMembershipPanelStateManager.prototype._getSharePointHomePageUrl = function () {
        var layoutString = '/_layouts/15/sharepoint.aspx';
        var webAbsoluteUrl = this._pageContext.webAbsoluteUrl;
        var webServerRelativeUrl = this._pageContext.webServerRelativeUrl;
        if (webAbsoluteUrl && webServerRelativeUrl) {
            return webAbsoluteUrl.replace(webServerRelativeUrl, '') + layoutString;
        }
        else {
            return undefined;
        }
    };
    GroupMembershipPanelStateManager.prototype.setState = function (state) {
        this._params.groupMembershipPanelContainer.setState(state);
    };
    /**
     * Checks for the presence of an error message returned from the server.
     * If there is none, uses a generic error message.
     */
    GroupMembershipPanelStateManager.prototype._setErrorMessage = function (error) {
        var errorMessage = this._params.strings.serverErrorMessage;
        if (error && error.message && error.message.value) {
            errorMessage = error.message.value;
        }
        this.setState({
            errorMessageText: errorMessage
        });
    };
    /**
     * Computes an error message if the add members operation failed. Follows the same pattern used in group creation.
     * Currently not using selectedOwnerNames, but including for when the long term add members design is complete.
     *
     * @param {IDataBatchOperationResult} error - error returned from the server
     * @param {string[]} selectedOwnerNames - names of the owners you were attempting to add
     * @param {string[]} selectedMemberNames - names of the members you were attempting to add
     */
    GroupMembershipPanelStateManager.prototype._setAddMembersErrorMessage = function (error, selectedOwnerNames, selectedMemberNames) {
        var failedMembers = [];
        var failedOwners = [];
        if (error && error.hasError && error.items) {
            var errors = error.items;
            for (var i = 0; i < errors.length; i++) {
                var currentError = errors[i].error;
                if (currentError && (currentError.code || currentError.message)) {
                    if (i < selectedOwnerNames.length) {
                        failedOwners.push(selectedOwnerNames[i]);
                    }
                    else {
                        failedMembers.push(selectedMemberNames[i - selectedOwnerNames.length]);
                    }
                }
            }
        }
        var errorMsg = '';
        // TODO: When you can add owners as well as members, create an error message for any owners that failed to be added.
        if (failedMembers.length === 1) {
            errorMsg =
                errorMsg +
                    ' ' +
                    _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](this._params.strings.addMemberFailedSingularText, failedMembers[0]);
        }
        else if (failedMembers.length >= 2) {
            errorMsg =
                errorMsg +
                    ' ' +
                    _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](this._params.strings.addMemberFailedPluralText, failedMembers.join(', '));
        }
        if (!errorMsg) {
            errorMsg = this._params.strings.addMemberFailedText;
        }
        this.setState({
            errorMessageText: errorMsg
        });
    };
    /**
     * There is a discrepancy between the userId returned from the GroupsDataSource, which is a
     * GUID like '2282955c-14bd-4e69-9c2d-cb0d49935a88', and the userId returned from the PeoplePicker,
     * which has the form 'i:0#.f|membership|examplename@microsoft.com'.
     * As a result, when receiving an IPerson from the PeoplePicker, we need to extract the principalName
     * from the userId rather than using the userId directly.
     * For guests, the userId has the form 'i:0#.f|membership|name_externaldomain.com#ext#@microsoft.onmicrosoft.com',
     * so we must be sure to encode '#' as '%23'.
     */
    GroupMembershipPanelStateManager.prototype._extractPrincipalName = function (userId) {
        var principalName = userId;
        if (principalName) {
            var separatorIndex = userId.lastIndexOf('|');
            if (separatorIndex !== -1) {
                var extractedName = principalName.substring(separatorIndex + 1);
                return _ms_odsp_utilities_lib_encoding_UriEncoding__WEBPACK_IMPORTED_MODULE_6__["default"].encodeRestUriStringToken(extractedName);
            }
        }
        return principalName;
    };
    return GroupMembershipPanelStateManager;
}());

//# sourceMappingURL=GroupMembershipStateManager.js.map

/***/ }),

/***/ "Xxza":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SiteSharingSettingsPanel/SiteSharingSettingsPanel.js ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: SiteSharingSettingsPanelBase, SiteSharingSettingsPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SiteSharingSettingsPanelBase", function() { return SiteSharingSettingsPanelBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SiteSharingSettingsPanel", function() { return SiteSharingSettingsPanel; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SiteSharingSettingsPanel_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SiteSharingSettingsPanel.scss */ "RbLw");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var _SiteSharingSettingsPanel_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SiteSharingSettingsPanel.styles */ "T5Dc");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./SiteSharingSettingsPanel.resx */ "6ByR");
/* harmony import */ var _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! office-ui-fabric-react/lib/Panel */ "p6C6");
/* harmony import */ var office_ui_fabric_react_lib_Toggle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! office-ui-fabric-react/lib/Toggle */ "40s1");
/* harmony import */ var office_ui_fabric_react_lib_ChoiceGroup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! office-ui-fabric-react/lib/ChoiceGroup */ "HVOw");
/* harmony import */ var office_ui_fabric_react_lib_TextField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! office-ui-fabric-react/lib/TextField */ "tTm/");
/* harmony import */ var office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! office-ui-fabric-react/lib/Button */ "epn0");
/* harmony import */ var office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! office-ui-fabric-react/lib/Spinner */ "fyAn");
/* harmony import */ var office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! office-ui-fabric-react/lib/Label */ "wMNn");
/* harmony import */ var _PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker */ "5zxV");
/* harmony import */ var _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker.Props */ "wWxM");
/* harmony import */ var _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../utilities/peoplepicker/PeoplePickerHelper */ "zluq");
/* harmony import */ var office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! office-ui-fabric-react/lib/MessageBar */ "oW6A");
/* harmony import */ var office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! office-ui-fabric-react/lib/Dialog */ "wPGM");



















var AccessRequestOption;
(function (AccessRequestOption) {
    AccessRequestOption[AccessRequestOption["Default"] = 0] = "Default";
    AccessRequestOption[AccessRequestOption["Email"] = 1] = "Email";
})(AccessRequestOption || (AccessRequestOption = {}));
var MembersCanShareOption;
(function (MembersCanShareOption) {
    MembersCanShareOption[MembersCanShareOption["FileFolderSite"] = 0] = "FileFolderSite";
    MembersCanShareOption[MembersCanShareOption["FileFolder"] = 1] = "FileFolder";
    MembersCanShareOption[MembersCanShareOption["None"] = 2] = "None";
})(MembersCanShareOption || (MembersCanShareOption = {}));
var TenantAdminMemberCanShareOption;
(function (TenantAdminMemberCanShareOption) {
    TenantAdminMemberCanShareOption[TenantAdminMemberCanShareOption["Unspecified"] = 0] = "Unspecified";
    TenantAdminMemberCanShareOption[TenantAdminMemberCanShareOption["On"] = 1] = "On";
    TenantAdminMemberCanShareOption[TenantAdminMemberCanShareOption["Off"] = 2] = "Off";
})(TenantAdminMemberCanShareOption || (TenantAdminMemberCanShareOption = {}));
/**
 * @public
 */
var SiteSharingSettingsPanelBase = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SiteSharingSettingsPanelBase, _super);
    function SiteSharingSettingsPanelBase(props) {
        var _this = _super.call(this, props) || this;
        _this.onDismiss = function () {
            // reset state back to fetched sharing settings
            _this.resetState();
            _this.props.onDismiss && _this.props.onDismiss();
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.OnDismiss.Click' });
        };
        _this.onBackButtonClick = function () {
            if (!_this.hasInvalidSettings() && _this.haveSettingsChanged()) {
                _this.setState({
                    showConfirmDialog: true
                });
            }
            else {
                _this.resetState();
                if (_this.props.onDismiss) {
                    _this.props.onDismiss();
                }
            }
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.BackButton.Click' });
        };
        _this.onSaveClick = function () {
            var selectedPerson = _this.state.selectedPersons && _this.state.selectedPersons.length === 1
                ? _this.state.selectedPersons[0]
                : null;
            // set the default value to be someone@example.com
            var email = 'someone@example.com';
            var useDefault = false;
            if (_this.state.accessRequestEnabled) {
                if (_this.state.accessRequestOption === AccessRequestOption.Email) {
                    email = selectedPerson.email;
                }
                else {
                    useDefault = true;
                }
            }
            else {
                email = '';
            }
            _this.setMembersCanShareFromOption(_this.state.membersCanShareOption);
            var siteSharingSettings = {
                membersCanShare: _this.membersCanShareEnabled,
                requestAccessEmail: email,
                useAccessRequestDefault: useDefault,
                accessRequestSiteDescription: _this.state.accessRequestSiteDescription,
                defaultMembersGroupAddMembers: _this.membersCanShareEnabled && _this.membersCanAddToGroupEnabled,
                membersGroup: _this.siteSharingSettings.membersGroup,
                ownersGroup: _this.siteSharingSettings.ownersGroup
            };
            _this.sharingSiteProvider.setSiteSharingSettings(siteSharingSettings).then(function (response) {
                _this.siteSharingSettings = siteSharingSettings;
                _this.setState({
                    showLoadingSpinner: false
                });
                if (_this.props.onDismiss) {
                    _this.props.onDismiss();
                }
            }, function (result) {
                var errorMessages = [];
                if (result && result.hasError && result.items) {
                    var results = result.items;
                    for (var i = 0; i < results.length; i++) {
                        var errorResult = results[i];
                        if (errorResult && errorResult.error) {
                            errorMessages.push(errorResult.error.message);
                        }
                    }
                }
                _this.setState({
                    showLoadingSpinner: false,
                    saveFailed: true,
                    serverErrorDetails: errorMessages
                });
            });
            _this.setState({
                showLoadingSpinner: true,
                showConfirmDialog: false
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.Save.Click' });
        };
        _this.onDiscardClick = function () {
            _this.resetState();
            if (_this.props.onDismiss) {
                _this.props.onDismiss();
            }
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.Discard.Click' });
        };
        _this.onAccessRequestChange = function () {
            _this.setState({
                accessRequestEnabled: !_this.state.accessRequestEnabled
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.AccessRequest.Click' });
        };
        _this.onAccessRequestSiteDescriptionChange = function (event, newValue) {
            _this.setState({
                accessRequestSiteDescription: newValue
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.AccessRequestSiteDescription.Click' });
        };
        _this.onAccessRequestOptionChanged = function (ev, option) {
            _this.setState({
                accessRequestOption: AccessRequestOption[option.key]
            });
        };
        _this.onMembersCanShareOptionChanged = function (ev, option) {
            _this.setState({
                membersCanShareOption: MembersCanShareOption[option.key]
            });
        };
        _this.onSelectedPeopleChange = function (items) {
            var peoplePickerError;
            var peoplePickerErrorSpan = _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_16__["renderPickerError"]({
                selectedItems: items
            });
            if (!peoplePickerErrorSpan && items.length > 0) {
                var personaSelected_1 = items[0];
                if (!personaSelected_1.email) {
                    peoplePickerErrorSpan = react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("span", null, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.selectedPersonNoEmailError);
                }
            }
            if (peoplePickerErrorSpan) {
                peoplePickerError = (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_17__["MessageBar"], { className: 'ms-siteSharingSettingsPanel-peoplePicker-error', messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_17__["MessageBarType"].error }, peoplePickerErrorSpan));
            }
            var personaSelected = items.length > 0 && !peoplePickerError;
            _this.setState({
                selectedPersons: items,
                peoplePickerError: peoplePickerError,
                personaSelected: personaSelected
            });
        };
        _this.onSuggestionSelected = function (suggestion) {
            return _this.peoplePickerProvider.resolve(suggestion.userId, _this.pickerParams).then(function (person) {
                if (!person.email && person.rawData.EntityData) {
                    person.email = person.rawData.EntityData.OtherMails;
                }
                return person;
            });
        };
        _this.onDiscardDialogClick = function () {
            _this.resetState();
            if (_this.props.onDismiss) {
                _this.props.onDismiss();
            }
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.DialogDiscard.Click' });
        };
        _this.onDismissSaveErrorMessage = function () {
            _this.setState({
                saveFailed: false,
                serverErrorDetails: []
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.ErrorMessage.Click' });
        };
        _this.state = {
            showLoadingSpinner: true
        };
        _this.peoplePickerProvider = props.peoplePickerProvider;
        _this.sharingSiteProvider = props.sharingSiteProvider;
        _this.pickerParams = {
            principalSource: 15,
            principalType: 7,
            allowEmailAddresses: true,
            maximumEntitySuggestions: 30,
            forceResolve: true
        };
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_5__["Engagement"].logData({ name: 'SiteSharingSettingsPanel.Opened.Click' });
        return _this;
    }
    SiteSharingSettingsPanelBase.prototype.render = function () {
        var _this = this;
        var _a = this.props, pageContext = _a.pageContext, isOpen = _a.isOpen;
        var _b = this.state, showLoadingSpinner = _b.showLoadingSpinner, accessRequestOption = _b.accessRequestOption, membersCanShareOptionDisabled = _b.membersCanShareOptionDisabled, membersCanShareOption = _b.membersCanShareOption, accessRequestEnabled = _b.accessRequestEnabled, accessRequestSiteDescription = _b.accessRequestSiteDescription, selectedPersons = _b.selectedPersons, peoplePickerError = _b.peoplePickerError, showConfirmDialog = _b.showConfirmDialog;
        var iconProps = {
            iconName: 'Back'
        };
        var navigationContent = function (props, defaultRender) {
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], null,
                react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-Header' },
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-Title-Container' },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__["IconButton"], { "data-is-focusable": true, className: 'ms-siteSharingSettings-BackButton', ariaLabel: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.closeButtonAriaLabel, iconProps: iconProps, onClick: _this.onBackButtonClick }),
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("p", { className: 'ms-siteSharingSettingsPanel-Title' },
                            " ",
                            _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.siteSharingSettingsPanelHeader))),
                defaultRender(props)));
        };
        var footerContent = function (props, defaultRender) {
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-Footer' },
                react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__["PrimaryButton"], { className: 'ms-siteSharingSettingsPanel-saveButton', onClick: _this.onSaveClick, "data-automationid": 'SiteSharingSettingsPanelSaveButton', disabled: _this.hasInvalidSettings() || !_this.haveSettingsChanged() }, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.saveButtonText),
                react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__["DefaultButton"], { className: 'ms-siteSharingSettingsPanel-discardButton', onClick: _this.onDiscardClick, "data-automationid": 'SiteSharingSettingsPanelPanelDiscardButton' }, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.discardButtonText),
                _this.state.saveFailed && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-groupMember-errorMessage' },
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_17__["MessageBar"], { messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_17__["MessageBarType"].error, isMultiline: true, onDismiss: _this.onDismissSaveErrorMessage, dismissButtonAriaLabel: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.closeButtonAriaLabel },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("span", null, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.saveFailureMessage),
                        _this.state.serverErrorDetails.map(function (error) { return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("span", null, error)); }))))));
        };
        return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__["Panel"], { className: 'ms-siteSharingSettingsPanel', isOpen: isOpen, type: office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_7__["PanelType"].smallFixedFar, onDismiss: this.onDismiss, isLightDismiss: true, forceFocusInsideTrap: false, closeButtonAriaLabel: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.closeButtonAriaLabel, onRenderNavigationContent: navigationContent, onRenderFooterContent: footerContent, styles: { content: 'siteSharingSettingsPanel-content' } },
            react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-Content' },
                !showLoadingSpinner && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", null,
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'SiteSharingSettingsPanelDescription', "data-automationid": 'SiteSharingSettingsPanelDescription' }, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.siteSharingSettingsPanelDescription),
                    membersCanShareOptionDisabled ? (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_13__["Label"], { className: 'ms-siteSharingSettingsPanel-tenantAdminMembersCanShareMessage' }, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.tenantAdminMembersCanShareMessage)) : null,
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-SharingPermissionsChoiceGroup' },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_ChoiceGroup__WEBPACK_IMPORTED_MODULE_9__["ChoiceGroup"], { selectedKey: MembersCanShareOption[membersCanShareOption], options: [
                                {
                                    key: MembersCanShareOption[0],
                                    text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.membersCanShareChoiceFileFolderSite
                                },
                                {
                                    key: MembersCanShareOption[1],
                                    text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.membersCanShareChoiceFileFolder
                                },
                                {
                                    key: MembersCanShareOption[2],
                                    text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.membersCanShareChoiceNone
                                }
                            ], label: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.membersCanShareHeader, styles: {
                                applicationRole: {
                                    marginBottom: 48
                                },
                                label: {
                                    fontWeight: '600',
                                    fontSize: 16
                                }
                            }, required: false, disabled: membersCanShareOptionDisabled, onChange: this.onMembersCanShareOptionChanged })),
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-sectionHeader' },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_13__["Label"], { className: 'ms-siteSharingSettingsPanel-sectionHeaderLabel' }, _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestHeader)),
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Toggle__WEBPACK_IMPORTED_MODULE_8__["Toggle"], { checked: accessRequestEnabled, label: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestToggleLabel, inlineLabel: true, onChange: this.onAccessRequestChange, onText: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.toggleOnText, offText: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.toggleOffText, styles: { root: { justifyContent: 'space-between' } } }),
                    accessRequestEnabled && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-AccessRequestsChoiceGroup' },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_ChoiceGroup__WEBPACK_IMPORTED_MODULE_9__["ChoiceGroup"], { selectedKey: AccessRequestOption[accessRequestOption], options: [
                                {
                                    key: AccessRequestOption[0],
                                    text: (this.siteSharingSettings.ownersGroup &&
                                        this.siteSharingSettings.ownersGroup.title) ||
                                        _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestOwnersGroupRadioButtonLabel
                                },
                                {
                                    key: AccessRequestOption[1],
                                    text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestEmailRadioButtonLabel
                                }
                            ], label: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestChoicesDescription, required: false, onChange: this.onAccessRequestOptionChanged, styles: {
                                applicationRole: {
                                    marginBottom: 16
                                },
                                label: {
                                    fontWeight: '600'
                                }
                            } }))),
                    accessRequestEnabled && accessRequestOption === AccessRequestOption.Email && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: 'ms-siteSharingSettingsPanel-container' },
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_14__["PeoplePicker"], { noResultsFoundText: ' ', context: pageContext, peoplePickerType: _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_15__["PeoplePickerType"].normal, onSelectedPersonasChange: this.onSelectedPeopleChange, onSuggestionSelected: this.onSuggestionSelected, dataProvider: this.peoplePickerProvider, itemLimit: 1, peoplePickerQueryParams: this.pickerParams, selectedItems: selectedPersons }),
                        peoplePickerError)),
                    accessRequestEnabled && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_TextField__WEBPACK_IMPORTED_MODULE_10__["TextField"], { label: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestSiteDescriptionLabel, className: 'ms-siteSharingSettingsPanel-textField', placeholder: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.accessRequestSiteDescriptionPlaceholder, multiline: true, rows: 4, resizable: false, value: accessRequestSiteDescription, onChange: this.onAccessRequestSiteDescriptionChange, maxLength: 500, styles: {
                            subComponentStyles: {
                                label: {
                                    root: {
                                        paddingBottom: 16
                                    }
                                }
                            }
                        } })))),
                showLoadingSpinner && react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_12__["Spinner"], null),
                react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_18__["Dialog"], { hidden: !showConfirmDialog, className: 'ms-siteSharingSettingsPanel-confirmDialog', onDismiss: this.onDiscardDialogClick, dialogContentProps: {
                        type: office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_18__["DialogType"].normal,
                        title: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.dialogTitleText
                    }, modalProps: {
                        isBlocking: false
                    } },
                    react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_18__["DialogFooter"], null,
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__["PrimaryButton"], { className: 'ms-siteSharingSettingsPanel-saveButton', onClick: this.onSaveClick, text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.saveButtonText }),
                        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_11__["DefaultButton"], { className: 'ms-siteSharingSettingsPanel-discardButton', onClick: this.onDiscardDialogClick, text: _SiteSharingSettingsPanel_resx__WEBPACK_IMPORTED_MODULE_6___default.a.discardButtonText }))))));
    };
    SiteSharingSettingsPanelBase.prototype.componentDidMount = function () {
        this.loadSiteSharingSettings();
    };
    SiteSharingSettingsPanelBase.prototype.loadSiteSharingSettings = function () {
        var _this = this;
        this.getSiteSharingSettings().then(function () {
            _this.setState({
                showLoadingSpinner: false,
                membersCanShareOption: _this.getMembersCanShareOption(),
                membersCanShareOptionDisabled: _this.siteSharingSettings &&
                    _this.siteSharingSettings.tenantAdminMembersCanShare &&
                    _this.siteSharingSettings.tenantAdminMembersCanShare !== TenantAdminMemberCanShareOption.Unspecified,
                accessRequestEnabled: _this.siteSharingSettings &&
                    (_this.siteSharingSettings.useAccessRequestDefault || !!_this.siteSharingSettings.requestAccessEmail),
                accessRequestOption: _this.siteSharingSettings &&
                    (_this.siteSharingSettings.useAccessRequestDefault || !_this.siteSharingSettings.requestAccessEmail)
                    ? AccessRequestOption.Default
                    : AccessRequestOption.Email,
                requestAccessEmail: _this.siteSharingSettings && _this.siteSharingSettings.requestAccessEmail,
                accessRequestSiteDescription: _this.siteSharingSettings && _this.siteSharingSettings.accessRequestSiteDescription
            });
            if (_this.state.requestAccessEmail) {
                _this.peoplePickerProvider
                    .resolve(_this.state.requestAccessEmail, _this.pickerParams)
                    .then(function (person) {
                    if (!person.email && person.rawData.EntityData) {
                        person.email = person.rawData.EntityData.OtherMails;
                    }
                    _this.setState({
                        selectedPersons: [person],
                        showLoadingSpinner: false,
                        personaSelected: true
                    });
                });
            }
            else {
                _this.setState({
                    showLoadingSpinner: false
                });
            }
        });
    };
    SiteSharingSettingsPanelBase.prototype.getSiteSharingSettings = function () {
        var _this = this;
        return this.sharingSiteProvider
            .getSiteSharingSettings()
            .then(function (siteSharingSettings) {
            _this.siteSharingSettings = siteSharingSettings;
        })
            .catch(function (error) {
            _this.siteSharingSettings = undefined;
        });
    };
    SiteSharingSettingsPanelBase.prototype.haveSettingsChanged = function () {
        var _a = this.state, accessRequestOption = _a.accessRequestOption, membersCanShareOption = _a.membersCanShareOption, accessRequestEnabled = _a.accessRequestEnabled, accessRequestSiteDescription = _a.accessRequestSiteDescription, selectedPersons = _a.selectedPersons, personaSelected = _a.personaSelected;
        var newRequestAccessEmail = accessRequestEnabled && accessRequestOption === AccessRequestOption.Email && personaSelected
            ? selectedPersons[0].email
            : '';
        this.setMembersCanShareFromOption(membersCanShareOption);
        return (this.siteSharingSettings &&
            (this.siteSharingSettings.membersCanShare !== this.membersCanShareEnabled ||
                (this.siteSharingSettings.membersGroup &&
                    this.siteSharingSettings.membersGroup.allowMembersEditMembership !==
                        this.membersCanAddToGroupEnabled) ||
                this.siteSharingSettings.requestAccessEmail !== newRequestAccessEmail ||
                this.siteSharingSettings.useAccessRequestDefault !==
                    (accessRequestEnabled && accessRequestOption === AccessRequestOption.Default) ||
                this.siteSharingSettings.accessRequestSiteDescription !== accessRequestSiteDescription));
    };
    SiteSharingSettingsPanelBase.prototype.hasInvalidSettings = function () {
        return (this.state.accessRequestEnabled &&
            this.state.accessRequestOption === AccessRequestOption.Email &&
            !this.state.personaSelected);
    };
    SiteSharingSettingsPanelBase.prototype.setMembersCanShareFromOption = function (membersCanShareOption) {
        this.membersCanShareEnabled = false;
        this.membersCanAddToGroupEnabled = false;
        switch (membersCanShareOption) {
            case MembersCanShareOption.FileFolderSite:
                this.membersCanShareEnabled = true;
                this.membersCanAddToGroupEnabled = true;
                break;
            case MembersCanShareOption.FileFolder:
                this.membersCanShareEnabled = true;
                this.membersCanAddToGroupEnabled = false;
                break;
            default:
                this.membersCanShareEnabled = false;
                this.membersCanAddToGroupEnabled = false;
                break;
        }
    };
    SiteSharingSettingsPanelBase.prototype.getMembersCanShareOption = function () {
        var membersCanShareOption = MembersCanShareOption.FileFolderSite;
        if (this.siteSharingSettings) {
            // Use TenantAdmin choice if present
            if (this.siteSharingSettings.tenantAdminMembersCanShare &&
                this.siteSharingSettings.tenantAdminMembersCanShare !== TenantAdminMemberCanShareOption.Unspecified) {
                if (this.siteSharingSettings.tenantAdminMembersCanShare === TenantAdminMemberCanShareOption.On) {
                    membersCanShareOption = MembersCanShareOption.FileFolderSite;
                }
                else {
                    membersCanShareOption = MembersCanShareOption.None;
                }
            }
            else if (this.siteSharingSettings.membersCanShare &&
                this.siteSharingSettings.membersGroup &&
                this.siteSharingSettings.membersGroup.allowMembersEditMembership) {
                membersCanShareOption = MembersCanShareOption.FileFolderSite;
            }
            else if (this.siteSharingSettings.membersCanShare) {
                membersCanShareOption = MembersCanShareOption.FileFolder;
            }
            else {
                membersCanShareOption = MembersCanShareOption.None;
            }
            return membersCanShareOption;
        }
    };
    SiteSharingSettingsPanelBase.prototype.resetState = function () {
        this.setState({
            membersCanShareOption: this.getMembersCanShareOption(),
            accessRequestEnabled: this.siteSharingSettings &&
                (this.siteSharingSettings.useAccessRequestDefault || !!this.siteSharingSettings.requestAccessEmail),
            accessRequestOption: this.siteSharingSettings && this.siteSharingSettings.useAccessRequestDefault
                ? AccessRequestOption.Default
                : AccessRequestOption.Email,
            requestAccessEmail: this.siteSharingSettings && this.siteSharingSettings.requestAccessEmail,
            accessRequestSiteDescription: this.siteSharingSettings && this.siteSharingSettings.accessRequestSiteDescription,
            serverErrorDetails: [],
            saveFailed: false
        });
    };
    return SiteSharingSettingsPanelBase;
}(react__WEBPACK_IMPORTED_MODULE_2__["Component"]));

/**
 * @public
 */
var SiteSharingSettingsPanel = Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_3__["styled"])(SiteSharingSettingsPanelBase, _SiteSharingSettingsPanel_styles__WEBPACK_IMPORTED_MODULE_4__["getStyles"]);
//# sourceMappingURL=SiteSharingSettingsPanel.js.map

/***/ }),

/***/ "YfzS":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-1.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-1\"",
            src: "url('" + baseUrl + "fabric-icons-1-4d521695.woff') format('woff')"
        },
        icons: {
            'Paste': '\uE77F',
            'WindowsLogo': '\uE782',
            'Error': '\uE783',
            'GripperBarVertical': '\uE784',
            'Unlock': '\uE785',
            'Slideshow': '\uE786',
            'Trim': '\uE78A',
            'AutoEnhanceOn': '\uE78D',
            'AutoEnhanceOff': '\uE78E',
            'Color': '\uE790',
            'SaveAs': '\uE792',
            'Light': '\uE793',
            'Filters': '\uE795',
            'AspectRatio': '\uE799',
            'Contrast': '\uE7A1',
            'Redo': '\uE7A6',
            'Crop': '\uE7A8',
            'PhotoCollection': '\uE7AA',
            'Album': '\uE7AB',
            'Rotate': '\uE7AD',
            'PanoIndicator': '\uE7B0',
            'Translate': '\uE7B2',
            'RedEye': '\uE7B3',
            'ViewOriginal': '\uE7B4',
            'ThumbnailView': '\uE7B6',
            'Package': '\uE7B8',
            'Telemarketer': '\uE7B9',
            'Warning': '\uE7BA',
            'Financial': '\uE7BB',
            'Education': '\uE7BE',
            'ShoppingCart': '\uE7BF',
            'Train': '\uE7C0',
            'Move': '\uE7C2',
            'TouchPointer': '\uE7C9',
            'Merge': '\uE7D5',
            'TurnRight': '\uE7DB',
            'Ferry': '\uE7E3',
            'Highlight': '\uE7E6',
            'PowerButton': '\uE7E8',
            'Tab': '\uE7E9',
            'Admin': '\uE7EF',
            'TVMonitor': '\uE7F4',
            'Speakers': '\uE7F5',
            'Game': '\uE7FC',
            'HorizontalTabKey': '\uE7FD',
            'UnstackSelected': '\uE7FE',
            'StackIndicator': '\uE7FF',
            'Nav2DMapView': '\uE800',
            'StreetsideSplitMinimize': '\uE802',
            'Car': '\uE804',
            'Bus': '\uE806',
            'EatDrink': '\uE807',
            'SeeDo': '\uE808',
            'LocationCircle': '\uE80E',
            'Home': '\uE80F',
            'SwitcherStartEnd': '\uE810',
            'ParkingLocation': '\uE811',
            'IncidentTriangle': '\uE814',
            'Touch': '\uE815',
            'MapDirections': '\uE816',
            'CaretHollow': '\uE817',
            'CaretSolid': '\uE818',
            'History': '\uE81C',
            'Location': '\uE81D',
            'MapLayers': '\uE81E',
            'SearchNearby': '\uE820',
            'Work': '\uE821',
            'Recent': '\uE823',
            'Hotel': '\uE824',
            'Bank': '\uE825',
            'LocationDot': '\uE827',
            'Dictionary': '\uE82D',
            'ChromeBack': '\uE830',
            'FolderOpen': '\uE838',
            'PinnedFill': '\uE842',
            'RevToggleKey': '\uE845',
            'USB': '\uE88E',
            'Previous': '\uE892',
            'Next': '\uE893',
            'Sync': '\uE895',
            'Help': '\uE897',
            'Emoji': '\uE899',
            'MailForward': '\uE89C',
            'ClosePane': '\uE89F',
            'OpenPane': '\uE8A0',
            'PreviewLink': '\uE8A1',
            'ZoomIn': '\uE8A3',
            'Bookmarks': '\uE8A4',
            'Document': '\uE8A5',
            'ProtectedDocument': '\uE8A6',
            'OpenInNewWindow': '\uE8A7',
            'MailFill': '\uE8A8',
            'ViewAll': '\uE8A9',
            'Switch': '\uE8AB',
            'Rename': '\uE8AC',
            'Go': '\uE8AD',
            'Remote': '\uE8AF',
            'SelectAll': '\uE8B3',
            'Orientation': '\uE8B4',
            'Import': '\uE8B5'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-1.js.map

/***/ }),

/***/ "Z+E6":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipPanel.js ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipPanel", function() { return GroupMembershipPanel; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _GroupMembershipPanel_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GroupMembershipPanel.scss */ "cCgw");
/* harmony import */ var office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/Panel */ "p6C6");
/* harmony import */ var office_ui_fabric_react_lib_components_Button_IconButton_IconButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/Button/IconButton/IconButton */ "cULl");
/* harmony import */ var office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Persona */ "UXmd");
/* harmony import */ var _GroupMembershipMenu_GroupMembershipMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./GroupMembershipMenu/GroupMembershipMenu */ "zlrR");
/* harmony import */ var _GroupMembershipList_GroupMembershipList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./GroupMembershipList/GroupMembershipList */ "dnCp");
/* harmony import */ var office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! office-ui-fabric-react/lib/Button */ "epn0");
/* harmony import */ var _PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker */ "5zxV");
/* harmony import */ var _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker.Props */ "wWxM");
/* harmony import */ var office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! office-ui-fabric-react/lib/Spinner */ "fyAn");
/* harmony import */ var office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! office-ui-fabric-react/lib/Link */ "F3Wv");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! office-ui-fabric-react/lib/Dialog */ "wPGM");
/* harmony import */ var office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! office-ui-fabric-react/lib/MessageBar */ "oW6A");
/* harmony import */ var _components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../components/LivePersonaCardAdapter/DeferredSpLivePersonaCard */ "5Txe");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _utilities_wrapPlaceholderContent__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../utilities/wrapPlaceholderContent */ "dHB+");
/* harmony import */ var _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ms/odsp-utilities/lib/guid/Guid */ "vo05");
/* harmony import */ var _GroupMembershipPanel_resx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./GroupMembershipPanel.resx */ "QVZ7");
/* harmony import */ var _GroupMembershipPanel_resx__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_GroupMembershipPanel_resx__WEBPACK_IMPORTED_MODULE_20__);





















/**
 * @public
 */
var GroupMembershipPanel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(GroupMembershipPanel, _super);
    function GroupMembershipPanel(props) {
        var _this = _super.call(this, props) || this;
        _this._onClickDismiss = function () {
            _this._setIsAddingMembers(false);
        };
        _this._onRenderPersona = function (persona, index) {
            if (persona && typeof index === 'number') {
                var personaControl = _this._getPersonaControl(persona);
                return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-itemBtn', title: persona.name, key: index },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-personName' }, personaControl)));
            }
            else {
                return undefined;
            }
        };
        _this._closePanel = function () {
            _this.setState({ showPanel: false });
            if (_this.props.onDismiss) {
                _this.props.onDismiss();
            }
        };
        _this._onClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.AddMembers.Click', isIntentional: true });
            _this._setIsAddingMembers(true);
        };
        _this._onCancelClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.Cancel.Click', isIntentional: true });
            _this._setIsAddingMembers(false);
        };
        _this._onDoneClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.Save.Click', isIntentional: true });
            // clear any error message from previous attempts
            if (_this.props.errorMessageText) {
                _this.props.clearErrorMessage();
            }
            if (_this.state.selectedMembers && _this.state.selectedMembers.length > 0) {
                if (_this.props.onSave) {
                    _this.setState({
                        showSavingSpinner: true,
                        saveButtonDisabled: true
                    });
                    _this.props.onSave(_this.state.selectedMembers).then(function () {
                        // If save was successful, return to members list view
                        _this.setState({
                            isAddingMembers: false,
                            isAddingGuest: false,
                            selectedMembers: [],
                            showSavingSpinner: false,
                            saveButtonDisabled: true
                        });
                    }, function (error) {
                        // If save was not successful, remain in add members view
                        // Error message was set in state manager
                        _this.setState({
                            showSavingSpinner: false,
                            saveButtonDisabled: false
                        });
                    });
                }
            }
            else {
                // If no members were selected to add, clicking Save simply takes you back to the members list experience
                _this._setIsAddingMembers(false);
            }
        };
        /**
         * When a user clicks the link to view a large group in Outlook, log the event before
         * navigating away. Users need to go to OWA to search for a specific member.
         */
        _this._logLargeGroupOutlookClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.LargeGroupSearchLink.Click', isIntentional: true });
            return true;
        };
        /**
         * When a user clicks the link to add guests in Outlook, log the event before
         * navigating away.
         */
        _this._logAddGuestsLinkClick = function () {
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.AddGuestOutlookLink.Click', isIntentional: true });
            return true;
        };
        _this._onSelectedMembersChange = function (selectedPersonas) {
            // If canAddGuests is true, we allow guest users to resolve in the PeoplePicker.
            // If one of the selected members is a guest, we need to show the guest info message.
            var guestIsSelected = false;
            if (_this.props.canAddGuests) {
                guestIsSelected = selectedPersonas.some(function (value) {
                    return value.entityType === 1; /* EntityType.externalUser */
                });
            }
            _this.setState({
                selectedMembers: selectedPersonas,
                isAddingGuest: guestIsSelected,
                saveButtonDisabled: !selectedPersonas.length // Disable Save button if zero members selected
            });
        };
        _this._closeDialog = function () {
            if (_this.props.onCloseConfirmationDialog) {
                _this.props.onCloseConfirmationDialog();
            }
        };
        _this._approveDialog = function () {
            if (_this.props.onApproveConfirmationDialog) {
                _this.props.onApproveConfirmationDialog();
            }
        };
        _this._dismissErrorMessage = function () {
            _this.props.clearErrorMessage();
        };
        _this.state = {
            showPanel: true,
            isAddingMembers: false,
            isAddingGuest: false,
            selectedMembers: [],
            showSavingSpinner: false,
            saveButtonDisabled: true // Disable Save button until at least one member is selected
        };
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["Engagement"].logData({ name: 'GroupMembershipPanel.Opened.Click' });
        return _this;
    }
    GroupMembershipPanel.prototype.render = function () {
        var _this = this;
        // If members have loaded, display them. Otherwise, show a spinner.
        var membersList = react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_11__["Spinner"], { className: 'ms-groupMemberList-spinner' });
        // For long lists of members, render link to OWA.
        // Message appears at top of members list and tells users to
        // go to OWA if they want to search the large list for a specific member.
        var searchMembersMessage = undefined;
        if (this.props.largeGroupMessage) {
            searchMembersMessage = this._getMessageWithLink(this.props.largeGroupMessage, this.props.outlookLinkText, 'ms-groupMember-largeGroupMessage', this._logLargeGroupOutlookClick);
        }
        var personas = this.props ? this.props.personas : undefined;
        if (personas && personas.length > 0) {
            // Show virtualized members list (uses paging)
            membersList = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_GroupMembershipList_GroupMembershipList__WEBPACK_IMPORTED_MODULE_7__["GroupMembershipList"], { members: personas, totalNumberOfMembers: this.props.totalNumberOfMembers, onRenderPersona: this._onRenderPersona, onLoadMoreMembers: this.props.onLoadMoreMembers }));
        }
        var footerContent = function (props, defaultRender) {
            return _this.state.isAddingMembers ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMemberButton-div', "data-automationid": 'GroupMembershipPanelFooter' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-groupMemberButton-container' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__["PrimaryButton"], { disabled: _this.state.saveButtonDisabled, onClick: _this._onDoneClick, "data-automationid": 'AddMembersSaveButton' }, _this.props.doneButtonText)),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-groupMemberButton-container' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__["DefaultButton"], { onClick: _this._onCancelClick, "data-automationid": 'AddMembersCancelButton', className: 'ms-groupMemberButton-Cancel' }, _this.props.cancelButtonText)))) : null;
        };
        var navigationContent = function (props, defaultRender) {
            return _this.state.isAddingMembers ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-NavigationContent' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_components_Button_IconButton_IconButton__WEBPACK_IMPORTED_MODULE_4__["IconButton"], { iconProps: { iconName: 'Back' }, className: 'ms-groupMember-BackIcon', onClick: _this._onClickDismiss, ariaLabel: _this.props.closeButtonAriaLabel }),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: 'ms-groupMember-Title' },
                    " ",
                    _this.props.addMembersText),
                defaultRender(props))) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-NavigationContentDismiss' },
                " ",
                defaultRender(props),
                " "));
        };
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_3__["Panel"], { className: 'ms-groupMemberPanel', isOpen: this.state.showPanel, type: office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_3__["PanelType"].smallFixedFar, onDismiss: this._closePanel, isLightDismiss: true, closeButtonAriaLabel: this.props.closeButtonAriaLabel, headerText: this.state.isAddingMembers ? null : this.props.title, onRenderFooterContent: footerContent, onRenderNavigationContent: navigationContent },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { "data-automationid": 'GroupMembershipPanelContents', className: 'ms-GroupMembershipPanelContents' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_14__["Dialog"], { hidden: !this.props.showConfirmationDialog, type: office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_14__["DialogType"].close, onDismiss: this._closeDialog, subText: this.props.confirmationText, isBlocking: false, closeButtonAriaLabel: this.props.closeButtonAriaLabel },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Dialog__WEBPACK_IMPORTED_MODULE_14__["DialogFooter"], null,
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__["PrimaryButton"], { onClick: this._approveDialog }, this.props.okButtonText),
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__["DefaultButton"], { onClick: this._closeDialog }, this.props.cancelButtonText))),
                this.props.errorMessageText && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-errorMessage' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_15__["MessageBar"], { messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_15__["MessageBarType"].error, isMultiline: true, onDismiss: this._dismissErrorMessage, dismissButtonAriaLabel: this.props.dismissErrorMessageAriaLabel }, this.props.errorMessageText))),
                !this.state.isAddingMembers && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { "data-automationid": 'GroupMembersList' },
                    searchMembersMessage,
                    this.props.numberOfMembersText && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { "aria-live": 'assertive', className: 'ms-groupMember-membersCount', "data-automationid": 'PanelNumberOfMembersText' }, this.props.numberOfMembersText)),
                    this.props.canAddMembers && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-AddMemberButtonArea' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_8__["PrimaryButton"], { onClick: this._onClick, iconProps: { iconName: 'PeopleAdd' }, "data-automationid": 'AddMembersButton' }, this.props.addMembersText))),
                    membersList)),
                this.state.isAddingMembers && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { "data-automationid": 'AddMembersView', className: 'ms-groupMember-addingDiv' },
                    this.state.isAddingGuest && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-addingGuest' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_15__["MessageBar"], { messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_15__["MessageBarType"].info, isMultiline: true }, this.props.addingGuestText))),
                    this._getAddMemberInstructions(),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMember-peoplePicker', "data-automationid": 'AddMembersPeoplePicker' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_9__["PeoplePicker"], { context: this.props.pageContext, peoplePickerType: _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_10__["PeoplePickerType"].listBelow, peoplePickerQueryParams: this._getPeoplePickerQueryParams(), onSelectedPersonasChange: this._onSelectedMembersChange, inputProps: this._getPeoplePickerInputProps(), dataSource: this.props.peoplePickerDataSource, suggestionsAvailableAlertText: _GroupMembershipPanel_resx__WEBPACK_IMPORTED_MODULE_20___default.a.suggestionsAvailableAlertText, enableSelectedSuggestionAlert: true })),
                    this.state.showSavingSpinner && react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_11__["Spinner"], { className: 'ms-groupMember-spinner' }))))));
    };
    GroupMembershipPanel.prototype._makeDeferredLpcProps = function (persona) {
        return {
            personaType: persona && persona.type === 2 ? 'Group' : 'User',
            identifier: persona && persona.email,
            pageContext: this.props.pageContext,
            moduleLoader: this.props.lpcModuleLoader,
            customWaiter: this.props.lpcModuleCustomWaiter,
            addGroupMembersCallback: undefined,
            lpcHoverTargetProps: {
                upn: persona && persona.email,
                hostAppPersonaInfo: {
                    PersonaDisplayName: persona && persona.name
                }
            }
        };
    };
    GroupMembershipPanel.prototype._wrapPersona = function (persona, targetClassName) {
        var _this = this;
        return function (coinProps, defaultCoinRenderer) {
            var cardProps = _this._makeDeferredLpcProps(persona);
            return Object(_components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_16__["wrapWithDeferredSpLivePersonaCard"])(cardProps, react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: targetClassName },
                " ",
                defaultCoinRenderer(coinProps)));
        };
    };
    GroupMembershipPanel.prototype._getPersonaControl = function (persona) {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_5__["Persona"], { imageUrl: persona.imageUrl, primaryText: persona.name, size: office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_5__["PersonaSize"].small, hidePersonaDetails: false, onRenderCoin: this.props.lpcModuleLoader ? this._wrapPersona(persona, 'ms-groupMember-lpcpersonacoin') : undefined, onRenderPrimaryText: this.props.lpcModuleLoader
                ? this._wrapPersona(persona, 'ms-groupMember-lpcpersonatitle')
                : undefined, "data-automationid": 'GroupMemberPersona' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_GroupMembershipMenu_GroupMembershipMenu__WEBPACK_IMPORTED_MODULE_6__["GroupMembershipMenu"], { menuItems: this.props.canChangeMemberStatus ? persona.memberStatusMenuItems : null, title: persona.contextualMenuTitle, showSpinner: persona.showSpinner })));
    };
    /**
     * Get the instructions to show above the PeoplePicker.
     * If adding guests is allowed, use a formatted string with a link to the members list in Outlook. This directs users to Outlook if they wish to
     * add guests by resolving arbitrary email addresses, which is not supported as of June 2017.
     * If adding guests is not allowed, use a simple string.
     */
    GroupMembershipPanel.prototype._getAddMemberInstructions = function () {
        var instructionsClassName = 'ms-groupMember-addMemberInstructions';
        if (this.props.showGuestsMessage &&
            this.props.addMembersOrGuestsInstructionsText &&
            this.props.addGuestsLinkText) {
            return this._getMessageWithLink(this.props.addMembersOrGuestsInstructionsText, this.props.addGuestsLinkText, instructionsClassName, this._logAddGuestsLinkClick);
        }
        else {
            return react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: instructionsClassName }, this.props.addMembersInstructionsText);
        }
    };
    /**
     * Get a formatted message including a link to Outlook.
     *
     * @param outerMessage The message with the '{0}' token to indicate the position of the inline link
     * @param innerMessage The text to display for the inline link
     * @param divClassName The class name to apply to the outer div element
     * @param onClickFunction The function to call when a user clicks the link before navigating to Outlook. Used for engagement logging.
     */
    GroupMembershipPanel.prototype._getMessageWithLink = function (outerMessage, innerMessage, divClassName, onClickFunction) {
        var messageWithLink = null;
        if (this.props.membersUrl && outerMessage && innerMessage) {
            messageWithLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: divClassName }, Object(_utilities_wrapPlaceholderContent__WEBPACK_IMPORTED_MODULE_18__["wrapPlaceholderContent"])(outerMessage, innerMessage, office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_12__["Link"], {
                href: this.props.membersUrl,
                onClick: onClickFunction,
                target: '_blank'
            })));
        }
        return messageWithLink;
    };
    /**
     * Need to use non-default query parameters for the PeoplePicker.
     * In particular, do not allow email addresses or groups (security groups and SharePoint groups)
     */
    GroupMembershipPanel.prototype._getPeoplePickerQueryParams = function () {
        var _a = this.props, pageContext = _a.pageContext, canAddGuests = _a.canAddGuests;
        var useIBSegmentsKillSwitch = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_17__["Killswitch"].isActivated('34c10010-00ae-48db-8ec7-d9fd2f8d7804', '3/19/2020', 'use IBSegment');
        return {
            allowEmailAddresses: false,
            allowMultipleEntities: null,
            allUrlZones: null,
            enabledClaimProviders: null,
            forceClaims: null,
            groupID: 0,
            maximumEntitySuggestions: 30,
            principalSource: 15,
            principalType: 1,
            required: null,
            urlZone: null,
            urlZoneSpecified: null,
            filterExternalUsers: !canAddGuests,
            blockExternalUsers: !canAddGuests,
            useGraph: !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_17__["Killswitch"].isActivated('F18F4F84-A337-4C37-81BF-20545B8B9BD9', '4/28/2020', 'Use enforceIBSegmentFilter.')
                ? !pageContext.enforceIBSegmentFilter
                : true,
            useSubstrate: useIBSegmentsKillSwitch && pageContext.IBSegments && pageContext.IBSegments.length > 0,
            conversationId: _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_19__["default"].generate(),
            siteIBSegmentIDs: useIBSegmentsKillSwitch && pageContext.IBSegments
        };
    };
    /**
     * Input element native props to be put onto the input element in the PeoplePicker
     */
    GroupMembershipPanel.prototype._getPeoplePickerInputProps = function () {
        return {
            placeholder: this.props.peoplePickerPlaceholderText,
            'aria-label': _GroupMembershipPanel_resx__WEBPACK_IMPORTED_MODULE_20___default.a.peoplePickerToAddMembers,
            autoFocus: true
        };
    };
    /**
     * When you switch between viewing the members list and adding members,
     * also clear any error messages, warnings, and previously selected members.
     *
     * @param {boolean} newState - true to choose the adding members state, false for the members list
     */
    GroupMembershipPanel.prototype._setIsAddingMembers = function (newState) {
        this.setState({
            isAddingMembers: newState,
            isAddingGuest: false,
            selectedMembers: [],
            saveButtonDisabled: true
        });
        if (this.props.errorMessageText) {
            this.props.clearErrorMessage();
        }
    };
    return GroupMembershipPanel;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=GroupMembershipPanel.js.map

/***/ }),

/***/ "ZRaF":
/*!**********************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/utilities-date-time@1.2.0/node_modules/@ms/utilities-date-time/lib/relativePast.js ***!
  \**********************************************************************************************************************************************/
/*! exports provided: getRelativeDateTimeStringPast, getRelativeDateTimeStringPastWithHourMinute, getRelativeDateTimeResx, getRelativeDateTimeIntervalString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRelativeDateTimeStringPast", function() { return getRelativeDateTimeStringPast; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRelativeDateTimeStringPastWithHourMinute", function() { return getRelativeDateTimeStringPastWithHourMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRelativeDateTimeResx", function() { return getRelativeDateTimeResx; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRelativeDateTimeIntervalString", function() { return getRelativeDateTimeIntervalString; });
/* harmony import */ var _ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/utilities-strings/lib/index */ "2h7V");
/* harmony import */ var _ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./helpers */ "PgVY");
/* harmony import */ var _DateTime_resx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DateTime.resx */ "lnCR");
/* harmony import */ var _DateTime_resx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_DateTime_resx__WEBPACK_IMPORTED_MODULE_2__);



/**
 * Get a string like "X minutes ago" that reflects the time elapsed since the input time.
 * Only works for past times, future times just return a browser-determined localized time string.
 */
function getRelativeDateTimeStringPast(pastTime, language, startWithLowerCase) {
    if (startWithLowerCase === void 0) { startWithLowerCase = false; }
    var timespan = Date.now() - pastTime.getTime(); // time elapsed in ms
    if (timespan < -5 * _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_MINUTE"]) {
        // in the future, with a 5m leeway
        return toLocaleDateString(pastTime, language);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_MINUTE"]) {
        // 1m ago to 5m in the future
        // "Less than a minute ago"
        return getRelativeDateTimeResx('LessThanAMinute', startWithLowerCase);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["TWO_MINUTES"]) {
        // "About a minute ago"
        return getRelativeDateTimeResx('AboutAMinute', startWithLowerCase);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_HOUR"]) {
        // "{0} minutes ago"
        var minutes = Math.floor(timespan / _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_MINUTE"]);
        return getRelativeDateTimeIntervalString(minutes, 'XMinutes');
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["TWO_HOURS"]) {
        // "About an hour ago"
        return getRelativeDateTimeResx('AboutAnHour', startWithLowerCase);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_DAY"]) {
        // "{0} hours ago"
        var hours = Math.floor(timespan / _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_HOUR"]);
        return getRelativeDateTimeIntervalString(hours, 'XHours');
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["TWO_DAYS"]) {
        // "Yesterday at {0}"
        var locTime = pastTime.toLocaleTimeString(language);
        return getRelativeDateTimeResx('YesterdayAndTime', startWithLowerCase).replace('{0}', locTime);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_MONTH"]) {
        // "{0} days ago" (in the past month-ish)
        var days = Math.floor(timespan / _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_DAY"]);
        return getRelativeDateTimeIntervalString(days, 'XDays');
    }
    // Any other time, just return the regular full original time
    return toLocaleDateString(pastTime, language); // browser-determined localized date (no time)
}
/**
 * This is a modified implementation of `DateTime.GetRelativeDateTimeStringPast(...)`.
 * The differences here are as follows:
 *   1. The time string for yesterday does not include the seconds
 *   2. Instead of showing 'X days ago' for dates older than a month, default to showing the full date
 *   3. The full date will also include the time (also without seconds)
 */
function getRelativeDateTimeStringPastWithHourMinute(pastTime, language) {
    var timespan = Date.now() - pastTime.getTime(); // time elapsed in ms
    var date = pastTime.toLocaleDateString(language); // browser-determined localized date
    var time = pastTime.toLocaleTimeString(language, { hour: 'numeric', minute: '2-digit' }); // time without seconds
    if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["ONE_DAY"]) {
        return getRelativeDateTimeStringPast(pastTime, language);
    }
    else if (timespan < _helpers__WEBPACK_IMPORTED_MODULE_1__["TWO_DAYS"]) {
        // "Yesterday at {0}" without seconds
        return Object(_ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0__["format"])(_DateTime_resx__WEBPACK_IMPORTED_MODULE_2___default.a.RelativeDateTime_YesterdayAndTime, time);
    }
    // Any other time, just return the regular full original date with time, without seconds
    return Object(_ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0__["format"])(_DateTime_resx__WEBPACK_IMPORTED_MODULE_2___default.a.DateTime_DateAndTime, date, time);
}
/**
 * Internal helper function to reduce verbosity of string names.
 */
function getRelativeDateTimeResx(name, startWithLowerCase, isFuture, isInterval) {
    // Example full string names:
    // RelativeDateTime_AboutAnHour
    // RelativeDateTime_AboutAnHour_StartWithLowerCase
    // RelativeDateTime_AboutAnHourFuture
    // RelativeDateTime_AboutAnHourFuture_StartWithLowerCase
    // tslint:disable-next-line:no-any
    return _DateTime_resx__WEBPACK_IMPORTED_MODULE_2___default.a[[
        'RelativeDateTime_',
        name,
        isFuture ? 'Future' : '',
        isInterval ? 'Intervals' : '',
        startWithLowerCase ? '_StartWithLowerCase' : ''
    ].join('')];
}
/**
 * Internal helper function to get a localized count value for an interval.
 */
function getRelativeDateTimeIntervalString(value, intervalType, startWithLowerCase, isFuture) {
    // Example full string names:
    // RelativeDateTime_XMinutes
    // RelativeDateTime_XMinutesFuture
    // RelativeDateTime_XMinutesFuture_StartWithLowerCase
    // (note non-future variant has no lowercase variant...so English-centric)
    var mainResx = getRelativeDateTimeResx(intervalType, isFuture ? startWithLowerCase : false, isFuture);
    // Example full string names:
    // RelativeDateTime_XMinutesIntervals
    // RelativeDateTime_XMinutesFutureIntervals
    var intervalResx = getRelativeDateTimeResx(intervalType, false /*lowercase*/, isFuture, true /*intervals*/);
    return (Object(_ms_utilities_strings_lib_index__WEBPACK_IMPORTED_MODULE_0__["getLocalizedCountValue"])(mainResx, intervalResx, value) || '').replace('{0}', value + '');
}
var dateTimeFormat = {};
/**
 * Helper function formatting the given time with the given language.
 * In order to significantly speed up performance, a memoized instance of `Intl.DateTimeFormat`
 * (if available in the browser) is used for formatting.
 */
function toLocaleDateString(time, language) {
    if (typeof Intl !== 'undefined' && Intl.DateTimeFormat) {
        if (!dateTimeFormat[language]) {
            dateTimeFormat[language] = new Intl.DateTimeFormat(language);
        }
        return dateTimeFormat[language].format(time);
    }
    else {
        return time.toLocaleDateString(language);
    }
}
//# sourceMappingURL=relativePast.js.map

/***/ }),

/***/ "ZUAD":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-12.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-12\"",
            src: "url('" + baseUrl + "fabric-icons-12-7e945a1e.woff') format('woff')"
        },
        icons: {
            'FinancialSolid': '\uF346',
            'FinancialMirroredSolid': '\uF347',
            'HeadsetSolid': '\uF348',
            'PermissionsSolid': '\uF349',
            'ParkingSolid': '\uF34A',
            'ParkingMirroredSolid': '\uF34B',
            'DiamondSolid': '\uF34C',
            'AsteriskSolid': '\uF34D',
            'OfflineStorageSolid': '\uF34E',
            'BankSolid': '\uF34F',
            'DecisionSolid': '\uF350',
            'Parachute': '\uF351',
            'ParachuteSolid': '\uF352',
            'FiltersSolid': '\uF353',
            'ColorSolid': '\uF354',
            'ReviewSolid': '\uF355',
            'ReviewRequestSolid': '\uF356',
            'ReviewRequestMirroredSolid': '\uF357',
            'ReviewResponseSolid': '\uF358',
            'FeedbackRequestSolid': '\uF359',
            'FeedbackRequestMirroredSolid': '\uF35A',
            'FeedbackResponseSolid': '\uF35B',
            'WorkItemBar': '\uF35C',
            'WorkItemBarSolid': '\uF35D',
            'Separator': '\uF35E',
            'NavigateExternalInline': '\uF35F',
            'PlanView': '\uF360',
            'TimelineMatrixView': '\uF361',
            'EngineeringGroup': '\uF362',
            'ProjectCollection': '\uF363',
            'CaretBottomRightCenter8': '\uF364',
            'CaretBottomLeftCenter8': '\uF365',
            'CaretTopRightCenter8': '\uF366',
            'CaretTopLeftCenter8': '\uF367',
            'DonutChart': '\uF368',
            'ChevronUnfold10': '\uF369',
            'ChevronFold10': '\uF36A',
            'DoubleChevronDown8': '\uF36B',
            'DoubleChevronUp8': '\uF36C',
            'DoubleChevronLeft8': '\uF36D',
            'DoubleChevronRight8': '\uF36E',
            'ChevronDownEnd6': '\uF36F',
            'ChevronUpEnd6': '\uF370',
            'ChevronLeftEnd6': '\uF371',
            'ChevronRightEnd6': '\uF372',
            'ContextMenu': '\uF37C',
            'AzureAPIManagement': '\uF37F',
            'AzureServiceEndpoint': '\uF380',
            'VSTSLogo': '\uF381',
            'VSTSAltLogo1': '\uF382',
            'VSTSAltLogo2': '\uF383',
            'FileTypeSolution': '\uF387',
            'WordLogoInverse16': '\uF390',
            'WordLogo16': '\uF391',
            'WordLogoFill16': '\uF392',
            'PowerPointLogoInverse16': '\uF393',
            'PowerPointLogo16': '\uF394',
            'PowerPointLogoFill16': '\uF395',
            'ExcelLogoInverse16': '\uF396',
            'ExcelLogo16': '\uF397',
            'ExcelLogoFill16': '\uF398',
            'OneNoteLogoInverse16': '\uF399',
            'OneNoteLogo16': '\uF39A',
            'OneNoteLogoFill16': '\uF39B',
            'OutlookLogoInverse16': '\uF39C',
            'OutlookLogo16': '\uF39D',
            'OutlookLogoFill16': '\uF39E',
            'PublisherLogoInverse16': '\uF39F',
            'PublisherLogo16': '\uF3A0',
            'PublisherLogoFill16': '\uF3A1',
            'VisioLogoInverse16': '\uF3A2',
            'VisioLogo16': '\uF3A3',
            'VisioLogoFill16': '\uF3A4',
            'TestBeaker': '\uF3A5',
            'TestBeakerSolid': '\uF3A6',
            'TestExploreSolid': '\uF3A7',
            'TestAutoSolid': '\uF3A8',
            'TestUserSolid': '\uF3A9',
            'TestImpactSolid': '\uF3AA',
            'TestPlan': '\uF3AB',
            'TestStep': '\uF3AC',
            'TestParameter': '\uF3AD',
            'TestSuite': '\uF3AE',
            'TestCase': '\uF3AF',
            'Sprint': '\uF3B0',
            'SignOut': '\uF3B1',
            'TriggerApproval': '\uF3B2',
            'Rocket': '\uF3B3',
            'AzureKeyVault': '\uF3B4',
            'Onboarding': '\uF3BA',
            'Transition': '\uF3BC',
            'LikeSolid': '\uF3BF',
            'DislikeSolid': '\uF3C0',
            'CRMCustomerInsightsApp': '\uF3C8',
            'EditCreate': '\uF3C9',
            'PlayReverseResume': '\uF3E4',
            'PlayReverse': '\uF3E5',
            'SearchData': '\uF3F1',
            'UnSetColor': '\uF3F9',
            'DeclineCall': '\uF405'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-12.js.map

/***/ }),

/***/ "ZduO":
/*!*******************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/AccessRequests/AccessRequestsDataSource.js ***!
  \*******************************************************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestsDataSource */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsDataSource", function() { return AccessRequestsDataSource; });
/* harmony import */ var _base_DataRequestor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../base/DataRequestor */ "PayJ");
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/guid/Guid */ "vo05");
/* harmony import */ var _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base/DataBatchOperationHelper */ "zMwE");





var GetPendingAccessRequestsUrlEndpoint = '/_api/web/AccessRequestsList/GetItems';
var GetIfPendingAccessRequestsUrlEndpoint = '/_api/SP.Web.GetObjectSharingSettings?$expand=ObjectSharingInformation';
var ChangeRequestStatusEndpoint = '/_api/SP.AccessRequests.ChangeRequestStatus';
/**
 * SitePermissionssStateManager definitions
 */
var PERMISSION_ID = {
    Edit: 1073741830,
    Read: 1073741826
};
/**
 * @inheritdoc
 * Class that handles API calls related to Access Requests
 *
 * ChangeRequestStatus to change request status of one or multiple requests
 *
 * GetPendingAccessRequests uses AccessRequestsList to get list of
 * pending requests, parses json into IAccessRequest list
 *
 * hasAccessRequests uses
 * SP.Web.GetObjectSharingSettings to get a boolean hasPendingAccessRequests, used by
 * SitePermissionsPanel
 */
var AccessRequestsDataSource = /** @class */ (function () {
    function AccessRequestsDataSource(params) {
        this._pageContext = params.pageContext;
        this._urlBeginning = Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__["getSafeWebServerRelativeUrl"])(params.pageContext);
        this._getPendingAccessRequestsUrl = this._urlBeginning + GetPendingAccessRequestsUrlEndpoint;
        this._getChangeRequestStatusUrl = this._urlBeginning + ChangeRequestStatusEndpoint;
        this._getIfPendingAccessRequestsUrl = this._urlBeginning + GetIfPendingAccessRequestsUrlEndpoint;
        this._dataRequestor = new _base_DataRequestor__WEBPACK_IMPORTED_MODULE_0__["default"]({ pageContext: params.pageContext });
    }
    AccessRequestsDataSource.prototype.changeRequestStatus = function (requests, newStatus) {
        var _this = this;
        if (!requests || requests.length < 1) {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_1__["default"].reject([false]);
        }
        if (requests.length > 1) {
            var batchGuid = _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_3__["default"].generate();
            var contentType = 'multipart/mixed; boundary=batch_' + batchGuid;
            var perReqContentBody_1 = [];
            var perReqMethod_1 = [];
            var endpoints_1 = [];
            requests.forEach(function (request) {
                endpoints_1.push(_this._getChangeRequestStatusUrl);
                var permType = request.isWeb ? 'SharePoint Group' : 'Role Definition';
                var permissionLevel = request.isWeb
                    ? request.groupId
                    : request.isEditor
                        ? PERMISSION_ID.Edit
                        : PERMISSION_ID.Read;
                perReqContentBody_1.push(JSON.stringify({
                    itemId: request.id,
                    newStatus: newStatus,
                    convStr: null,
                    permType: permType,
                    permissionLevel: permissionLevel
                }));
                perReqMethod_1.push('POST');
            });
            var bathRequestPromise = this._dataRequestor.getData({
                url: _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["default"].getBatchOperationUrl(this._pageContext.webAbsoluteUrl),
                parseResponse: function (responseText) {
                    return responseText;
                },
                qosName: 'acceptDenyAccessRequests',
                additionalPostData: _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["default"].getBatchContentExtended(batchGuid, endpoints_1, 'POST', _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["default"].defaultBatchRequestPostData, perReqContentBody_1, _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["default"].defaultBatchAcceptData, perReqMethod_1),
                method: 'POST',
                contentType: contentType,
                noRedirect: true,
                needsRequestDigest: true
            });
            return bathRequestPromise
                .then(function (responseText) {
                var result = _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["default"].processBatchResponse(responseText);
                if (result.hasError) {
                    return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_1__["default"].reject(result);
                }
                return result;
            })
                .then(function (result) {
                return result.items.map(function () { return true; });
            }, function (error) {
                return error.items.map(function (response) { return !response.error; });
            });
        }
        else {
            var url = this._getChangeRequestStatusUrl;
            var permType = requests[0].isWeb ? 'SharePoint Group' : 'Role Definition';
            var permissionLevel = requests[0].isWeb
                ? requests[0].groupId
                : requests[0].isEditor
                    ? PERMISSION_ID.Edit
                    : PERMISSION_ID.Read;
            var contentBody = {
                itemId: requests[0].id,
                newStatus: newStatus,
                convStr: null,
                permType: permType,
                permissionLevel: permissionLevel
            };
            return this._dataRequestor.getData({
                url: url,
                parseResponse: function (responseText) {
                    return [!responseText];
                },
                qosName: 'acceptDenyAccessRequests',
                additionalPostData: JSON.stringify(contentBody),
                method: 'POST',
                noRedirect: true,
                needsRequestDigest: true
            });
        }
    };
    AccessRequestsDataSource.prototype.getPendingAccessRequests = function (orderBy, ascending, top, skip) {
        var _this = this;
        var queryParams = [];
        if (top) {
            queryParams.push('$top=' + top);
        }
        if (skip) {
            queryParams.push('$skip=' + skip);
        }
        queryParams.push('$select=ID,RequestedForDisplayName,RequestDate,ObjectRequestedTitleDisp,RequestedObjectUrl,RequestedForUserId,RequestedFor,Conversation,RequestedWebId,RequestedListId,RequestedListItemId');
        var url = this._getPendingAccessRequestsUrl;
        if (queryParams.length > 0) {
            url += '?' + queryParams.join('&');
        }
        var cendingString = !ascending ? 'TRUE' : 'FALSE';
        var postBody = {
            query: {
                __metadata: {
                    type: 'SP.CamlQuery'
                },
                ViewXml: "<View><Query><OrderBy><FieldRef Name='" +
                    orderBy +
                    "' Ascending='" +
                    cendingString +
                    "'/></OrderBy><Where><And><Eq><FieldRef Name='IsInvitation'></FieldRef><Value Type='Boolean'>0</Value></Eq><Eq><FieldRef Name='Status'></FieldRef><Value Type='Integer'>0</Value></Eq></And></Where></Query></View>"
            }
        };
        return this._dataRequestor.getData({
            url: url,
            method: 'POST',
            additionalPostData: JSON.stringify(postBody),
            qosName: 'getPendingAccessRequests',
            parseResponse: function (responseText) {
                var src = JSON.parse(responseText);
                return src && src.d && src.d.results
                    ? src.d.results.map(function (responseObj) {
                        return {
                            id: responseObj.ID,
                            requesterDispName: responseObj.RequestedForDisplayName,
                            requestDate: new Date(responseObj.RequestDate),
                            item: responseObj.ObjectRequestedTitleDisp,
                            itemUrl: new URL(responseObj.RequestedObjectUrl.Url),
                            userLogin: _this.getLogin(responseObj.RequestedFor),
                            userId: responseObj.RequestedForUserId,
                            isEditor: true,
                            isWeb: responseObj.RequestedListItemId === _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_3__["default"].Empty &&
                                responseObj.RequestedListId === _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_3__["default"].Empty &&
                                responseObj.RequestedWebId != _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_3__["default"].Empty,
                            comment: responseObj.Conversation
                        };
                    })
                    : responseText;
            }
        });
    };
    AccessRequestsDataSource.prototype.hasAccessRequests = function () {
        var url = this._getIfPendingAccessRequestsUrl;
        var hostname = this._pageContext.webAbsoluteUrl;
        var postBody = {
            objectUrl: hostname,
            useSimplifiedRoles: true
        };
        return this._dataRequestor.getData({
            url: url,
            method: 'POST',
            additionalPostData: JSON.stringify(postBody),
            qosName: 'getIfPendingAccessRequests',
            parseResponse: function (responseText) {
                var src = JSON.parse(responseText);
                return (src &&
                    src.d &&
                    src.d.ObjectSharingInformation &&
                    src.d.ObjectSharingInformation.HasPendingAccessRequests);
            }
        });
    };
    /**
     * Returns user login given string returned from query
     *
     * @param userString - string parsed from json
     * example: internal user /i:0#.f|membership|t-person@microsoft.com
     *
     * @returns userLogin, typically an email
     *
     * only works for internal right now
     * @todo - make consistent for external
     */
    AccessRequestsDataSource.prototype.getLogin = function (userString) {
        var start = userString.lastIndexOf('|') + 1;
        var login = userString.substring(start);
        return login;
    };
    return AccessRequestsDataSource;
}());

//# sourceMappingURL=AccessRequestsDataSource.js.map

/***/ }),

/***/ "a2CF":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingScope.js ***!
  \*****************************************************************************************************************************************************************************************************/
/*! exports provided: SharingScope */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingScope", function() { return SharingScope; });
/**
 * This enum is mapped to the server code at:
 * https://onedrive.visualstudio.com/SharePoint%20Online/_git/SPO?path=%2Fsts%2Fstsom%2FSharing%2FSPObjectSharingInformation.cs&version=GBmaster&line=337&lineEnd=337&lineStartColumn=16&lineEndColumn=28&lineStyle=plain
 */
var SharingScope;
(function (SharingScope) {
    SharingScope[SharingScope["uninitialized"] = -1] = "uninitialized";
    SharingScope[SharingScope["anyone"] = 0] = "anyone";
    SharingScope[SharingScope["organization"] = 1] = "organization";
    SharingScope[SharingScope["specificPeople"] = 2] = "specificPeople";
})(SharingScope || (SharingScope = {}));
//# sourceMappingURL=SharingScope.js.map

/***/ }),

/***/ "aCgj":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/providers/AccessRequests/AccessRequestsProvider.js ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestsProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsProvider", function() { return AccessRequestsProvider; });
var AccessRequestsProvider = /** @class */ (function () {
    function AccessRequestsProvider(params) {
        this._dataSource = params.dataSource;
    }
    /**
     * @inheritdoc
     */
    AccessRequestsProvider.prototype.getPendingAccessRequests = function (orderBy, ascending, top, skip) {
        return this._dataSource.getPendingAccessRequests(orderBy, ascending, top, skip);
    };
    AccessRequestsProvider.prototype.changeRequestStatus = function (requests, statusRequested) {
        return this._dataSource.changeRequestStatus(requests, statusRequested);
    };
    AccessRequestsProvider.prototype.hasAccessRequests = function () {
        return this._dataSource.hasAccessRequests();
    };
    return AccessRequestsProvider;
}());

//# sourceMappingURL=AccessRequestsProvider.js.map

/***/ }),

/***/ "bZph":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissions/SitePermissions.js ***!
  \************************************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissions", function() { return SitePermissions; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SitePermissions_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SitePermissions.scss */ "2w7h");
/* harmony import */ var office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/Persona */ "UXmd");
/* harmony import */ var _SitePermissionsMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SitePermissionsMenu */ "66MK");
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! office-ui-fabric-react/lib/FocusZone */ "NMYH");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! office-ui-fabric-react/lib/Icon */ "56LG");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/LivePersonaCardAdapter/DeferredSpLivePersonaCard */ "5Txe");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _SitePermissions_resx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./SitePermissions.resx */ "90b+");
/* harmony import */ var _SitePermissions_resx__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_SitePermissions_resx__WEBPACK_IMPORTED_MODULE_10__);











/**
 * sitePermissions displays properties of an O365 site
 * @public
 */
var SitePermissions = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SitePermissions, _super);
    function SitePermissions(props) {
        var _this = _super.call(this, props) || this;
        _this._onClick = function () {
            _this.setState({
                isExpanded: !_this.state.isExpanded
            });
        };
        _this._onLPCOpen = function () {
            if (_this.props.isLPCOpenHandler) {
                _this.props.isLPCOpenHandler(true);
            }
        };
        _this._onLPCClose = function () {
            if (_this.props.isLPCOpenHandler) {
                _this.props.isLPCOpenHandler(false);
            }
        };
        _this.state = {
            isExpanded: props && props.hideHeader // if the header is hidden then groups are expanded by default (there is no way for user to expand them)
        };
        return _this;
    }
    SitePermissions.prototype.render = function () {
        var _this = this;
        var props = this.props;
        var personas = props.personas;
        var hideHeader = props.hideHeader;
        var isExpanded = this.state.isExpanded;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-body', "data-automationid": 'SitePermissionsBody' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_6__["FocusZone"], { direction: office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_6__["FocusZoneDirection"].vertical, isInnerZoneKeystroke: function (ev) { return ev.which === Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_5__["getRTLSafeKeyCode"])(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_5__["KeyCodes"].right); } },
                !hideHeader && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-sitePerm-itemBtn', onClick: this._onClick, "data-is-focusable": true, "data-automationid": 'SitePermHeader' + props.permLevel, "aria-expanded": !!isExpanded, role: 'button' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_7__["Icon"], { iconName: 'ChevronDown', className: Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_5__["css"])('ms-sitePerm-chevron', isExpanded && 'is-expanded') }),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-sitePerm-itemBtn-title', "data-automationid": 'SitePermissionsBodyButton' }, props.title))),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-personaContainer' }, isExpanded && personas && personas.length
                    ? personas.map(function (persona, index) {
                        if (persona.currentUserCannotViewMembers) {
                            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-cannotViewMembersText' }, _SitePermissions_resx__WEBPACK_IMPORTED_MODULE_10___default.a.cannotViewMembersText));
                        }
                        else {
                            var personaControl = _this._getPersonaControl(persona);
                            return _this._getPersona(personaControl, persona, index);
                        }
                    })
                    : isExpanded && react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-emptyGroupText' }, _SitePermissions_resx__WEBPACK_IMPORTED_MODULE_10___default.a.emptyGroupText)))));
    };
    SitePermissions.prototype._makeDeferredLpcProps = function (persona) {
        var lpcHoverTargetV2Props = undefined;
        var lpcHoverTargetProps = undefined;
        var personaType = persona.type === 2 /* group */ ? 'Group' : 'User';
        lpcHoverTargetV2Props = {
            cardParameters: {
                personaInfo: {
                    identifiers: {
                        Smtp: persona.groupId ? undefined : persona.email,
                        PersonaType: personaType,
                        Upn: persona.email,
                        AadObjectId: persona.groupId,
                        DisplayName: persona.name
                    }
                },
                behavior: {
                    onCardOpen: this._onLPCOpen,
                    onCardClose: this._onLPCClose
                }
            }
        };
        return {
            personaType: personaType,
            identifier: persona.email,
            pageContext: this.props.pageContext,
            moduleLoader: this.props.lpcModuleLoader,
            customWaiter: this.props.lpcModuleCustomWaiter,
            addGroupMembersCallback: undefined,
            lpcHoverTargetProps: lpcHoverTargetProps,
            lpcHoverTargetV2Props: lpcHoverTargetV2Props
        };
    };
    SitePermissions.prototype._wrapPersona = function (persona) {
        var _this = this;
        return function (personaSharedProps, defaultCoinRenderer) {
            var cardProps = _this._makeDeferredLpcProps(persona);
            return Object(_components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_8__["wrapWithDeferredSpLivePersonaCard"])(cardProps, react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, defaultCoinRenderer(personaSharedProps)));
        };
    };
    SitePermissions.prototype._getPersonaControl = function (persona) {
        var lpcInteractivityEnabled = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_9__["Killswitch"].isActivated('C3DECEDD-44C3-4A2F-8DA3-27AB01A6E1E1', '05/21/2018', 'LPC interactivity in SiteSettings Panel');
        var wrapedOnRender = lpcInteractivityEnabled && this.props.lpcModuleLoader ? this._wrapPersona(persona) : undefined;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_3__["Persona"], { "data-is-focusable": true, imageInitials: persona.imageInitials, imageUrl: persona.imageUrl, initialsColor: persona.initialsColor, primaryText: persona.name, size: office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_3__["PersonaSize"].small, hidePersonaDetails: false, onRenderCoin: wrapedOnRender, onRenderInitials: wrapedOnRender, onRenderPrimaryText: wrapedOnRender, "data-automationid": 'SitePermissionsPersonaControl' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_SitePermissionsMenu__WEBPACK_IMPORTED_MODULE_4__["SitePermissionsMenu"], { menuItems: persona.menuItems, title: this.props.title, permLevelTitle: this.props.permLevelTitle })));
    };
    SitePermissions.prototype._getPersona = function (personaControl, persona, index) {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-Persona', title: persona.name, key: index + persona.name, "data-automationid": 'SitePermissionsPersona' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-personName', "data-automationid": 'SitePermissionsPersonaName' }, personaControl)));
    };
    return SitePermissions;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=SitePermissions.js.map

/***/ }),

/***/ "cCgw":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipPanel.scss.js ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-groupMember-itemBtn{text-align:center;margin-top:20px;margin-bottom:20px}[dir='ltr'] .ms-groupMember-itemBtn{margin-right:4px}[dir='rtl'] .ms-groupMember-itemBtn{margin-left:4px}.ms-groupMember-personName{white-space:nowrap;text-overflow:ellipsis}[dir='ltr'] .ms-groupMember-personName{text-align:left}[dir='rtl'] .ms-groupMember-personName{text-align:right}.ms-groupMember-personName .ms-Persona-secondaryText{display:none}.ms-groupMember-personName .ms-groupMember-lpcpersonacoin{width:40px;height:40px}.ms-groupMember-AddMemberButtonArea{max-height:40px;margin-bottom:16px}.ms-GroupMembershipPanelContents{margin:8px 0px 24px}.ms-groupMember-personName>div{margin-top:10px;margin-bottom:10px}.ms-groupMember-largeGroupMessage{margin-bottom:10px}.ms-groupMember-membersCount{font-weight:600;margin-bottom:16px}.ms-groupMember-list{list-style-type:none}[dir='ltr'] .ms-groupMember-list{padding-left:0px}[dir='rtl'] .ms-groupMember-list{padding-right:0px}.ms-groupMember-errorMessage{-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-box-shadow:none;box-shadow:none;margin:0;padding:0;margin-top:20px;margin-bottom:13px}.ms-groupMember-addingGuest{-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-box-shadow:none;box-shadow:none;margin:0;padding:0;margin-bottom:20px}.ms-groupMember-addMemberInstructions{margin-bottom:24px}.ms-groupMember-peoplePicker{margin-bottom:24px}.ms-groupMember-peoplePicker .ms-BasePicker-selectedItems{margin-top:8px}.ms-groupMemberButton-Cancel{margin-left:8px}.ms-groupMember-spinner{overflow:hidden}.ms-groupMemberList-spinner{margin-top:10px;margin-bottom:10px;overflow:hidden}.ms-groupMember-NavigationContent{margin-top:18px;display:-webkit-box;display:-ms-flexbox;display:flex;width:100%;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.ms-groupMember-NavigationContent .ms-Panel-closeButton{margin-top:7px}.ms-groupMember-NavigationContentDismiss{display:-webkit-box;display:-ms-flexbox;display:flex;width:100%;-webkit-box-pack:end;-ms-flex-pack:end;justify-content:flex-end}.ms-groupMember-NavigationContentDismiss .ms-Panel-closeButton{margin-top:25px}.ms-groupMember-BackIcon{color:" }, { "theme": "themePrimary", "defaultValue": "#0078d4" }, { "rawString": ";position:absolute;left:16px;margin-top:0px}.ms-groupMember-Title{font-size:" }, { "theme": "xLargeFontSize", "defaultValue": "20px" }, { "rawString": ";font-weight:" }, { "theme": "xLargeFontWeight", "defaultValue": "600" }, { "rawString": ";position:absolute;left:58px;margin-top:0px}.ms-groupMemberPanel .ms-Panel-navigation{height:18px;display:block}.ms-groupMember-addingDiv{margin-top:38px}\n" }]);
//# sourceMappingURL=GroupMembershipPanel.scss.js.map

/***/ }),

/***/ "cULl":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/IconButton/IconButton.js ***!
  \**********************************************************************************************************************************************************************************************************/
/*! exports provided: IconButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconButton", function() { return IconButton; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _BaseButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../BaseButton */ "5SA5");
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../Utilities */ "mkpW");
/* harmony import */ var _IconButton_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./IconButton.styles */ "JEr8");





/**
 * {@docCategory Button}
 */
var IconButton = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(IconButton, _super);
    function IconButton() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    IconButton.prototype.render = function () {
        var _a = this.props, styles = _a.styles, theme = _a.theme;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_BaseButton__WEBPACK_IMPORTED_MODULE_2__["BaseButton"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, this.props, { variantClassName: "ms-Button--icon", styles: Object(_IconButton_styles__WEBPACK_IMPORTED_MODULE_4__["getStyles"])(theme, styles), onRenderText: _Utilities__WEBPACK_IMPORTED_MODULE_3__["nullRender"], onRenderDescription: _Utilities__WEBPACK_IMPORTED_MODULE_3__["nullRender"] })));
    };
    IconButton = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_Utilities__WEBPACK_IMPORTED_MODULE_3__["customizable"])('IconButton', ['theme', 'styles'], true)
    ], IconButton);
    return IconButton;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=IconButton.js.map

/***/ }),

/***/ "dHB+":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/utilities/wrapPlaceholderContent.js ***!
  \**************************************************************************************************************************************************************************************************/
/*! exports provided: wrapPlaceholderContent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wrapPlaceholderContent", function() { return wrapPlaceholderContent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Takes a string with a {0} placeholder and wraps the placeholder content in the given
 * element/component type--for example, to make the content bold or make it into a link.
 *
 * @param mainString Whole string containing a {0} placeholder
 * @param placeholderContent String substituted for the placeholder
 * @param placeholderWrapperType Wrap the placeholder content with this element/component type
 * (such as 'span' or office-ui-fabric-react Link)
 * @param placeholderWrapperProps Props for the wrapper element/component
 * @returns Array containing the text before the placeholder, the formatted placeholder content,
 * and the text after the placeholder (can be rendered inside some other element)
 */
function wrapPlaceholderContent(mainString, placeholderContent, placeholderWrapperType, placeholderWrapperProps) {
    var mainStrParts = mainString.split('{0}');
    // When rendering a JSX element that's part of an array, React gives a console warning if
    // the element doesn't have a key. So add an arbitrary key.
    placeholderWrapperProps = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({ key: 'key' }, (placeholderWrapperProps || {}));
    return [
        mainStrParts[0],
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](placeholderWrapperType, placeholderWrapperProps, placeholderContent),
        mainStrParts[1]
    ];
}
//# sourceMappingURL=wrapPlaceholderContent.js.map

/***/ }),

/***/ "dR+P":
/*!****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/SharingInterfaces.js ***!
  \****************************************************************************************************************************************************************************************************/
/*! exports provided: UpdatePermissionsRole, SharingLinkKind, SharingLinkType, SharingInfoType, SharingRole, AccessStatus, ClientId, Error, Category, Mode, SharePermission, SharingAudience, SharingAudienceTemplates, SharingRoleV3, SharingLinkExpressOptions, SharingLinkStatus, SharingScope */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _IUpdatePermissionsResponse__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./IUpdatePermissionsResponse */ "le/i");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UpdatePermissionsRole", function() { return _IUpdatePermissionsResponse__WEBPACK_IMPORTED_MODULE_0__["UpdatePermissionsRole"]; });

/* harmony import */ var _enums_SharingLinkKind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./enums/SharingLinkKind */ "+W9d");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkKind", function() { return _enums_SharingLinkKind__WEBPACK_IMPORTED_MODULE_1__["SharingLinkKind"]; });

/* harmony import */ var _enums_SharingLinkType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./enums/SharingLinkType */ "0m3a");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkType", function() { return _enums_SharingLinkType__WEBPACK_IMPORTED_MODULE_2__["SharingLinkType"]; });

/* harmony import */ var _enums_SharingInfoType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./enums/SharingInfoType */ "wN6/");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingInfoType", function() { return _enums_SharingInfoType__WEBPACK_IMPORTED_MODULE_3__["SharingInfoType"]; });

/* harmony import */ var _enums_SharingRole__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./enums/SharingRole */ "8DW8");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingRole", function() { return _enums_SharingRole__WEBPACK_IMPORTED_MODULE_4__["SharingRole"]; });

/* harmony import */ var _enums_AccessStatus__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./enums/AccessStatus */ "ye7z");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AccessStatus", function() { return _enums_AccessStatus__WEBPACK_IMPORTED_MODULE_5__["AccessStatus"]; });

/* harmony import */ var _enums_ClientId__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./enums/ClientId */ "ljal");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ClientId", function() { return _enums_ClientId__WEBPACK_IMPORTED_MODULE_6__["default"]; });

/* harmony import */ var _enums_Error__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./enums/Error */ "QTSG");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Error", function() { return _enums_Error__WEBPACK_IMPORTED_MODULE_7__["default"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Category", function() { return _enums_Error__WEBPACK_IMPORTED_MODULE_7__["Category"]; });

/* harmony import */ var _enums_Mode__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./enums/Mode */ "oZSW");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Mode", function() { return _enums_Mode__WEBPACK_IMPORTED_MODULE_8__["default"]; });

/* harmony import */ var _enums_SharePermission__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./enums/SharePermission */ "oeOE");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharePermission", function() { return _enums_SharePermission__WEBPACK_IMPORTED_MODULE_9__["default"]; });

/* harmony import */ var _enums_SharingAudience__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./enums/SharingAudience */ "gIZz");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingAudience", function() { return _enums_SharingAudience__WEBPACK_IMPORTED_MODULE_10__["default"]; });

/* harmony import */ var _enums_SharingAudienceTemplates__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./enums/SharingAudienceTemplates */ "e/PU");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingAudienceTemplates", function() { return _enums_SharingAudienceTemplates__WEBPACK_IMPORTED_MODULE_11__["SharingAudienceTemplates"]; });

/* harmony import */ var _enums_SharingRoleV3__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./enums/SharingRoleV3 */ "rZN7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingRoleV3", function() { return _enums_SharingRoleV3__WEBPACK_IMPORTED_MODULE_12__["SharingRoleV3"]; });

/* harmony import */ var _enums_SharingLinkExpressOptions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./enums/SharingLinkExpressOptions */ "zo6u");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkExpressOptions", function() { return _enums_SharingLinkExpressOptions__WEBPACK_IMPORTED_MODULE_13__["SharingLinkExpressOptions"]; });

/* harmony import */ var _enums_SharingLinkStatus__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./enums/SharingLinkStatus */ "jwej");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingLinkStatus", function() { return _enums_SharingLinkStatus__WEBPACK_IMPORTED_MODULE_14__["SharingLinkStatus"]; });

/* harmony import */ var _enums_SharingScope__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./enums/SharingScope */ "a2CF");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SharingScope", function() { return _enums_SharingScope__WEBPACK_IMPORTED_MODULE_15__["SharingScope"]; });


// Export enums.















//# sourceMappingURL=SharingInterfaces.js.map

/***/ }),

/***/ "dnCp":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipList/GroupMembershipList.js ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipList", function() { return GroupMembershipList; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _GroupMembershipList_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GroupMembershipList.scss */ "0A++");
/* harmony import */ var office_ui_fabric_react_lib_List__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/List */ "HP5x");
/* harmony import */ var office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/Spinner */ "fyAn");





/**
 * This helper component shows a spinner and triggers loading more members.
 */
var MembersLoader = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(MembersLoader, _super);
    function MembersLoader(props) {
        return _super.call(this, props) || this;
    }
    MembersLoader.prototype.render = function () {
        return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_4__["Spinner"], { className: 'ms-groupMemberList-spinner' });
    };
    MembersLoader.prototype.componentDidMount = function () {
        if (this.props.onLoadMoreMembers) {
            this.props.onLoadMoreMembers();
        }
    };
    return MembersLoader;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));
/**
 * The group membership list component provides a virtualized list of group members.
 * It allows "lazy loading" of group members for large groups.
 * @public
 */
var GroupMembershipList = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(GroupMembershipList, _super);
    function GroupMembershipList(props) {
        return _super.call(this, props) || this;
    }
    GroupMembershipList.prototype.render = function () {
        var _this = this;
        // If the total number of members exceeds the length of the members list, and
        // we have a callback to load more members, push a null flag onto the end of the members
        // list to indicate when we need to load more members.
        var membersFormatted = [];
        if (this.props.members) {
            membersFormatted = this.props.members;
            if (this.props.onLoadMoreMembers && this.props.totalNumberOfMembers > this.props.members.length) {
                // Use concatenation to avoid altering array that was passed in.
                membersFormatted = membersFormatted.concat([null]);
            }
        }
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_List__WEBPACK_IMPORTED_MODULE_3__["List"], { items: membersFormatted, onRenderCell: function (item, index) {
                return item ? (_this.props.onRenderPersona(item, index)) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](MembersLoader, { onLoadMoreMembers: _this.props.onLoadMoreMembers }));
            } }));
    };
    return GroupMembershipList;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=GroupMembershipList.js.map

/***/ }),

/***/ "e/PU":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingAudienceTemplates.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: SharingAudienceTemplates */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingAudienceTemplates", function() { return SharingAudienceTemplates; });
/**
 * Used for SharingLinkTemplates to match the enum in the server side code
 */
var SharingAudienceTemplates;
(function (SharingAudienceTemplates) {
    SharingAudienceTemplates[SharingAudienceTemplates["anyone"] = 0] = "anyone";
    SharingAudienceTemplates[SharingAudienceTemplates["organization"] = 1] = "organization";
    SharingAudienceTemplates[SharingAudienceTemplates["specificPeople"] = 2] = "specificPeople";
})(SharingAudienceTemplates || (SharingAudienceTemplates = {}));
//# sourceMappingURL=SharingAudienceTemplates.js.map

/***/ }),

/***/ "ek0/":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequestsList.js ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestsListBase, AccessRequestsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsListBase", function() { return AccessRequestsListBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestsList", function() { return AccessRequestsList; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/DetailsList */ "0q4O");
/* harmony import */ var _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-datasources/lib/AccessRequests */ "Vdfb");
/* harmony import */ var office_ui_fabric_react_lib_Fabric__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/Fabric */ "OBNh");
/* harmony import */ var office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Button */ "epn0");
/* harmony import */ var _AccessRequestsDialog_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./AccessRequestsDialog.scss */ "DkMg");
/* harmony import */ var _AccessRequestsList_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./AccessRequestsList.scss */ "5s0Y");
/* harmony import */ var _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./AccessRequests.resx */ "AAtU");
/* harmony import */ var _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var office_ui_fabric_react_lib_ScrollablePane__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! office-ui-fabric-react/lib/ScrollablePane */ "4YcF");
/* harmony import */ var office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! office-ui-fabric-react/lib/Sticky */ "vsgo");
/* harmony import */ var office_ui_fabric_react_lib_ShimmeredDetailsList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! office-ui-fabric-react/lib/ShimmeredDetailsList */ "yRr/");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var _AccessRequestsList_styles__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./AccessRequestsList.styles */ "scPC");
/* harmony import */ var office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! office-ui-fabric-react/lib/Link */ "F3Wv");
/* harmony import */ var _ms_utilities_date_time_lib_relativePast__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ms/utilities-date-time/lib/relativePast */ "ZRaF");
/* harmony import */ var office_ui_fabric_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! office-ui-fabric-react/lib/Dropdown */ "6yAV");
/* harmony import */ var office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! office-ui-fabric-react/lib/Stack */ "N28N");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! office-ui-fabric-react/lib/Icon */ "56LG");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var office_ui_fabric_react_lib_Tooltip__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! office-ui-fabric-react/lib/Tooltip */ "c4qa");
/* harmony import */ var _ms_odsp_datasources_lib_PeoplePicker__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ms/odsp-datasources/lib/PeoplePicker */ "sQJ6");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ms/odsp-utilities/lib/guid/Guid */ "vo05");
/* harmony import */ var _components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../components/LivePersonaCardAdapter/DeferredSpLivePersonaCard */ "5Txe");
/* harmony import */ var office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! office-ui-fabric-react/lib/Persona */ "UXmd");
/* harmony import */ var _uifabric_icons__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @uifabric/icons */ "xb1K");
/* harmony import */ var _uifabric_file_type_icons_lib_index__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @uifabric/file-type-icons/lib/index */ "hVhz");
/* harmony import */ var _ms_odsp_datasources_lib_SitePermissions__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ms/odsp-datasources/lib/SitePermissions */ "h827");






























var AccessRequestsListBase = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(AccessRequestsListBase, _super);
    function AccessRequestsListBase(props) {
        var _this = _super.call(this, props) || this;
        _this._getColumns = function (orderBy, descending) {
            var columns = [
                {
                    key: 'column1',
                    name: '     ' + _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Name,
                    fieldName: 'RequestedForDisplayName',
                    iconName: 'Contact',
                    minWidth: 200,
                    isRowHeader: true,
                    isResizable: false,
                    isSorted: orderBy === 'RequestedForDisplayName',
                    isSortedDescending: descending,
                    onRender: _this._renderNameColumn,
                    onColumnClick: _this._onColumnClick,
                    data: 'string',
                    isPadded: false,
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-NameColumn'
                },
                {
                    key: 'column2',
                    name: 'File type',
                    isResizable: false,
                    iconName: 'Page',
                    isIconOnly: true,
                    minWidth: 16,
                    maxWidth: 16,
                    onColumnClick: _this._onColumnClick,
                    onRender: _this._renderFileType,
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-IconColumn'
                },
                {
                    key: 'column3',
                    name: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Item,
                    fieldName: 'ObjectRequestedTitleDisp',
                    minWidth: 280,
                    isSorted: orderBy === 'ObjectRequestedTitleDisp',
                    isSortedDescending: descending,
                    isResizable: false,
                    onColumnClick: _this._onColumnClick,
                    data: 'string',
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-ItemColumn',
                    onRender: _this._renderFilename,
                    isPadded: false
                },
                {
                    key: 'column4',
                    name: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.RequestDate,
                    fieldName: 'RequestDate',
                    minWidth: 138,
                    isSorted: orderBy === 'RequestDate',
                    isSortedDescending: descending,
                    isResizable: false,
                    onColumnClick: _this._onColumnClick,
                    data: 'string',
                    onRender: _this._renderRequestDate,
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-RequestDateColumn',
                    isPadded: false
                },
                {
                    key: 'column5',
                    name: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Permissions,
                    isResizable: false,
                    onRender: _this._renderPermissionsDropdown,
                    minWidth: 138,
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-PermissionsColumn',
                    isPadded: false
                },
                {
                    key: 'column6',
                    name: '',
                    isResizable: false,
                    onRender: _this._renderRequestComment,
                    minWidth: 78,
                    //maxWidth: 16,
                    className: 'ms-AccessRequestsList-Column ms-AccessRequestsList-CommentColumn',
                    isPadded: false
                }
            ];
            return columns;
        };
        /**
         * Displays message that there are no requests to be displayed.
         */
        _this._renderNoRequestsMessage = function () {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["Sticky"], { stickyClassName: 'ms-AccessRequest-AccessRequestListHeader', stickyPosition: office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["StickyPositionType"].Header },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.NoRequests)));
        };
        /**
         * Displays message that there are no requests to be displayed when requests are filtered by internal only.
         */
        _this._renderNoInternalRequestsMessage = function () {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["Sticky"], { stickyClassName: 'ms-AccessRequest-AccessRequestListHeader', stickyPosition: office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["StickyPositionType"].Header },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.NoInternalRequests)));
        };
        /**
         * Displays message that there are no requests to be displayed when requests are filtered by external only.
         */
        _this._renderNoExternalRequestsMessage = function () {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["Sticky"], { stickyClassName: 'ms-AccessRequest-AccessRequestListHeader', stickyPosition: office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["StickyPositionType"].Header },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.NoExternalRequests)));
        };
        _this._renderContainsError = function () {
            var alignTokens = {
                childrenGap: 10,
                padding: 10
            };
            var stackStyles = {
                root: {
                    width: "100%"
                }
            };
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"], { horizontal: true, tokens: alignTokens, styles: stackStyles },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 1, className: 'ms-accessRequestsList-Blocked' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__["Icon"], { iconName: 'Blocked2' })),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["StackItem"], { order: 2, className: 'ms-accessRequestsList-ErrorText' }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.ErrorInSelection),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["StackItem"], { order: 3 },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["IconButton"], { className: 'ms-accessRequestsList-Cancel', iconProps: { iconName: 'Cancel' }, onClick: function () {
                            _this.setState({ containsError: false });
                        } }))));
        };
        _this._renderTopButtons = function () {
            var requests = _this._selection.getSelection();
            var addAll = requests.length > 1 ? true : false;
            var disableButtons = requests.length > 0 ? false : true;
            var acceptIcon = { iconName: 'CheckMark' };
            var declineIcon = { iconName: 'Cancel' };
            //const ignoreIcon: IIconProps = { iconName: 'Hide' };
            var refreshIcon = { iconName: 'Refresh' };
            var alignTokens = {
                childrenGap: 10,
                padding: 10
            };
            var stackStyles = {
                root: {
                    width: "100%"
                }
            };
            var onClickAccept;
            onClickAccept = function () {
                _this._approveDeclineAll(requests, _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__["AccessRequestStatus"].Approve);
            };
            var onClickDecline;
            onClickDecline = function () {
                _this._approveDeclineAll(requests, _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__["AccessRequestStatus"].Decline);
            };
            /*
            let onClickIgnore: () => any;
            onClickIgnore = () => {
              this._ignoreAll(requests);
            };*/
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"], { horizontal: true, className: 'ms-accessRequestsButtons', tokens: alignTokens, styles: stackStyles },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 1 },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null,
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["ActionButton"], { iconProps: acceptIcon, allowDisabledFocus: true, onClick: onClickAccept, disabled: disableButtons }, addAll ? _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.ApproveAll : _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Approve))),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 2 },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null,
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["ActionButton"], { iconProps: declineIcon, allowDisabledFocus: true, onClick: onClickDecline, disabled: disableButtons }, addAll ? _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.DeclineAll : _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Decline))),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 3 }, requests.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["ActionButton"], { iconProps: refreshIcon, allowDisabledFocus: true, onClick: _this._refreshPage }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Refresh)) : null)));
        };
        _this._refreshPage = function () {
            _this.setState({
                allRequests: [],
                hasMoreRequests: true,
                orderBy: 'RequestDate'
            }, function () { return _this._fetchPendingRequests(); });
        };
        _this._approveDeclineAll = function (requests, newStatus) {
            var containsCompleted = false;
            requests.forEach(function (request) {
                if (request.completed === true) {
                    containsCompleted = true;
                }
            });
            if (containsCompleted) {
                _this.setState({ containsError: true });
            }
            else {
                _this.setState({ containsError: false });
                _this._accessRequestsProvider.changeRequestStatus(requests, newStatus).then(function (success) {
                    requests.forEach(function (request) {
                        request.completed = true;
                        request.completedStatus =
                            newStatus === _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__["AccessRequestStatus"].Approve ? _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Approved : _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Declined;
                    });
                    _this._selection.setAllSelected(true);
                    _this._selection.setAllSelected(false);
                });
            }
        };
        _this._renderList = function () {
            if (_this.props.currentFilter === 'internal') {
                _this._filterForInternal();
            }
            else if (_this.props.currentFilter === 'external') {
                _this._filterForExternal();
            }
            var _a = _this.state, allRequests = _a.allRequests, internalRequests = _a.internalRequests, externalRequests = _a.externalRequests, columns = _a.columns, hasMoreRequests = _a.hasMoreRequests;
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Fabric__WEBPACK_IMPORTED_MODULE_4__["Fabric"], null,
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ShimmeredDetailsList__WEBPACK_IMPORTED_MODULE_12__["ShimmeredDetailsList"], { "data-automation-id": 'AccessRequestDetailsList', className: 'ms-AccessRequest-AccessRequestList', checkboxCellClassName: 'ms-AccessRequestList-Checkbox', items: _this.props.currentFilter === 'all'
                        ? allRequests
                        : _this.props.currentFilter === 'internal'
                            ? internalRequests
                                ? internalRequests
                                : []
                            : _this.props.currentFilter === 'external'
                                ? externalRequests
                                    ? externalRequests
                                    : []
                                : [], compact: false, columns: columns, selectionMode: allRequests && allRequests.length > 0 ? office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["SelectionMode"].multiple : office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["SelectionMode"].none, layoutMode: office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["DetailsListLayoutMode"].justified, isHeaderVisible: true, selection: _this._selection, selectionPreservedOnEmptyClick: true, enterModalSelectionOnTouch: true, ariaLabelForSelectionColumn: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.SelectionAriaLabel, ariaLabelForSelectAllCheckbox: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.SelectAllAriaLabel, onRowDidMount: function (item, index) {
                        _this._onRenderItem(item, index);
                    }, constrainMode: office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["ConstrainMode"].horizontalConstrained, enableShimmer: allRequests ? allRequests.length === 0 && hasMoreRequests : hasMoreRequests, onRenderDetailsHeader: _this.onRenderDetailsHeader, onRenderRow: _this._onRenderRow })));
        };
        _this._onRenderRow = function (detailsRowProps, defaultRender, detailsRowStyleProps) {
            return defaultRender(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, (detailsRowProps || {})), { onRenderCheck: _this._onRenderCheck }));
        };
        _this._onRenderCheck = function (detailsCheckBoxProps, DefaultRender) {
            if (DefaultRender === void 0) { DefaultRender = office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["DetailsRowCheck"]; }
            var styles = {
                root: 'ms-AccessRequestsList-CheckBoxRoot',
                check: 'ms-AccessRequestsList-CheckBoxCheck',
                isDisabled: 'ms-AccessRequestsList-CheckBoxDisabled'
            };
            return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](DefaultRender, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, detailsCheckBoxProps, { styles: styles }));
        };
        _this._renderFileType = function (request) {
            if (request) {
                var iconInfo = _this._getItemIcon(request.itemUrl);
                return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__["Icon"], { iconName: iconInfo });
            }
        };
        _this._renderRequestComment = function (request) {
            var messageIcon = { iconName: 'Message' };
            var calloutProps = { gapSpace: 0 };
            var hostStyles = { root: { display: 'inline-block' } };
            if (request && request.comment && request.comment.length) {
                return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Tooltip__WEBPACK_IMPORTED_MODULE_20__["TooltipHost"], { content: _this._renderRequestCommentToolTip(request), calloutProps: calloutProps, styles: hostStyles },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["IconButton"], { iconProps: messageIcon, title: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.MessageTitle, ariaLabel: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.MessageTitle }))));
            }
        };
        _this._renderRequestCommentToolTip = function (request) {
            var acceptIcon = { iconName: 'CheckMark' };
            var declineIcon = { iconName: 'Cancel' };
            //const ignoreIcon: IIconProps = { iconName: 'Hide' };
            var onClickAccept;
            onClickAccept = function () {
                _this._selection.setAllSelected(false);
                _this._approveDeclineAll([request], _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__["AccessRequestStatus"].Approve);
            };
            var onClickDecline;
            onClickDecline = function () {
                _this._selection.setAllSelected(false);
                _this._approveDeclineAll([request], _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_3__["AccessRequestStatus"].Decline);
            };
            /*
            let onClickIgnore: () => any;
            onClickIgnore = () => {
              this._ignoreAll([request]);
            };
            */
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-CommentToolTip' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-Comment' },
                    " ",
                    request.comment,
                    " "),
                request.completed ? null : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"], { horizontal: true },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 1 },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["ActionButton"], { iconProps: acceptIcon, allowDisabledFocus: true, onClick: onClickAccept }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Approve)),
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"].Item, { order: 2 },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["ActionButton"], { iconProps: declineIcon, allowDisabledFocus: true, onClick: onClickDecline }, _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Decline))))));
        };
        _this._renderRequestDate = function (request) {
            var pageContext = _this.props.pageContext;
            if (request) {
                if (request.completed === true) {
                    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-CompletedStatus' }, request.completedStatus);
                }
                var dateRequested = request.requestDate;
                var time = dateRequested && new Date(dateRequested).getTime();
                if (typeof time === 'number' && !isNaN(time)) {
                    var language = pageContext.currentUICultureName;
                    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-RequestDate' }, Object(_ms_utilities_date_time_lib_relativePast__WEBPACK_IMPORTED_MODULE_16__["getRelativeDateTimeStringPast"])(new Date(time), language)));
                }
            }
        };
        _this._onRenderOption = function (option) {
            var iconStyles = { marginRight: '8px' };
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
                option.data && option.data.icon && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__["Icon"], { style: iconStyles, iconName: option.data.icon, "aria-hidden": 'true', title: option.data.icon })),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, option.text)));
        };
        _this._onRenderPlaceholder = function (props) {
            var iconStyles = { marginRight: '8px' };
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'dropdownExample-placeholder' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__["Icon"], { style: iconStyles, iconName: 'Edit', "aria-hidden": 'true' }),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, props.placeholder)));
        };
        _this._onRenderTitle = function (options) {
            var iconStyles = { marginRight: '8px' };
            var option = options[0];
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
                option.data && option.data.icon && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_19__["Icon"], { style: iconStyles, iconName: option.data.icon, "aria-hidden": 'true', title: option.data.icon })),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, option.text)));
        };
        _this._renderPermissionsDropdown = function (request) {
            var dropdownStyles = { dropdown: { width: 120 } };
            var stackTokens = { childrenGap: 20 };
            request.dropRef = react__WEBPACK_IMPORTED_MODULE_1__["createRef"]();
            if (request.isWeb) {
                if (!_this._associatedGroups || _this._associatedGroups.length === 0) {
                    _this._fetchAssociatedGroups();
                }
                // if we don't find the default groups fall back to edit/view
                if (!_this._associatedGroups || _this._associatedGroups.length < 2) {
                    request.isWeb = false;
                }
            }
            var change;
            change = function () {
                var key = request.dropRef.current.selectedOptions[0].key;
                return _this._onChangePermission(key, request);
            };
            var editString = request.isWeb ? _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Member : _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Edit;
            var viewString = request.isWeb ? _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.Visitor : _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.View;
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Stack__WEBPACK_IMPORTED_MODULE_18__["Stack"], { tokens: stackTokens, verticalAlign: 'end' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Dropdown__WEBPACK_IMPORTED_MODULE_17__["Dropdown"], { componentRef: request.dropRef, disabled: request.completed, placeholder: editString, ariaLabel: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.SelectPermissions, options: [
                        { key: 'Edit', text: editString, data: { icon: 'Edit' } },
                        { key: 'View', text: viewString, data: { icon: 'Uneditable2' } }
                    ], styles: dropdownStyles, onRenderOption: _this._onRenderOption, onRenderPlaceholder: _this._onRenderPlaceholder, onRenderTitle: _this._onRenderTitle, onChange: change })));
        };
        _this._renderNameColumn = function (request) {
            var resolvedPersons = _this.state.resolvedPersons;
            if (resolvedPersons[request.userLogin]) {
                var person = resolvedPersons[request.userLogin];
                var cardProps = {
                    personaType: 'User',
                    identifier: person.userId,
                    pageContext: _this.props.pageContext,
                    lpcHoverTargetProps: {
                        upn: person.email,
                        hostAppPersonaInfo: {
                            PersonaDisplayName: request.requesterDispName
                        }
                    }
                };
                return Object(_components_LivePersonaCardAdapter_DeferredSpLivePersonaCard__WEBPACK_IMPORTED_MODULE_24__["wrapWithDeferredSpLivePersonaCard"])(cardProps, react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-card' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_25__["Persona"], { "data-is-focusable": true, imageUrl: person.image, primaryText: request.requesterDispName, size: office_ui_fabric_react_lib_Persona__WEBPACK_IMPORTED_MODULE_25__["PersonaSize"].small, hidePersonaDetails: false, showInitialsUntilImageLoads: true })));
            }
            else {
                if (!request.queried) {
                    _this._queryForPersonaInfo(request.userLogin);
                    request.queried = true;
                }
                var calloutProps = { gapSpace: 0 };
                var hostStyles = { root: { display: 'inline-block' } };
                return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-name' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Tooltip__WEBPACK_IMPORTED_MODULE_20__["TooltipHost"], { content: _AccessRequests_resx__WEBPACK_IMPORTED_MODULE_8___default.a.UserNotInOrg, calloutProps: calloutProps, styles: hostStyles }, request.requesterDispName)));
            }
        };
        _this._renderFilename = function (request) {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-AccessRequestsList-ColumnText' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_15__["Link"], { href: request.itemUrl.toString(), target: '_blank', className: 'ms-AccessRequestsList-Link' }, request.item)));
        };
        _this._fetchPendingRequests = function () {
            var _a = _this.state, hasMoreRequests = _a.hasMoreRequests, allRequests = _a.allRequests, orderBy = _a.orderBy, ascending = _a.ascending;
            var pageSize = _this.props.pageSize;
            if (hasMoreRequests) {
                var currentRequests_1;
                if (allRequests) {
                    currentRequests_1 = _this.state.allRequests;
                }
                else {
                    currentRequests_1 = [];
                }
                _this._accessRequestsProvider
                    .getPendingAccessRequests(orderBy, ascending, pageSize, currentRequests_1.length)
                    .then(function (response) {
                    if (Array.isArray(response) && response.length > 0) {
                        response.forEach(function (request) {
                            request.queried = false;
                            currentRequests_1.push(request);
                        });
                        var allRequests_1 = _this._mergeInNewRequests(response);
                        var fetchMoreRequests = response.length === pageSize && allRequests_1 && allRequests_1.length < pageSize;
                        _this.setState({
                            allRequests: allRequests_1,
                            hasMoreRequests: response.length === pageSize
                        });
                        return fetchMoreRequests;
                    }
                    else {
                        _this.setState({
                            hasMoreRequests: false
                        });
                        return false;
                    }
                })
                    .then(function (fetchMoreRequests) {
                    if (fetchMoreRequests) {
                        _this._fetchPendingRequests();
                    }
                })
                    .catch(function (error) {
                    _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_13__["default"].logData({ name: 'AccessRequests.Error' });
                });
            }
        };
        _this._queryForPersonaInfo = function (userQuery) {
            var resolvedPersons = _this.state.resolvedPersons;
            var newResolvedPersons = _this.state.resolvedPersons;
            if (!resolvedPersons[userQuery]) {
                _this._onGetMoreResults(userQuery).then(function (foundPerson) {
                    newResolvedPersons[userQuery] = {
                        userId: foundPerson.userId,
                        name: foundPerson.name,
                        email: foundPerson.email,
                        image: foundPerson.image,
                        department: foundPerson.department,
                        job: foundPerson.job,
                        office: foundPerson.office,
                        phone: foundPerson.phone,
                        isResolved: foundPerson.isResolved,
                        isExternal: foundPerson.isExternal
                    };
                    _this.setState({
                        resolvedPersons: newResolvedPersons
                    });
                });
            }
            return true;
        };
        _this._onGetMoreResults = function (query) {
            var pageContext = _this.props.pageContext;
            var canAddGuests = true;
            var useIBSegmentsKillSwitch = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_22__["Killswitch"].isActivated('34c10010-00ae-48db-8ec7-d9fd2f8d7804', '3/19/2020', 'use IBSegment');
            var peoplePickerQueryParams = {
                allowEmailAddresses: false,
                allowMultipleEntities: null,
                allUrlZones: null,
                enabledClaimProviders: null,
                forceClaims: null,
                groupID: 0,
                maximumEntitySuggestions: 30,
                principalSource: 15,
                principalType: 1,
                required: null,
                urlZone: null,
                urlZoneSpecified: null,
                filterExternalUsers: !canAddGuests,
                blockExternalUsers: !canAddGuests,
                useGraph: !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_22__["Killswitch"].isActivated('F18F4F84-A337-4C37-81BF-20545B8B9BD9', '4/28/2020', 'Use enforceIBSegmentFilter.')
                    ? !pageContext.enforceIBSegmentFilter
                    : true,
                useSubstrate: useIBSegmentsKillSwitch && pageContext.IBSegments && pageContext.IBSegments.length > 0,
                conversationId: _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_23__["default"].generate(),
                siteIBSegmentIDs: useIBSegmentsKillSwitch && pageContext.IBSegments
            };
            return _this._peoplePickerProvider.resolve(query, peoplePickerQueryParams);
        };
        _this._mergeInNewRequests = function (requests) {
            var allRequests = _this.state.allRequests;
            if (allRequests && allRequests.length > 0) {
                var map_1 = _this._mapRequests(allRequests);
                var newRequests = requests.filter(function (request) { return !(request.id in map_1); });
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(allRequests, newRequests);
            }
            else {
                return requests;
            }
        };
        _this._mapRequests = function (requests) {
            var map = {};
            for (var _i = 0, requests_1 = requests; _i < requests_1.length; _i++) {
                var request = requests_1[_i];
                map[request.id] = request;
            }
            return map;
        };
        _this._sort = function (requesters, fieldName, ascending) {
            var sortFunction = fieldName === 'RequestedForDisplayName'
                ? function (a, b) {
                    return a.requesterDispName
                        .toLocaleUpperCase()
                        .localeCompare(b.requesterDispName.toLocaleUpperCase());
                }
                : fieldName === 'ObjectRequestedTitleDisp'
                    ? function (a, b) {
                        return a.item.toLocaleUpperCase().localeCompare(b.item.toLocaleUpperCase());
                    }
                    : function (a, b) {
                        return a.requestDate.valueOf() - b.requestDate.valueOf();
                    };
            requesters.sort(sortFunction);
            if (ascending) {
                requesters.reverse();
            }
            return requesters;
        };
        _this._onRenderItem = function (item, index) {
            var allRequests = _this.state.allRequests;
            var pageSize = _this.props.pageSize;
            if (index === allRequests.length - pageSize ||
                (allRequests.length < pageSize && index === allRequests.length - 1)) {
                _this._fetchPendingRequests();
            }
        };
        _this._getSelectionDetails = function () {
            var selectionCount = _this._selection.getSelectedCount();
            return selectionCount > 0;
        };
        _this._onColumnClick = function (ev, column) {
            var _a = _this.state, columns = _a.columns, hasMoreRequests = _a.hasMoreRequests, allRequests = _a.allRequests;
            var newColumns = columns.map(function (oldColumn) {
                var isMatch = oldColumn.key === column.key;
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, oldColumn), { isSorted: isMatch, isSortedDescending: isMatch && !oldColumn.isSortedDescending });
            });
            if (hasMoreRequests) {
                _this.setState({
                    allRequests: [],
                    hasMoreRequests: true,
                    orderBy: column.fieldName,
                    ascending: !column.isSortedDescending,
                    columns: newColumns
                }, function () { return _this._fetchPendingRequests(); });
            }
            else {
                _this.setState({
                    allRequests: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(_this._sort(allRequests, column.fieldName, !column.isSortedDescending)),
                    orderBy: column.fieldName,
                    ascending: !column.isSortedDescending,
                    columns: newColumns
                });
            }
        };
        _this._accessRequestsProvider = props.accessRequestsProvider;
        _this._peoplePickerProvider = new _ms_odsp_datasources_lib_PeoplePicker__WEBPACK_IMPORTED_MODULE_21__["PeoplePickerProvider"]({
            pageContext: props.pageContext,
            peoplePickerDataSource: props.peoplePickerDataSource
        });
        _this._sitePermissionsProvider = new _ms_odsp_datasources_lib_SitePermissions__WEBPACK_IMPORTED_MODULE_28__["SitePermissionsProvider"](props.pageContext);
        var columns = _this._getColumns('RequestDate', false);
        _this._selection = new office_ui_fabric_react_lib_DetailsList__WEBPACK_IMPORTED_MODULE_2__["Selection"]({
            onSelectionChanged: function () {
                _this.setState({
                    isRequestSelected: _this._getSelectionDetails()
                });
            }
        });
        var requests = [];
        var internalReqs = [];
        var externalReqs = [];
        _this.state = {
            columns: columns,
            allRequests: requests,
            isRequestSelected: _this._getSelectionDetails(),
            internalRequests: internalReqs,
            externalRequests: externalReqs,
            selectedRequest: undefined,
            hasMoreRequests: true,
            orderBy: 'RequestDate',
            ascending: true,
            isCommentTooltipVisible: false,
            resolvedPersons: new Map(),
            containsError: false
        };
        Object(_uifabric_icons__WEBPACK_IMPORTED_MODULE_26__["initializeIcons"])();
        return _this;
    }
    AccessRequestsListBase.prototype.render = function () {
        var _a = this.state, allRequests = _a.allRequests, internalRequests = _a.internalRequests, externalRequests = _a.externalRequests, hasMoreRequests = _a.hasMoreRequests;
        var renderNoRequestsMessage = (!allRequests || allRequests.length === 0) && !hasMoreRequests;
        var renderNoInternalRequestsMessage = internalRequests && !internalRequests.length;
        var renderNoExternalRequestsMessage = externalRequests && !externalRequests.length;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-accessRequestsList' },
            this._renderTopButtons(),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-accessRequestsList-ErrorMessage' }, this.state.containsError && this._renderContainsError()),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-accessRequestsList-ScrollablePane' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ScrollablePane__WEBPACK_IMPORTED_MODULE_10__["ScrollablePane"], { scrollbarVisibility: office_ui_fabric_react_lib_ScrollablePane__WEBPACK_IMPORTED_MODULE_10__["ScrollbarVisibility"].auto },
                    this._renderList(),
                    this.props.currentFilter === 'all'
                        ? renderNoRequestsMessage && this._renderNoRequestsMessage()
                        : this.props.currentFilter === 'internal'
                            ? renderNoInternalRequestsMessage && this._renderNoInternalRequestsMessage()
                            : this.props.currentFilter === 'external'
                                ? renderNoExternalRequestsMessage && this._renderNoExternalRequestsMessage()
                                : ''))));
    };
    AccessRequestsListBase.prototype.componentDidMount = function () {
        // We need to fetch member & visitor group to match edit/view for web.
        // Eventually we should fetch all available roles/spgroups and provide that in the drop down.
        this._fetchAssociatedGroups();
        this._fetchPendingRequests();
    };
    AccessRequestsListBase.prototype.componentDidUpdate = function (prevProps) {
        if (prevProps.accessRequestsEnabled !== this.props.accessRequestsEnabled) {
            this.setState({
                columns: this._getColumns(this.state.orderBy, this.state.ascending)
            });
        }
    };
    /*
    private _ignoreAll = (requests: AccessRequest[]) => {};
    */
    /**
     * Renders sticky header columns, displayed when user scrolls on the list.
     */
    AccessRequestsListBase.prototype.onRenderDetailsHeader = function (props, defaultRender) {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["Sticky"], { stickyClassName: 'ms-AccessRequest-AccessRequestListHeader', stickyPosition: office_ui_fabric_react_lib_Sticky__WEBPACK_IMPORTED_MODULE_11__["StickyPositionType"].Header, isScrollSynced: true }, defaultRender(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props))));
    };
    /**
     * Update current list of internal requests to reflect most recent requests.
     * Only updates if there is a difference between the old and new internal request list.
     */
    AccessRequestsListBase.prototype._filterForInternal = function () {
        var _a = this.state, allRequests = _a.allRequests, internalRequests = _a.internalRequests, resolvedPersons = _a.resolvedPersons;
        var dispReqs = [];
        var shouldUpdateFilter = false;
        for (var _i = 0, allRequests_2 = allRequests; _i < allRequests_2.length; _i++) {
            var currReq = allRequests_2[_i];
            if (resolvedPersons[currReq.userLogin]) {
                if (!resolvedPersons[currReq.userLogin].isExternal) {
                    dispReqs.push(currReq);
                    if (internalRequests && internalRequests.length >= dispReqs.length) {
                        if (dispReqs[dispReqs.length - 1] !== internalRequests[dispReqs.length - 1]) {
                            shouldUpdateFilter = true;
                        }
                    }
                }
            }
        }
        if (internalRequests && internalRequests.length !== dispReqs.length) {
            shouldUpdateFilter = true;
        }
        if (shouldUpdateFilter) {
            this.setState({
                internalRequests: dispReqs
            });
        }
    };
    /**
     * Update current list of external requests to reflect most recent requests.
     * Only updates if there is a difference bteween the old and new internal request list.
     */
    AccessRequestsListBase.prototype._filterForExternal = function () {
        var _a = this.state, allRequests = _a.allRequests, externalRequests = _a.externalRequests, resolvedPersons = _a.resolvedPersons;
        var dispReqs = [];
        var shouldUpdateFilter = false;
        for (var _i = 0, allRequests_3 = allRequests; _i < allRequests_3.length; _i++) {
            var currReq = allRequests_3[_i];
            if (resolvedPersons[currReq.userLogin]) {
                if (resolvedPersons[currReq.userLogin].isExternal) {
                    dispReqs.push(currReq);
                    if (externalRequests && externalRequests.length >= dispReqs.length) {
                        if (dispReqs[dispReqs.length - 1] !== externalRequests[dispReqs.length - 1]) {
                            shouldUpdateFilter = true;
                        }
                    }
                }
            }
        }
        if (externalRequests && externalRequests.length !== dispReqs.length) {
            shouldUpdateFilter = true;
        }
        if (shouldUpdateFilter) {
            this.setState({
                externalRequests: dispReqs
            });
        }
    };
    AccessRequestsListBase.prototype._getItemIcon = function (itemURL) {
        var imageSize = 16;
        if (itemURL) {
            var docType = null;
            var urlString = itemURL.toString();
            var urlArr = urlString.split('/');
            var pathName = urlArr[urlArr.length - 1];
            //no period means site or folder usually
            if (!pathName.includes('.')) {
                //is prob a site (not always correct since subsites are a thing)
                if (urlArr[urlArr.length - 2] === 'teams') {
                    return 'SharepointLogo'; //SharepointLogo20_svg doesnt work for sizing
                }
                else {
                    //else its a folder
                    var iconProps_1 = Object(_uifabric_file_type_icons_lib_index__WEBPACK_IMPORTED_MODULE_27__["getFileTypeIconProps"])({ type: _uifabric_file_type_icons_lib_index__WEBPACK_IMPORTED_MODULE_27__["FileIconType"].folder, size: imageSize });
                    return iconProps_1.iconName;
                }
            }
            //it's a file
            else {
                var docEnd = pathName.split('.')[1];
                docType = docEnd.split('?')[0];
            }
            var iconProps = Object(_uifabric_file_type_icons_lib_index__WEBPACK_IMPORTED_MODULE_27__["getFileTypeIconProps"])({ extension: docType, size: imageSize });
            return iconProps.iconName;
        }
    };
    AccessRequestsListBase.prototype._onChangePermission = function (key, request) {
        if (key === 'Edit') {
            request.isEditor = true;
            if (request.isWeb && this._associatedGroups && this._associatedGroups.length > 2) {
                request.groupId = this._associatedGroups[1].id;
            }
        }
        else {
            request.isEditor = false;
            if (request.isWeb && this._associatedGroups && this._associatedGroups.length > 2) {
                request.groupId = this._associatedGroups[2].id;
            }
        }
    };
    AccessRequestsListBase.prototype._fetchAssociatedGroups = function () {
        var _this = this;
        // Note: we get 0: Owner, 1: Member, 2: Visitor in the returned array.
        this._sitePermissionsProvider.getAssociatedPermissionGroups().then(function (permGroups) {
            _this._associatedGroups = permGroups;
        });
    };
    return AccessRequestsListBase;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

var AccessRequestsList = Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_9__["styled"])(AccessRequestsListBase, _AccessRequestsList_styles__WEBPACK_IMPORTED_MODULE_14__["getStyles"]);
//# sourceMappingURL=AccessRequestsList.js.map

/***/ }),

/***/ "fsNk":
/*!***************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/iconAliases.js ***!
  \***************************************************************************************************************************************************************/
/*! exports provided: registerIconAliases, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerIconAliases", function() { return registerIconAliases; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");

var registerIconAliases = function () {
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('trash', 'delete');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('onedrive', 'onedrivelogo');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('alertsolid12', 'eventdatemissed12');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('sixpointstar', '6pointstar');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('twelvepointstar', '12pointstar');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('toggleon', 'toggleleft');
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIconAlias"])('toggleoff', 'toggleright');
};
/* harmony default export */ __webpack_exports__["default"] = (registerIconAliases);
//# sourceMappingURL=iconAliases.js.map

/***/ }),

/***/ "fvyv":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/containers/groupMembershipPanel/index.js ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipPanelStateManager */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _GroupMembershipStateManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GroupMembershipStateManager */ "WkNf");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipPanelStateManager", function() { return _GroupMembershipStateManager__WEBPACK_IMPORTED_MODULE_0__["GroupMembershipPanelStateManager"]; });


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "gIZz":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingAudience.js ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/** SharingAudience defines "who to share with". */
var SharingAudience;
(function (SharingAudience) {
    /** Used by both ODC/ODB. Used when sharing link should work for specific people only. Also called "Secure sharing" in ODC. */
    SharingAudience[SharingAudience["specificPeople"] = 0] = "specificPeople";
    /** SPO/ODB only. Used when sharing with anyone in the organization with a link. */
    SharingAudience[SharingAudience["organization"] = 1] = "organization";
    /** Used by both ODC/ODB. Used when sharing with anyone (in the world) with a link. */
    SharingAudience[SharingAudience["anyone"] = 2] = "anyone";
    /** ODB/SPO only. Used to forward canonical URLs to people with existing access without generating a new link. */
    SharingAudience[SharingAudience["existing"] = 3] = "existing";
    /** ODB/SPO only. 'Flex' stands for flexible which is a new link type in SPO. */
    SharingAudience[SharingAudience["specificPeopleFlex"] = 4] = "specificPeopleFlex";
    /**
     * ODB/SPO only. This is a special audience option used by Teams/Outlook to show an option like
     * 'People in this chat', or 'Recipients of this email'.
     */
    SharingAudience[SharingAudience["customLabeledSpecificPeople"] = 5] = "customLabeledSpecificPeople";
})(SharingAudience || (SharingAudience = {}));
/* harmony default export */ __webpack_exports__["default"] = (SharingAudience);
//# sourceMappingURL=SharingAudience.js.map

/***/ }),

/***/ "gnvf":
/*!******************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/UserExpiration.js ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: UserExpirationDataSource, UserExpirationProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dataSources_UserExpiration_UserExpirationDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dataSources/UserExpiration/UserExpirationDataSource */ "HbnO");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UserExpirationDataSource", function() { return _dataSources_UserExpiration_UserExpirationDataSource__WEBPACK_IMPORTED_MODULE_0__["UserExpirationDataSource"]; });

/* harmony import */ var _providers_UserExpiration_UserExpirationProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./providers/UserExpiration/UserExpirationProvider */ "0ol6");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UserExpirationProvider", function() { return _providers_UserExpiration_UserExpirationProvider__WEBPACK_IMPORTED_MODULE_1__["UserExpirationProvider"]; });



//# sourceMappingURL=UserExpiration.js.map

/***/ }),

/***/ "h827":
/*!*******************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/SitePermissions.js ***!
  \*******************************************************************************************************************************************************************************/
/*! exports provided: RoleType, AssociatedPermGroups, HubSitePermGroups, SitePermissionsDataSource, SitePermissionsProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dataSources_roleAssignments_ISPUser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dataSources/roleAssignments/ISPUser */ "osLv");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RoleType", function() { return _dataSources_roleAssignments_ISPUser__WEBPACK_IMPORTED_MODULE_0__["RoleType"]; });

/* harmony import */ var _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dataSources/roleAssignments/SitePermissionsDataSource */ "S+Lk");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AssociatedPermGroups", function() { return _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_1__["AssociatedPermGroups"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HubSitePermGroups", function() { return _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_1__["HubSitePermGroups"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsDataSource", function() { return _dataSources_roleAssignments_SitePermissionsDataSource__WEBPACK_IMPORTED_MODULE_1__["SitePermissionsDataSource"]; });

/* harmony import */ var _dataSources_roleAssignments_PrincipalType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dataSources/roleAssignments/PrincipalType */ "2+UY");
/* empty/unused harmony star reexport *//* harmony import */ var _providers_sitePermissions_SitePermissionsProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./providers/sitePermissions/SitePermissionsProvider */ "Jdg/");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsProvider", function() { return _providers_sitePermissions_SitePermissionsProvider__WEBPACK_IMPORTED_MODULE_3__["SitePermissionsProvider"]; });

// Everything related to the Site Permissions datasource




//# sourceMappingURL=SitePermissions.js.map

/***/ }),

/***/ "hVhz":
/*!*****************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/index.js ***!
  \*****************************************************************************************************************************************************************************/
/*! exports provided: initializeFileTypeIcons, getFileTypeIconProps, FileIconType, getFileTypeIconAsHTMLString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _initializeFileTypeIcons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./initializeFileTypeIcons */ "3r9+");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "initializeFileTypeIcons", function() { return _initializeFileTypeIcons__WEBPACK_IMPORTED_MODULE_0__["initializeFileTypeIcons"]; });

/* harmony import */ var _getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getFileTypeIconProps */ "1EGi");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconProps", function() { return _getFileTypeIconProps__WEBPACK_IMPORTED_MODULE_1__["getFileTypeIconProps"]; });

/* harmony import */ var _FileIconType__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FileIconType */ "ALXe");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FileIconType", function() { return _FileIconType__WEBPACK_IMPORTED_MODULE_2__["FileIconType"]; });

/* harmony import */ var _getFileTypeIconAsHTMLString__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./getFileTypeIconAsHTMLString */ "LtPq");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getFileTypeIconAsHTMLString", function() { return _getFileTypeIconAsHTMLString__WEBPACK_IMPORTED_MODULE_3__["getFileTypeIconAsHTMLString"]; });

/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./version */ "Qcoe");





//# sourceMappingURL=index.js.map

/***/ }),

/***/ "hXlI":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/PeoplePicker/PeoplePickerItemWithMenu.js ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: PeoplePickerItemWithMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_shared_react_people_picker_lib_PeoplePickerItemWithMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/shared-react-people-picker/lib/PeoplePickerItemWithMenu */ "926j");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PeoplePickerItemWithMenu", function() { return _ms_shared_react_people_picker_lib_PeoplePickerItemWithMenu__WEBPACK_IMPORTED_MODULE_0__["PeoplePickerItemWithMenu"]; });


//# sourceMappingURL=PeoplePickerItemWithMenu.js.map

/***/ }),

/***/ "jrI6":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-3.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-3\"",
            src: "url('" + baseUrl + "fabric-icons-3-089e217a.woff') format('woff')"
        },
        icons: {
            'ChevronDownSmall': '\uE96E',
            'ChevronLeftSmall': '\uE96F',
            'ChevronRightSmall': '\uE970',
            'ChevronUpMed': '\uE971',
            'ChevronDownMed': '\uE972',
            'ChevronLeftMed': '\uE973',
            'ChevronRightMed': '\uE974',
            'Devices2': '\uE975',
            'PC1': '\uE977',
            'PresenceChickletVideo': '\uE979',
            'Reply': '\uE97A',
            'HalfAlpha': '\uE97E',
            'ConstructionCone': '\uE98F',
            'DoubleChevronLeftMed': '\uE991',
            'Volume0': '\uE992',
            'Volume1': '\uE993',
            'Volume2': '\uE994',
            'Volume3': '\uE995',
            'Chart': '\uE999',
            'Robot': '\uE99A',
            'Manufacturing': '\uE99C',
            'LockSolid': '\uE9A2',
            'FitPage': '\uE9A6',
            'FitWidth': '\uE9A7',
            'BidiLtr': '\uE9AA',
            'BidiRtl': '\uE9AB',
            'RightDoubleQuote': '\uE9B1',
            'Sunny': '\uE9BD',
            'CloudWeather': '\uE9BE',
            'Cloudy': '\uE9BF',
            'PartlyCloudyDay': '\uE9C0',
            'PartlyCloudyNight': '\uE9C1',
            'ClearNight': '\uE9C2',
            'RainShowersDay': '\uE9C3',
            'Rain': '\uE9C4',
            'Thunderstorms': '\uE9C6',
            'RainSnow': '\uE9C7',
            'Snow': '\uE9C8',
            'BlowingSnow': '\uE9C9',
            'Frigid': '\uE9CA',
            'Fog': '\uE9CB',
            'Squalls': '\uE9CC',
            'Duststorm': '\uE9CD',
            'Unknown': '\uE9CE',
            'Precipitation': '\uE9CF',
            'Ribbon': '\uE9D1',
            'AreaChart': '\uE9D2',
            'Assign': '\uE9D3',
            'FlowChart': '\uE9D4',
            'CheckList': '\uE9D5',
            'Diagnostic': '\uE9D9',
            'Generate': '\uE9DA',
            'LineChart': '\uE9E6',
            'Equalizer': '\uE9E9',
            'BarChartHorizontal': '\uE9EB',
            'BarChartVertical': '\uE9EC',
            'Freezing': '\uE9EF',
            'FunnelChart': '\uE9F1',
            'Processing': '\uE9F5',
            'Quantity': '\uE9F8',
            'ReportDocument': '\uE9F9',
            'StackColumnChart': '\uE9FC',
            'SnowShowerDay': '\uE9FD',
            'HailDay': '\uEA00',
            'WorkFlow': '\uEA01',
            'HourGlass': '\uEA03',
            'StoreLogoMed20': '\uEA04',
            'TimeSheet': '\uEA05',
            'TriangleSolid': '\uEA08',
            'UpgradeAnalysis': '\uEA0B',
            'VideoSolid': '\uEA0C',
            'RainShowersNight': '\uEA0F',
            'SnowShowerNight': '\uEA11',
            'Teamwork': '\uEA12',
            'HailNight': '\uEA13',
            'PeopleAdd': '\uEA15',
            'Glasses': '\uEA16',
            'DateTime2': '\uEA17',
            'Shield': '\uEA18',
            'Header1': '\uEA19',
            'PageAdd': '\uEA1A',
            'NumberedList': '\uEA1C',
            'PowerBILogo': '\uEA1E',
            'Info2': '\uEA1F',
            'MusicInCollectionFill': '\uEA36',
            'Asterisk': '\uEA38',
            'ErrorBadge': '\uEA39',
            'CircleFill': '\uEA3B',
            'Record2': '\uEA3F',
            'AllAppsMirrored': '\uEA40',
            'BookmarksMirrored': '\uEA41',
            'BulletedListMirrored': '\uEA42',
            'CaretHollowMirrored': '\uEA45',
            'CaretSolidMirrored': '\uEA46',
            'ChromeBackMirrored': '\uEA47',
            'ClearSelectionMirrored': '\uEA48',
            'ClosePaneMirrored': '\uEA49',
            'DockLeftMirrored': '\uEA4C',
            'DoubleChevronLeftMedMirrored': '\uEA4D',
            'GoMirrored': '\uEA4F'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-3.js.map

/***/ }),

/***/ "jwej":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingLinkStatus.js ***!
  \**********************************************************************************************************************************************************************************************************/
/*! exports provided: SharingLinkStatus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingLinkStatus", function() { return SharingLinkStatus; });
/**
 * This enum is mapped to the server code at:
 * https://onedrive.visualstudio.com/SharePoint%20Online/_git/SPO?path=%2Fsts%2Fstsom%2FSharing%2FSPObjectSharingInformation.cs&version=GBmaster&line=173&lineEnd=173&lineStartColumn=17&lineEndColumn=34&lineStyle=plain
 */
var SharingLinkStatus;
(function (SharingLinkStatus) {
    SharingLinkStatus[SharingLinkStatus["uninitialized"] = 0] = "uninitialized";
    SharingLinkStatus[SharingLinkStatus["created"] = 1] = "created";
    SharingLinkStatus[SharingLinkStatus["updated"] = 2] = "updated";
})(SharingLinkStatus || (SharingLinkStatus = {}));
//# sourceMappingURL=SharingLinkStatus.js.map

/***/ }),

/***/ "kG5v":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-8.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-8\"",
            src: "url('" + baseUrl + "fabric-icons-8-6fdf1528.woff') format('woff')"
        },
        icons: {
            'CollapseMenu': '\uEF66',
            'ExpandMenu': '\uEF67',
            'Boards': '\uEF68',
            'SunAdd': '\uEF69',
            'SunQuestionMark': '\uEF6A',
            'LandscapeOrientation': '\uEF6B',
            'DocumentSearch': '\uEF6C',
            'PublicCalendar': '\uEF6D',
            'PublicContactCard': '\uEF6E',
            'PublicEmail': '\uEF6F',
            'PublicFolder': '\uEF70',
            'WordDocument': '\uEF71',
            'PowerPointDocument': '\uEF72',
            'ExcelDocument': '\uEF73',
            'GroupedList': '\uEF74',
            'ClassroomLogo': '\uEF75',
            'Sections': '\uEF76',
            'EditPhoto': '\uEF77',
            'Starburst': '\uEF78',
            'ShareiOS': '\uEF79',
            'AirTickets': '\uEF7A',
            'PencilReply': '\uEF7B',
            'Tiles2': '\uEF7C',
            'SkypeCircleCheck': '\uEF7D',
            'SkypeCircleClock': '\uEF7E',
            'SkypeCircleMinus': '\uEF7F',
            'SkypeMessage': '\uEF83',
            'ClosedCaption': '\uEF84',
            'ATPLogo': '\uEF85',
            'OfficeFormsLogoInverse': '\uEF86',
            'RecycleBin': '\uEF87',
            'EmptyRecycleBin': '\uEF88',
            'Hide2': '\uEF89',
            'Breadcrumb': '\uEF8C',
            'BirthdayCake': '\uEF8D',
            'TimeEntry': '\uEF95',
            'CRMProcesses': '\uEFB1',
            'PageEdit': '\uEFB6',
            'PageArrowRight': '\uEFB8',
            'PageRemove': '\uEFBA',
            'Database': '\uEFC7',
            'DataManagementSettings': '\uEFC8',
            'CRMServices': '\uEFD2',
            'EditContact': '\uEFD3',
            'ConnectContacts': '\uEFD4',
            'AppIconDefaultAdd': '\uEFDA',
            'AppIconDefaultList': '\uEFDE',
            'ActivateOrders': '\uEFE0',
            'DeactivateOrders': '\uEFE1',
            'ProductCatalog': '\uEFE8',
            'ScatterChart': '\uEFEB',
            'AccountActivity': '\uEFF4',
            'DocumentManagement': '\uEFFC',
            'CRMReport': '\uEFFE',
            'KnowledgeArticle': '\uF000',
            'Relationship': '\uF003',
            'HomeVerify': '\uF00E',
            'ZipFolder': '\uF012',
            'SurveyQuestions': '\uF01B',
            'TextDocument': '\uF029',
            'TextDocumentShared': '\uF02B',
            'PageCheckedOut': '\uF02C',
            'PageShared': '\uF02D',
            'SaveAndClose': '\uF038',
            'Script': '\uF03A',
            'Archive': '\uF03F',
            'ActivityFeed': '\uF056',
            'Compare': '\uF057',
            'EventDate': '\uF059',
            'ArrowUpRight': '\uF069',
            'CaretRight': '\uF06B',
            'SetAction': '\uF071',
            'ChatBot': '\uF08B',
            'CaretSolidLeft': '\uF08D',
            'CaretSolidDown': '\uF08E',
            'CaretSolidRight': '\uF08F',
            'CaretSolidUp': '\uF090',
            'PowerAppsLogo': '\uF091',
            'PowerApps2Logo': '\uF092',
            'SearchIssue': '\uF09A',
            'SearchIssueMirrored': '\uF09B',
            'FabricAssetLibrary': '\uF09C',
            'FabricDataConnectionLibrary': '\uF09D',
            'FabricDocLibrary': '\uF09E',
            'FabricFormLibrary': '\uF09F',
            'FabricFormLibraryMirrored': '\uF0A0',
            'FabricReportLibrary': '\uF0A1',
            'FabricReportLibraryMirrored': '\uF0A2',
            'FabricPublicFolder': '\uF0A3',
            'FabricFolderSearch': '\uF0A4',
            'FabricMovetoFolder': '\uF0A5',
            'FabricUnsyncFolder': '\uF0A6',
            'FabricSyncFolder': '\uF0A7',
            'FabricOpenFolderHorizontal': '\uF0A8',
            'FabricFolder': '\uF0A9',
            'FabricFolderFill': '\uF0AA',
            'FabricNewFolder': '\uF0AB',
            'FabricPictureLibrary': '\uF0AC',
            'PhotoVideoMedia': '\uF0B1',
            'AddFavorite': '\uF0C8'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-8.js.map

/***/ }),

/***/ "kGUQ":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissionsPanel/SitePermissionsPanel.resx.js ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"additionalGroupsDescription":"There are additional groups or people with permissions on this site. To see them, please visit {0}.","uniquePermissionDescription":"This site has unique permissions. To see them, please visit {0}.","sharePanelUniquePermissionDescription":"This site has unique permissions. To share the site, please visit {0}.","title":"Permissions","fullControl":"Full control","edit":"Edit","read":"Read","remove":"Remove","panelDescription":"Manage site permissions or invite others to collaborate","addMembersToGroup":"Add members to group","shareSiteOnly":"Share site only","shareSiteOnlyDescription":"Provide access only to this site","shareSiteOnlyVerboseText":"Note that this site is part of a Microsoft 365 Group. If you add users here, they will be given access to the site, but not to other group resources such as calendars and conversations. To do that, {0} instead.","invitePeople":"Invite people","groupOwners":"{0} Owners","groupMembers":"{0} Members","addButton":"Add","share":"Share","cancelButton":"Cancel","shareSitePeoplePickerArialLabel":"People picker to share site","hubVisitorsPeoplePickerArialLabel":"People picker to add hub visitors","addUserOrGroupText":"Add users, Microsoft 365 Groups, or security groups to give them access to the site.","addUserOrGroupTextNoO365Group":"Add users or security groups","advancedPermSettings":"Advanced permissions settings","goToOutlookLink":"Outlook","goToOutlookText":"To view or change the group members for this site, go to {0}.","manageSitePermissions":"Manage permissions for this site here","siteOwners":"Site owners","siteMembers":"Site members","siteVisitors":"Site visitors","shareSiteOnlyAddMembersLinkText":"add members to the group","shareSiteTitle":"Share site","sendEmailText":"Send email","messagePlaceHolderText":"Add a message","closeButtonAriaLabel":"Close","backButtonAriaLabel":"Back","siteSharingSectionTitle":"Site Sharing","siteSharingSectionText":"Change how members can share","userExpirationText":"Your organization does not require guest access to expire.||Your organization requires guests to lose access to this site after {0} day.||Your organization requires guests to lose access to this site after {0} days.","userExpirationInterval":"0||1||2-","userExpiration":"Guest Expiration","userExpirationLink":"Manage","suggestionsAvailableAlertText":"Contact suggestions available.","pivotThisSite":"This site","pivotHubSite":"Hub","enableHubSitePermissionSyncToggle":"Sync hub permissions to associated sites","enableAssociatedSitePermissionSyncToggle":"Sync hub permissions to this site","toggleOn":"On","toggleOff":"Off","hubSitePivotHelperTextLabel":"Enter the names of individuals or groups to grant visitor access to the hub and associated sites. Existing site permissions will not change.","hubSitePivotDisabledHelperTextLabel":"Sync hub permissions to associated sites to ensure users can access all sites in the hub if the site owner allows. Existing site permissions will not change.","associatedSitePivotHelperTextLabel":"{0} is inheriting permissions from {1}.","hubSiteSyncDisallowedHelperTextLabel":"Sync hub permissions to your site to give access to hub visitors.","hubVisitors":"Hub visitors","genericHubPivotError":"An error occurred while accessing the hub permission settings.","hubPeoplePickerPlaceholder":"Enter a name or group","LearnMoreLinkText":"Learn more","accessRequestsLink":"Manage pending access requests","accessRequestsDialogTitle":"Access requests"};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "l+sn":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/siteHeader/AcronymAndColorDataSource.js ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: PersonaInitialsColor, COLOR_SERVICE_POSSIBLE_COLORS, AcronymAndColorDataSource, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PersonaInitialsColor", function() { return PersonaInitialsColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COLOR_SERVICE_POSSIBLE_COLORS", function() { return COLOR_SERVICE_POSSIBLE_COLORS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AcronymAndColorDataSource", function() { return AcronymAndColorDataSource; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _base_CachedDataSource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../base/CachedDataSource */ "zpEg");
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _ms_odsp_utilities_lib_encoding_UriEncoding__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-utilities/lib/encoding/UriEncoding */ "+35T");





var PersonaInitialsColor;
(function (PersonaInitialsColor) {
    PersonaInitialsColor[PersonaInitialsColor["lightBlue"] = 0] = "lightBlue";
    PersonaInitialsColor[PersonaInitialsColor["blue"] = 1] = "blue";
    PersonaInitialsColor[PersonaInitialsColor["darkBlue"] = 2] = "darkBlue";
    PersonaInitialsColor[PersonaInitialsColor["teal"] = 3] = "teal";
    PersonaInitialsColor[PersonaInitialsColor["lightGreen"] = 4] = "lightGreen";
    PersonaInitialsColor[PersonaInitialsColor["green"] = 5] = "green";
    PersonaInitialsColor[PersonaInitialsColor["darkGreen"] = 6] = "darkGreen";
    PersonaInitialsColor[PersonaInitialsColor["lightPink"] = 7] = "lightPink";
    PersonaInitialsColor[PersonaInitialsColor["pink"] = 8] = "pink";
    PersonaInitialsColor[PersonaInitialsColor["magenta"] = 9] = "magenta";
    PersonaInitialsColor[PersonaInitialsColor["purple"] = 10] = "purple";
    PersonaInitialsColor[PersonaInitialsColor["black"] = 11] = "black";
    PersonaInitialsColor[PersonaInitialsColor["orange"] = 12] = "orange";
    PersonaInitialsColor[PersonaInitialsColor["red"] = 13] = "red";
    PersonaInitialsColor[PersonaInitialsColor["darkRed"] = 14] = "darkRed";
})(PersonaInitialsColor || (PersonaInitialsColor = {}));
/** This is an array of possible colors that the service returns as of 11 Oct 2016.
 * However, the list of colors the service returns may change.
 * This is a weak contract provided for convenience,
 * so do not take a strong dependency on this array.
 * Look at /sporel/otools/inc/sts/stsom/utilities/SPWebLogoUtility.cs for the master copy */
var COLOR_SERVICE_POSSIBLE_COLORS = [
    '#0078d7',
    '#088272',
    '#107c10',
    '#881798',
    '#b4009e',
    '#e81123',
    '#da3b01',
    '#006f94',
    '#005e50',
    '#004e8c',
    '#a80000',
    '#4e257f'
];
/**
 * This datasource makes a call to the Acronyms and Colors service and returns an IAcronymColor object.
 */
var AcronymAndColorDataSource = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(AcronymAndColorDataSource, _super);
    function AcronymAndColorDataSource(pageContext) {
        return _super.call(this, {
            dataSourceName: 'SiteHeaderLogoAcronym',
            id: 'acronymAndColors'
        }, {
            pageContext: pageContext
        }) || this;
    }
    AcronymAndColorDataSource.decodeAcronymColor = function (color) {
        return COLOR_SERVICE_POSSIBLE_COLORS.indexOf(color) + 1;
    };
    /**
     * Given a site name, return a site logo acronym and color information through the GetAcronymsAndColors API.
     * Note: API takes in additional optional arguments like lcid, which as of this writing this method doesn't support.
     *       Please extend as appropriate.
     *
     * @param {string} siteName Name of the site.
     * @returns {Promise<IAcronymColor>} Site acronym and Color.
     */
    AcronymAndColorDataSource.prototype.getAcronymData = function (siteName) {
        return this.getAcronyms([siteName]).then(function (val) {
            return val[0];
        }, function () {
            return {
                acronym: undefined,
                color: undefined,
                text: undefined
            };
        });
    };
    /**
     * Given an array of strings, return acronym and color information through the GetAcronymsAndColors API.
     * Note: API takes in additional optional arguments like lcid, which as of this writing this method doesn't support.
     *       Please extend as appropriate.
     *
     * @param {string[]} strings An array of strings to pass to the service.
     * @param {IAcronymOptions} options An optional interface that allows customization of the QoS Name.
     * @returns {Promise<IAcronymColor[]>} An array of IAcronymColor objects containing site acronym and color information.
     */
    AcronymAndColorDataSource.prototype.getAcronyms = function (strings, options) {
        var _this = this;
        if (options === void 0) { options = {}; }
        if (this._pageContext.webServerRelativeUrl) {
            var _a = options.qosName, qosName = _a === void 0 ? 'GetSiteHeaderLogoAcronym' : _a;
            return this.getDataUtilizingPersistentCache({
                getUrl: function () {
                    // URL
                    var requestStr = strings
                        .map(function (str) { return "{Text: " + _ms_odsp_utilities_lib_encoding_UriEncoding__WEBPACK_IMPORTED_MODULE_4__["default"].encodeURIComponent('"' + str + '"') + "}"; })
                        .join(',');
                    return (Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__["getSafeWebServerRelativeUrl"])(_this._pageContext) +
                        ("/_api/sphome/GetAcronymsAndColors?labels=[" + requestStr + "]"));
                },
                parseResponse: function (responseText) {
                    // parse the responseText
                    var response = JSON.parse(responseText);
                    var responseResult = response.d.GetAcronymsAndColors.results;
                    return responseResult.map(function (val) {
                        return { acronym: val.Acronym, color: val.Color, text: val.Text };
                    });
                },
                method: 'GET',
                qosName: qosName
            });
        }
        else {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_3__["default"].reject(new Error('No web URL specified for request.'));
        }
    };
    return AcronymAndColorDataSource;
}(_base_CachedDataSource__WEBPACK_IMPORTED_MODULE_2__["CachedDataSource"]));

/* harmony default export */ __webpack_exports__["default"] = (AcronymAndColorDataSource);
//# sourceMappingURL=AcronymAndColorDataSource.js.map

/***/ }),

/***/ "le/i":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/IUpdatePermissionsResponse.js ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: UpdatePermissionsRole */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdatePermissionsRole", function() { return UpdatePermissionsRole; });
/**
 * November 2017 - interface moved from odsp-next
 */
var UpdatePermissionsRole;
(function (UpdatePermissionsRole) {
    UpdatePermissionsRole[UpdatePermissionsRole["NONE"] = 0] = "NONE";
    UpdatePermissionsRole[UpdatePermissionsRole["VIEW"] = 1] = "VIEW";
    UpdatePermissionsRole[UpdatePermissionsRole["EDIT"] = 2] = "EDIT";
    UpdatePermissionsRole[UpdatePermissionsRole["OWNER"] = 3] = "OWNER";
    UpdatePermissionsRole[UpdatePermissionsRole["REVIEW"] = 6] = "REVIEW";
})(UpdatePermissionsRole || (UpdatePermissionsRole = {}));
//# sourceMappingURL=IUpdatePermissionsResponse.js.map

/***/ }),

/***/ "ljal":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/ClientId.js ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: getClientId, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getClientId", function() { return getClientId; });
/**
 * Port any changes to
 * \odsp-common\items-view\core\src\private\facets\LoggerFacets.ts
 * TODO: we will fix package dependencies to avoid duplication
 */
var ClientId;
(function (ClientId) {
    ClientId[ClientId["unknown"] = 1] = "unknown";
    ClientId[ClientId["odb"] = 2] = "odb";
    ClientId[ClientId["sharePoint"] = 3] = "sharePoint";
    ClientId[ClientId["ngsc"] = 4] = "ngsc";
    ClientId[ClientId["word"] = 5] = "word";
    ClientId[ClientId["powerpoint"] = 6] = "powerpoint";
    ClientId[ClientId["excel"] = 7] = "excel";
    ClientId[ClientId["onenoteWeb"] = 8] = "onenoteWeb";
    ClientId[ClientId["wac"] = 9] = "wac";
    ClientId[ClientId["visio"] = 10] = "visio";
    ClientId[ClientId["officecom"] = 11] = "officecom";
    ClientId[ClientId["listPart"] = 12] = "listPart";
    ClientId[ClientId["outlookWeb"] = 13] = "outlookWeb";
    ClientId[ClientId["odIos"] = 14] = "odIos";
    ClientId[ClientId["odAndroid"] = 15] = "odAndroid";
    ClientId[ClientId["teams"] = 16] = "teams";
    ClientId[ClientId["sample"] = 17] = "sample";
    ClientId[ClientId["odc"] = 18] = "odc";
    ClientId[ClientId["wordAndroid"] = 19] = "wordAndroid";
    ClientId[ClientId["excelAndroid"] = 20] = "excelAndroid";
    ClientId[ClientId["powerpointAndroid"] = 21] = "powerpointAndroid";
    ClientId[ClientId["wordIos"] = 22] = "wordIos";
    ClientId[ClientId["excelIos"] = 23] = "excelIos";
    ClientId[ClientId["powerpointIos"] = 24] = "powerpointIos";
    ClientId[ClientId["onenote"] = 25] = "onenote";
    ClientId[ClientId["teamsIos"] = 26] = "teamsIos";
    ClientId[ClientId["teamsAndroid"] = 27] = "teamsAndroid";
    ClientId[ClientId["onenoteIos"] = 28] = "onenoteIos";
    ClientId[ClientId["visioIos"] = 29] = "visioIos";
    ClientId[ClientId["onenoteAndroid"] = 30] = "onenoteAndroid";
    ClientId[ClientId["visioAndroid"] = 31] = "visioAndroid";
    ClientId[ClientId["outlookWindows"] = 32] = "outlookWindows";
    ClientId[ClientId["outlookMac"] = 33] = "outlookMac";
    ClientId[ClientId["onenoteUWP"] = 34] = "onenoteUWP";
    ClientId[ClientId["officemobileIos"] = 35] = "officemobileIos";
    ClientId[ClientId["officemobileAndroid"] = 36] = "officemobileAndroid";
    ClientId[ClientId["odcWac"] = 37] = "odcWac";
    ClientId[ClientId["outlookGroupsWeb"] = 38] = "outlookGroupsWeb";
    ClientId[ClientId["fluid"] = 39] = "fluid";
    ClientId[ClientId["modernFileExplorer"] = 40] = "modernFileExplorer";
    ClientId[ClientId["listsHome"] = 41] = "listsHome";
    ClientId[ClientId["listsIos"] = 42] = "listsIos";
    ClientId[ClientId["edgeEnterpriseNtp"] = 43] = "edgeEnterpriseNtp";
    ClientId[ClientId["officeFeed"] = 44] = "officeFeed";
    ClientId[ClientId["searchUx"] = 45] = "searchUx";
})(ClientId || (ClientId = {}));
var clientIdLookUpMap = undefined;
/** Returns a ClientId value given its string value regardless of the casing. */
function getClientId(clientIdParam) {
    if (clientIdLookUpMap === undefined) {
        clientIdLookUpMap = {};
        for (var x in ClientId) {
            var numericValue = parseInt(x);
            if (!isNaN(numericValue)) {
                var enumName = ClientId[numericValue].toLowerCase();
                clientIdLookUpMap[enumName] = numericValue;
            }
        }
    }
    var clientIdLowercased = clientIdParam ? clientIdParam.toLowerCase() : '';
    return clientIdLookUpMap[clientIdLowercased] || ClientId.unknown;
}
/* harmony default export */ __webpack_exports__["default"] = (ClientId);
//# sourceMappingURL=ClientId.js.map

/***/ }),

/***/ "lnCR":
/*!***********************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/utilities-date-time@1.2.0/node_modules/@ms/utilities-date-time/lib/DateTime.resx.js ***!
  \***********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var strings = {"RelativeDateTime_AFewSeconds":"A few seconds ago","RelativeDateTime_AFewSeconds_StartWithLowerCase":"a few seconds ago","RelativeDateTime_AFewSecondsFuture":"In a few seconds","RelativeDateTime_AFewSecondsFuture_StartWithLowerCase":"in a few seconds","RelativeDateTime_AboutAMinuteFuture":"In about a minute","RelativeDateTime_AboutAMinuteFuture_StartWithLowerCase":"in about a minute","RelativeDateTime_LessThanAMinute":"Less than a minute ago","RelativeDateTime_LessThanAMinute_StartWithLowerCase":"less than a minute ago","RelativeDateTime_AboutAMinute":"About a minute ago","RelativeDateTime_AboutAMinute_StartWithLowerCase":"about a minute ago","RelativeDateTime_XMinutesFuture":"In {0} minute||In {0} minutes","RelativeDateTime_XMinutesFuture_StartWithLowerCase":"in {0} minute||in {0} minutes","RelativeDateTime_XMinutesFutureIntervals":"1||2-","RelativeDateTime_XMinutesIntervals":"1||2-","RelativeDateTime_AboutAnHourFuture":"In about an hour","RelativeDateTime_AboutAnHourFuture_StartWithLowerCase":"in about an hour","RelativeDateTime_AboutAnHour":"About an hour ago","RelativeDateTime_AboutAnHour_StartWithLowerCase":"about an hour ago","RelativeDateTime_Tomorrow":"Tomorrow","RelativeDateTime_Tomorrow_StartWithLowerCase":"tomorrow","RelativeDateTime_Yesterday":"Yesterday","RelativeDateTime_Yesterday_StartWithLowerCase":"yesterday","RelativeDateTime_YesterdayAndTime":"Yesterday at {0}","RelativeDateTime_YesterdayAndTime_StartWithLowerCase":"yesterday at {0}","DateTime_DateAndTime":"{0} at {1}","RelativeDateTime_TomorrowAndTime":"Tomorrow at {0}","RelativeDateTime_TomorrowAndTime_StartWithLowerCase":"tomorrow at {0}","RelativeDateTime_XHoursFuture":"In {0} hour||In {0} hours","RelativeDateTime_XHoursFuture_StartWithLowerCase":"in {0} hour||in {0} hours","RelativeDateTime_XHours":"{0} hour ago||{0} hours ago","RelativeDateTime_XHoursFutureIntervals":"1||2-","RelativeDateTime_XHoursIntervals":"1||2-","RelativeDateTime_DayAndTime":"{0} at {1}","RelativeDateTime_XDaysFuture":"{0} day from now||{0} days from now","RelativeDateTime_XDays":"{0} day ago||{0} days ago","RelativeDateTime_XDaysFutureIntervals":"1||2-","RelativeDateTime_XDaysIntervals":"1||2-","RelativeDateTime_Today":"Today","RelativeDateTime_Today_StartWithLowerCase":"today","RelativeDateTime_XMinutes":"{0} minute ago||{0} minutes ago","MonthAndYear":"{0} {1}","today":"Today","yesterday":"Yesterday"};
strings.default = strings;
module.exports = strings;

/***/ }),

/***/ "mLh3":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/providers/sharing/SharingSiteProvider.js ***!
  \*****************************************************************************************************************************************************************************************************/
/*! exports provided: SharingSiteProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingSiteProvider", function() { return SharingSiteProvider; });
/* harmony import */ var _dataSources_sharing_SharingSiteDataSource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../dataSources/sharing/SharingSiteDataSource */ "tcjH");

/**
 * @inheritdoc
 */
var SharingSiteProvider = /** @class */ (function () {
    function SharingSiteProvider(params) {
        this._dataSource = params.sharingSiteDataSource || new _dataSources_sharing_SharingSiteDataSource__WEBPACK_IMPORTED_MODULE_0__["SharingSiteDataSource"](params.pageContext);
    }
    /**
     * @inheritdoc
     */
    SharingSiteProvider.prototype.getSharingSettings = function () {
        return this._dataSource.getSharingSettings();
    };
    /**
     * @inheritdoc
     */
    SharingSiteProvider.prototype.shareSite = function (people, context) {
        return this._dataSource.shareSite(people, context);
    };
    /**
     * @inheritdoc
     */
    SharingSiteProvider.prototype.getSiteSharingSettings = function () {
        return this._dataSource.getSiteSharingSettings();
    };
    /**
     * @inheritdoc
     */
    SharingSiteProvider.prototype.setSiteSharingSettings = function (siteSharingSettings) {
        return this._dataSource.setSiteSharingSettings(siteSharingSettings);
    };
    return SharingSiteProvider;
}());

//# sourceMappingURL=SharingSiteProvider.js.map

/***/ }),

/***/ "ntSI":
/*!***************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/file-type-icons@7.6.24_c129be21209ec549b9ba61bf76d54bcc/node_modules/@uifabric/file-type-icons/lib/FileTypeIconMap.js ***!
  \***************************************************************************************************************************************************************************************/
/*! exports provided: FileTypeIconMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileTypeIconMap", function() { return FileTypeIconMap; });
/**
 * Enumeration of icon file names, and what extensions they map to.
 * Please keep items alphabetical. Items without extensions may require specific logic in the code to map.
 * Always use getFileTypeIconProps to get the most up-to-date icon at the right pixel density.
 */
var FileTypeIconMap = {
    accdb: {
        extensions: ['accdb', 'mdb'],
    },
    archive: {
        extensions: ['7z', 'ace', 'arc', 'arj', 'dmg', 'gz', 'iso', 'lzh', 'pkg', 'rar', 'sit', 'tgz', 'tar', 'z'],
    },
    audio: {
        extensions: [
            'aif',
            'aiff',
            'aac',
            'alac',
            'amr',
            'ape',
            'au',
            'awb',
            'dct',
            'dss',
            'dvf',
            'flac',
            'gsm',
            'm4a',
            'm4p',
            'mid',
            'mmf',
            'mp3',
            'oga',
            'ra',
            'rm',
            'wav',
            'wma',
            'wv',
        ],
    },
    calendar: {
        extensions: ['ical', 'icalendar', 'ics', 'ifb', 'vcs'],
    },
    code: {
        extensions: [
            'abap',
            'ada',
            'adp',
            'ahk',
            'as',
            'as3',
            'asc',
            'ascx',
            'asm',
            'asp',
            'awk',
            'bash',
            'bash_login',
            'bash_logout',
            'bash_profile',
            'bashrc',
            'bat',
            'bib',
            'bsh',
            'build',
            'builder',
            'c',
            'cbl',
            'c++',
            'capfile',
            'cc',
            'cfc',
            'cfm',
            'cfml',
            'cl',
            'clj',
            'cls',
            'cmake',
            'cmd',
            'coffee',
            'config',
            'cpp',
            'cpt',
            'cpy',
            'cs',
            'cshtml',
            'cson',
            'csproj',
            'css',
            'ctp',
            'cxx',
            'd',
            'ddl',
            'di',
            'disco',
            'dml',
            'dtd',
            'dtml',
            'el',
            'emakefile',
            'erb',
            'erl',
            'f',
            'f90',
            'f95',
            'fs',
            'fsi',
            'fsscript',
            'fsx',
            'gemfile',
            'gemspec',
            'gitconfig',
            'go',
            'groovy',
            'gvy',
            'h',
            'h++',
            'haml',
            'handlebars',
            'hbs',
            'hcp',
            'hh',
            'hpp',
            'hrl',
            'hs',
            'htc',
            'hxx',
            'idl',
            'iim',
            'inc',
            'inf',
            'ini',
            'inl',
            'ipp',
            'irbrc',
            'jade',
            'jav',
            'java',
            'js',
            'json',
            'jsp',
            'jsproj',
            'jsx',
            'l',
            'less',
            'lhs',
            'lisp',
            'log',
            'lst',
            'ltx',
            'lua',
            'm',
            'mak',
            'make',
            'manifest',
            'master',
            'md',
            'markdn',
            'markdown',
            'mdown',
            'mkdn',
            'ml',
            'mli',
            'mll',
            'mly',
            'mm',
            'mud',
            'nfo',
            'opml',
            'osascript',
            'p',
            'pas',
            'patch',
            'php',
            'php2',
            'php3',
            'php4',
            'php5',
            'phtml',
            'pl',
            'pm',
            'pod',
            'pp',
            'profile',
            'ps1',
            'ps1xml',
            'psd1',
            'psm1',
            'pss',
            'pt',
            'py',
            'pyw',
            'r',
            'rake',
            'rb',
            'rbx',
            'rc',
            'rdf',
            're',
            'reg',
            'rest',
            'resw',
            'resx',
            'rhtml',
            'rjs',
            'rprofile',
            'rpy',
            'rss',
            'rst',
            'ruby',
            'rxml',
            's',
            'sass',
            'scala',
            'scm',
            'sconscript',
            'sconstruct',
            'script',
            'scss',
            'sgml',
            'sh',
            'shtml',
            'sml',
            'svn-base',
            'swift',
            'sql',
            'sty',
            'tcl',
            'tex',
            'textile',
            'tld',
            'tli',
            'tmpl',
            'tpl',
            'vb',
            'vi',
            'vim',
            'vmg',
            'webpart',
            'wsp',
            'wsdl',
            'xhtml',
            'xoml',
            'xsd',
            'xslt',
            'yaml',
            'yaws',
            'yml',
            'zsh',
        ],
    },
    contact: {
        extensions: ['vcf'],
    },
    /*  css: {},  not broken out yet, snapping to 'code' for now */
    csv: {
        extensions: ['csv'],
    },
    desktopfolder: {},
    docset: {},
    documentfolder: {},
    docx: {
        extensions: ['doc', 'docm', 'docx', 'docb'],
    },
    dotx: {
        extensions: ['dot', 'dotm', 'dotx'],
    },
    email: {
        extensions: ['eml', 'msg', 'ost', 'pst'],
    },
    exe: {
        extensions: ['application', 'appref-ms', 'apk', 'app', 'appx', 'exe', 'ipa', 'msi', 'xap'],
    },
    folder: {},
    font: {
        extensions: ['ttf', 'otf', 'woff'],
    },
    fluid: {
        extensions: ['b', 'fluid'],
    },
    genericfile: {},
    html: {
        extensions: ['htm', 'html', 'mht'],
    },
    link: {
        extensions: ['lnk', 'link', 'url', 'website', 'webloc'],
    },
    linkedfolder: {},
    listitem: {},
    officescript: {
        extensions: ['osts'],
    },
    splist: {
        extensions: ['listitem'],
    },
    model: {
        extensions: [
            '3ds',
            '3mf',
            'blend',
            'cool',
            'dae',
            'df',
            'dwfx',
            'dwg',
            'dxf',
            'fbx',
            'glb',
            'gltf',
            'holo',
            'layer',
            'layout',
            'max',
            'mcworld',
            'mtl',
            'obj',
            'off',
            'ply',
            'skp',
            'stp',
            'stl',
            't',
            'thl',
            'x',
        ],
    },
    mpp: {
        extensions: ['mpp'],
    },
    mpt: {
        extensions: ['mpt'],
    },
    multiple: {},
    one: {
        // This represents a single Fluid Note, or a partial exported section/page of a notebook.
        extensions: ['note', 'one'],
    },
    onetoc: {
        extensions: ['ms-one-stub', 'onetoc', 'onetoc2', 'onepkg'],
    },
    pbiapp: {},
    pdf: {
        extensions: ['pdf'],
    },
    photo: {
        extensions: [
            'arw',
            'bmp',
            'cr2',
            'crw',
            'dic',
            'dicm',
            'dcm',
            'dcm30',
            'dcr',
            'dds',
            'dib',
            'dng',
            'erf',
            'gif',
            'heic',
            'heif',
            'ico',
            'jfi',
            'jfif',
            'jif',
            'jpe',
            'jpeg',
            'jpg',
            'kdc',
            'mrw',
            'nef',
            'orf',
            'pct',
            'pict',
            'png',
            'pns',
            'psb',
            'psd',
            'raw',
            'tga',
            'tif',
            'tiff',
            'wdp',
        ],
    },
    photo360: {},
    picturesfolder: {},
    potx: {
        extensions: ['pot', 'potm', 'potx'],
    },
    powerbi: {
        extensions: ['pbids', 'pbix'],
    },
    ppsx: {
        extensions: ['pps', 'ppsm', 'ppsx'],
    },
    pptx: {
        extensions: ['ppt', 'pptm', 'pptx', 'sldx', 'sldm'],
    },
    presentation: {
        extensions: ['odp', 'gslides', 'key'],
    },
    pub: {
        extensions: ['pub'],
    },
    spo: {
        extensions: ['aspx', 'classifier'],
    },
    sponews: {},
    spreadsheet: {
        extensions: ['odc', 'ods', 'gsheet', 'numbers', 'tsv'],
    },
    stream: {},
    rtf: {
        extensions: ['epub', 'gdoc', 'odt', 'rtf', 'wri', 'pages'],
    },
    sharedfolder: {},
    sway: {},
    sysfile: {
        extensions: [
            'bak',
            'bin',
            'cab',
            'cache',
            'cat',
            'cer',
            'class',
            'dat',
            'db',
            'dbg',
            'dl_',
            'dll',
            'ithmb',
            'jar',
            'kb',
            'ldt',
            'lrprev',
            'pkpass',
            'ppa',
            'ppam',
            'pdb',
            'rom',
            'thm',
            'thmx',
            'vsl',
            'xla',
            'xlam',
            'xlb',
            'xll',
        ],
    },
    txt: {
        extensions: ['dif', 'diff', 'readme', 'out', 'plist', 'properties', 'text', 'txt'],
    },
    vaultclosed: {},
    vaultopen: {},
    vector: {
        extensions: [
            'ai',
            'ait',
            'cvs',
            'dgn',
            'gdraw',
            'pd',
            'emf',
            'eps',
            'fig',
            'ind',
            'indd',
            'indl',
            'indt',
            'indb',
            'ps',
            'svg',
            'svgz',
            'wmf',
            'oxps',
            'xps',
            'xd',
            'sketch',
        ],
    },
    video: {
        extensions: [
            '3g2',
            '3gp',
            '3gp2',
            '3gpp',
            'asf',
            'avi',
            'dvr-ms',
            'flv',
            'm1v',
            'm4v',
            'mkv',
            'mod',
            'mov',
            'mm4p',
            'mp2',
            'mp2v',
            'mp4',
            'mp4v',
            'mpa',
            'mpe',
            'mpeg',
            'mpg',
            'mpv',
            'mpv2',
            'mts',
            'ogg',
            'qt',
            'swf',
            'ts',
            'vob',
            'webm',
            'wlmp',
            'wm',
            'wmv',
            'wmx',
        ],
    },
    video360: {},
    vsdx: {
        extensions: ['vdx', 'vsd', 'vsdm', 'vsdx', 'vsw', 'vdw'],
    },
    vssx: {
        extensions: ['vss', 'vssm', 'vssx'],
    },
    vstx: {
        extensions: ['vst', 'vstm', 'vstx', 'vsx'],
    },
    whiteboard: {
        extensions: ['whiteboard'],
    },
    xlsx: {
        extensions: ['xlc', 'xls', 'xlsb', 'xlsm', 'xlsx', 'xlw'],
    },
    xltx: {
        extensions: ['xlt', 'xltm', 'xltx'],
    },
    xml: {
        extensions: ['xaml', 'xml', 'xsl'],
    },
    xsn: {
        extensions: ['xsn'],
    },
    zip: {
        extensions: ['zip'],
    },
};
//# sourceMappingURL=FileTypeIconMap.js.map

/***/ }),

/***/ "oZSW":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/Mode.js ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * November 2017 - This interface moved from odsp-shared-sharing
 */
var Mode;
(function (Mode) {
    Mode[Mode["share"] = 1] = "share";
    Mode[Mode["copy"] = 2] = "copy";
    Mode[Mode["atMention"] = 3] = "atMention";
    Mode[Mode["linkSettings"] = 4] = "linkSettings";
    Mode[Mode["manageAccess"] = 5] = "manageAccess";
    Mode[Mode["notify"] = 6] = "notify";
    Mode[Mode["addPeople"] = 7] = "addPeople";
})(Mode || (Mode = {}));
/* harmony default export */ __webpack_exports__["default"] = (Mode);
//# sourceMappingURL=Mode.js.map

/***/ }),

/***/ "oeOE":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharePermission.js ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * November 2017 - This interface moved from odsp-shared-sharing
 */
var SharePermission;
(function (SharePermission) {
    SharePermission[SharePermission["view"] = 1] = "view";
    SharePermission[SharePermission["edit"] = 2] = "edit";
    /** Restricted view permission, when set to this, the item should have block download default. e.g. for meeting media files */
    SharePermission[SharePermission["restrictedView"] = 7] = "restrictedView";
})(SharePermission || (SharePermission = {}));
/* harmony default export */ __webpack_exports__["default"] = (SharePermission);
//# sourceMappingURL=SharePermission.js.map

/***/ }),

/***/ "osLv":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/roleAssignments/ISPUser.js ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: RoleType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoleType", function() { return RoleType; });
var RoleType;
(function (RoleType) {
    /**
     * Gurst permissions - Has limited rights to view pages and specific page elements.
     */
    RoleType[RoleType["Guest"] = 1] = "Guest";
    /**
     * Reader permissions - 	Has rights to view items; the reader cannot add content
     */
    RoleType[RoleType["Reader"] = 2] = "Reader";
    /**
     *  Contributor permissions - Has Reader rights, plus rights to add items, edit items, delete items, manage list permissions, manage
     *  personal views, personalize Web Part Pages, and browse directories.
     */
    RoleType[RoleType["Contributor"] = 3] = "Contributor";
    /**
     *  WebDesigner permissions - Has Contributor rights, plus rights to cancel check out, delete items, manage lists, add and customize
     *  pages, define and apply themes and borders, and link style sheets.
     */
    RoleType[RoleType["WebDesigner"] = 4] = "WebDesigner";
    /**
     *  Administrator permissions - Has all rights from other roles, plus rights to manage roles and view usage analysis data. Includes all
     * rights in the WebDesigner role, plus the following: ManageListPermissions, ManageRoles, ManageSubwebs, ViewUsageData.
     */
    RoleType[RoleType["Administrator"] = 5] = "Administrator";
    /**
     * Can add, edit and delete lists; can view, add, update and delete list items and documents.
     */
    RoleType[RoleType["Edit"] = 6] = "Edit";
    /**
     * For SharePoint internal use only. System roles can not be deleted, nor modified.
     */
    RoleType[RoleType["System"] = 255] = "System";
})(RoleType || (RoleType = {}));
//# sourceMappingURL=ISPUser.js.map

/***/ }),

/***/ "pVXM":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-10.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-10\"",
            src: "url('" + baseUrl + "fabric-icons-10-c4ded8e4.woff') format('woff')"
        },
        icons: {
            'ViewListGroup': '\uF248',
            'ViewListTree': '\uF249',
            'TriggerAuto': '\uF24A',
            'TriggerUser': '\uF24B',
            'PivotChart': '\uF24C',
            'StackedBarChart': '\uF24D',
            'StackedLineChart': '\uF24E',
            'BuildQueue': '\uF24F',
            'BuildQueueNew': '\uF250',
            'UserFollowed': '\uF25C',
            'ContactLink': '\uF25F',
            'Stack': '\uF26F',
            'Bullseye': '\uF272',
            'VennDiagram': '\uF273',
            'FiveTileGrid': '\uF274',
            'FocalPoint': '\uF277',
            'Insert': '\uF278',
            'RingerRemove': '\uF279',
            'TeamsLogoInverse': '\uF27A',
            'TeamsLogo': '\uF27B',
            'TeamsLogoFill': '\uF27C',
            'SkypeForBusinessLogoFill': '\uF27D',
            'SharepointLogo': '\uF27E',
            'SharepointLogoFill': '\uF27F',
            'DelveLogo': '\uF280',
            'DelveLogoFill': '\uF281',
            'OfficeVideoLogo': '\uF282',
            'OfficeVideoLogoFill': '\uF283',
            'ExchangeLogo': '\uF284',
            'ExchangeLogoFill': '\uF285',
            'Signin': '\uF286',
            'DocumentApproval': '\uF28B',
            'CloneToDesktop': '\uF28C',
            'InstallToDrive': '\uF28D',
            'Blur': '\uF28E',
            'Build': '\uF28F',
            'ProcessMetaTask': '\uF290',
            'BranchFork2': '\uF291',
            'BranchLocked': '\uF292',
            'BranchCommit': '\uF293',
            'BranchCompare': '\uF294',
            'BranchMerge': '\uF295',
            'BranchPullRequest': '\uF296',
            'BranchSearch': '\uF297',
            'BranchShelveset': '\uF298',
            'RawSource': '\uF299',
            'MergeDuplicate': '\uF29A',
            'RowsGroup': '\uF29B',
            'RowsChild': '\uF29C',
            'Deploy': '\uF29D',
            'Redeploy': '\uF29E',
            'ServerEnviroment': '\uF29F',
            'VisioDiagram': '\uF2A0',
            'HighlightMappedShapes': '\uF2A1',
            'TextCallout': '\uF2A2',
            'IconSetsFlag': '\uF2A4',
            'VisioLogo': '\uF2A7',
            'VisioLogoFill': '\uF2A8',
            'VisioDocument': '\uF2A9',
            'TimelineProgress': '\uF2AA',
            'TimelineDelivery': '\uF2AB',
            'Backlog': '\uF2AC',
            'TeamFavorite': '\uF2AD',
            'TaskGroup': '\uF2AE',
            'TaskGroupMirrored': '\uF2AF',
            'ScopeTemplate': '\uF2B0',
            'AssessmentGroupTemplate': '\uF2B1',
            'NewTeamProject': '\uF2B2',
            'CommentAdd': '\uF2B3',
            'CommentNext': '\uF2B4',
            'CommentPrevious': '\uF2B5',
            'ShopServer': '\uF2B6',
            'LocaleLanguage': '\uF2B7',
            'QueryList': '\uF2B8',
            'UserSync': '\uF2B9',
            'UserPause': '\uF2BA',
            'StreamingOff': '\uF2BB',
            'ArrowTallUpLeft': '\uF2BD',
            'ArrowTallUpRight': '\uF2BE',
            'ArrowTallDownLeft': '\uF2BF',
            'ArrowTallDownRight': '\uF2C0',
            'FieldEmpty': '\uF2C1',
            'FieldFilled': '\uF2C2',
            'FieldChanged': '\uF2C3',
            'FieldNotChanged': '\uF2C4',
            'RingerOff': '\uF2C5',
            'PlayResume': '\uF2C6',
            'BulletedList2': '\uF2C7',
            'BulletedList2Mirrored': '\uF2C8',
            'ImageCrosshair': '\uF2C9',
            'GitGraph': '\uF2CA',
            'Repo': '\uF2CB',
            'RepoSolid': '\uF2CC',
            'FolderQuery': '\uF2CD',
            'FolderList': '\uF2CE',
            'FolderListMirrored': '\uF2CF',
            'LocationOutline': '\uF2D0',
            'POISolid': '\uF2D1',
            'CalculatorNotEqualTo': '\uF2D2',
            'BoxSubtractSolid': '\uF2D3'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-10.js.map

/***/ }),

/***/ "pfuc":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/SitePermissionsPanel/SitePermissionsPanel.js ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissionsPanel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsPanel", function() { return SitePermissionsPanel; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/Panel */ "p6C6");
/* harmony import */ var office_ui_fabric_react_lib_components_Button_IconButton_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/Button/IconButton/IconButton */ "cULl");
/* harmony import */ var _SitePermissions_SitePermissions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../SitePermissions/SitePermissions */ "bZph");
/* harmony import */ var office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Button */ "epn0");
/* harmony import */ var office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! office-ui-fabric-react/lib/ContextualMenu */ "u4xd");
/* harmony import */ var office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! office-ui-fabric-react/lib/Utilities */ "mkpW");
/* harmony import */ var _SitePermissionsPanel_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SitePermissionsPanel.scss */ "1XQB");
/* harmony import */ var _PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker */ "5zxV");
/* harmony import */ var _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../containers/SitePermissions/SitePermissionsStateManager */ "CgVw");
/* harmony import */ var _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../PeoplePicker/PeoplePicker.Props */ "wWxM");
/* harmony import */ var office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! office-ui-fabric-react/lib/Spinner */ "fyAn");
/* harmony import */ var office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! office-ui-fabric-react/lib/Link */ "F3Wv");
/* harmony import */ var _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ms/odsp-utilities/lib/logging/events/Engagement.event */ "cDPE");
/* harmony import */ var _PeoplePicker_PeoplePickerItemWithMenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../PeoplePicker/PeoplePickerItemWithMenu */ "hXlI");
/* harmony import */ var office_ui_fabric_react_lib_TextField__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! office-ui-fabric-react/lib/TextField */ "tTm/");
/* harmony import */ var office_ui_fabric_react_lib_Checkbox__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! office-ui-fabric-react/lib/Checkbox */ "l0uo");
/* harmony import */ var _ms_odsp_datasources_lib_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ms/odsp-datasources/lib/interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_datasources_lib_PeoplePicker__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ms/odsp-datasources/lib/PeoplePicker */ "sQJ6");
/* harmony import */ var office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! office-ui-fabric-react/lib/MessageBar */ "oW6A");
/* harmony import */ var _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ms/odsp-datasources/lib/Permissions */ "jH+c");
/* harmony import */ var _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../utilities/peoplepicker/PeoplePickerHelper */ "zluq");
/* harmony import */ var _utilities_wrapPlaceholderContent__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../utilities/wrapPlaceholderContent */ "dHB+");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ms/odsp-utilities/lib/guid/Guid */ "vo05");
/* harmony import */ var _ms_odsp_datasources_lib_dataSources_roleAssignments_PrincipalType__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ms/odsp-datasources/lib/dataSources/roleAssignments/PrincipalType */ "2+UY");
/* harmony import */ var _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./SitePermissionsPanel.resx */ "kGUQ");
/* harmony import */ var _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/Features */ "8G1T");
/* harmony import */ var _ms_odsp_datasources_lib_Sharing__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @ms/odsp-datasources/lib/Sharing */ "ERuR");
/* harmony import */ var _SiteSharingSettingsPanel_SiteSharingSettingsPanel__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../SiteSharingSettingsPanel/SiteSharingSettingsPanel */ "Xxza");
/* harmony import */ var _ms_odsp_datasources_lib_UserExpiration__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @ms/odsp-datasources/lib/UserExpiration */ "gnvf");
/* harmony import */ var _UserExpirationPanel_UserExpirationPanel__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../UserExpirationPanel/UserExpirationPanel */ "Ml3t");
/* harmony import */ var office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! office-ui-fabric-react/lib/Pivot */ "wD6F");
/* harmony import */ var office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! office-ui-fabric-react/lib/Label */ "wMNn");
/* harmony import */ var office_ui_fabric_react_lib_Toggle__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! office-ui-fabric-react/lib/Toggle */ "40s1");
/* harmony import */ var _AccessRequests_AccessRequestsDialog__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ../AccessRequests/AccessRequestsDialog */ "2mns");
/* harmony import */ var _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @ms/odsp-datasources/lib/AccessRequests */ "Vdfb");







































var UserExpirationPanelExperience = { ODB: 1559 };
var AccessRequestsModernManagementUI = { ODB: 1479 };
/**
 * @public
 */
var SitePermissionsPanel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SitePermissionsPanel, _super);
    function SitePermissionsPanel(props) {
        var _this = _super.call(this, props) || this;
        _this._onChangeSendEmail = function (ev) {
            _this.setState({
                shouldSendEmail: !_this.state.shouldSendEmail
            });
        };
        _this._removePermControl = function (ev) {
            _this.setState({
                shouldHidePermControl: true
            });
        };
        _this._onChangeEnableHubPermissionSync = function (ev, checked) {
            if (_this.props.onSaveHubPermissionSync) {
                _this.props.onSaveHubPermissionSync(checked);
            }
        };
        _this._closePanel = function () {
            if (!_this._isLPCOpen) {
                _this.setState({
                    showPanel: false,
                    showUserExpirationPanel: false
                });
                if (_this.props.onDismiss) {
                    _this.props.onDismiss();
                }
            }
        };
        _this._onClick = function () {
            _this.setState({
                isInvitePeopleContextualMenuVisible: !_this.state.isInvitePeopleContextualMenuVisible
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.InvitePeople.Click' });
        };
        _this._onDismiss = function (ev) {
            _this.setState({
                isInvitePeopleContextualMenuVisible: false
            });
            ev.stopPropagation();
            ev.preventDefault();
        };
        _this._onSaveClick = function (ev) {
            _this.setState({
                showSavingSpinner: true,
                saveButtonDisabled: true
            });
            var users = _this._peoplePicker.selectedPeople;
            if (users && users.length && _this.props.onSave) {
                _this.props.onSave(users, _this.state.shouldSendEmail, _this._mailMessage).done(function (success) {
                    _this.setState({
                        showSavingSpinner: false,
                        saveButtonDisabled: false,
                        showPanel: _this.props.shouldLoadSharePanelOnly ? false : _this.state.showPanel
                    });
                    _this._resetSharePanel();
                });
            }
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.Save.Click' });
        };
        _this._onCancelClick = function (ev) {
            if (_this.props.onCancel) {
                _this._resetSharePanel();
                _this.props.onCancel();
            }
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.Cancel.Click' });
        };
        _this._onAccessRequestsClick = function () {
            _this.setState({
                showAccessRequestDialog: true
            });
        };
        _this._onDismissAccessRequestsDialog = function () {
            _this.setState({
                showAccessRequestDialog: false
            });
        };
        _this._onSuggestionSelected = function (suggestion) {
            var pickerSettings = _this.props.pickerSettings;
            var peoplePickerQueryParams = {
                principalSource: pickerSettings.PrincipalSource,
                principalType: pickerSettings.PrincipalAccountType,
                allowEmailAddresses: pickerSettings.AllowEmailAddresses,
                filterExternalUsers: false,
                maximumEntitySuggestions: 30,
                forceResolve: true
            };
            // If suggestion is an internal user, skip resolve.
            if (suggestion.isExternal === false || (suggestion.isExternal && suggestion.providerName)) {
                return suggestion;
            }
            else if (suggestion.principalType === _ms_odsp_datasources_lib_dataSources_roleAssignments_PrincipalType__WEBPACK_IMPORTED_MODULE_27__["default"].distributionList) {
                peoplePickerQueryParams.isGraphDistributionList = true;
                peoplePickerQueryParams.useGraph = true;
                peoplePickerQueryParams.useSubstrate = true;
            }
            return _this._peoplePickerProvider
                .resolve(suggestion.userId, peoplePickerQueryParams)
                .then(function (person) {
                /**
                 * Workaround for case when it's an existing authenticated user
                 * in a tenant and API doesn't return an email in the email property.
                 */
                if (!person.email && person.rawData.EntityData) {
                    person.email = person.rawData.EntityData.OtherMails;
                }
                if (!person.name && person.rawData.EntityData) {
                    person.name = person.rawData.EntityData.OtherMails;
                }
                return person;
            });
        };
        _this._onSelectHubPersona = function (items) {
            // only one persona can be selected at a time
            var firstPersona = items && items[0];
            // TODO: Handle people picker error states
            if (_this.props.onAddHubUserCallback) {
                _this.props.onAddHubUserCallback(firstPersona);
            }
        };
        _this._onSelectedPeopleChange = function (items) {
            var peoplePickerError;
            var peoplePickerWarnings;
            var warnings = [];
            var peoplePickerErrorSpan = _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_22__["renderPickerError"]({
                selectedItems: items
            });
            var oversharingExternalsWarning = _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_22__["getOversharingExternalsWarning"](items);
            var oversharingGroupsWarning = _utilities_peoplepicker_PeoplePickerHelper__WEBPACK_IMPORTED_MODULE_22__["getOversharingGroupsWarning"](items);
            if (peoplePickerErrorSpan) {
                peoplePickerError = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBar"], { className: 'ms-SitePermPanel-PeoplePicker-error', messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBarType"].error }, peoplePickerErrorSpan));
            }
            if (oversharingExternalsWarning) {
                warnings.push(react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBar"], { className: 'ms-SitePermPanel-PeoplePicker-warning', messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBarType"].warning }, oversharingExternalsWarning));
            }
            if (oversharingGroupsWarning) {
                warnings.push(react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBar"], { className: 'ms-SitePermPanel-PeoplePicker-warning', messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBarType"].warning }, oversharingGroupsWarning));
            }
            if (warnings.length > 0) {
                peoplePickerWarnings = react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-PeoplePicker-warnings' }, warnings);
            }
            _this.setState({
                isPersonaSelected: _this._peoplePicker.selectedPeople.length > 0 && !peoplePickerError,
                peoplePickerError: peoplePickerError,
                peoplePickerWarnings: peoplePickerWarnings
            });
        };
        _this._siteSharingSettingsOnClick = function () {
            _this.setState({
                showSiteSharingSettingsPanel: true
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.SiteSharingSettings.Click' });
        };
        _this._onDismissSiteSharingSettingsPanel = function () {
            _this.setState({
                showSiteSharingSettingsPanel: false
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.DismissSiteSharingSettings.Click' });
        };
        _this._onUserExpirationClick = function () {
            _this.setState({
                showUserExpirationPanel: true
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.UserExpirationPanel.Click' });
        };
        _this._onDismissUserExpirationPanel = function () {
            _this.setState({
                showUserExpirationPanel: false
            });
            _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.DismissUserExpirationPanel.Click' });
        };
        _this._isLPCOpenHandler = function (isLPCOpen) {
            _this._isLPCOpen = isLPCOpen;
        };
        _this._isUserExpirationPanelEnabled =
            props.pageContext.isSiteAdmin && _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_29__["default"].isFeatureEnabled(UserExpirationPanelExperience);
        _this._isAccessRequestDialogEnabled = false;
        _this._isGroup = Object(_ms_odsp_datasources_lib_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_18__["isGroupWebContext"])(props.pageContext);
        _this._resolveMenu = function (el) { return (_this._menu = el); };
        _this._mailMessage = '';
        _this._isLPCOpen = false;
        _this.state = {
            showPanel: true,
            showShareSiteOnly: props.showShareSiteOnly,
            shouldSendEmail: true,
            showSiteSharingSettingsPanel: false,
            showUserExpirationPanel: false,
            showAccessRequestDialog: false
        };
        _this._peoplePickerProvider = new _ms_odsp_datasources_lib_PeoplePicker__WEBPACK_IMPORTED_MODULE_19__["PeoplePickerProvider"]({
            pageContext: props.pageContext,
            peoplePickerDataSource: props.peoplePickerDataSource
        });
        if (_this._isUserExpirationPanelEnabled) {
            _this._userExpirationProvider = new _ms_odsp_datasources_lib_UserExpiration__WEBPACK_IMPORTED_MODULE_32__["UserExpirationProvider"]({
                dataSource: new _ms_odsp_datasources_lib_UserExpiration__WEBPACK_IMPORTED_MODULE_32__["UserExpirationDataSource"]({ pageContext: props.pageContext })
            });
            _this._userExpirationProvider
                .getExternalUserExpirationPolicy()
                .then(function (policyDays) { return _this.setState({ userExpirationPolicyDays: policyDays }); });
        }
        if (_ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_29__["default"].isFeatureEnabled(AccessRequestsModernManagementUI)) {
            _this._accessRequestsProvider = new _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_38__["AccessRequestsProvider"]({
                dataSource: new _ms_odsp_datasources_lib_AccessRequests__WEBPACK_IMPORTED_MODULE_38__["AccessRequestsDataSource"]({ pageContext: props.pageContext })
            });
            _this._accessRequestsProvider.hasAccessRequests().then(function (status) {
                _this._isAccessRequestDialogEnabled =
                    status && (props.pageContext.isSiteAdmin || props.pageContext.isSiteOwner);
            });
        }
        _ms_odsp_utilities_lib_logging_events_Engagement_event__WEBPACK_IMPORTED_MODULE_14__["Engagement"].logData({ name: 'SitePermissionsPanel.Opened.Click' });
        return _this;
    }
    SitePermissionsPanel.prototype.render = function () {
        var _this = this;
        var props = this.props;
        var showShareSiteOnly = props.showShareSiteOnly, shouldDismissPanel = props.shouldDismissPanel, pickerSettings = props.pickerSettings, showHubPivot = props.showHubPivot, shouldLoadSharePanelOnly = props.shouldLoadSharePanelOnly;
        var shareSitePanelTitle = shouldLoadSharePanelOnly
            ? props.shareSiteTitle || _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSiteTitle
            : null;
        var footerContent = function (props, defaultRender) {
            return showShareSiteOnly && pickerSettings ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanelButton' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-SitePermPanelButton-container' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["PrimaryButton"], { className: 'ms-SitePermPanel-saveButton', disabled: !_this.state.isPersonaSelected, onClick: _this._onSaveClick, "data-automationid": 'SitePermissionsPanelSaveButton' }, _this.props.saveButton)),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: 'ms-SitePermPanelButton-container' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["DefaultButton"], { className: 'ms-SitePermPanel-cancelButton', onClick: _this._onCancelClick, "data-automationid": 'SitePermissionsPanelCancelButton' }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.cancelButton)))) : null;
        };
        var navigationContent = function (props, defaultRender) {
            return showShareSiteOnly && !shouldLoadSharePanelOnly ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-NavigationContent' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_components_Button_IconButton_IconButton__WEBPACK_IMPORTED_MODULE_3__["IconButton"], { iconProps: { iconName: 'Back' }, className: 'ms-SitePermPanel-BackIcon', onClick: _this._onCancelClick, ariaLabel: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.backButtonAriaLabel }),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: 'ms-SitePermPanel-Title' }, _this.props.shareSiteTitle || _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSiteTitle),
                defaultRender(props))) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-NavigationContentDismiss' },
                " ",
                defaultRender(props),
                " "));
        };
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_2__["Panel"], { className: 'ms-SitePermPanel', isOpen: this.state.showPanel && !shouldDismissPanel, type: office_ui_fabric_react_lib_Panel__WEBPACK_IMPORTED_MODULE_2__["PanelType"].smallFixedFar, onDismiss: this._closePanel, isLightDismiss: true, headerText: showShareSiteOnly ? shareSitePanelTitle : props.title || _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.title, forceFocusInsideTrap: false, closeButtonAriaLabel: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.closeButtonAriaLabel, onRenderFooterContent: footerContent, onRenderNavigationContent: navigationContent },
            showShareSiteOnly && pickerSettings && this._renderShareSiteOnly(),
            !showShareSiteOnly && showHubPivot && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_34__["Pivot"], { className: 'ms-SitePermPanel-Pivot' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_34__["PivotItem"], { headerText: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.pivotThisSite }, this._renderPermissions()),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Pivot__WEBPACK_IMPORTED_MODULE_34__["PivotItem"], { headerText: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.pivotHubSite }, this._renderHubPermissions()))),
            !showShareSiteOnly && !showHubPivot && this._renderPermissions()));
    };
    SitePermissionsPanel.prototype._renderAdvancedPermSettings = function () {
        var _a = this.props, advancedPermSettingsUrl = _a.advancedPermSettingsUrl, hasCustomizedGroups = _a.hasCustomizedGroups, pageContext = _a.pageContext, permissionLevelOfCurrentUser = _a.permissionLevelOfCurrentUser, isDefaultPermissionsChanged = _a.isDefaultPermissionsChanged, showShareSiteOnly = _a.showShareSiteOnly;
        var advancedPermSettings;
        if (advancedPermSettingsUrl &&
            (permissionLevelOfCurrentUser === _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl ||
                _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_21__["PermissionMask"].hasPermission(pageContext.webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_21__["PermissionMask"].managePermissions))) {
            var advancedPermSettingsLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], { href: advancedPermSettingsUrl, target: '_blank', className: 'ms-MessageBar-link', "data-automationid": 'SitePermissionsPanelAdvancedPermLink' }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.advancedPermSettings));
            var description = void 0;
            if (isDefaultPermissionsChanged) {
                if (showShareSiteOnly) {
                    description = _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.sharePanelUniquePermissionDescription;
                }
                else {
                    description = _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.uniquePermissionDescription;
                }
            }
            else if (hasCustomizedGroups) {
                description = _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.additionalGroupsDescription;
            }
            if (description) {
                if (description.indexOf('{0}') === -1) {
                    description += ' {0}.';
                }
                advancedPermSettingsLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", null, _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__["formatToArray"](description, advancedPermSettingsLink)));
            }
            advancedPermSettings = react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-AdvancedPerm' }, advancedPermSettingsLink);
        }
        return advancedPermSettings;
    };
    SitePermissionsPanel.prototype._renderSiteSharingSetting = function () {
        var _a = this.props, pageContext = _a.pageContext, permissionLevelOfCurrentUser = _a.permissionLevelOfCurrentUser;
        var showSiteSharingSettingsPanel = this.state.showSiteSharingSettingsPanel;
        var siteSharingSettings;
        if (permissionLevelOfCurrentUser === _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl ||
            _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_21__["PermissionMask"].hasPermission(pageContext.webPermMasks, _ms_odsp_datasources_lib_Permissions__WEBPACK_IMPORTED_MODULE_21__["PermissionMask"].managePermissions)) {
            var siteSharingSettingsLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], { className: 'ms-MessageBar-link', "data-automationid": 'SitePermissionsPanelSiteSharingSettingsLink', onClick: this._siteSharingSettingsOnClick }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.siteSharingSectionText));
            siteSharingSettings = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-SharingSettings' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-sectionTitle' },
                    " ",
                    _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.siteSharingSectionTitle),
                siteSharingSettingsLink,
                showSiteSharingSettingsPanel && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_SiteSharingSettingsPanel_SiteSharingSettingsPanel__WEBPACK_IMPORTED_MODULE_31__["SiteSharingSettingsPanel"], { isOpen: showSiteSharingSettingsPanel, onDismiss: this._onDismissSiteSharingSettingsPanel, pageContext: pageContext, peoplePickerProvider: this._peoplePickerProvider, sharingSiteProvider: new _ms_odsp_datasources_lib_Sharing__WEBPACK_IMPORTED_MODULE_30__["SharingSiteProvider"]({ pageContext: pageContext }) }))));
        }
        return siteSharingSettings;
    };
    SitePermissionsPanel.prototype._renderUserExpiration = function () {
        var pageContext = this.props.pageContext;
        var _a = this.state, showUserExpirationPanel = _a.showUserExpirationPanel, userExpirationPolicyDays = _a.userExpirationPolicyDays;
        var userExpirationPanel;
        var userExpirationLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], { className: 'ms-MessageBar-link', "data-automationid": 'SitePermissionsPanelUserExpirationLink', onClick: this._onUserExpirationClick }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.userExpirationLink));
        userExpirationPanel = userExpirationPolicyDays != undefined && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-UserExpiration' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-sectionTitle' }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.userExpiration),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__["formatWithLocalizedCountValue"](_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.userExpirationText, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.userExpirationInterval, userExpirationPolicyDays)),
            userExpirationLink,
            showUserExpirationPanel && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_UserExpirationPanel_UserExpirationPanel__WEBPACK_IMPORTED_MODULE_33__["UserExpirationPanel"], { isOpen: showUserExpirationPanel, onBackButton: this._onDismissUserExpirationPanel, onDismiss: this._closePanel, pageContext: pageContext, userExpirationProvider: this._userExpirationProvider, userExpirationPolicyDays: userExpirationPolicyDays, userExpirationPolicyEnabled: userExpirationPolicyDays > 0 }))));
        return userExpirationPanel;
    };
    SitePermissionsPanel.prototype._renderAccessRequestsDialog = function () {
        var showAccessRequestDialog = this.state.showAccessRequestDialog;
        var pageContext = this.props.pageContext;
        var accessRequestsObj;
        var accessRequestsLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], { className: 'ms-AccessRequests-link', "data-automationid": 'SitePermissionsPanelAccessRequestsDialogLink', onClick: this._onAccessRequestsClick }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.accessRequestsLink));
        accessRequestsObj = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-AcessRequests' },
            accessRequestsLink,
            showAccessRequestDialog && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_AccessRequests_AccessRequestsDialog__WEBPACK_IMPORTED_MODULE_37__["AccessRequestsDialog"], { showAccessRequestDialog: showAccessRequestDialog, onDismiss: this._onDismissAccessRequestsDialog, pageContext: pageContext, peoplePickerDataSource: this.props.peoplePickerDataSource }))));
        return accessRequestsObj;
    };
    SitePermissionsPanel.prototype._renderPermissions = function () {
        var _this = this;
        var _a = this.props, menuItems = _a.menuItems, onShareSiteCallback = _a.onShareSiteCallback, sitePermissions = _a.sitePermissions, permissionLevelOfCurrentUser = _a.permissionLevelOfCurrentUser, pickerSettings = _a.pickerSettings;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("p", { className: 'ms-sitePermPanel-TextArea', "data-automationid": 'SitePermissionsPanelDescription' }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.panelDescription),
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePerm-ContextMenu' },
                    pickerSettings &&
                        sitePermissions &&
                        (permissionLevelOfCurrentUser === _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl ||
                            permissionLevelOfCurrentUser === _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].Edit) && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-sitePermPanel-buttonArea', ref: this._resolveMenu },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Button__WEBPACK_IMPORTED_MODULE_5__["PrimaryButton"], { className: Object(office_ui_fabric_react_lib_Utilities__WEBPACK_IMPORTED_MODULE_7__["css"])('ms-sitePermPanel-itemBtn', this._isGroup
                                ? 'ms-sitePermPanel-invitePeopleButton'
                                : 'ms-sitePermPanel-shareSiteButton'), onClick: this._isGroup ? this._onClick : onShareSiteCallback, "data-automationid": 'SitePermissionsPanelInviteButton' }, this._isGroup ? _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.invitePeople : _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSiteTitle))),
                    this.state.isInvitePeopleContextualMenuVisible && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__["ContextualMenu"], { className: 'ms-sitePermPanel-invitePeopleContextualMenu', items: menuItems, isBeakVisible: false, target: this._menu, directionalHint: office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_6__["DirectionalHint"].bottomLeftEdge, onDismiss: this._onDismiss, gapSpace: 0 })))),
            sitePermissions && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, sitePermissions.map(function (sitePermissions) {
                return _this._getSitePermissions(sitePermissions);
            }))),
            this._renderSiteSharingSetting(),
            this._isAccessRequestDialogEnabled && this._renderAccessRequestsDialog(),
            this._isUserExpirationPanelEnabled && this._renderUserExpiration(),
            this._renderAdvancedPermSettings()));
    };
    SitePermissionsPanel.prototype._renderHubPermissions = function () {
        var _this = this;
        var _a;
        var _b = this.props, isHubSite = _b.isHubSite, hubSiteTitle = _b.hubSiteTitle, enableHubPermissionsSync = _b.enableHubPermissionsSync, showHubSyncToggleSpinner = _b.showHubSyncToggleSpinner, hubSyncControlsAreDisabled = _b.hubSyncControlsAreDisabled, hubPivotErrorString = _b.hubPivotErrorString;
        var toggleLabel = isHubSite
            ? _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.enableHubSitePermissionSyncToggle
            : _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.enableAssociatedSitePermissionSyncToggle;
        var helperTextLabel = undefined;
        if (isHubSite) {
            helperTextLabel = enableHubPermissionsSync
                ? _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubSitePivotHelperTextLabel
                : _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubSitePivotDisabledHelperTextLabel;
        }
        else if (!!hubSiteTitle) {
            // if title isn't available yet then just hide the label until loading is done
            if (enableHubPermissionsSync) {
                helperTextLabel = _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__["format"](_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.associatedSitePivotHelperTextLabel, (_a = this.props.pageContext) === null || _a === void 0 ? void 0 : _a.webTitle, hubSiteTitle);
            }
            else {
                helperTextLabel = _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_24__["format"](_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubSiteSyncDisallowedHelperTextLabel, hubSiteTitle);
            }
        }
        var groupsVisible = enableHubPermissionsSync && !showHubSyncToggleSpinner;
        var pickerIsVisible = groupsVisible && isHubSite;
        var basePickerProps = this._getPeoplePickerProps();
        var pickerProps = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, basePickerProps), { itemLimit: 1, peoplePickerType: _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_11__["PeoplePickerType"].normal, onSelectedPersonasChange: this._onSelectHubPersona, peoplePickerQueryParams: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, basePickerProps.peoplePickerQueryParams), { allowEmailAddresses: false }), inputProps: {
                'aria-label': _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubVisitorsPeoplePickerArialLabel,
                placeholder: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubPeoplePickerPlaceholder
            } });
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-HubPivotDiv' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Toggle__WEBPACK_IMPORTED_MODULE_36__["Toggle"], { checked: enableHubPermissionsSync, disabled: showHubSyncToggleSpinner || hubSyncControlsAreDisabled, label: toggleLabel, onText: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.toggleOn, offText: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.toggleOff, onChange: this._onChangeEnableHubPermissionSync }),
            showHubSyncToggleSpinner ? react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_12__["Spinner"], null) : null,
            helperTextLabel && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_35__["Label"], { className: 'ms-SitePermPanel-HubPivot-helperText' },
                helperTextLabel + ' ',
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], { href: 'https://go.microsoft.com/fwlink/?linkid=2133626' }, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.LearnMoreLinkText))),
            groupsVisible && react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Label__WEBPACK_IMPORTED_MODULE_35__["Label"], null, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.hubVisitors),
            pickerIsVisible ? (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-PeoplePicker', "data-automationid": 'SitePermissionsPanelHubPeoplePicker' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_9__["PeoplePicker"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, pickerProps)))) : null,
            hubPivotErrorString && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBar"], { className: 'ms-SitePermPanel-HubPivot-error', messageBarType: office_ui_fabric_react_lib_MessageBar__WEBPACK_IMPORTED_MODULE_20__["MessageBarType"].error }, hubPivotErrorString)),
            !showHubSyncToggleSpinner && enableHubPermissionsSync && this.props.hubSitePermissions && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-HubPivot-permissions' }, this.props.hubSitePermissions.map(function (sitePermissions) {
                return _this._getSitePermissions(sitePermissions);
            })))));
    };
    SitePermissionsPanel.prototype._renderShareSiteOnly = function () {
        var _this = this;
        var _a = this.props, goToOutlookOnClick = _a.goToOutlookOnClick, isEmailSharingEnabled = _a.isEmailSharingEnabled, pageContext = _a.pageContext, shouldLoadSharePanelOnly = _a.shouldLoadSharePanelOnly, sitePermissions = _a.sitePermissions, sitePreviewLoader = _a.sitePreviewLoader, isDefaultPermissionsChanged = _a.isDefaultPermissionsChanged;
        var _b = this.state, isPersonaSelected = _b.isPersonaSelected, peoplePickerError = _b.peoplePickerError, peoplePickerWarnings = _b.peoplePickerWarnings, shouldHidePermControl = _b.shouldHidePermControl, shouldSendEmail = _b.shouldSendEmail, showSavingSpinner = _b.showSavingSpinner;
        var helpTextFooterForAddMemLink = null;
        if (this._isGroup && goToOutlookOnClick) {
            // shareSiteOnlyVerboseText designates the position of the inline link with a '{0}' token to permit proper localization.
            helpTextFooterForAddMemLink = (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-PeoplePicker', "data-automationid": 'SitePermissionsPanelPeoplePicker' }, Object(_utilities_wrapPlaceholderContent__WEBPACK_IMPORTED_MODULE_23__["wrapPlaceholderContent"])(_SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSiteOnlyVerboseText, _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSiteOnlyAddMembersLinkText, office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_13__["Link"], {
                className: 'ms-SitePermPanel-Link',
                onClick: goToOutlookOnClick,
                'data-automationid': 'SitePermissionsPanelAddMemberLink'
            })));
        }
        return isDefaultPermissionsChanged ? (this._renderAdvancedPermSettings()) : (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-SharePanel' },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { onClick: this._removePermControl, className: 'ms-SitePermPanel-PeoplePicker', "data-automationid": 'SitePermissionsPanelPeoplePicker' },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-PeoplePicker' }, pageContext.isSPO ? _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.addUserOrGroupText : _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.addUserOrGroupTextNoO365Group),
                helpTextFooterForAddMemLink,
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_PeoplePicker_PeoplePicker__WEBPACK_IMPORTED_MODULE_9__["PeoplePicker"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, this._getPeoplePickerProps(), { componentRef: function (c) {
                        if (c) {
                            _this._peoplePicker = c;
                        }
                    } })),
                peoplePickerError || peoplePickerWarnings),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
                shouldLoadSharePanelOnly && !shouldHidePermControl && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, sitePermissions &&
                    sitePermissions.map(function (sitePermission) {
                        return _this._getSitePermissions(sitePermission);
                    }))),
                isEmailSharingEnabled && isPersonaSelected && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-ShareSiteEmail' },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Checkbox__WEBPACK_IMPORTED_MODULE_17__["Checkbox"], { className: 'ms-SitePermPanel-ShareSiteEmail-checkbox', defaultChecked: shouldSendEmail, label: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.sendEmailText, onChange: this._onChangeSendEmail }),
                    shouldSendEmail && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-SitePermPanel-ShareSiteEmail-message-div' },
                        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_TextField__WEBPACK_IMPORTED_MODULE_16__["TextField"], { className: 'ms-SitePermPanel-ShareSiteEmail-message', multiline: true, resizable: false, placeholder: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.messagePlaceHolderText, onChange: function (ev, newValue) { return (_this._mailMessage = newValue); } }),
                        sitePreviewLoader))))),
            showSavingSpinner && react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_12__["Spinner"], null)));
    };
    SitePermissionsPanel.prototype.renderPeoplePickerItemWithMenu = function (props) {
        var availablePermissions = this.props.sitePermissionsContextualMenuItems.map(function (value) { return value.permissionLevel; });
        var currentPermissionLevel;
        if (props.item.permissionLevel) {
            currentPermissionLevel = props.item.permissionLevel;
        }
        else if (availablePermissions.indexOf(this.props.addMemberDefaultPermissionLevel) > -1) {
            currentPermissionLevel = this.props.addMemberDefaultPermissionLevel;
        }
        else if (availablePermissions.indexOf(_containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].Edit) > -1) {
            currentPermissionLevel = _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].Edit;
        }
        else if (availablePermissions.indexOf(_containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].Read) > -1) {
            currentPermissionLevel = _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].Read;
        }
        else {
            currentPermissionLevel = _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl;
        }
        // Only render permission contextual menu for full control permission.
        // Edit permission can only share with edit permission, and read permission can't share.
        var menuItems = this.props.permissionLevelOfCurrentUser === _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl
            ? this.props.sitePermissionsContextualMenuItems
                .filter(function (item) { return item.permissionLevel !== currentPermissionLevel; })
                .map(function (item) { return (Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, item), { onClick: function (ev, contextualMenuItem) {
                    var changedItem = props.item;
                    changedItem.permissionLevel = contextualMenuItem.permissionLevel;
                    props.onItemChange(changedItem, props.index);
                } })); })
            : undefined;
        return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_PeoplePicker_PeoplePickerItemWithMenu__WEBPACK_IMPORTED_MODULE_15__["PeoplePickerItemWithMenu"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props), { menuTitle: this.props.permissionLevelOfCurrentUser !== _containers_SitePermissions_SitePermissionsStateManager__WEBPACK_IMPORTED_MODULE_10__["PermissionLevel"].FullControl
                ? ''
                : this.props.permissionStrings[currentPermissionLevel], menuItems: menuItems }));
    };
    SitePermissionsPanel.prototype._getSitePermissions = function (sitePermissions) {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_SitePermissions_SitePermissions__WEBPACK_IMPORTED_MODULE_4__["SitePermissions"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, sitePermissions, { key: sitePermissions.permLevel, pageContext: this.props.pageContext, lpcModuleLoader: this.props.lpcModuleLoader, lpcModuleCustomWaiter: this.props.lpcModuleCustomWaiter, isLPCOpenHandler: this._isLPCOpenHandler })));
    };
    SitePermissionsPanel.prototype._resetSharePanel = function () {
        this.setState({
            shouldSendEmail: true,
            isPersonaSelected: false,
            peoplePickerWarnings: undefined,
            peoplePickerError: undefined
        });
    };
    SitePermissionsPanel.prototype._getPeoplePickerProps = function () {
        var _this = this;
        var props = this.props;
        var pageContext = props.pageContext, pickerSettings = props.pickerSettings;
        var useIBSegmentsKillSwitch = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_25__["Killswitch"].isActivated('34c10010-00ae-48db-8ec7-d9fd2f8d7804', '3/19/2020', 'use substrate');
        return {
            noResultsFoundText: ' ',
            context: pageContext,
            peoplePickerType: _PeoplePicker_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_11__["PeoplePickerType"].listBelow,
            onSelectedPersonasChange: this._onSelectedPeopleChange,
            onRenderItem: function (props) { return _this.renderPeoplePickerItemWithMenu(props); },
            onSuggestionSelected: this._onSuggestionSelected,
            dataProvider: this._peoplePickerProvider,
            peoplePickerQueryParams: {
                allowEmailAddresses: true,
                allowMultipleEntities: null,
                allUrlZones: null,
                enabledClaimProviders: null,
                forceClaims: null,
                groupID: 0,
                maximumEntitySuggestions: 30,
                // Corresponds to all sources server side.
                principalSource: pickerSettings && pickerSettings.PrincipalSource,
                blockExternalUsers: true,
                principalType: pickerSettings && pickerSettings.PrincipalAccountType,
                required: null,
                urlZone: null,
                urlZoneSpecified: null,
                useGraph: !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_25__["Killswitch"].isActivated('F18F4F84-A337-4C37-81BF-20545B8B9BD9', '4/28/2020', 'Use enforceIBSegmentFilter.')
                    ? !pageContext.enforceIBSegmentFilter
                    : true,
                useSubstrate: useIBSegmentsKillSwitch && pageContext.IBSegments && pageContext.IBSegments.length > 0,
                conversationId: _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_26__["default"].generate(),
                siteIBSegmentIDs: useIBSegmentsKillSwitch && pageContext.IBSegments
            },
            suggestionsAvailableAlertText: _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.suggestionsAvailableAlertText,
            enableSelectedSuggestionAlert: true,
            inputProps: {
                'aria-label': _SitePermissionsPanel_resx__WEBPACK_IMPORTED_MODULE_28___default.a.shareSitePeoplePickerArialLabel,
                autoFocus: true
            }
        };
    };
    return SitePermissionsPanel;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=SitePermissionsPanel.js.map

/***/ }),

/***/ "qWgY":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipMenu/GroupMembershipMenu.scss.js ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");
/* harmony import */ var _microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__);
/* tslint:disable */

Object(_microsoft_load_themed_styles__WEBPACK_IMPORTED_MODULE_0__["loadStyles"])([{ "rawString": ".ms-groupMembershipMenu-linkText{cursor:pointer}.ms-groupMembershipMenu-titleArea{line-height:20px;font-size:" }, { "theme": "smallFontSize", "defaultValue": "12px" }, { "rawString": ";color:" }, { "theme": "neutralSecondary", "defaultValue": "#605e5c" }, { "rawString": "}[dir='ltr'] .ms-groupMembershipMenu-chevron{margin-left:8px}[dir='rtl'] .ms-groupMembershipMenu-chevron{margin-right:8px}.ms-groupMembershipMenu-updatingSpinner{float:left}[dir='ltr'] .ms-groupMembershipMenu-updatingSpinner{margin-right:5px}[dir='rtl'] .ms-groupMembershipMenu-updatingSpinner{margin-left:5px}\n" }]);
//# sourceMappingURL=GroupMembershipMenu.scss.js.map

/***/ }),

/***/ "rZN7":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingRoleV3.js ***!
  \******************************************************************************************************************************************************************************************************/
/*! exports provided: SharingRoleV3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingRoleV3", function() { return SharingRoleV3; });
/**
 * November 2017 - This enum was moved from odsp-shared-sharing.
 * Originally copied from DocumentSharingTypes.cs in SPOREL.
 */
var SharingRoleV3;
(function (SharingRoleV3) {
    /**
     * A user has no permission to share a securable object.
     */
    SharingRoleV3[SharingRoleV3["none"] = 0] = "none";
    /**
     * A user can only read a securable object.
     */
    SharingRoleV3[SharingRoleV3["view"] = 1] = "view";
    /**
     * A user can edit or read a securable object, but cannot delete the object.
     */
    SharingRoleV3[SharingRoleV3["edit"] = 2] = "edit";
    /**
     * A user is an owner of a securable object, who can manage permissions, and edit, read or delete the object.
     * Currently used in permissions model only (e.g., ShareObject API)
     */
    SharingRoleV3[SharingRoleV3["owner"] = 3] = "owner";
    /**
     * A user can read a shared object, plus comment in/on a shared object.
     * Currently used in links model only (e.g., ShareLink API)
     */
    SharingRoleV3[SharingRoleV3["review"] = 6] = "review";
    /**
     * A user can view a shared object only in web viewer, cannot download the object.
     * Currently used in link model only.
     */
    SharingRoleV3[SharingRoleV3["restrictedview"] = 7] = "restrictedview";
    /**
     * A user can submit files to a file request folder. Can not view or edit folder contents.
     */
    SharingRoleV3[SharingRoleV3["submit"] = 8] = "submit";
})(SharingRoleV3 || (SharingRoleV3 = {}));
//# sourceMappingURL=SharingRoleV3.js.map

/***/ }),

/***/ "scPC":
/*!*********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/AccessRequests/AccessRequestsList.styles.js ***!
  \*********************************************************************************************************************************************************************************************************************/
/*! exports provided: getStyles */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStyles", function() { return getStyles; });
var getStyles = function (props) {
    return {
        root: [],
        label: {}
    };
};
//# sourceMappingURL=AccessRequestsList.styles.js.map

/***/ }),

/***/ "smyq":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-17.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-17\"",
            src: "url('" + baseUrl + "fabric-icons-17-0c4ed701.woff') format('woff')"
        },
        icons: {
            'CustomizeToolbar': '\uF828',
            'DuplicateRow': '\uF82A',
            'RemoveFromTrash': '\uF82B',
            'MailOptions': '\uF82C',
            'Childof': '\uF82D',
            'Footer': '\uF82E',
            'Header': '\uF82F',
            'BarChartVerticalFill': '\uF830',
            'StackedColumnChart2Fill': '\uF831',
            'PlainText': '\uF834',
            'AccessibiltyChecker': '\uF835',
            'DatabaseSync': '\uF842',
            'ReservationOrders': '\uF845',
            'TabOneColumn': '\uF849',
            'TabTwoColumn': '\uF84A',
            'TabThreeColumn': '\uF84B',
            'BulletedTreeList': '\uF84C',
            'MicrosoftTranslatorLogoGreen': '\uF852',
            'MicrosoftTranslatorLogoBlue': '\uF853',
            'InternalInvestigation': '\uF854',
            'AddReaction': '\uF85D',
            'ContactHeart': '\uF862',
            'VisuallyImpaired': '\uF866',
            'EventToDoLogo': '\uF869',
            'Variable2': '\uF86D',
            'ModelingView': '\uF871',
            'DisconnectVirtualMachine': '\uF873',
            'ReportLock': '\uF875',
            'Uneditable2': '\uF876',
            'Uneditable2Mirrored': '\uF877',
            'BarChartVerticalEdit': '\uF89D',
            'GlobalNavButtonActive': '\uF89F',
            'PollResults': '\uF8A0',
            'Rerun': '\uF8A1',
            'QandA': '\uF8A2',
            'QandAMirror': '\uF8A3',
            'BookAnswers': '\uF8A4',
            'AlertSettings': '\uF8B6',
            'TrimStart': '\uF8BB',
            'TrimEnd': '\uF8BC',
            'TableComputed': '\uF8F5',
            'DecreaseIndentLegacy': '\uE290',
            'IncreaseIndentLegacy': '\uE291',
            'SizeLegacy': '\uE2B2'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-17.js.map

/***/ }),

/***/ "sscn":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-16.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-16\"",
            src: "url('" + baseUrl + "fabric-icons-16-9cf93f3b.woff') format('woff')"
        },
        icons: {
            'OfficeChatSolid': '\uF710',
            'MailSchedule': '\uF72E',
            'WarningSolid': '\uF736',
            'Blocked2Solid': '\uF737',
            'SkypeCircleArrow': '\uF747',
            'SkypeArrow': '\uF748',
            'SyncStatus': '\uF751',
            'SyncStatusSolid': '\uF752',
            'ProjectDocument': '\uF759',
            'ToDoLogoOutline': '\uF75B',
            'VisioOnlineLogoFill32': '\uF75F',
            'VisioOnlineLogo32': '\uF760',
            'VisioOnlineLogoCloud32': '\uF761',
            'VisioDiagramSync': '\uF762',
            'Event12': '\uF763',
            'EventDateMissed12': '\uF764',
            'UserOptional': '\uF767',
            'ResponsesMenu': '\uF768',
            'DoubleDownArrow': '\uF769',
            'DistributeDown': '\uF76A',
            'BookmarkReport': '\uF76B',
            'FilterSettings': '\uF76C',
            'GripperDotsVertical': '\uF772',
            'MailAttached': '\uF774',
            'AddIn': '\uF775',
            'LinkedDatabase': '\uF779',
            'TableLink': '\uF77A',
            'PromotedDatabase': '\uF77D',
            'BarChartVerticalFilter': '\uF77E',
            'BarChartVerticalFilterSolid': '\uF77F',
            'MicOff2': '\uF781',
            'MicrosoftTranslatorLogo': '\uF782',
            'ShowTimeAs': '\uF787',
            'FileRequest': '\uF789',
            'WorkItemAlert': '\uF78F',
            'PowerBILogo16': '\uF790',
            'PowerBILogoBackplate16': '\uF791',
            'BulletedListText': '\uF792',
            'BulletedListBullet': '\uF793',
            'BulletedListTextMirrored': '\uF794',
            'BulletedListBulletMirrored': '\uF795',
            'NumberedListText': '\uF796',
            'NumberedListNumber': '\uF797',
            'NumberedListTextMirrored': '\uF798',
            'NumberedListNumberMirrored': '\uF799',
            'RemoveLinkChain': '\uF79A',
            'RemoveLinkX': '\uF79B',
            'FabricTextHighlight': '\uF79C',
            'ClearFormattingA': '\uF79D',
            'ClearFormattingEraser': '\uF79E',
            'Photo2Fill': '\uF79F',
            'IncreaseIndentText': '\uF7A0',
            'IncreaseIndentArrow': '\uF7A1',
            'DecreaseIndentText': '\uF7A2',
            'DecreaseIndentArrow': '\uF7A3',
            'IncreaseIndentTextMirrored': '\uF7A4',
            'IncreaseIndentArrowMirrored': '\uF7A5',
            'DecreaseIndentTextMirrored': '\uF7A6',
            'DecreaseIndentArrowMirrored': '\uF7A7',
            'CheckListText': '\uF7A8',
            'CheckListCheck': '\uF7A9',
            'CheckListTextMirrored': '\uF7AA',
            'CheckListCheckMirrored': '\uF7AB',
            'NumberSymbol': '\uF7AC',
            'Coupon': '\uF7BC',
            'VerifiedBrand': '\uF7BD',
            'ReleaseGate': '\uF7BE',
            'ReleaseGateCheck': '\uF7BF',
            'ReleaseGateError': '\uF7C0',
            'M365InvoicingLogo': '\uF7C1',
            'RemoveFromShoppingList': '\uF7D5',
            'ShieldAlert': '\uF7D7',
            'FabricTextHighlightComposite': '\uF7DA',
            'Dataflows': '\uF7DD',
            'GenericScanFilled': '\uF7DE',
            'DiagnosticDataBarTooltip': '\uF7DF',
            'SaveToMobile': '\uF7E0',
            'Orientation2': '\uF7E1',
            'ScreenCast': '\uF7E2',
            'ShowGrid': '\uF7E3',
            'SnapToGrid': '\uF7E4',
            'ContactList': '\uF7E5',
            'NewMail': '\uF7EA',
            'EyeShadow': '\uF7EB',
            'FabricFolderConfirm': '\uF7FF',
            'InformationBarriers': '\uF803',
            'CommentActive': '\uF804',
            'ColumnVerticalSectionEdit': '\uF806',
            'WavingHand': '\uF807',
            'ShakeDevice': '\uF80A',
            'SmartGlassRemote': '\uF80B',
            'Rotate90Clockwise': '\uF80D',
            'Rotate90CounterClockwise': '\uF80E',
            'CampaignTemplate': '\uF811',
            'ChartTemplate': '\uF812',
            'PageListFilter': '\uF813',
            'SecondaryNav': '\uF814',
            'ColumnVerticalSection': '\uF81E',
            'SkypeCircleSlash': '\uF825',
            'SkypeSlash': '\uF826'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-16.js.map

/***/ }),

/***/ "tTm/":
/*!****************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/TextField.js ***!
  \****************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
// Loading office-ui-fabric-react/./lib/TextField.js


/***/ }),

/***/ "tcjH":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/sharing/SharingSiteDataSource.js ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: SharingSiteDataSource, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingSiteDataSource", function() { return SharingSiteDataSource; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dataSources_base_DataSource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../dataSources/base/DataSource */ "AfY0");
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base/DataBatchOperationHelper */ "zMwE");
/* harmony import */ var _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities/lib/guid/Guid */ "vo05");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_6__);
// OneDrive:IgnoreCodeCoverage







// As of 8/30, external are sent using BDM, a third-party service, that
// has a 500 character message limit. PM decided to limit all messages to
// 500 characters to avoid the case of succeeding internally and failing
// externally.
var BDM_EMAIL_CHAR_LIMIT = 500;
var EDIT_ROLE = 'role:1073741827';
var VIEW_ROLE = 'role:1073741826';
var FULL_CONTROL_ROLE = 'role:1073741829';
/**
 * @inheritdoc
 */
var SharingSiteDataSource = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SharingSiteDataSource, _super);
    function SharingSiteDataSource(pageContext) {
        var _this = _super.call(this, {
            dataSourceName: 'SharingSiteDataSource'
        }, {
            pageContext: pageContext
        }) || this;
        var webServerRelativeUrl = Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_2__["getSafeWebServerRelativeUrl"])(_this._pageContext);
        _this._getSharingSettingsUrl =
            webServerRelativeUrl +
                '/_api/SP.Web.GetObjectSharingSettings?$expand=ObjectSharingInformation,SharePointSettings/PickerProperties';
        _this._shareUrl = webServerRelativeUrl + '/_api/SP.Web.ShareObject';
        _this._getSiteSharingtSettingsUrl =
            webServerRelativeUrl +
                '/_api/web?$select=MembersCanShare,TenantAdminMembersCanShare,RequestAccessEmail,UseAccessRequestDefault,AccessRequestSiteDescription,AssociatedOwnerGroup,AssociatedMemberGroup&$expand=AssociatedOwnerGroup,AssociatedMemberGroup,AssociatedMemberGroup/AllowMembersEditMembership';
        _this._setSiteSharingSettingsUrl = webServerRelativeUrl + '/_api/web';
        _this._setUseAccessRequestDefaultUrl =
            webServerRelativeUrl + '/_api/web/SetUseAccessRequestDefaultAndUpdate';
        _this._setUseAccessRequestDescriptiontUrl =
            webServerRelativeUrl + '/_api/web/SetAccessRequestSiteDescriptionAndUpdate';
        _this._setGroupAllowMembersEditMembershipUrl = webServerRelativeUrl + '/_api/web/SiteGroups({0})';
        return _this;
    }
    /**
     * @inheritdoc
     */
    SharingSiteDataSource.prototype.getSharingSettings = function () {
        var _this = this;
        return this._getSharingSettingsRawResponse().then(function (response) {
            // TODO: change response type to ISharingResponse when new API is on.
            return _this._parseSettings(response);
        }, function (error) {
            return _this._parseError(error);
        });
    };
    /**
     * @inheritdoc
     */
    SharingSiteDataSource.prototype.getSiteSharingSettings = function () {
        var _this = this;
        var qosName = 'SP.Web.SiteSharingSettings';
        return this.getData(
        /* getUrl */ function () { return _this._getSiteSharingtSettingsUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            return response.d;
        }, 
        /* qosName */ qosName, 
        /* getAdditionalPostData */ null, 
        /* method */ 'GET', 
        /* addtionHeaders */ null, 
        /* contentType */ null, 
        /* maxRetries */ null, 
        /* noRedirect */ true).then(function (response) {
            var siteSharingSettings = {};
            siteSharingSettings.membersCanShare = response.MembersCanShare;
            siteSharingSettings.tenantAdminMembersCanShare = response.TenantAdminMembersCanShare;
            siteSharingSettings.requestAccessEmail = response.RequestAccessEmail;
            siteSharingSettings.useAccessRequestDefault = response.UseAccessRequestDefault;
            siteSharingSettings.accessRequestSiteDescription = response.AccessRequestSiteDescription;
            siteSharingSettings.ownersGroup = _this.parseSPGroup(response.AssociatedOwnerGroup);
            siteSharingSettings.membersGroup = _this.parseSPGroup(response.AssociatedMemberGroup);
            return siteSharingSettings;
        }, function (error) {
            return _this._parseError(error);
        });
    };
    /**
     * @inheritdoc
     */
    SharingSiteDataSource.prototype.setSiteSharingSettings = function (siteSharingSettings) {
        var _this = this;
        var qosName = 'SP.Web.SetSiteSharingSettings';
        var batchGuid = _ms_odsp_utilities_lib_guid_Guid__WEBPACK_IMPORTED_MODULE_5__["default"].generate();
        var contentType = 'multipart/mixed; boundary=batch_' + batchGuid;
        var endpointSets = [];
        var perEndpointData = [];
        var perEndpointRequestMethod = [];
        if (siteSharingSettings.membersCanShare !== undefined ||
            siteSharingSettings.requestAccessEmail !== undefined) {
            endpointSets.push(this._setSiteSharingSettingsUrl);
            perEndpointRequestMethod.push('MERGE');
            perEndpointData.push(JSON.stringify({
                __metadata: { type: 'SP.Web' },
                MembersCanShare: siteSharingSettings.membersCanShare,
                RequestAccessEmail: siteSharingSettings.requestAccessEmail
            }));
        }
        if (siteSharingSettings.useAccessRequestDefault !== undefined) {
            endpointSets.push(this._setUseAccessRequestDefaultUrl);
            perEndpointRequestMethod.push('POST');
            perEndpointData.push(JSON.stringify({
                useAccessRequestDefault: siteSharingSettings.useAccessRequestDefault
            }));
        }
        if (siteSharingSettings.accessRequestSiteDescription !== undefined) {
            endpointSets.push(this._setUseAccessRequestDescriptiontUrl);
            perEndpointRequestMethod.push('POST');
            perEndpointData.push(JSON.stringify({
                description: siteSharingSettings.accessRequestSiteDescription
            }));
        }
        if (siteSharingSettings.membersGroup && siteSharingSettings.defaultMembersGroupAddMembers !== undefined) {
            endpointSets.push(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_6__["format"](this._setGroupAllowMembersEditMembershipUrl, siteSharingSettings.membersGroup.id));
            perEndpointRequestMethod.push('MERGE');
            perEndpointData.push(JSON.stringify({
                __metadata: { type: 'SP.Group' },
                AllowMembersEditMembership: siteSharingSettings.defaultMembersGroupAddMembers
            }));
        }
        if (endpointSets.length == 0) {
            return;
        }
        var batchRequestPromise = this.getData(function () {
            return _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["DataBatchOperationHelper"].getBatchOperationUrl(_this._pageContext.webAbsoluteUrl);
        } /*getUrl*/, function (responseText) {
            return responseText;
        } /*parseResponse*/, qosName, function () {
            return _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["DataBatchOperationHelper"].getBatchContentExtended(batchGuid, endpointSets, 'POST', _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["DataBatchOperationHelper"].defaultBatchRequestPostData, perEndpointData, _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["DataBatchOperationHelper"].defaultBatchAcceptData, perEndpointRequestMethod);
        } /*getAddtionalPostData*/, 'POST' /*method*/, 
        /* additionalHeaders*/ null, contentType, undefined, undefined, undefined);
        var onExecute = function (complete, error) {
            batchRequestPromise.then(function (responseFromServer) {
                var batchResponseResult = _base_DataBatchOperationHelper__WEBPACK_IMPORTED_MODULE_4__["DataBatchOperationHelper"].processBatchResponse(responseFromServer);
                if (batchResponseResult.hasError) {
                    error(batchResponseResult);
                }
                else {
                    complete(batchResponseResult);
                }
            }, function (errorFromServer) {
                error(errorFromServer);
            });
        };
        return new _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_3__["default"](onExecute).then(function (result) { }, function (error) {
            return _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_3__["default"].reject(error);
        });
    };
    /**
     * @inheritdoc
     */
    SharingSiteDataSource.prototype.shareSite = function (people, context) {
        var _this = this;
        return this.getData(
        /* getUrl */ function () { return _this._shareUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var data = response.d;
            var results = [];
            if (data.UniquelyPermissionedUsers && data.UniquelyPermissionedUsers.results) {
                results = data.UniquelyPermissionedUsers.results;
            }
            var invitedUsers = [];
            if (data.InvitedUsers && data.InvitedUsers.results) {
                invitedUsers = data.InvitedUsers.results;
            }
            var shareResult = {};
            shareResult.statusCode = data.StatusCode;
            shareResult.errorMessage = data.ErrorMessage;
            shareResult.people = SharingSiteDataSource._parsePeople(results, context.siteUrl);
            shareResult.invitedUsers = SharingSiteDataSource._parsePeople(invitedUsers, context.siteUrl);
            return shareResult;
        }, 
        /* qosName */ 'ShareSite', 
        /* getAdditionalPostData */ function () {
            var peoplePickerSchema = [];
            for (var i = 0; i < people.length; i++) {
                var p = people[i];
                peoplePickerSchema.push(p.rawPersonData);
            }
            // Convert SharingRole value to value understood by the share API.
            if (context.roleValue === 2 /* Edit */.toString()) {
                context.roleValue = EDIT_ROLE;
            }
            else if (context.roleValue === 1 /* View */.toString()) {
                context.roleValue = VIEW_ROLE;
            }
            else if (context.roleValue === 0 /* Owner */.toString()) {
                context.roleValue = FULL_CONTROL_ROLE;
            }
            var strBody = {
                url: context.siteUrl,
                peoplePickerInput: JSON.stringify(peoplePickerSchema),
                roleValue: context.roleValue,
                groupId: context.groupId,
                sendEmail: context.sendEmail,
                emailBody: context.message,
                emailSubject: context.subject,
                includeAnonymousLinkInEmail: !context.requireSignIn,
                propagateAcl: context.propagateSharing,
                useSimplifiedRoles: true
            };
            return JSON.stringify(strBody);
        });
    };
    /**
     * Get the raw response from SP.Web.GetObjectSharingSettings api, with ObjectSharingInformation and SharePointSettings/PickerProperties expanded.
     * @returns {Promise} A promise for raw response from SP.Web.GetObjectSharingSettings api
     */
    SharingSiteDataSource.prototype._getSharingSettingsRawResponse = function () {
        var _this = this;
        var qosName = 'SP.Web.GetObjectSharingSettings';
        var strBody = {};
        // SP.Web.GetObjectSharingSettings objectUrl and needs set useSimplifiedRoles to true.
        strBody['useSimplifiedRoles'] = true;
        strBody['objectUrl'] = this._pageContext.webAbsoluteUrl;
        return this.getData(
        /* getUrl */ function () { return _this._getSharingSettingsUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            return response.d;
        }, 
        /* qosName */ qosName, 
        /* getAdditionalPostData */ function () {
            return JSON.stringify(strBody);
        }, 
        /* method */ 'POST', 
        /* addtionHeaders */ null, 
        /* contentType */ null, 
        /* maxRetries */ null, 
        /* noRedirect */ true);
    };
    SharingSiteDataSource._parsePeople = function (results, siteUrl) {
        return results.map(function (result) {
            var sharingInfo = {
                siteUrl: siteUrl,
                role: SharingSiteDataSource._parseSharingRole(result.CurrentRole),
                statusCode: Number(!result.Status),
                errorMessage: result.Message || null
            };
            return {
                name: result.DisplayName,
                email: result.Email,
                userId: result.UserId,
                sharingInfo: sharingInfo
            };
        });
    };
    SharingSiteDataSource._parseSharingRole = function (role) {
        switch (role) {
            case 0:
                return 5 /* None */;
            case 1:
                return 1 /* View */;
            case 2:
                return 2 /* Edit */;
            default:
                return 1 /* View */;
        }
    };
    SharingSiteDataSource.prototype._parseError = function (error) {
        var sharingSettings = {};
        sharingSettings.sharingApiErrorMessage = error.message.value;
        return sharingSettings;
    };
    SharingSiteDataSource.prototype._parseSettings = function (data) {
        var sharingSettings = {};
        sharingSettings.canSendEmail = data.canSendEmail;
        sharingSettings.pickerProperties = {};
        sharingSettings.itemUrl = data.itemUrl;
        sharingSettings.mailSettings = {
            defaultCharacterLimit: BDM_EMAIL_CHAR_LIMIT
        };
        sharingSettings.itemId = data.ItemId;
        sharingSettings.itemName = data.ItemName;
        sharingSettings.canManagePermissions = data.ObjectSharingInformation.CanManagePermissions;
        sharingSettings.canSendEmail = data.CanSendEmail;
        sharingSettings.pickerProperties = {};
        sharingSettings.supportsSharingPropagation = data.SupportsAclPropagation;
        sharingSettings.showAdditionalExternalWarning = data.ShowExternalSharingWarning;
        sharingSettings.sharedWithMany =
            data.ObjectSharingInformation.IsSharedWithSecurityGroup ||
                data.ObjectSharingInformation.IsSharedWithMany;
        sharingSettings.blockPeoplePickerAndSharing = data.BlockPeoplePickerAndSharing;
        sharingSettings.canCurrentUserShareExternally = data.CanCurrentUserShareExternally;
        // Parse picker properties
        if (data.SharePointSettings && data.SharePointSettings.PickerProperties) {
            this._setPickerProperties(data.SharePointSettings.PickerProperties, data.SharePointSettings.PickerProperties.PrincipalAccountType, sharingSettings);
        }
        // Parse simplified sharing roles
        var sharingRoleData = [];
        if (data.SimplifiedRoles && data.SimplifiedRoles.results) {
            for (var i = 0; i < data.SimplifiedRoles.results.length; i++) {
                var roleData = {};
                roleData.name = data.SimplifiedRoles.results[i].Key;
                roleData.value = data.SimplifiedRoles.results[i].Value;
                sharingRoleData.push(roleData);
            }
        }
        sharingSettings.sharingRoles = sharingRoleData;
        sharingSettings.showAdvanced = sharingSettings.canManagePermissions;
        return sharingSettings;
    };
    SharingSiteDataSource.prototype.parseSPGroup = function (o) {
        return {
            id: o.Id,
            loginName: o.LoginName,
            principalType: o.PrincipalType,
            title: o.Title,
            allowMembersEditMembership: o.AllowMembersEditMembership,
            description: o.Description
        };
    };
    SharingSiteDataSource.prototype._setPickerProperties = function (pickerProperties, principalAccountType, sharingSettings) {
        sharingSettings.pickerProperties = pickerProperties;
        sharingSettings.pickerProperties.PrincipalAccountType = this._convertPrincipalType(principalAccountType);
    };
    // Convert comma-separated account selection text to SPPrincipalType
    SharingSiteDataSource.prototype._convertPrincipalType = function (principalTypes) {
        if (!principalTypes) {
            return 0; /*SP.Utilities.PrincipalType.none*/
        }
        var result = 0;
        var types = principalTypes.split(',');
        /* tslint:disable: no-bitwise */
        for (var _i = 0, types_1 = types; _i < types_1.length; _i++) {
            var t = types_1[_i];
            if (t === 'User') {
                result |= 1; /*SP.Utilities.PrincipalType.user*/
            }
            else if (t === 'DL') {
                result |= 2; /*SP.Utilities.PrincipalType.distributionList*/
            }
            else if (t === 'SecGroup') {
                result |= 4; /*SP.Utilities.PrincipalType.securityGroup*/
            }
            else if (t === 'SPGroup') {
                result |= 8; /*SP.Utilities.PrincipalType.sharePointGroup*/
            }
        }
        return result;
    };
    return SharingSiteDataSource;
}(_dataSources_base_DataSource__WEBPACK_IMPORTED_MODULE_1__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (SharingSiteDataSource);
//# sourceMappingURL=SharingSiteDataSource.js.map

/***/ }),

/***/ "uEVh":
/*!**************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/SitePermissionsPanel.js ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: SitePermissionsPanel, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_SitePermissionsPanel_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/SitePermissionsPanel/index */ "3+om");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SitePermissionsPanel", function() { return _components_SitePermissionsPanel_index__WEBPACK_IMPORTED_MODULE_0__["SitePermissionsPanel"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _components_SitePermissionsPanel_index__WEBPACK_IMPORTED_MODULE_0__["SitePermissionsPanel"]; });



//# sourceMappingURL=SitePermissionsPanel.js.map

/***/ }),

/***/ "vxX2":
/*!***********************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/version.js ***!
  \***********************************************************************************************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _uifabric_set_version__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/set-version */ "Eyzw");
// Do not modify this file; it is generated as part of publish.
// The checked in version is a placeholder only and will not be updated.

Object(_uifabric_set_version__WEBPACK_IMPORTED_MODULE_0__["setVersion"])('@uifabric/icons', '7.5.17');
//# sourceMappingURL=version.js.map

/***/ }),

/***/ "wIBa":
/*!***********************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/utilities/path/Path.js ***!
  \***********************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFolderNameFromPath", function() { return getFolderNameFromPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSharePointPath", function() { return getSharePointPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "canonicalizeUrl", function() { return canonicalizeUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "canonicalizeDecodedUrl", function() { return canonicalizeDecodedUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDecodedUrl", function() { return getDecodedUrl; });
/* harmony import */ var _ms_odsp_utilities_lib_path_Path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-utilities/lib/path/Path */ "G4wV");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _ms_odsp_utilities_lib_path_Path__WEBPACK_IMPORTED_MODULE_0__) if(["default","getFolderNameFromPath","getSharePointPath","canonicalizeUrl","canonicalizeDecodedUrl","getDecodedUrl"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _ms_odsp_utilities_lib_path_Path__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
// OneDrive:IgnoreCodeCoverage


function getFolderNameFromPath(itemUrl) {
    var index = itemUrl.lastIndexOf('/');
    return index >= 0 ? itemUrl.substring(index + 1) : itemUrl;
}
function getSharePointPath(encodedUrl) {
    return decodeURI(encodedUrl);
}
function canonicalizeUrl(url) {
    var decodedUrl;
    try {
        decodedUrl = decodeURI(url);
    }
    catch (e) {
        decodedUrl = url;
    }
    if (decodedUrl === url) {
        // the url is decoded, it's not real supported url format, make sure it's encoded properly before sending to URI class which
        // only supports encoded url as input.
        url = Object(_ms_odsp_utilities_lib_path_Path__WEBPACK_IMPORTED_MODULE_0__["encodePath"])(url, true);
    }
    else {
        // encodeURI API doesn't encode # path. Here for openUrl we know # is path, not Hash, so encode it properly "manually".
        url = url.replace('#', '%23');
    }
    return url;
}
function canonicalizeDecodedUrl(url) {
    if (url && url.indexOf('?') < 0) {
        url = encodeURI(url);
        // encodeURI API doesn't encode # path. Here for openUrl we know # is path, not Hash, so encode it properly "manually".
        url = url.replace(/#/g, '%23');
    }
    return url;
}
function getDecodedUrl(url) {
    var segments = url.split('/');
    if (segments.length > 3) {
        for (var i = 3; i < segments.length; i++) {
            segments[i] = decodeURIComponent(segments[i]);
        }
        return segments.join('/');
    }
    return url;
}
//# sourceMappingURL=Path.js.map

/***/ }),

/***/ "wN6/":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingInfoType.js ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: SharingInfoType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingInfoType", function() { return SharingInfoType; });
// OneDrive:IgnoreCodeCoverage
var SharingInfoType;
(function (SharingInfoType) {
    SharingInfoType[SharingInfoType["Email"] = 0] = "Email";
    SharingInfoType[SharingInfoType["User"] = 1] = "User";
    SharingInfoType[SharingInfoType["Group"] = 2] = "Group";
    SharingInfoType[SharingInfoType["Link"] = 3] = "Link";
    SharingInfoType[SharingInfoType["Public"] = 4] = "Public";
    SharingInfoType[SharingInfoType["Friends"] = 5] = "Friends";
    SharingInfoType[SharingInfoType["Facebook"] = 6] = "Facebook";
    SharingInfoType[SharingInfoType["Application"] = 7] = "Application";
    SharingInfoType[SharingInfoType["GroupOwned"] = 99] = "GroupOwned";
})(SharingInfoType || (SharingInfoType = {}));
//# sourceMappingURL=SharingInfoType.js.map

/***/ }),

/***/ "wWxM":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/PeoplePicker/PeoplePicker.Props.js ***!
  \************************************************************************************************************************************************************************************************************/
/*! exports provided: PeoplePickerType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ms_shared_react_people_picker_lib_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/shared-react-people-picker/lib/PeoplePicker.Props */ "7mE5");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PeoplePickerType", function() { return _ms_shared_react_people_picker_lib_PeoplePicker_Props__WEBPACK_IMPORTED_MODULE_0__["PeoplePickerType"]; });


//# sourceMappingURL=PeoplePicker.Props.js.map

/***/ }),

/***/ "wXdL":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/office-ui-fabric-react@7.156.0_baa7aab8a1d5d20fe3858de8537800ba/node_modules/office-ui-fabric-react/lib/components/Button/SplitButton/SplitButton.classNames.js ***!
  \***********************************************************************************************************************************************************************************************************************/
/*! exports provided: getSplitButtonClassNames */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSplitButtonClassNames", function() { return getSplitButtonClassNames; });
/* harmony import */ var _Utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../Utilities */ "mkpW");
/* harmony import */ var _Styling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../Styling */ "PL71");


var getSplitButtonClassNames = Object(_Utilities__WEBPACK_IMPORTED_MODULE_0__["memoizeFunction"])(function (styles, disabled, expanded, checked, primaryDisabled) {
    return {
        root: Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["mergeStyles"])(styles.splitButtonMenuButton, expanded && [styles.splitButtonMenuButtonExpanded], disabled && [styles.splitButtonMenuButtonDisabled], checked && !disabled && [styles.splitButtonMenuButtonChecked]),
        splitButtonContainer: Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["mergeStyles"])(styles.splitButtonContainer, !disabled &&
            checked && [
            styles.splitButtonContainerChecked,
            {
                selectors: {
                    ':hover': styles.splitButtonContainerCheckedHovered,
                },
            },
        ], !disabled &&
            !checked && [
            {
                selectors: {
                    ':hover': styles.splitButtonContainerHovered,
                    ':focus': styles.splitButtonContainerFocused,
                },
            },
        ], disabled && styles.splitButtonContainerDisabled),
        icon: Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["mergeStyles"])(styles.splitButtonMenuIcon, disabled && styles.splitButtonMenuIconDisabled, !disabled && primaryDisabled && styles.splitButtonMenuIcon),
        flexContainer: Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["mergeStyles"])(styles.splitButtonFlexContainer),
        divider: Object(_Styling__WEBPACK_IMPORTED_MODULE_1__["mergeStyles"])(styles.splitButtonDivider, (primaryDisabled || disabled) && styles.splitButtonDividerDisabled),
    };
});
//# sourceMappingURL=SplitButton.classNames.js.map

/***/ }),

/***/ "wZUW":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/sharing/SharingDataSource.js ***!
  \*****************************************************************************************************************************************************************************************************/
/*! exports provided: EDIT_ROLE, VIEW_ROLE, OWNER_ROLE, HasInheritedLinksUI, SharingDataSource, parseSharingLinkInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EDIT_ROLE", function() { return EDIT_ROLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VIEW_ROLE", function() { return VIEW_ROLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OWNER_ROLE", function() { return OWNER_ROLE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HasInheritedLinksUI", function() { return HasInheritedLinksUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingDataSource", function() { return SharingDataSource; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseSharingLinkInfo", function() { return parseSharingLinkInfo; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ms_odsp_utilities_lib_dateTime_DateTime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/dateTime/DateTime */ "ZqbN");
/* harmony import */ var _utilities_url_ItemUrlHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utilities/url/ItemUrlHelper */ "+1yd");
/* harmony import */ var _utilities_url_ApiUrlHelper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../utilities/url/ApiUrlHelper */ "sVQZ");
/* harmony import */ var _base_DataSource__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base/DataSource */ "AfY0");
/* harmony import */ var _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../interfaces/sharing/SharingInterfaces */ "dR+P");
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_utilities_lib_icons_ItemType__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ms/odsp-utilities/lib/icons/ItemType */ "FAc7");
/* harmony import */ var _SharingDataSourceHelper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SharingDataSourceHelper */ "T9Ft");
/* harmony import */ var _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../web/WebTemplateType */ "xYco");
/* harmony import */ var _ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ms/odsp-utilities/lib/alternativeUrls/SPAlternativeUrls */ "vmDi");
/* harmony import */ var _ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ms/odsp-utilities/lib/features/Features */ "8G1T");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _utilities_common_utilities__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../utilities/common/utilities */ "yruj");














// Role values imported from SPOREL: sts/Vroom/src/Helpers/Permissions/RoleDescriptor.cs
var EDIT_ROLE = 'role:1073741827';
var VIEW_ROLE = 'role:1073741826';
var OWNER_ROLE = 'role:1073741829';
var HasInheritedLinksUI = { ODB: 1657 };
var useTrackableAnyoneLinkKS = !_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_12__["Killswitch"].isActivated('f8f5a253-cc95-4903-8f09-41053f644db1', '10/13/2020', 'Deactivate Trackable Anyone Link, disable anyoneLinkAbility');
var SharingDataSource = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(SharingDataSource, _super);
    function SharingDataSource(params, dependencies) {
        if (dependencies === void 0) { dependencies = {
            pageContext: params.pageContext
        }; }
        var _this = _super.call(this, {
            dataSourceName: 'SharingDataSource'
        }, dependencies) || this;
        _this._getParentListId = params.getParentListId;
        _this._itemUrlHelper = params.itemUrlHelper || new _utilities_url_ItemUrlHelper__WEBPACK_IMPORTED_MODULE_2__["ItemUrlHelper"]({}, { pageContext: params.pageContext });
        _this._apiUrlHelper =
            params.apiUrlHelper ||
                new _utilities_url_ApiUrlHelper__WEBPACK_IMPORTED_MODULE_3__["ApiUrlHelper"]({}, { pageContext: params.pageContext, itemUrlHelper: _this._itemUrlHelper });
        _this._sharingContextInformation = params.sharingContextInformation || undefined;
        _this._sharingDataSourceHelper = new _SharingDataSourceHelper__WEBPACK_IMPORTED_MODULE_8__["default"]({
            itemUrlHelper: _this._itemUrlHelper,
            sharingContextInformation: _this._sharingContextInformation,
            isItemUrlEncoded: params.isItemUrlEncoded
        });
        var webServerRelativeUrl = Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_6__["getSafeWebServerRelativeUrl"])(_this._pageContext);
        _this._shareUrl = webServerRelativeUrl + '/_api/SP.Web.ShareObject';
        return _this;
    }
    SharingDataSource.parsePeople = function (results) {
        return results.map(function (result) {
            var sharingInfo = {
                role: SharingDataSource.parseSharingRole(result.CurrentRole),
                statusCode: Number(!result.Status),
                errorMessage: result.Message || null
            };
            return {
                name: result.DisplayName,
                email: result.Email,
                userId: result.UserId,
                sharingInfo: sharingInfo
            };
        });
    };
    SharingDataSource.parseSharingRole = function (role) {
        switch (role) {
            case 0:
                return 5 /* None */;
            case 1:
                return 1 /* View */;
            case 2:
                return 2 /* Edit */;
            case 6:
                return 6 /* Review */;
            default:
                return 1 /* View */;
        }
    };
    // Add expand link template boolean to the method call. We always want picker settings, expandPermissions and expandLink are independent
    // Once we get the template, we need to parse it, then send the relevant info to password stuff
    SharingDataSource.prototype.getSharingInformation = function (item, expandPermissionsInformation, sharingLinkTemplates, baseUrl, addressBarLinkSettings, authToken) {
        var _this = this;
        baseUrl =
            baseUrl ||
                this._sharingDataSourceHelper.getApiRoot(this._apiUrlHelper, item, this._getParentListId(item));
        var getSharingInformationUrlBuilder = baseUrl.segment('GetSharingInformation');
        /**
         * If we're using the sharing abilitites matrix, we don't need to request
         * "permissionsInformation", which will improve the perf.
         */
        var getSharingInformationUrl;
        var sharingInformationSettings = 'pickerSettings';
        if (expandPermissionsInformation) {
            sharingInformationSettings += ',permissionsInformation';
        }
        if (sharingLinkTemplates) {
            sharingInformationSettings += ',sharingLinkTemplates';
        }
        if (addressBarLinkSettings) {
            sharingInformationSettings += ',addressBarLinkSettings';
        }
        getSharingInformationUrl = getSharingInformationUrlBuilder
            .oDataParameter('$Expand', sharingInformationSettings)
            .toString();
        return this.getData(
        /* getUrl */ function () { return getSharingInformationUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var sharingInformation = _this._parseGetSharingInformationResponse(response, item);
            return sharingInformation;
        }, 
        /* qosName */ 'GetSharingInformation', 
        /* getAdditionalPostData */ null, 
        /* method */ 'POST', 
        /* additionalHeaders */ null, 
        /* contentType */ null, 
        /* maxRetries */ null, 
        /* noRedirect */ true, 
        /* crossSiteCollectionCall */ undefined, 
        /* telemetryHandler */ undefined, 
        /* qosExtraData */ this._getExtraData(), 
        /* authToken */ authToken);
    };
    SharingDataSource.prototype.emailWithoutPermissioning = function (recipients, item, message, subject) {
        var forwardObjectLinkUrl = this._sharingDataSourceHelper
            .getApiRoot(this._apiUrlHelper, item, this._getParentListId(item))
            .segment('ForwardObjectLink')
            .toString();
        return this.getData(
        /* getUrl */ function () { return forwardObjectLinkUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var data = response.d;
            var results = [];
            if (data.UniquelyPermissionedUsers && data.UniquelyPermissionedUsers.results) {
                results = data.UniquelyPermissionedUsers.results;
            }
            var invitedUsers = [];
            if (data.InvitedUsers && data.InvitedUsers.results) {
                invitedUsers = data.InvitedUsers.results;
            }
            var shareResult = {};
            shareResult.statusCode = data.StatusCode;
            shareResult.errorMessage = data.ErrorMessage;
            shareResult.people = SharingDataSource.parsePeople(results);
            shareResult.invitedUsers = SharingDataSource.parsePeople(invitedUsers);
            shareResult.itemId = item && item.id;
            // If there are any invitees, grab the invitation link.
            if (invitedUsers.length > 0) {
                shareResult.invitationLink = invitedUsers[0].InvitationLink;
            }
            // If there are any users with invalid emails, extract them.
            shareResult.invalidEmails = [];
            if (data.UsersWithInvalidEmails && data.UsersWithInvalidEmails.results) {
                for (var _i = 0, _a = data.UsersWithInvalidEmails.results; _i < _a.length; _i++) {
                    var user = _a[_i];
                    shareResult.invalidEmails.push(user.User);
                }
            }
            return shareResult;
        }, 
        /* qosName */ 'ForwardObjectLink', 
        /* getAdditionalPostData */ function () {
            var peoplePickerSchema = [];
            for (var _i = 0, recipients_1 = recipients; _i < recipients_1.length; _i++) {
                var p = recipients_1[_i];
                peoplePickerSchema.push(p.rawPersonData);
            }
            var body = {
                peoplePickerInput: JSON.stringify(peoplePickerSchema),
                emailBody: message,
                emailSubject: subject
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype.checkPermissions = function (recipients, item) {
        var checkPermissionsUrl = this._sharingDataSourceHelper
            .getApiRoot(this._apiUrlHelper, item, this._getParentListId(item))
            .segment('CheckPermissions')
            .toString();
        return this.getData(
        /* getUrl */ function () { return checkPermissionsUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            if (response.d) {
                var data = response.d.CheckPermissions;
                return data.results;
            }
            else {
                return null;
            }
        }, 
        /* qosName */ 'CheckPermissions', 
        /* getAdditionalPostData */ function () {
            var body = {
                recipients: recipients
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype.share = function (people, context) {
        var _this = this;
        var canUseSecurable = !!this._sharingContextInformation || this._sharingDataSourceHelper.canUseSecurable(context.items[0]);
        if (context.linkType === 9 /* Organization */ ||
            context.linkType === 6 /* Edit */ ||
            context.linkType === 5 /* View */) {
            return this._shareLink(people, context);
        }
        else {
            /**
             * Use new securable sharing API if item has necessary properties to build the
             * API root, otherwise, fall back to the web API.
             */
            var shareUrl_1;
            if (canUseSecurable) {
                var item = context.items[0];
                var shareUrlBuilder = this._sharingDataSourceHelper.getApiRoot(this._apiUrlHelper, item, this._getParentListId(item));
                shareUrl_1 = shareUrlBuilder.segment('ShareObject').toString();
            }
            else {
                shareUrl_1 = this._shareUrl;
            }
            return this.getData(
            /* getUrl */ function () { return shareUrl_1; }, 
            /* parseResponse */ function (responseText) {
                var response = JSON.parse(responseText);
                var data = response.d;
                var results = [];
                if (data.UniquelyPermissionedUsers && data.UniquelyPermissionedUsers.results) {
                    results = data.UniquelyPermissionedUsers.results;
                }
                var invitedUsers = [];
                if (data.InvitedUsers && data.InvitedUsers.results) {
                    invitedUsers = data.InvitedUsers.results;
                }
                var shareResult = {};
                shareResult.statusCode = data.StatusCode;
                shareResult.errorMessage = data.ErrorMessage;
                shareResult.people = SharingDataSource.parsePeople(results);
                shareResult.invitedUsers = SharingDataSource.parsePeople(invitedUsers);
                shareResult.itemId = context.items[0] && context.items[0].id;
                // If there are any invitees, grab the invitation link.
                if (invitedUsers.length > 0) {
                    shareResult.invitationLink = invitedUsers[0].InvitationLink;
                }
                // If there are any users with invalid emails, extract them.
                shareResult.invalidEmails = [];
                if (data.UsersWithInvalidEmails && data.UsersWithInvalidEmails.results) {
                    for (var _i = 0, _a = data.UsersWithInvalidEmails.results; _i < _a.length; _i++) {
                        var user = _a[_i];
                        shareResult.invalidEmails.push(user.User);
                    }
                }
                return shareResult;
            }, 
            /* qosName */ 'Share', 
            /* getAdditionalPostData */ function () {
                var peoplePickerSchema = [];
                for (var i = 0; i < people.length; i++) {
                    var p = people[i];
                    peoplePickerSchema.push(p.rawPersonData);
                }
                // Convert SharingRole value to value understood by the share API.
                if (context.roleValue === 2 /* Edit */.toString()) {
                    context.roleValue = EDIT_ROLE;
                }
                else if (context.roleValue === 1 /* View */.toString()) {
                    context.roleValue = VIEW_ROLE;
                }
                var strBody = {
                    peoplePickerInput: JSON.stringify(peoplePickerSchema),
                    roleValue: context.roleValue,
                    sendEmail: context.sendEmail,
                    emailBody: context.message,
                    emailSubject: context.subject,
                    includeAnonymousLinkInEmail: !context.requireSignIn,
                    propagateAcl: context.propagateSharing,
                    useSimplifiedRoles: true
                };
                // If using old sharing APIs, add url parameter to payload.
                if (!canUseSecurable) {
                    strBody['url'] = _this._sharingDataSourceHelper.getFileUrl(context.items[0]);
                }
                return JSON.stringify(strBody);
            });
        }
    };
    SharingDataSource.prototype.updatePermissions2 = function (person, item, role) {
        var updatePermissionsUrlBuilder = this._sharingDataSourceHelper.getApiRoot(this._apiUrlHelper, item, this._getParentListId(item));
        var updatePermissionsUrl = updatePermissionsUrlBuilder.segment('UpdateDocumentSharingInfo').toString();
        return this.getData(
        /* getUrl */ function () { return updatePermissionsUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var data = response.d;
            if (!data) {
                return null;
            }
            var updatePermissionsResponse = {
                role: data.UpdateDocumentSharingInfo.results[0].CurrentRole
            };
            return updatePermissionsResponse;
        }, 
        /* qosName */ 'UpdatePermissions2', 
        /* getAdditionalPostData */ function () {
            var newRole;
            switch (role) {
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].none:
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].view:
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].review:
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].edit:
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].owner:
                    newRole = role;
                    break;
                default:
                    newRole = _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].view;
                    break;
            }
            var userRoles = [
                {
                    UserId: person.loginName,
                    Role: newRole
                }
            ];
            var body = {
                userRoleAssignments: userRoles,
                validateExistingPermissions: false,
                additiveMode: false,
                sendServerManagedNotification: false,
                customMessage: null,
                includeAnonymousLinksInNotification: false,
                propagateAcl: true
            };
            return JSON.stringify(body);
        });
    };
    // Update permissions for many people
    SharingDataSource.prototype.updatePermissionsMultiple = function (people, item, role, notify, message) {
        var updatePermissionsUrlBuilder = this._sharingDataSourceHelper.getApiRoot(this._apiUrlHelper, item, this._getParentListId(item));
        var updatePermissionsUrl = updatePermissionsUrlBuilder.segment('UpdateDocumentSharingInfo').toString();
        return this.getData(
        /* getUrl */ function () { return updatePermissionsUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var data = response.d;
            if (!data) {
                return null;
            }
            var updatePermissionsResponse = {
                role: data.UpdateDocumentSharingInfo.results[0].CurrentRole,
                success: data.UpdateDocumentSharingInfo.results.map(function (x) { return x.Status; }).reduce(function (x, y) { return x && y; }, true) // Check that status is true for all the returned results
            };
            return updatePermissionsResponse;
        }, 
        /* qosName */ 'UpdatePermissionsMultiple', 
        /* getAdditionalPostData */ function () {
            var newRole;
            switch (role) {
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].none:
                    newRole = 0; /* stop sharing */
                    break;
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].view:
                    newRole = 1;
                    break;
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].review:
                    newRole = 6;
                    break;
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].edit:
                    newRole = 2;
                    break;
                default:
                    newRole = 1;
                    break;
            }
            var userRoles = people.map(function (person) {
                return { UserId: person.userId, Role: newRole };
            });
            var body = {
                userRoleAssignments: userRoles,
                validateExistingPermissions: false,
                additiveMode: false,
                sendServerManagedNotification: notify,
                customMessage: message,
                includeAnonymousLinksInNotification: false,
                propagateAcl: true
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype.parseRawSharingInformation = function (rawSharingInformation) {
        return this._parseGetSharingInformationResponse(rawSharingInformation, undefined);
    };
    SharingDataSource.prototype.unshareLink = function (context) {
        var deleteLinkUrl = this._sharingDataSourceHelper
            .getApiRoot(this._apiUrlHelper, context.item, this._getParentListId(context.item))
            .segment('UnshareLink')
            .toString();
        return this.getData(
        /* getUrl */ function () { return deleteLinkUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var unshareLinkResponse = !!response.d;
            // If unshareLinkResponse is true, unshare was successful.
            return unshareLinkResponse;
        }, 
        /* qosName */ 'UnshareLink', 
        /* getAdditionalPostData */ function () {
            var body = {
                linkKind: context.kind,
                shareId: context.shareId
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype.shareLink = function (context) {
        var shareLinkSettings = context.settings;
        var item = context.items[0];
        var shareLinkUrl = this._sharingDataSourceHelper
            .getApiRoot(this._apiUrlHelper, context.items[0], this._getParentListId(item))
            .segment('ShareLink')
            .toString();
        return this.getData(
        /* getUrl */ function () { return shareLinkUrl; }, 
        /* parseResponse */ function (responseText) {
            var fullResponse = JSON.parse(responseText);
            if (fullResponse.d) {
                return parseSharingLinkInfo(fullResponse);
            }
            else if (fullResponse.error) {
                return {
                    error: 5 /* generic */,
                    errorMessage: fullResponse.error.message
                };
            }
        }, 
        /* qosName */ 'ShareLink', 
        /* getAdditionalPostData */ function () {
            // Get expiration value.
            var expirationString = null;
            if (shareLinkSettings.expiration) {
                expirationString = Object(_ms_odsp_utilities_lib_dateTime_DateTime__WEBPACK_IMPORTED_MODULE_1__["convertDateToISOString"])(shareLinkSettings.expiration.toString());
            }
            // Get peoplePickerInput value.
            var peoplePickerInput = null;
            if (context.recipients && context.recipients.length > 0) {
                peoplePickerInput = [];
                for (var _i = 0, _a = context.recipients; _i < _a.length; _i++) {
                    var recipient = _a[_i];
                    if (recipient.rawPersonData) {
                        peoplePickerInput.push(recipient.rawPersonData);
                    }
                }
            }
            var inviteesToRemove = null;
            if (shareLinkSettings.inviteesToRemove && shareLinkSettings.inviteesToRemove.length > 0) {
                inviteesToRemove = [];
                for (var _b = 0, _c = shareLinkSettings.inviteesToRemove; _b < _c.length; _b++) {
                    var inviteeToRemove = _c[_b];
                    inviteesToRemove.push({
                        id: inviteeToRemove.id,
                        loginName: inviteeToRemove.loginName,
                        name: inviteeToRemove.primaryText,
                        isExternal: inviteeToRemove.isExternal,
                        principalType: inviteeToRemove.type,
                        email: inviteeToRemove.email
                    });
                }
            }
            var body = {
                request: {
                    createLink: !!shareLinkSettings.createLink,
                    settings: {
                        allowAnonymousAccess: shareLinkSettings.allowAnonymousAccess,
                        trackLinkUsers: shareLinkSettings.trackLinkUsers,
                        linkKind: shareLinkSettings.sharingLinkKind,
                        expiration: expirationString,
                        role: shareLinkSettings.role,
                        restrictShareMembership: shareLinkSettings.restrictShareMembership,
                        updatePassword: shareLinkSettings.updatePassword,
                        password: shareLinkSettings.password,
                        shareId: shareLinkSettings.shareId,
                        description: shareLinkSettings.description,
                        scope: shareLinkSettings.scope
                    }
                }
            };
            if (inviteesToRemove) {
                body.request.settings['inviteesToRemove'] = { results: inviteesToRemove };
            }
            // Include email notification fields if they're present, otherwise omit them
            // from the request.
            if (peoplePickerInput && peoplePickerInput.length > 0) {
                body.request['peoplePickerInput'] = JSON.stringify(peoplePickerInput);
                // A blank message is OK, but if value is null, don't append to request.
                var emailMessage = context.emailData;
                var emailSubject = context.emailSubject;
                if (emailMessage !== undefined && emailSubject === undefined) {
                    body.request['emailData'] = {
                        body: context.emailData,
                        subject: ''
                    };
                }
                if (emailMessage === undefined && emailSubject !== undefined) {
                    body.request['emailData'] = {
                        body: '',
                        subject: context.emailSubject
                    };
                }
                if (emailMessage !== undefined && emailSubject !== undefined) {
                    body.request['emailData'] = {
                        body: context.emailData,
                        subject: context.emailSubject
                    };
                }
            }
            // Include the share ID if one was provided.
            var shareId = context.settings.shareId;
            if (shareId) {
                body.request.settings['shareId'] = shareId;
                body.request['emailData'] = {
                    body: ''
                };
            }
            return JSON.stringify(body);
        }, 
        /* method */ 'POST', 
        /* additionalHeaders */ null, 
        /* contentType */ null, 
        /* maxRetries */ null, 
        /* noRedirect */ true, 
        /* crossSiteCollectionCall */ undefined, 
        /* telemetryHandler */ undefined, 
        /* qosExtraData */ this._getExtraData()).catch(function (error) {
            var debugMessage = '';
            try {
                debugMessage = JSON.stringify(error);
            }
            catch (e) {
                // do nothing
            }
            return {
                error: 5 /* generic */,
                debugErrorMessage: debugMessage
            };
        });
    };
    SharingDataSource.prototype.setAddressBarLinkCapability = function (listItem, enable) {
        var setAddressBarLinkCapabilityUrl = this._sharingDataSourceHelper
            .getApiRoot(this._apiUrlHelper, listItem, this._getParentListId(listItem))
            .segment('SetAddressBarLinkCapability')
            .toString();
        return this.getData(
        /* getUrl */ function () { return setAddressBarLinkCapabilityUrl; }, 
        /* parseResponse */ function (responseText) {
            var response = JSON.parse(responseText);
            var setAddressBarLinkCapabilityResponse = !!response.d;
            // If setAddressBarLinkCapabilityResponse is true, setting address bar link was successful.
            return setAddressBarLinkCapabilityResponse;
        }, 
        /* qosName */ 'SetAddressBarLinkCapability', 
        /* getAdditionalPostData */ function () {
            var body = {
                enable: enable
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype.shareLinkExpress = function (listId, listItemId, expressOption) {
        var shareLinkExpressUrl = this._apiUrlHelper
            .build()
            .webByUrl({
            webUrl: this._pageContext.webAbsoluteUrl
        })
            .method('Lists', listId)
            .method('GetItemById', listItemId)
            .segment('ShareLinkExpress')
            .toString();
        return this.getData(
        /* getUrl */ function () { return shareLinkExpressUrl; }, 
        /* parseResponse */ function (responseText) {
            var fullResponse = JSON.parse(responseText);
            if (fullResponse.d) {
                return _parseSharingLinkInfo(fullResponse.d.ShareLinkExpress.sharingLinkInfo);
            }
            else if (fullResponse.error) {
                return {
                    error: 5 /* generic */,
                    errorMessage: fullResponse.error.message
                };
            }
        }, 
        /* qosName */ 'ShareLinkExpress', 
        /* getAdditionalPostData */ function () {
            var body = {
                expressOption: expressOption
            };
            return JSON.stringify(body);
        }, 
        /* method */ 'POST', 
        /* additionalHeaders */ null, 
        /* contentType */ null, 
        /* maxRetries */ null, 
        /* noRedirect */ true, 
        /* crossSiteCollectionCall */ undefined, 
        /* telemetryHandler */ undefined, 
        /* qosExtraData */ this._getExtraData()).catch(function (error) {
            var debugMessage = '';
            try {
                debugMessage = JSON.stringify(error);
            }
            catch (e) {
                // do nothing
            }
            return {
                error: 5 /* generic */,
                debugErrorMessage: debugMessage
            };
        });
    };
    SharingDataSource.prototype.getClientId = function () {
        var webTemplate = Number(this._pageContext.webTemplate);
        // Check for comm site by using the feature ID instead of template
        if (Object(_utilities_common_utilities__WEBPACK_IMPORTED_MODULE_13__["isCommSite"])(this._pageContext)) {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["ClientId"].sharePoint;
        }
        switch (webTemplate) {
            case _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__["default"].teamSite:
            case _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__["default"].group:
            case _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__["default"].subgroup:
            case _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__["default"].sitePagePublishing:
                return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["ClientId"].sharePoint;
            case _web_WebTemplateType__WEBPACK_IMPORTED_MODULE_9__["default"].mySite:
                return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["ClientId"].odb;
            default:
                if (!_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_12__["Killswitch"].isActivated('49c1f4de-c1fb-47ed-8d4b-695083cb10ef', '11/08/2019', 'Default clientId to SharePoint if unknown for other web templates')) {
                    return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["ClientId"].sharePoint;
                }
                else {
                    return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["ClientId"].unknown;
                }
        }
    };
    SharingDataSource.prototype._shareLink = function (people, context) {
        var _this = this;
        var item = context.items[0];
        var urlBuilder = this._sharingDataSourceHelper.getApiRoot(this._apiUrlHelper, item, this._getParentListId(item));
        var url = urlBuilder.segment('ShareLink').toString();
        return this.getData(
        /* getUrl */ function () { return url; }, 
        /* parseResponse */ function (responseText) {
            return {
                statusCode: 0,
                errorMessage: '',
                people: people,
                itemId: context.items[0].id
            };
        }, 
        /* qosName */ 'ShareLink', 
        /* getAdditionalPostData */ function () {
            var peoplePickerSchema = [];
            for (var _i = 0, people_1 = people; _i < people_1.length; _i++) {
                var person = people_1[_i];
                peoplePickerSchema.push(person.rawPersonData);
            }
            var expirationString = null;
            if (context.expiration) {
                expirationString = Object(_ms_odsp_utilities_lib_dateTime_DateTime__WEBPACK_IMPORTED_MODULE_1__["convertDateToISOString"])(context.expiration);
            }
            var body = {
                request: {
                    peoplePickerInput: JSON.stringify(peoplePickerSchema),
                    emailData: {
                        body: context.message,
                        subject: context.subject
                    },
                    linkKind: _this._getSharingLinkKind(context.linkType, context.roleValue),
                    createLink: true,
                    expiration: expirationString
                }
            };
            return JSON.stringify(body);
        });
    };
    SharingDataSource.prototype._getSharingLinkKind = function (linkType, roleValue) {
        var linkKind = 1 /* direct */;
        if (linkType === 6 /* Edit */) {
            linkKind = 5 /* anonymousEdit */;
        }
        else if (linkType === 5 /* View */) {
            linkKind = 4 /* anonymousView */;
        }
        else if (linkType === 9 /* Organization */) {
            if (roleValue === 2 /* Edit */.toString()) {
                linkKind = 3 /* organizationEdit */;
            }
            else {
                linkKind = 2 /* organizationView */;
            }
        }
        return linkKind;
    };
    // Functions below here are helpers for share UI v3 data layer.
    SharingDataSource.prototype._parseGetSharingInformationResponse = function (rawGetSharingInformationResponse, item) {
        // Determine if there was an error getting sharing information.
        if (rawGetSharingInformationResponse.error) {
            return {
                error: 5 /* generic */,
                anonymousLinkExpirationRestrictionDays: undefined,
                anyoneLinkTrackUsers: undefined,
                canAddExternalPrincipal: undefined,
                canAddInternalPrincipal: undefined,
                canRequestAccessForGrantAccess: undefined,
                canManagePermissions: undefined,
                defaultSharingLink: undefined,
                defaultShareLinkToExistingAccess: undefined,
                hasInheritedLinks: undefined,
                isShared: undefined,
                item: undefined,
                fileExtension: undefined,
                sharedObjectType: undefined,
                sharingLinks: undefined,
                sharingPrincipals: undefined,
                peoplePickerSettings: undefined,
                userDisplayName: undefined,
                blockPeoplePickerAndSharing: undefined,
                userRole: undefined,
                defaultShareLinkPermission: undefined,
                sharingAbilities: undefined,
                defaultLinkKind: undefined,
                directLink: undefined,
                hasPermissionsInformation: undefined,
                sharingLinkTemplates: undefined,
                webTemplateId: undefined,
                itemUniqueId: undefined
            };
        }
        var response = rawGetSharingInformationResponse.d;
        var hasPermissionsInformation = !!response.permissionsInformation;
        var hasSharingLinkTemplatesInformation = !!response.sharingLinkTemplates;
        var hasInheritedLinkInformation = _ms_odsp_utilities_lib_features_Features__WEBPACK_IMPORTED_MODULE_11__["default"].isFeatureEnabled(HasInheritedLinksUI) && hasPermissionsInformation;
        var hasAddressBarLinkSettings = !!response.addressBarLinkSettings;
        // Get all sharing links.
        var sharingLinks = hasPermissionsInformation
            ? this._parseSharingLinks(response.permissionsInformation.links.results, response.directUrl)
            : [];
        var sharingLinkTemplates = hasSharingLinkTemplatesInformation
            ? this._parseSharingLinkTemplates(response.sharingLinkTemplates.templates.results)
            : [];
        var addressBarLinkSettings = hasAddressBarLinkSettings ? response.addressBarLinkSettings : null;
        // Get sharing principals.
        var sharingPrincipals = [];
        if (_ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_12__["Killswitch"].isActivated('4681ee55-dadc-4d9b-a53c-30012907318a', '5/5/2020', 'Mark site admins amongst sharing principals')) {
            var sharingPrincipalsFromServer = hasPermissionsInformation
                ? response.permissionsInformation.siteAdmins.results.concat(response.permissionsInformation.principals.results)
                : [];
            sharingPrincipals = this._parseSharingPrincipals(sharingPrincipalsFromServer);
        }
        else if (hasPermissionsInformation) {
            var siteAdminsFromServer = response.permissionsInformation.siteAdmins.results;
            var permissionPrincipalsFromServer = response.permissionsInformation.principals.results;
            var siteAdmins = this._parseSharingPrincipals(siteAdminsFromServer);
            siteAdmins.forEach(function (x) { return (x.isSiteAdmin = true); });
            var permissionPrincipals = this._parseSharingPrincipals(permissionPrincipalsFromServer);
            sharingPrincipals = siteAdmins.concat(permissionPrincipals);
        }
        // Get default sharing link (the link that the UI will default to).
        var defaultSharingLink = this._getDefaultSharingLink(response.defaultLinkKind, sharingLinks, response.sharingAbilities);
        // Get item information if we don't have a resolved item.
        var itemInformation = {
            name: this._sharingContextInformation ? this._sharingContextInformation.itemName : undefined,
            childCount: this._sharingContextInformation ? this._sharingContextInformation.itemCount : undefined,
            hasDlpPolicy: this._sharingContextInformation
                ? this._sharingContextInformation.hasDlpPolicy
                : undefined,
            extension: this._sharingContextInformation && this._sharingContextInformation.itemExtension
                ? this._sharingContextInformation.itemExtension
                : response.fileExtension,
            appmap: this._sharingContextInformation ? this._sharingContextInformation.itemAppmap : undefined,
            itemType: this._sharingContextInformation ? this._sharingContextInformation.itemType : undefined
        };
        // Get item information if we have a resolved item.
        if (item) {
            var itemProperties = item.properties;
            var itemChildCount = itemProperties.ItemChildCount ? parseInt(itemProperties.ItemChildCount, 10) : 0;
            var folderChildCount = itemProperties.FolderChildCount
                ? parseInt(itemProperties.FolderChildCount, 10)
                : 0;
            var totalItemCount = item.type === _ms_odsp_utilities_lib_icons_ItemType__WEBPACK_IMPORTED_MODULE_7__["default"].OneNote ? 0 : itemChildCount + folderChildCount;
            var blockSharingPolicyTipFlag = this._isPolicyTipFlagSet(item.policyTip, 4 /* blockSharing */);
            itemInformation = {
                name: item.name,
                childCount: totalItemCount,
                hasDlpPolicy: blockSharingPolicyTipFlag,
                extension: item.extension,
                appmap: item.appMap,
                itemType: item.type
            };
        }
        // Determine if user has ability to manage permissions.
        var canManagePermissions = response.canRequestAccessForGrantAccess || response.canAddInternalPrincipal || sharingLinks.length > 1;
        // On-prem protection. Probably only affects dev boxes right now...
        var anonymousLinkExpirationRestrictionDays = response.anonymousLinkExpirationRestrictionDays === 0
            ? -1
            : response.anonymousLinkExpirationRestrictionDays;
        // Compile all of the parsed information and return.
        var parsedResponse = {
            anonymousLinkExpirationRestrictionDays: anonymousLinkExpirationRestrictionDays,
            anyoneLinkTrackUsers: response.anyoneLinkTrackUsers,
            canAddExternalPrincipal: response.canAddExternalPrincipal,
            canAddInternalPrincipal: response.canAddInternalPrincipal,
            defaultShareLinkToExistingAccess: response.defaultShareLinkToExistingAccess,
            canManagePermissions: canManagePermissions,
            defaultSharingLink: defaultSharingLink,
            fileExtension: response.fileExtension,
            sharedObjectType: response.sharedObjectType,
            hasInheritedLinks: hasInheritedLinkInformation
                ? response.permissionsInformation.hasInheritedLinks
                : false,
            isShared: this._computeIsShared(sharingLinks, sharingPrincipals),
            item: itemInformation,
            sharingLinks: sharingLinks,
            sharingPrincipals: sharingPrincipals,
            peoplePickerSettings: response.pickerSettings,
            userDisplayName: this._pageContext.userDisplayName,
            blockPeoplePickerAndSharing: response.blockPeoplePickerAndSharing,
            requiresAccessApproval: !response.canAddInternalPrincipal && response.canRequestAccessForGrantAccess,
            canRequestAccessForGrantAccess: response.canRequestAccessForGrantAccess,
            userRole: response.currentRole,
            defaultShareLinkPermission: response.defaultShareLinkPermission,
            sharingAbilities: response.sharingAbilities,
            defaultLinkKind: response.defaultLinkKind,
            directLink: {
                allowsAnonymousAccess: false,
                audience: _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].existing,
                expiration: null,
                description: null,
                isActive: true,
                isEdit: true,
                principals: [],
                invitees: [],
                shareId: '',
                sharingLinkKind: 1 /* direct */,
                url: response.directUrl,
                updatePassword: false,
                password: '',
                passwordLastModifiedBy: null
            },
            hasPermissionsInformation: !!response.permissionsInformation,
            sharingLinkTemplates: sharingLinkTemplates,
            addressBarLinkSettings: addressBarLinkSettings,
            webTemplateId: response.webTemplateId,
            itemUniqueId: response.itemUniqueId,
            customizedExternalSharingServiceUrl: response.customizedExternalSharingServiceUrl || '',
            siteIBSegmentIDs: response.siteIBSegmentIDs ? response.siteIBSegmentIDs.results : null,
            enforceIBSegmentFiltering: response.enforceIBSegmentFiltering ? true : false
        };
        return parsedResponse;
    };
    SharingDataSource.prototype._computeIsShared = function (sharingLinks, sharingPrincipals) {
        var isShared = false;
        // See if there are any active sharing links.
        for (var _i = 0, sharingLinks_1 = sharingLinks; _i < sharingLinks_1.length; _i++) {
            var sharingLink = sharingLinks_1[_i];
            if (sharingLink.isActive && sharingLink.sharingLinkKind !== 1 /* direct */) {
                isShared = true;
            }
        }
        // If there are no active links, see if anyone has been ACL'ed to item.
        if (!isShared) {
            isShared = sharingPrincipals.length > 0;
        }
        return isShared;
    };
    SharingDataSource.prototype._parseSharingLinks = function (links, canonicalLink) {
        var _this = this;
        // Remove inherited links.
        links = links.filter(function (link) {
            return !link.isInherited;
        });
        // Convert server response to ISharingLinkV3 interface.
        var sharingLinks = links.map(function (link) {
            var details = link.linkDetails;
            // SharingScope is introduced with trackable anyoneLink feature
            // if Scope is defined and initialized (-1 is uninitialized), we shall use getSharingLinkAudienceByScope
            var audience;
            if (useTrackableAnyoneLinkKS &&
                details.Scope !== undefined &&
                details.Scope !== -1 /* uninitialized */) {
                audience = getSharingLinkAudienceByScope(details.LinkKind, details.Scope);
            }
            else {
                audience = getSharingLinkAudience(details.LinkKind, details.AllowsAnonymousAccess, details.RestrictedShareMembership);
            }
            var sharingLink = {
                allowsAnonymousAccess: details.AllowsAnonymousAccess,
                hasPassword: details.RequiresPassword,
                blockDownload: details.BlocksDownload,
                description: details.Description,
                audience: audience,
                expiration: details.Expiration ? new Date(details.Expiration) : null,
                isActive: details.IsActive,
                isEdit: computeIsEditLink(details.LinkKind) || details.IsEditLink,
                isReview: details.IsReviewLink,
                principals: _this._parseSharingPrincipals(link.linkMembers.results, details.LinkKind),
                invitees: _this._parseLinkInvitees(details),
                shareId: details.ShareId,
                sharingLinkKind: details.LinkKind,
                url: details.Url,
                updatePassword: details.UpdatePassword,
                password: details.Password,
                passwordLastModifiedBy: _this._parseSharingPrincipal(details.PasswordLastModifiedBy),
                isCreateOnlyLink: details.IsCreateOnlyLink,
                isAddressBarLink: details.IsAddressBarLink,
                isUnhealthy: details.IsUnhealthy,
                status: details.SharingLinkStatus,
                created: details.Created,
                trackLinkUsers: details.TrackLinkUsers
            };
            return sharingLink;
        });
        // Sort the links based on ranking (most permissive on the top)
        sharingLinks = sharingLinks.sort(function (a, b) {
            return _this._getLinkRanking(b) - _this._getLinkRanking(a);
        });
        // Add direct link to sharing links collection.
        sharingLinks.push({
            allowsAnonymousAccess: false,
            audience: _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeople,
            expiration: null,
            description: null,
            isActive: true,
            isEdit: true,
            principals: [],
            invitees: [],
            shareId: '',
            sharingLinkKind: 1 /* direct */,
            url: canonicalLink,
            updatePassword: false,
            password: '',
            passwordLastModifiedBy: null
        });
        return sharingLinks;
    };
    SharingDataSource.prototype._getLinkRanking = function (link) {
        var rank = 0;
        switch (link.audience) {
            case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone:
                rank += 30;
                break;
            case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization:
                rank += 20;
                break;
            case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeopleFlex:
                rank += 10;
                break;
        }
        if (link.isEdit) {
            rank += 3;
        }
        else if (link.isReview) {
            rank += 2;
        }
        else if (!link.isEdit && !link.isReview && !link.blockDownload) {
            rank += 1;
        }
        return rank;
    };
    SharingDataSource.prototype._getSharingLinkTemplateRanking = function (linkTemplate) {
        var rank = 0;
        if (!!linkTemplate && !!linkTemplate.linkDetails && !!linkTemplate.linkDetails.shareId) {
            switch (linkTemplate.scope) {
                case 0 /* anyone */:
                    rank += 30;
                    break;
                case 1 /* organization */:
                    rank += 20;
                    break;
                case 2 /* specificPeople */:
                    rank += 10;
                    break;
            }
            switch (linkTemplate.role) {
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].edit:
                    rank += 3;
                    break;
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].review:
                    rank += 2;
                    break;
                case _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingRoleV3"].view:
                    rank += 1;
                    break;
            }
        }
        return rank;
    };
    /**
     * Parses link templates and returns as a list
     * @param links
     * @param canonicalLink
     */
    SharingDataSource.prototype._parseSharingLinkTemplates = function (links) {
        var _this = this;
        // Convert server response to ISharingLinkV3 interface.
        var sharingLinkTemplates = links.map(function (link) {
            var details = link.linkDetails;
            var parsedLinkDetails;
            if (details !== null) {
                // SharingScope is introduced with trackable anyoneLink feature
                // if Scope is defined and initialized (-1 is uninitialized), we shall use getSharingLinkAudienceByScope
                var audience = void 0;
                if (useTrackableAnyoneLinkKS &&
                    details.Scope !== undefined &&
                    details.Scope !== -1 /* uninitialized */) {
                    audience = getSharingLinkAudienceByScope(details.LinkKind, details.Scope);
                }
                else {
                    audience = getSharingLinkAudience(details.LinkKind, details.AllowsAnonymousAccess, details.RestrictedShareMembership);
                }
                parsedLinkDetails = {
                    allowsAnonymousAccess: details.AllowsAnonymousAccess,
                    hasPassword: details.RequiresPassword,
                    blockDownload: details.BlocksDownload,
                    audience: audience,
                    expiration: details.Expiration ? new Date(details.Expiration) : null,
                    description: details.Description,
                    isActive: details.IsActive,
                    isEdit: computeIsEditLink(details.LinkKind) || details.IsEditLink,
                    isReview: details.IsReviewLink,
                    principals: undefined,
                    invitees: _this._parseLinkInvitees(details),
                    shareId: details.ShareId,
                    sharingLinkKind: details.LinkKind,
                    url: details.Url,
                    updatePassword: details.UpdatePassword,
                    password: details.Password,
                    passwordLastModifiedBy: _this._parseSharingPrincipal(details.PasswordLastModifiedBy)
                };
            }
            var sharingLinkTemplate = {
                linkDetails: parsedLinkDetails,
                passwordProtected: link.passwordProtected,
                role: link.role,
                scope: link.scope,
                shareKind: link.shareKind
            };
            return sharingLinkTemplate;
        });
        // Sort the links based on ranking (most permissive on the top, if link details are present)
        sharingLinkTemplates = sharingLinkTemplates.sort(function (a, b) {
            return _this._getSharingLinkTemplateRanking(b) - _this._getSharingLinkTemplateRanking(a);
        });
        return sharingLinkTemplates;
    };
    SharingDataSource.prototype._parseLinkInvitees = function (serverLinkDetails) {
        var invitations = serverLinkDetails.Invitations;
        // If there aren't any invitations on the link, return an empty array.
        if (!invitations) {
            return [];
        }
        var invitees = [];
        for (var _i = 0, _a = invitations.results; _i < _a.length; _i++) {
            var invitation = _a[_i];
            if (invitation && invitation.invitee) {
                invitees.push(invitation.invitee);
            }
        }
        return invitees.map(function (invitee) {
            return {
                id: invitee.id,
                email: invitee.email,
                primaryText: invitee.name,
                isExternal: invitee.isExternal,
                loginName: invitee.loginName,
                role: null,
                secondaryText: invitee.jobTitle,
                type: invitee.principalType,
                imageUrl: Object(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10__["getUserPhotoUrl"])(invitations.email)
            };
        });
    };
    SharingDataSource.prototype._parseSharingPrincipals = function (principals, sharingLinkKind) {
        // Convert server response to ISharingPrincipal interface.
        var sharingPrincipals = principals.map(function (principal) {
            // Principals on linkMembers different from principals at root level.
            var principalInfo = principal.principal;
            if (!principalInfo) {
                principalInfo = principal;
            }
            var sharingPrincipal = {
                id: principalInfo.id,
                isExternal: principalInfo.isExternal,
                loginName: principalInfo.loginName,
                primaryText: principalInfo.name,
                role: principal.role,
                secondaryText: principalInfo.jobTitle,
                type: principalInfo.principalType,
                imageUrl: Object(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10__["getUserPhotoUrl"])(principalInfo.email),
                email: principalInfo.email
            };
            // If parsing principals from link members of a sharing link, add the sharing link
            // type from which they have access to the principal.
            if (sharingLinkKind) {
                sharingPrincipal.sharingLinkKind = sharingLinkKind;
            }
            return sharingPrincipal;
        });
        // make sure that the loginName is unique
        return _SharingDataSourceHelper__WEBPACK_IMPORTED_MODULE_8__["default"].getUniqueSharingPrincipals(sharingPrincipals);
    };
    SharingDataSource.prototype._getExtraData = function () {
        var extraData;
        if (this._sharingContextInformation) {
            extraData = {
                clientId: this._sharingContextInformation.clientId,
                mode: _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["Mode"][this._sharingContextInformation.mode]
            };
        }
        return extraData;
    };
    /**
     * Parses a ISharingPrincipalFromAPI object and returns ISharingPrincipal.
     * @param principal the principal returned from the API.
     */
    SharingDataSource.prototype._parseSharingPrincipal = function (principal) {
        if (principal) {
            var principalInfo = principal.principal;
            if (!principalInfo) {
                principalInfo = principal;
            }
            var sharingPrincipal = {
                id: principalInfo.id,
                isExternal: principalInfo.isExternal,
                loginName: principalInfo.loginName,
                primaryText: principalInfo.name,
                role: principal.role,
                secondaryText: principalInfo.jobTitle,
                type: principalInfo.principalType,
                imageUrl: Object(_ms_odsp_utilities_lib_alternativeUrls_SPAlternativeUrls__WEBPACK_IMPORTED_MODULE_10__["getUserPhotoUrl"])(principalInfo.email),
                email: principalInfo.email
            };
            return sharingPrincipal;
        }
        return null;
    };
    SharingDataSource.prototype._getDefaultSharingLink = function (defaultLinkKind, sharingLinks, sharingAbilities) {
        var peopleSharingLinks = sharingAbilities.peopleSharingLinkAbilities.canManageEditLink.enabled ||
            sharingAbilities.peopleSharingLinkAbilities.canManageReadLink.enabled;
        if (peopleSharingLinks && defaultLinkKind === 1 /* direct */) {
            defaultLinkKind = 6 /* flexible */;
        }
        /**
         * Using "sharing abilities", then all we need to get is the default
         * link kind. The default link kind might be more permissive than the user
         * has the ability to create, so check that here and adjust accordingly.
         */
        var mostPermissiveLinkKind = defaultLinkKind;
        if (useTrackableAnyoneLinkKS && sharingAbilities.anyoneLinkAbilities) {
            if (mostPermissiveLinkKind === 5 /* anonymousEdit */ &&
                !sharingAbilities.anyoneLinkAbilities.canManageEditLink.enabled) {
                mostPermissiveLinkKind = 4 /* anonymousView */;
            }
            if (mostPermissiveLinkKind === 4 /* anonymousView */ &&
                !sharingAbilities.anyoneLinkAbilities.canManageReadLink.enabled) {
                mostPermissiveLinkKind = 3 /* organizationEdit */;
            }
        }
        else {
            if (mostPermissiveLinkKind === 5 /* anonymousEdit */ &&
                !sharingAbilities.anonymousLinkAbilities.canManageEditLink.enabled) {
                mostPermissiveLinkKind = 4 /* anonymousView */;
            }
            if (mostPermissiveLinkKind === 4 /* anonymousView */ &&
                !sharingAbilities.anonymousLinkAbilities.canManageReadLink.enabled) {
                mostPermissiveLinkKind = 3 /* organizationEdit */;
            }
        }
        if (mostPermissiveLinkKind === 3 /* organizationEdit */ &&
            !sharingAbilities.organizationLinkAbilities.canManageEditLink.enabled) {
            mostPermissiveLinkKind = 2 /* organizationView */;
        }
        if (mostPermissiveLinkKind === 2 /* organizationView */ &&
            !sharingAbilities.organizationLinkAbilities.canManageReadLink.enabled) {
            mostPermissiveLinkKind = 1 /* direct */;
        }
        var audience = undefined;
        // Set the audience correctly in the default sharing link
        if (defaultLinkKind === 5 /* anonymousEdit */ ||
            defaultLinkKind === 4 /* anonymousView */) {
            audience = _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone;
        }
        else if (defaultLinkKind === 3 /* organizationEdit */ ||
            defaultLinkKind === 2 /* organizationView */) {
            audience = _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization;
        }
        else if (defaultLinkKind === 1 /* direct */) {
            audience = _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeople;
        }
        else if (defaultLinkKind === 6 /* flexible */) {
            audience = _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeopleFlex;
        }
        return {
            allowsAnonymousAccess: undefined,
            audience: audience,
            expiration: undefined,
            description: undefined,
            isActive: true,
            isEdit: undefined,
            principals: undefined,
            shareId: undefined,
            sharingLinkKind: mostPermissiveLinkKind,
            url: undefined,
            invitees: undefined,
            updatePassword: false,
            password: '',
            passwordLastModifiedBy: undefined
        };
    };
    /**
     * This function copied from PolicyTipHelper in odsp-next.
     * If we need additional helper functions from that file, we might consider a separate helper file.
     */
    SharingDataSource.prototype._isPolicyTipFlagSet = function (policyTip, flag) {
        /* tslint:disable: no-bitwise */
        return policyTip && (policyTip & flag) === flag;
        /* tslint:enable: no-bitwise */
    };
    return SharingDataSource;
}(_base_DataSource__WEBPACK_IMPORTED_MODULE_4__["default"]));

function parseSharingLinkInfo(response) {
    if (response.d) {
        var sharingLinkInfo = response.d.ShareLink.sharingLinkInfo;
        return _parseSharingLinkInfo(sharingLinkInfo);
    }
}
function _parseSharingLinkInfo(sharingLinkInfo) {
    // SharingScope is introduced with trackable anyoneLink feature
    // if Scope is defined and initialized (-1 is uninitialized), we shall use getSharingLinkAudienceByScope
    var audience;
    if (useTrackableAnyoneLinkKS &&
        sharingLinkInfo.Scope !== undefined &&
        sharingLinkInfo.Scope !== -1 /* uninitialized */) {
        audience = getSharingLinkAudienceByScope(sharingLinkInfo.LinkKind, sharingLinkInfo.Scope);
    }
    else {
        audience = getSharingLinkAudience(sharingLinkInfo.LinkKind, sharingLinkInfo.AllowsAnonymousAccess, sharingLinkInfo.RestrictedShareMembership);
    }
    var expiration = sharingLinkInfo.Expiration ? new Date(sharingLinkInfo.Expiration) : undefined;
    var sharingLink = {
        allowsAnonymousAccess: sharingLinkInfo.AllowsAnonymousAccess,
        audience: audience,
        expiration: expiration,
        description: sharingLinkInfo.Description,
        isActive: sharingLinkInfo.IsActive,
        isEdit: computeIsEditLink(sharingLinkInfo.LinkKind) || sharingLinkInfo.IsEditLink,
        principals: null,
        invitees: null,
        hasPassword: sharingLinkInfo.RequiresPassword,
        shareId: sharingLinkInfo.ShareId,
        sharingLinkKind: sharingLinkInfo.LinkKind,
        url: sharingLinkInfo.Url,
        updatePassword: sharingLinkInfo.UpdatePassword,
        password: sharingLinkInfo.Password,
        passwordLastModifiedBy: sharingLinkInfo.PasswordLastModifiedBy,
        shareTokenString: sharingLinkInfo.ShareTokenString,
        isAddressBarLink: sharingLinkInfo.IsAddressBarLink,
        isUnhealthy: sharingLinkInfo.IsUnhealthy,
        status: sharingLinkInfo.SharingLinkStatus,
        created: sharingLinkInfo.Created
    };
    return {
        link: sharingLink
    };
}
function getSharingLinkAudience(sharingLinkKind, AllowsAnonymousAccess, RestrictedShareMembership) {
    /**
     * Note: Currently, the only flexible sharing link supported by the share UI
     * is PSLs, so we can safely return "specificPeopleFlex" as the audience. In the
     * future, if share UI supports more flexible link types, this will likely
     * need to be changed.
     */
    if (sharingLinkKind === 5 /* anonymousEdit */ ||
        sharingLinkKind === 4 /* anonymousView */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone;
    }
    else if (sharingLinkKind === 3 /* organizationEdit */ ||
        sharingLinkKind === 2 /* organizationView */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization;
    }
    else if (sharingLinkKind === 1 /* direct */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeople;
    }
    else if (sharingLinkKind === 6 /* flexible */) {
        // Additional checks to make sure that we get the Audience right
        if (AllowsAnonymousAccess) {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone;
        }
        else if (RestrictedShareMembership === false) {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization;
        }
        else {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeopleFlex;
        }
    }
}
function getSharingLinkAudienceByScope(sharingLinkKind, scope) {
    /**
     * Note: Currently the flexible sharing link supported by the share UI
     * is PSLs and trackable anyone link
     */
    if (sharingLinkKind === 5 /* anonymousEdit */ ||
        sharingLinkKind === 4 /* anonymousView */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone;
    }
    else if (sharingLinkKind === 3 /* organizationEdit */ ||
        sharingLinkKind === 2 /* organizationView */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization;
    }
    else if (sharingLinkKind === 1 /* direct */) {
        return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeople;
    }
    else if (sharingLinkKind === 6 /* flexible */) {
        // Additional checks to make sure that we get the Audience right
        if (scope == 0 /* anyone */) {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].anyone;
        }
        else if (scope === 1 /* organization */) {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].organization;
        }
        else {
            return _interfaces_sharing_SharingInterfaces__WEBPACK_IMPORTED_MODULE_5__["SharingAudience"].specificPeopleFlex;
        }
    }
}
/**
 * Determines if link has edit capabilities or not.
 * Returns null if link type is flexible (because we don't know).
 */
function computeIsEditLink(sharingLinkKind) {
    if (sharingLinkKind === 5 /* anonymousEdit */ ||
        sharingLinkKind === 3 /* organizationEdit */) {
        return true;
    }
    else if (sharingLinkKind === 4 /* anonymousView */ ||
        sharingLinkKind === 2 /* organizationView */) {
        return false;
    }
    else {
        // Future-proofing for flexible links...
        return null;
    }
}
//# sourceMappingURL=SharingDataSource.js.map

/***/ }),

/***/ "xb1K":
/*!*********************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/index.js ***!
  \*********************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _fabric_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fabric-icons */ "7CEq");
/* harmony import */ var _fabric_icons_0__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fabric-icons-0 */ "+RYZ");
/* harmony import */ var _fabric_icons_1__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./fabric-icons-1 */ "YfzS");
/* harmony import */ var _fabric_icons_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fabric-icons-2 */ "HGZC");
/* harmony import */ var _fabric_icons_3__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fabric-icons-3 */ "jrI6");
/* harmony import */ var _fabric_icons_4__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fabric-icons-4 */ "xmbi");
/* harmony import */ var _fabric_icons_5__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fabric-icons-5 */ "3/jV");
/* harmony import */ var _fabric_icons_6__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fabric-icons-6 */ "WJGS");
/* harmony import */ var _fabric_icons_7__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./fabric-icons-7 */ "ytrP");
/* harmony import */ var _fabric_icons_8__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./fabric-icons-8 */ "kG5v");
/* harmony import */ var _fabric_icons_9__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./fabric-icons-9 */ "86Ak");
/* harmony import */ var _fabric_icons_10__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./fabric-icons-10 */ "pVXM");
/* harmony import */ var _fabric_icons_11__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./fabric-icons-11 */ "0Gja");
/* harmony import */ var _fabric_icons_12__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./fabric-icons-12 */ "ZUAD");
/* harmony import */ var _fabric_icons_13__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./fabric-icons-13 */ "Oz68");
/* harmony import */ var _fabric_icons_14__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./fabric-icons-14 */ "6MNw");
/* harmony import */ var _fabric_icons_15__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./fabric-icons-15 */ "zxpB");
/* harmony import */ var _fabric_icons_16__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./fabric-icons-16 */ "sscn");
/* harmony import */ var _fabric_icons_17__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./fabric-icons-17 */ "smyq");
/* harmony import */ var _iconAliases__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./iconAliases */ "fsNk");
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./version */ "vxX2");




















var DEFAULT_BASE_URL = 'https://spoprod-a.akamaihd.net/files/fabric/assets/icons/';
function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = DEFAULT_BASE_URL; }
    [
        _fabric_icons__WEBPACK_IMPORTED_MODULE_0__["initializeIcons"],
        _fabric_icons_0__WEBPACK_IMPORTED_MODULE_1__["initializeIcons"],
        _fabric_icons_1__WEBPACK_IMPORTED_MODULE_2__["initializeIcons"],
        _fabric_icons_2__WEBPACK_IMPORTED_MODULE_3__["initializeIcons"],
        _fabric_icons_3__WEBPACK_IMPORTED_MODULE_4__["initializeIcons"],
        _fabric_icons_4__WEBPACK_IMPORTED_MODULE_5__["initializeIcons"],
        _fabric_icons_5__WEBPACK_IMPORTED_MODULE_6__["initializeIcons"],
        _fabric_icons_6__WEBPACK_IMPORTED_MODULE_7__["initializeIcons"],
        _fabric_icons_7__WEBPACK_IMPORTED_MODULE_8__["initializeIcons"],
        _fabric_icons_8__WEBPACK_IMPORTED_MODULE_9__["initializeIcons"],
        _fabric_icons_9__WEBPACK_IMPORTED_MODULE_10__["initializeIcons"],
        _fabric_icons_10__WEBPACK_IMPORTED_MODULE_11__["initializeIcons"],
        _fabric_icons_11__WEBPACK_IMPORTED_MODULE_12__["initializeIcons"],
        _fabric_icons_12__WEBPACK_IMPORTED_MODULE_13__["initializeIcons"],
        _fabric_icons_13__WEBPACK_IMPORTED_MODULE_14__["initializeIcons"],
        _fabric_icons_14__WEBPACK_IMPORTED_MODULE_15__["initializeIcons"],
        _fabric_icons_15__WEBPACK_IMPORTED_MODULE_16__["initializeIcons"],
        _fabric_icons_16__WEBPACK_IMPORTED_MODULE_17__["initializeIcons"],
        _fabric_icons_17__WEBPACK_IMPORTED_MODULE_18__["initializeIcons"],
    ].forEach(function (initialize) { return initialize(baseUrl, options); });
    Object(_iconAliases__WEBPACK_IMPORTED_MODULE_19__["registerIconAliases"])();
}

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "xmbi":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-4.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-4\"",
            src: "url('" + baseUrl + "fabric-icons-4-a656cc0a.woff') format('woff')"
        },
        icons: {
            'HelpMirrored': '\uEA51',
            'ImportMirrored': '\uEA52',
            'ImportAllMirrored': '\uEA53',
            'ListMirrored': '\uEA55',
            'MailForwardMirrored': '\uEA56',
            'MailReplyMirrored': '\uEA57',
            'MailReplyAllMirrored': '\uEA58',
            'MiniContractMirrored': '\uEA59',
            'MiniExpandMirrored': '\uEA5A',
            'OpenPaneMirrored': '\uEA5B',
            'ParkingLocationMirrored': '\uEA5E',
            'SendMirrored': '\uEA63',
            'ShowResultsMirrored': '\uEA65',
            'ThumbnailViewMirrored': '\uEA67',
            'Media': '\uEA69',
            'Devices3': '\uEA6C',
            'Focus': '\uEA6F',
            'VideoLightOff': '\uEA74',
            'Lightbulb': '\uEA80',
            'StatusTriangle': '\uEA82',
            'VolumeDisabled': '\uEA85',
            'Puzzle': '\uEA86',
            'EmojiNeutral': '\uEA87',
            'EmojiDisappointed': '\uEA88',
            'HomeSolid': '\uEA8A',
            'Ringer': '\uEA8F',
            'PDF': '\uEA90',
            'HeartBroken': '\uEA92',
            'StoreLogo16': '\uEA96',
            'MultiSelectMirrored': '\uEA98',
            'Broom': '\uEA99',
            'AddToShoppingList': '\uEA9A',
            'Cocktails': '\uEA9D',
            'Wines': '\uEABF',
            'Articles': '\uEAC1',
            'Cycling': '\uEAC7',
            'DietPlanNotebook': '\uEAC8',
            'Pill': '\uEACB',
            'ExerciseTracker': '\uEACC',
            'HandsFree': '\uEAD0',
            'Medical': '\uEAD4',
            'Running': '\uEADA',
            'Weights': '\uEADB',
            'Trackers': '\uEADF',
            'AddNotes': '\uEAE3',
            'AllCurrency': '\uEAE4',
            'BarChart4': '\uEAE7',
            'CirclePlus': '\uEAEE',
            'Coffee': '\uEAEF',
            'Cotton': '\uEAF3',
            'Market': '\uEAFC',
            'Money': '\uEAFD',
            'PieDouble': '\uEB04',
            'PieSingle': '\uEB05',
            'RemoveFilter': '\uEB08',
            'Savings': '\uEB0B',
            'Sell': '\uEB0C',
            'StockDown': '\uEB0F',
            'StockUp': '\uEB11',
            'Lamp': '\uEB19',
            'Source': '\uEB1B',
            'MSNVideos': '\uEB1C',
            'Cricket': '\uEB1E',
            'Golf': '\uEB1F',
            'Baseball': '\uEB20',
            'Soccer': '\uEB21',
            'MoreSports': '\uEB22',
            'AutoRacing': '\uEB24',
            'CollegeHoops': '\uEB25',
            'CollegeFootball': '\uEB26',
            'ProFootball': '\uEB27',
            'ProHockey': '\uEB28',
            'Rugby': '\uEB2D',
            'SubstitutionsIn': '\uEB31',
            'Tennis': '\uEB33',
            'Arrivals': '\uEB34',
            'Design': '\uEB3C',
            'Website': '\uEB41',
            'Drop': '\uEB42',
            'HistoricalWeather': '\uEB43',
            'SkiResorts': '\uEB45',
            'Snowflake': '\uEB46',
            'BusSolid': '\uEB47',
            'FerrySolid': '\uEB48',
            'AirplaneSolid': '\uEB4C',
            'TrainSolid': '\uEB4D',
            'Ticket': '\uEB54',
            'WifiWarning4': '\uEB63',
            'Devices4': '\uEB66',
            'AzureLogo': '\uEB6A',
            'BingLogo': '\uEB6B',
            'MSNLogo': '\uEB6C',
            'OutlookLogoInverse': '\uEB6D',
            'OfficeLogo': '\uEB6E',
            'SkypeLogo': '\uEB6F',
            'Door': '\uEB75',
            'EditMirrored': '\uEB7E',
            'GiftCard': '\uEB8E',
            'DoubleBookmark': '\uEB8F',
            'StatusErrorFull': '\uEB90'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-4.js.map

/***/ }),

/***/ "ye7z":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/AccessStatus.js ***!
  \*****************************************************************************************************************************************************************************************************/
/*! exports provided: AccessStatus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessStatus", function() { return AccessStatus; });
var AccessStatus;
(function (AccessStatus) {
    AccessStatus[AccessStatus["none"] = 1] = "none";
    AccessStatus[AccessStatus["pending"] = 2] = "pending";
    AccessStatus[AccessStatus["hasAccess"] = 3] = "hasAccess";
})(AccessStatus || (AccessStatus = {}));
//# sourceMappingURL=AccessStatus.js.map

/***/ }),

/***/ "yruj":
/*!******************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/utilities/common/utilities.js ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: waitFor, isCommSite, isAbleToManageGlobalNav */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitFor", function() { return waitFor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isCommSite", function() { return isCommSite; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isAbleToManageGlobalNav", function() { return isAbleToManageGlobalNav; });
/* harmony import */ var _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ms/odsp-utilities/lib/async/Promise */ "7Ihg");
/* harmony import */ var _interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../interfaces/ISpPageContext */ "GlwB");
/* harmony import */ var _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities/lib/killswitch/Killswitch */ "QUgr");
/* harmony import */ var _interfaces_WebTemplateType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../interfaces/WebTemplateType */ "DRdk");
/* harmony import */ var _interfaces_SPFeatureInfo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../interfaces/SPFeatureInfo */ "eDfq");
/* harmony import */ var _permissions_PermissionMask__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../permissions/PermissionMask */ "z7Uc");






/**
 * Helper function that returns a promise that resolves once the specified condition happens.
 */
function waitFor(checker, frequency, maxTime) {
    var count = 0;
    var waitFor = function (complete, error) {
        var waiter = setInterval(function () {
            if (count * frequency <= maxTime) {
                count++;
                if (checker()) {
                    clearInterval(waiter);
                    complete();
                }
            }
            else {
                clearInterval(waiter);
                throw 'Timed out waiting for checker ' + checker;
            }
        }, frequency);
    };
    return new _ms_odsp_utilities_lib_async_Promise__WEBPACK_IMPORTED_MODULE_0__["default"](waitFor);
}
function isCommSite(pageContext) {
    var isServerKillSwitchActivated = _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_2__["Killswitch"].isActivated('fcc930ba-8fe4-4065-b185-8b74488eba20', '10/08/2019', 'SitePagePublishing_FeatureEnabled');
    var isClientKillSwitchActivated = _ms_odsp_utilities_lib_killswitch_Killswitch__WEBPACK_IMPORTED_MODULE_2__["Killswitch"].isActivated('1c067c05-41cd-48a7-bf78-bb398a461041', '10/15/2019', 'Check comm site feature instead of template');
    if (!isServerKillSwitchActivated && !isClientKillSwitchActivated && pageContext.featureInfo) {
        var features = new _interfaces_SPFeatureInfo__WEBPACK_IMPORTED_MODULE_4__["default"](pageContext.featureInfo);
        if (features) {
            var feature = features.get('SitePagePublishing');
            return !!feature && feature.enabled;
        }
        else {
            return false;
        }
    }
    else {
        return Number(pageContext.webTemplate) === _interfaces_WebTemplateType__WEBPACK_IMPORTED_MODULE_3__["default"].sitePagePublishing;
    }
}
/**
 * Helper function to check if current user can manage global nav. It need to meet:
 *     1. Current web is root web
 *     2. Current site is home site
 *     3. Has manage web permission
 * @param spPageContext page context instance
 */
function isAbleToManageGlobalNav(spPageContext) {
    return !!(Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__["isHomeSite"])(spPageContext) &&
        Object(_interfaces_ISpPageContext__WEBPACK_IMPORTED_MODULE_1__["isRootWebContext"])(spPageContext) &&
        _permissions_PermissionMask__WEBPACK_IMPORTED_MODULE_5__["PermissionMask"].hasPermission(spPageContext.webPermMasks, _permissions_PermissionMask__WEBPACK_IMPORTED_MODULE_5__["PermissionMask"].manageWeb));
}
//# sourceMappingURL=utilities.js.map

/***/ }),

/***/ "ytrP":
/*!******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-7.js ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-7\"",
            src: "url('" + baseUrl + "fabric-icons-7-2b97bb99.woff') format('woff')"
        },
        icons: {
            'SingleBookmark': '\uEDFF',
            'SingleBookmarkSolid': '\uEE00',
            'DoubleChevronDown': '\uEE04',
            'FollowUser': '\uEE05',
            'ReplyAll': '\uEE0A',
            'WorkforceManagement': '\uEE0F',
            'RecruitmentManagement': '\uEE12',
            'Questionnaire': '\uEE19',
            'ManagerSelfService': '\uEE23',
            'ProductionFloorManagement': '\uEE29',
            'ProductRelease': '\uEE2E',
            'ProductVariant': '\uEE30',
            'ReplyMirrored': '\uEE35',
            'ReplyAllMirrored': '\uEE36',
            'Medal': '\uEE38',
            'AddGroup': '\uEE3D',
            'QuestionnaireMirrored': '\uEE4B',
            'CloudImportExport': '\uEE55',
            'TemporaryUser': '\uEE58',
            'CaretSolid16': '\uEE62',
            'GroupedDescending': '\uEE66',
            'GroupedAscending': '\uEE67',
            'AwayStatus': '\uEE6A',
            'MyMoviesTV': '\uEE6C',
            'GenericScan': '\uEE6F',
            'AustralianRules': '\uEE70',
            'WifiEthernet': '\uEE77',
            'TrackersMirrored': '\uEE92',
            'DateTimeMirrored': '\uEE93',
            'StopSolid': '\uEE95',
            'DoubleChevronUp12': '\uEE96',
            'DoubleChevronDown12': '\uEE97',
            'DoubleChevronLeft12': '\uEE98',
            'DoubleChevronRight12': '\uEE99',
            'CalendarAgenda': '\uEE9A',
            'ConnectVirtualMachine': '\uEE9D',
            'AddEvent': '\uEEB5',
            'AssetLibrary': '\uEEB6',
            'DataConnectionLibrary': '\uEEB7',
            'DocLibrary': '\uEEB8',
            'FormLibrary': '\uEEB9',
            'FormLibraryMirrored': '\uEEBA',
            'ReportLibrary': '\uEEBB',
            'ReportLibraryMirrored': '\uEEBC',
            'ContactCard': '\uEEBD',
            'CustomList': '\uEEBE',
            'CustomListMirrored': '\uEEBF',
            'IssueTracking': '\uEEC0',
            'IssueTrackingMirrored': '\uEEC1',
            'PictureLibrary': '\uEEC2',
            'OfficeAddinsLogo': '\uEEC7',
            'OfflineOneDriveParachute': '\uEEC8',
            'OfflineOneDriveParachuteDisabled': '\uEEC9',
            'TriangleSolidUp12': '\uEECC',
            'TriangleSolidDown12': '\uEECD',
            'TriangleSolidLeft12': '\uEECE',
            'TriangleSolidRight12': '\uEECF',
            'TriangleUp12': '\uEED0',
            'TriangleDown12': '\uEED1',
            'TriangleLeft12': '\uEED2',
            'TriangleRight12': '\uEED3',
            'ArrowUpRight8': '\uEED4',
            'ArrowDownRight8': '\uEED5',
            'DocumentSet': '\uEED6',
            'GoToDashboard': '\uEEED',
            'DelveAnalytics': '\uEEEE',
            'ArrowUpRightMirrored8': '\uEEEF',
            'ArrowDownRightMirrored8': '\uEEF0',
            'CompanyDirectory': '\uEF0D',
            'OpenEnrollment': '\uEF1C',
            'CompanyDirectoryMirrored': '\uEF2B',
            'OneDriveAdd': '\uEF32',
            'ProfileSearch': '\uEF35',
            'Header2': '\uEF36',
            'Header3': '\uEF37',
            'Header4': '\uEF38',
            'RingerSolid': '\uEF3A',
            'Eyedropper': '\uEF3C',
            'MarketDown': '\uEF42',
            'CalendarWorkWeek': '\uEF51',
            'SidePanel': '\uEF52',
            'GlobeFavorite': '\uEF53',
            'CaretTopLeftSolid8': '\uEF54',
            'CaretTopRightSolid8': '\uEF55',
            'ViewAll2': '\uEF56',
            'DocumentReply': '\uEF57',
            'PlayerSettings': '\uEF58',
            'ReceiptForward': '\uEF59',
            'ReceiptReply': '\uEF5A',
            'ReceiptCheck': '\uEF5B',
            'Fax': '\uEF5C',
            'RecurringEvent': '\uEF5D',
            'ReplyAlt': '\uEF5E',
            'ReplyAllAlt': '\uEF5F',
            'EditStyle': '\uEF60',
            'EditMail': '\uEF61',
            'Lifesaver': '\uEF62',
            'LifesaverLock': '\uEF63',
            'InboxCheck': '\uEF64',
            'FolderSearch': '\uEF65'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-7.js.map

/***/ }),

/***/ "zLRY":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/dataSources/AccessRequests/IAccessRequestsDataSource.js ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: AccessRequestStatus */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessRequestStatus", function() { return AccessRequestStatus; });
/**
 * Enum for status of the request wish to accomplish
 * as defined in:
 * spo/src/otools/inc/sts/stsom/core/InvitationHelper.cs
 */
var AccessRequestStatus;
(function (AccessRequestStatus) {
    AccessRequestStatus[AccessRequestStatus["Approve"] = 1] = "Approve";
    AccessRequestStatus[AccessRequestStatus["Decline"] = 3] = "Decline";
})(AccessRequestStatus || (AccessRequestStatus = {}));
//# sourceMappingURL=IAccessRequestsDataSource.js.map

/***/ }),

/***/ "zlrR":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/components/GroupMembershipPanel/GroupMembershipMenu/GroupMembershipMenu.js ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: GroupMembershipMenu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupMembershipMenu", function() { return GroupMembershipMenu; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _GroupMembershipMenu_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./GroupMembershipMenu.scss */ "qWgY");
/* harmony import */ var office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! office-ui-fabric-react/lib/ContextualMenu */ "u4xd");
/* harmony import */ var office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! office-ui-fabric-react/lib/FocusZone */ "NMYH");
/* harmony import */ var office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/Spinner */ "fyAn");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! office-ui-fabric-react/lib/Icon */ "56LG");
/* harmony import */ var office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__);







/**
 * The group membership menu is a contextual menu dropdown attached to each persona
 * If no menu items are available, only the title is displayed
 * @public
 */
var GroupMembershipMenu = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(GroupMembershipMenu, _super);
    function GroupMembershipMenu(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this._onClick = function () {
            // Only show the contextual menu if options are available.
            if (_this.props.menuItems && _this.props.menuItems.length > 0) {
                _this.setState({
                    isContextualMenuVisible: !_this.state.isContextualMenuVisible
                });
            }
        };
        _this._onDismiss = function (ev) {
            _this.setState({
                isContextualMenuVisible: false
            });
            ev.stopPropagation();
            ev.preventDefault();
        };
        _this._resolveMenu = function (el) { return (_this.menu = el); };
        _this.state = {
            isContextualMenuVisible: false
        };
        return _this;
    }
    GroupMembershipMenu.prototype.render = function () {
        var menuItemsExist = this.props.menuItems && this.props.menuItems.length > 0;
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null,
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_4__["FocusZone"], { direction: office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_4__["FocusZoneDirection"].horizontal },
                react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: 'ms-groupMembershipMenu-titleArea', ref: this._resolveMenu },
                    react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("span", { className: menuItemsExist ? 'ms-groupMembershipMenu-linkText' : undefined, onClick: this._onClick, "data-is-focusable": menuItemsExist, role: 'button', "aria-haspopup": true, "aria-expanded": this.state.isContextualMenuVisible ? true : false },
                        this.props.showSpinner && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_5__["Spinner"], { className: 'ms-groupMembershipMenu-updatingSpinner', size: office_ui_fabric_react_lib_Spinner__WEBPACK_IMPORTED_MODULE_5__["SpinnerSize"].small })),
                        this.props.title,
                        menuItemsExist && react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_Icon__WEBPACK_IMPORTED_MODULE_6__["Icon"], { iconName: 'ChevronDown', className: 'ms-groupMembershipMenu-chevron' }))),
                menuItemsExist && this.state.isContextualMenuVisible && (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__["ContextualMenu"], { items: this.props.menuItems, isBeakVisible: false, target: this.menu, directionalHint: office_ui_fabric_react_lib_ContextualMenu__WEBPACK_IMPORTED_MODULE_3__["DirectionalHint"].bottomLeftEdge, onDismiss: this._onDismiss, gapSpace: 0 })))));
    };
    return GroupMembershipMenu;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]));

//# sourceMappingURL=GroupMembershipMenu.js.map

/***/ }),

/***/ "zluq":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-shared-react@47.12.13_d89e40c38ccaa8bd6af6488f37cb196d/node_modules/@ms/odsp-shared-react/lib/utilities/peoplepicker/PeoplePickerHelper.js ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: getExternalPeopleCount, getOversharingExternalsWarning, getOversharingGroupsWarning, renderPickerError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExternalPeopleCount", function() { return getExternalPeopleCount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOversharingExternalsWarning", function() { return getOversharingExternalsWarning; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getOversharingGroupsWarning", function() { return getOversharingGroupsWarning; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renderPickerError", function() { return renderPickerError; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ms/odsp-utilities/lib/string/StringHelper */ "BY+f");
/* harmony import */ var _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/Link */ "F3Wv");
/* harmony import */ var _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./PeoplePickerHelper.resx */ "BVxC");
/* harmony import */ var _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ms_odsp_datasources_lib_dataSources_roleAssignments_PrincipalType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-datasources/lib/dataSources/roleAssignments/PrincipalType */ "2+UY");





function getExternalPeopleCount(selectedItems) {
    if (!selectedItems || selectedItems.length === 0) {
        return 0;
    }
    var externalPeople = selectedItems.filter(function (item) {
        return item.entityType === 1 /* externalUser */;
    });
    return externalPeople.length;
}
function getOversharingExternalsWarning(selectedItems) {
    var externalPeople = selectedItems.filter(function (item) {
        return item.entityType === 1 /* externalUser */;
    });
    var numberOfPeople = externalPeople.length;
    var names = externalPeople.map(function (persona) {
        return persona.name;
    });
    if (numberOfPeople === 2) {
        var result = names.join(', ');
        var oxfordComma = result.lastIndexOf(',');
        var userNames = result.substring(0, oxfordComma) + " " + _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.and + " " + result.substring(oxfordComma + 1);
        return _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.outsideOfYourOrgPlural, userNames);
    }
    else if (numberOfPeople > 2) {
        var result = names.join(', ');
        var oxfordComma = result.lastIndexOf(',');
        var userNames = result.substring(0, oxfordComma + 1) + " " + _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.and + " " + result.substring(oxfordComma + 1);
        return _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.outsideOfYourOrgPlural, userNames);
    }
    else if (numberOfPeople === 1) {
        return _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.outsideOfYourOrgSingular, names[0]);
    }
    else {
        return '';
    }
}
function getOversharingGroupsWarning(selectedItems, groupsMemberCount) {
    var groups = selectedItems.filter(function (item) {
        return item.entityType === 2 /* group */;
    });
    var numberOfGroups = groups.length;
    var warningText = '';
    if (numberOfGroups === 1) {
        warningText = _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.oneGroupInvited;
    }
    else if (numberOfGroups > 1) {
        warningText = _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.multipleGroupsInvited, numberOfGroups);
    }
    if (groupsMemberCount >= 1000) {
        warningText += " " + _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.groupsMemberCountLargeLabel;
    }
    else if (groupsMemberCount >= 25) {
        warningText += " " + _ms_odsp_utilities_lib_string_StringHelper__WEBPACK_IMPORTED_MODULE_1__["format"](_PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.groupsMemberCountLabel, groupsMemberCount);
    }
    return warningText;
}
function renderPickerError(props) {
    var selectedItems = props.selectedItems, sharingLinkKind = props.sharingLinkKind, canAddExternalPrincipal = props.canAddExternalPrincipal, hasDlpPolicyTip = props.hasDlpPolicyTip, viewPolicyTipCallback = props.viewPolicyTipCallback, permissionsMap = props.permissionsMap;
    for (var _i = 0, selectedItems_1 = selectedItems; _i < selectedItems_1.length; _i++) {
        var selectedItem = selectedItems_1[_i];
        /**
         * Check for unresolved users, and use server message if we find one.
         *
         * In the case where we have an unresolved user and the item blocks
         * sharing via policy, use a special error message instead of the one
         * provided by the server.
         *
         * It shouldn't happen, but if the user doesn't get resolved, and the
         * server doesn't provide an error message, fall back to generic "no
         * exact match" error to at least provide some error message.
         */
        if (!selectedItem.isResolved) {
            if (hasDlpPolicyTip && !canAddExternalPrincipal) {
                return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null,
                        _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.PolicyTipNotifyAndBlock,
                        " "),
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"](office_ui_fabric_react_lib_Link__WEBPACK_IMPORTED_MODULE_2__["Link"], { onClick: viewPolicyTipCallback }, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.ViewPolicyTip)));
            }
            else if (selectedItem.rawData) {
                return selectedItem.rawData.Description;
            }
            else {
                return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.noExactMatch);
            }
        }
        /**
         * If the user is external and is a distribution list group, we know we have a legacy DL selected and need to show an error.
         * These objects can be returned when using Graph to retrieve search results in the picker. Since legacy DLs are not valid
         * share targets, we need to error them out for the user.
         */
        if (selectedItem.isExternal &&
            selectedItem.principalType === _ms_odsp_datasources_lib_dataSources_roleAssignments_PrincipalType__WEBPACK_IMPORTED_MODULE_4__["default"].distributionList &&
            selectedItem.entityType === 2 /* group */) {
            return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.peoplePickerErrorDLNotSupported);
        }
        /**
         * If the user is external and the user has a CSL configured, show
         * specific error.
         */
        var isCompanyShareableLink = sharingLinkKind === 3 /* organizationEdit */ ||
            sharingLinkKind === 2 /* organizationView */;
        if (selectedItem.isExternal && isCompanyShareableLink) {
            return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.peoplePickerErrorCsl);
        }
    }
    /**
     * If we have a permissionsMap and a canonical is being shared, we need to
     * check if desired recipients actually have permission to access the item.
     */
    if (permissionsMap && sharingLinkKind === 1 /* direct */) {
        var usersWithoutPermissions = 0;
        for (var email in permissionsMap) {
            if (permissionsMap[email] === 1 /* none */) {
                usersWithoutPermissions++;
            }
        }
        if (usersWithoutPermissions === 1) {
            return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.insufficientPermissionsError);
        }
        else if (usersWithoutPermissions > 1) {
            return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("span", null, _PeoplePickerHelper_resx__WEBPACK_IMPORTED_MODULE_3___default.a.insufficientPermissionsErrorPlural);
        }
    }
    return null;
}
//# sourceMappingURL=PeoplePickerHelper.js.map

/***/ }),

/***/ "zo6u":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@ms/odsp-datasources@45.13.10_e509c819ab980023b76e5746ec0fc9e2/node_modules/@ms/odsp-datasources/lib/interfaces/sharing/enums/SharingLinkExpressOptions.js ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: SharingLinkExpressOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharingLinkExpressOptions", function() { return SharingLinkExpressOptions; });
var SharingLinkExpressOptions;
(function (SharingLinkExpressOptions) {
    SharingLinkExpressOptions[SharingLinkExpressOptions["uninitialized"] = 0] = "uninitialized";
    SharingLinkExpressOptions[SharingLinkExpressOptions["AddressBarLink"] = 1] = "AddressBarLink";
})(SharingLinkExpressOptions || (SharingLinkExpressOptions = {}));
//# sourceMappingURL=SharingLinkExpressOptions.js.map

/***/ }),

/***/ "zxpB":
/*!*******************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/@uifabric/icons@7.5.18_baa7aab8a1d5d20fe3858de8537800ba/node_modules/@uifabric/icons/lib/fabric-icons-15.js ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: initializeIcons */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeIcons", function() { return initializeIcons; });
/* harmony import */ var _uifabric_styling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @uifabric/styling */ "dqzI");
// Your use of the content in the files referenced here is subject to the terms of the license at https://aka.ms/fluentui-assets-license

function initializeIcons(baseUrl, options) {
    if (baseUrl === void 0) { baseUrl = ''; }
    var subset = {
        style: {
            MozOsxFontSmoothing: 'grayscale',
            WebkitFontSmoothing: 'antialiased',
            fontStyle: 'normal',
            fontWeight: 'normal',
            speak: 'none'
        },
        fontFace: {
            fontFamily: "\"FabricMDL2Icons-15\"",
            src: "url('" + baseUrl + "fabric-icons-15-3807251b.woff') format('woff')"
        },
        icons: {
            'CalendarSettings': '\uF558',
            'CalendarSettingsMirrored': '\uF559',
            'HardDriveLock': '\uF55A',
            'HardDriveUnlock': '\uF55B',
            'AccountManagement': '\uF55C',
            'ReportWarning': '\uF569',
            'TransitionPop': '\uF5B2',
            'TransitionPush': '\uF5B3',
            'TransitionEffect': '\uF5B4',
            'LookupEntities': '\uF5B5',
            'ExploreData': '\uF5B6',
            'AddBookmark': '\uF5B7',
            'SearchBookmark': '\uF5B8',
            'DrillThrough': '\uF5B9',
            'MasterDatabase': '\uF5BA',
            'CertifiedDatabase': '\uF5BB',
            'MaximumValue': '\uF5BC',
            'MinimumValue': '\uF5BD',
            'VisualStudioIDELogo32': '\uF5D0',
            'PasteAsText': '\uF5D5',
            'PasteAsCode': '\uF5D6',
            'BrowserTab': '\uF5D7',
            'BrowserTabScreenshot': '\uF5D8',
            'DesktopScreenshot': '\uF5D9',
            'FileYML': '\uF5DA',
            'ClipboardSolid': '\uF5DC',
            'FabricUserFolder': '\uF5E5',
            'FabricNetworkFolder': '\uF5E6',
            'BullseyeTarget': '\uF5F0',
            'AnalyticsView': '\uF5F1',
            'Video360Generic': '\uF609',
            'Untag': '\uF60B',
            'Leave': '\uF627',
            'Trending12': '\uF62D',
            'Blocked12': '\uF62E',
            'Warning12': '\uF62F',
            'CheckedOutByOther12': '\uF630',
            'CheckedOutByYou12': '\uF631',
            'CircleShapeSolid': '\uF63C',
            'SquareShapeSolid': '\uF63D',
            'TriangleShapeSolid': '\uF63E',
            'DropShapeSolid': '\uF63F',
            'RectangleShapeSolid': '\uF640',
            'ZoomToFit': '\uF649',
            'InsertColumnsLeft': '\uF64A',
            'InsertColumnsRight': '\uF64B',
            'InsertRowsAbove': '\uF64C',
            'InsertRowsBelow': '\uF64D',
            'DeleteColumns': '\uF64E',
            'DeleteRows': '\uF64F',
            'DeleteRowsMirrored': '\uF650',
            'DeleteTable': '\uF651',
            'AccountBrowser': '\uF652',
            'VersionControlPush': '\uF664',
            'StackedColumnChart2': '\uF666',
            'TripleColumnWide': '\uF66E',
            'QuadColumn': '\uF66F',
            'WhiteBoardApp16': '\uF673',
            'WhiteBoardApp32': '\uF674',
            'PinnedSolid': '\uF676',
            'InsertSignatureLine': '\uF677',
            'ArrangeByFrom': '\uF678',
            'Phishing': '\uF679',
            'CreateMailRule': '\uF67A',
            'PublishCourse': '\uF699',
            'DictionaryRemove': '\uF69A',
            'UserRemove': '\uF69B',
            'UserEvent': '\uF69C',
            'Encryption': '\uF69D',
            'PasswordField': '\uF6AA',
            'OpenInNewTab': '\uF6AB',
            'Hide3': '\uF6AC',
            'VerifiedBrandSolid': '\uF6AD',
            'MarkAsProtected': '\uF6AE',
            'AuthenticatorApp': '\uF6B1',
            'WebTemplate': '\uF6B2',
            'DefenderTVM': '\uF6B3',
            'MedalSolid': '\uF6B9',
            'D365TalentLearn': '\uF6BB',
            'D365TalentInsight': '\uF6BC',
            'D365TalentHRCore': '\uF6BD',
            'BacklogList': '\uF6BF',
            'ButtonControl': '\uF6C0',
            'TableGroup': '\uF6D9',
            'MountainClimbing': '\uF6DB',
            'TagUnknown': '\uF6DF',
            'TagUnknownMirror': '\uF6E0',
            'TagUnknown12': '\uF6E1',
            'TagUnknown12Mirror': '\uF6E2',
            'Link12': '\uF6E3',
            'Presentation': '\uF6E4',
            'Presentation12': '\uF6E5',
            'Lock12': '\uF6E6',
            'BuildDefinition': '\uF6E9',
            'ReleaseDefinition': '\uF6EA',
            'SaveTemplate': '\uF6EC',
            'UserGauge': '\uF6ED',
            'BlockedSiteSolid12': '\uF70A',
            'TagSolid': '\uF70E',
            'OfficeChat': '\uF70F'
        }
    };
    Object(_uifabric_styling__WEBPACK_IMPORTED_MODULE_0__["registerIcons"])(subset, options);
}
//# sourceMappingURL=fabric-icons-15.js.map

/***/ })

}]);
//# sourceMappingURL=chunk.vendors~spcx-panels_[locale].js.map