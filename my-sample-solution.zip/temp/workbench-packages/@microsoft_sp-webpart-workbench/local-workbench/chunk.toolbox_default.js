(window["webpackJsonp_5388ac31_7915_4ba6_a021_0f8808dd5784_0_0_1"] = window["webpackJsonp_5388ac31_7915_4ba6_a021_0f8808dd5784_0_0_1"] || []).push([["toolbox"],{

/***/ "+ium":
/*!*********************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemLarge.js ***!
  \*********************************************/
/*! exports provided: ToolboxItemLarge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemLarge", function() { return ToolboxItemLarge; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxItemBase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxItemBase */ "+FXA");
/* harmony import */ var _ToolboxItemLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemLarge.module.scss */ "x0iz");




function ToolboxItemLarge(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxItemBase__WEBPACK_IMPORTED_MODULE_2__["ToolboxItemBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { titleLineCount: 3, itemClassName: _ToolboxItemLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].item, itemStyles: { height: 128 }, flexBoxClassName: _ToolboxItemLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].flexBox, iconClassName: _ToolboxItemLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].icon, titleClassName: _ToolboxItemLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].title, "data-item-size": 'large' })));
}


/***/ }),

/***/ "+zNl":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxGroup/ToolboxGroupBase.module.css ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ab_h_08a7513e{clear:both;position:relative}.ab_h_08a7513e.ac_h_08a7513e{margin-bottom:12px}.ae_h_08a7513e{letter-spacing:1px}[dir=ltr] .ae_h_08a7513e{text-align:left}[dir=rtl] .ae_h_08a7513e{text-align:right}.ae_h_08a7513e:not(.f_h_08a7513e){color:\"[theme:neutralPrimary, default: #323130]\";background-color:\"[theme:neutralLighter, default: #f3f2f1]\";font-weight:600;height:32px;line-height:32px;padding:0 12px}.ae_h_08a7513e.f_h_08a7513e{font-size:\"[theme:mediumPlusFontSize, default: 16px]\";font-weight:\"[theme:mediumPlusFontWeight, default: 400]\";font-weight:600;color:\"[theme:neutralSecondary, default: #605e5c]\";height:40px;line-height:40px;padding:0 16px;border-top:1px solid \"[theme:neutrallight, default: #edebe9]\"}.ae_h_08a7513e.ac_h_08a7513e{border-top:none}.af_h_08a7513e{height:32px;color:\"[theme:themeDarkAlt, default: #106ebe]\";position:absolute;top:0}[dir=ltr] .af_h_08a7513e{right:0}[dir=rtl] .af_h_08a7513e{left:0}.af_h_08a7513e.f_h_08a7513e{font-size:\"[theme:mediumFontSize, default: 14px]\";font-weight:\"[theme:mediumFontWeight, default: 400]\"}", ""]);


/***/ }),

/***/ "/U0d":
/*!**********************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxLarge/ViewSearch.module.css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".an_p_08a7513e{height:100%}.ao_p_08a7513e{height:100%;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;-ms-flex-align:center;align-items:center}.ap_p_08a7513e{margin-bottom:18px;font-size:32px}[dir=ltr] .ap_p_08a7513e{margin-right:14px}[dir=rtl] .ap_p_08a7513e{margin-left:14px}.aq_p_08a7513e{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;-ms-flex-align:center;align-items:center}.ar_p_08a7513e{font-size:21px;font-weight:100;margin-bottom:4px}.ar_p_08a7513e,.as_p_08a7513e{color:\"[theme:neutralSecondary, default: #605e5c]\"}.as_p_08a7513e{font-size:17px;font-weight:300}", ""]);


/***/ }),

/***/ "00Tc":
/*!***************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupUtilities.js ***!
  \***************************************************/
/*! exports provided: categorizeGroups, categorizeGroupsWithMfu, getFeaturedGroup, getAlphabeticalGroup, getSectionGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categorizeGroups", function() { return categorizeGroups; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categorizeGroupsWithMfu", function() { return categorizeGroupsWithMfu; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFeaturedGroup", function() { return getFeaturedGroup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAlphabeticalGroup", function() { return getAlphabeticalGroup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSectionGroup", function() { return getSectionGroup; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-lodash-subset */ "Pk8u");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxData */ "b6WH");



var PREDEFINED_GROUP_IDS = new Set(_toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].PREDEFINED_GROUPS.map(function (_a) {
    var id = _a[0];
    return id;
}));
function categorizeGroups(items, featuredIds) {
    // @todo #461149: Leverage item.isInternal to enforce third-party connector web parts to others category.
    var result = categorizeDefaultGroups(items);
    var featuredGroup = getFeaturedGroup(items, featuredIds);
    return featuredGroup.items.length > 0 ? [featuredGroup].concat(result) : result;
}
function categorizeGroupsWithMfu(items, mfuGroupIds, isMostFrequentlyGroupLoading) {
    if (mfuGroupIds === void 0) { mfuGroupIds = []; }
    var result = categorizeDefaultGroups(items);
    var newGroup = {
        title: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].MOST_FREQUENTLY_GROUP[1],
        groupId: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].MOST_FREQUENTLY_GROUP[0],
        items: isMostFrequentlyGroupLoading
            ? []
            : items
                .filter(function (item) { return mfuGroupIds.indexOf(item.id) > -1; })
                .sort(function (a, b) { return mfuGroupIds.indexOf(a.id) - mfuGroupIds.indexOf(b.id); })
                .map(function (item) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, item), { isFrequentlyUsed: true });
            }),
        isLoading: isMostFrequentlyGroupLoading
    };
    return newGroup.items.length > 0 || newGroup.isLoading ? [newGroup].concat(result) : result;
}
function getFeaturedGroup(items, featuredIds) {
    var featuredItems = items
        .filter(function (item) { return featuredIds.indexOf(item.id) > -1; })
        .sort(function (a, b) { return featuredIds.indexOf(a.id) - featuredIds.indexOf(b.id); });
    return {
        title: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].FEATURED_GROUP[1],
        groupId: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].FEATURED_GROUP[0],
        items: featuredItems
    };
}
function getAlphabeticalGroup(items, featuredIds) {
    var alphabeticalItems = items.filter(function (item) { return featuredIds.indexOf(item.id) === -1; });
    return {
        title: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].ALPHABETICAL_GROUP[1],
        groupId: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].ALPHABETICAL_GROUP[0],
        items: alphabeticalItems
    };
}
function getSectionGroup(items) {
    return {
        title: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].SECTION_GROUP[1],
        groupId: _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].SECTION_GROUP[0],
        items: items
    };
}
function categorizeDefaultGroups(items) {
    // @todo #461149: Leverage item.isInternal to enforce third-party connector web parts to others category.
    var groups = Object(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__["groupBy"])(items, function (item) {
        return PREDEFINED_GROUP_IDS.has(item.groupId) ? item.groupId : _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].OTHER_GROUP[0];
    });
    return _toolboxData__WEBPACK_IMPORTED_MODULE_2__["Group"].PREDEFINED_GROUPS.map(function (_a) {
        var groupId = _a[0], title = _a[1];
        return ({
            title: title,
            groupId: groupId,
            items: groups[groupId] || []
        });
    }).filter(function (group) { return group.items.length > 0; });
}


/***/ }),

/***/ "0OY+":
/*!***********************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupLarge.module.scss.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxGroupLarge.module.css */ "s7ZS");
var styles = {
    flexGroup: 't_f_08a7513e',
    grid: 'u_f_08a7513e',
    spinner: 'v_f_08a7513e',
    eightColumnWide: 'w_f_08a7513e',
    sevenColumnWide: 'x_f_08a7513e',
    sixColumnWide: 'y_f_08a7513e',
    fiveColumnWide: 'z_f_08a7513e',
    fourColumnWide: 'aa_f_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "0Tom":
/*!**********************************************!*\
  !*** ./lib/toolboxChromeV2/ToolboxChrome.js ***!
  \**********************************************/
/*! exports provided: ToolboxChrome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxChrome", function() { return ToolboxChrome; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_components_SearchBox_SearchBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/SearchBox/SearchBox */ "Ldz5");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _toolboxChrome_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../toolboxChrome/ToolboxChromeStrings.resx */ "6KRj");
var _toolboxChrome_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_7___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../toolboxChrome/ToolboxChromeStrings.resx */ "6KRj", 1);
/* harmony import */ var _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ToolboxChrome.module.scss */ "9iAH");









var ToolboxChrome = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxChrome, _super);
    function ToolboxChrome() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._searchBoxContainer = react__WEBPACK_IMPORTED_MODULE_3__["createRef"]();
        _this._commandBar = react__WEBPACK_IMPORTED_MODULE_3__["createRef"]();
        _this._handleSearchChange = function (event, value) {
            _this.props.onChange(value || '');
        };
        _this._handleEscape = function () {
            if (_this.props.searchQuery) {
                _this.props.onChange('');
            }
            else if (_this.props.onEscape) {
                _this.props.onEscape();
            }
        };
        return _this;
    }
    ToolboxChrome.prototype.componentDidMount = function () {
        var _this = this;
        if (this._searchBoxContainer.current) {
            var inputDOMNode = react_dom__WEBPACK_IMPORTED_MODULE_4__["findDOMNode"](this._searchBoxContainer.current);
            if (inputDOMNode && inputDOMNode instanceof Element) {
                var input = inputDOMNode.querySelector('input');
                if (input) {
                    var valueLength = input.value.length;
                    input.setSelectionRange(valueLength, valueLength);
                }
            }
        }
        // This is a workaround to remeasure the command bar width to avoid collapsed button group.
        // Later, we should consumer the animation context for remeasurement and avoid `setTimeout`.
        setTimeout(function () { var _a, _b, _c; return (_c = (_a = _this._commandBar.current) === null || _a === void 0 ? void 0 : (_b = _a).remeasure) === null || _c === void 0 ? void 0 : _c.call(_b); }, 300);
    };
    ToolboxChrome.prototype.render = function () {
        var ariaLabel = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__["StringHelper"].format(_toolboxChrome_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_7__["ToolboxSearchAccessibleLabelTemplate"], this.props.searchQuery ? _toolboxChrome_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_7__["ToolboxSearchEscapeAccessibleLabel"] : '');
        var fluentEnabled = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__["isFluentEnabled"])();
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("div", { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(this.props.className, _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].chrome), ref: this._searchBoxContainer },
            react__WEBPACK_IMPORTED_MODULE_3__["createElement"](office_ui_fabric_react_lib_components_SearchBox_SearchBox__WEBPACK_IMPORTED_MODULE_2__["SearchBox"], { ariaLabel: ariaLabel, placeholder: _toolboxChrome_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_7__["ToolboxSearchLabel"], onChange: this._handleSearchChange, onSearch: this.props.onSearch, onEscape: this._handleEscape, value: this.props.searchQuery, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].searchBox, fluentEnabled && _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].fluent), "data-automation-id": 'toolbox-searchBox' }),
            this._renderCommandBar(),
            react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("div", { className: _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].content, "data-automation-id": 'spPageCanvasLargeToolboxBody' }, this.props.children)));
    };
    ToolboxChrome.prototype._renderCommandBar = function () {
        if (!this.props.commandBar) {
            return null; // tslint:disable-line:no-null-keyword
        }
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["CommandBar"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, this.props.commandBar, { items: this.props.items || [], farItems: this.props.farItems, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(this.props.commandBar.className, _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].commandBar), componentRef: this._commandBar })));
    };
    return ToolboxChrome;
}(react__WEBPACK_IMPORTED_MODULE_3__["PureComponent"]));



/***/ }),

/***/ "1Ic1":
/*!***********************************!*\
  !*** ./lib/toolboxError/index.js ***!
  \***********************************/
/*! exports provided: ToolboxError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxErrorAnimationLayer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxErrorAnimationLayer */ "T4HN");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxError", function() { return _ToolboxErrorAnimationLayer__WEBPACK_IMPORTED_MODULE_0__["ToolboxErrorAnimationLayer"]; });




/***/ }),

/***/ "4G67":
/*!******************************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmall.module.scss.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxSmall.module.css */ "AKYj");
var styles = {
    noResults: 'ba_t_08a7513e',
    calloutContent: 'bb_t_08a7513e',
    noTopicResults: 'bc_t_08a7513e',
    fluent: 'f_t_08a7513e',
    menuCommandBar: 'ax_t_08a7513e',
    selectedItem: 'ay_t_08a7513e',
    sectionHeader: 'be_t_08a7513e',
    menuCommandBarLabel: 'bf_t_08a7513e',
    menuCommandBarCategoryName: 'bg_t_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "5FlS":
/*!***********************************!*\
  !*** ./lib/toolboxGroup/index.js ***!
  \***********************************/
/*! exports provided: ToolboxGroupLarge, ToolboxGroupSmall, categorizeGroups, categorizeGroupsWithMfu, getAlphabeticalGroup, getFeaturedGroup, getSectionGroup */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxGroupLarge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxGroupLarge */ "gTvL");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxGroupLarge", function() { return _ToolboxGroupLarge__WEBPACK_IMPORTED_MODULE_0__["ToolboxGroupLarge"]; });

/* harmony import */ var _ToolboxGroupSmall__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToolboxGroupSmall */ "sJc3");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxGroupSmall", function() { return _ToolboxGroupSmall__WEBPACK_IMPORTED_MODULE_1__["ToolboxGroupSmall"]; });

/* harmony import */ var _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxGroupUtilities */ "00Tc");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "categorizeGroups", function() { return _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__["categorizeGroups"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "categorizeGroupsWithMfu", function() { return _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__["categorizeGroupsWithMfu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getAlphabeticalGroup", function() { return _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__["getAlphabeticalGroup"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getFeaturedGroup", function() { return _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__["getFeaturedGroup"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSectionGroup", function() { return _ToolboxGroupUtilities__WEBPACK_IMPORTED_MODULE_2__["getSectionGroup"]; });






/***/ }),

/***/ "6Jn7":
/*!************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewBase.module.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxItemListViewBase.module.css */ "wNeH");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "6KRj":
/*!*****************************************************!*\
  !*** ./lib/toolboxChrome/ToolboxChromeStrings.resx ***!
  \*****************************************************/
/*! exports provided: ToolboxSearchAccessibleLabelTemplate, ToolboxSearchEscapeAccessibleLabel, ToolboxSearchLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxSearchAccessibleLabelTemplate\":\"ToolboxSearchAccessibleLabelTemplate\",\"ToolboxSearchEscapeAccessibleLabel\":\"ToolboxSearchEscapeAccessibleLabel\",\"ToolboxSearchLabel\":\"ToolboxSearchLabel\"}");

/***/ }),

/***/ "6eS9":
/*!******************************************!*\
  !*** ./lib/toolboxLarge/ViewCategory.js ***!
  \******************************************/
/*! exports provided: ViewCategory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewCategory", function() { return ViewCategory; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-lodash-subset */ "Pk8u");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxItem */ "nKzV");
/* harmony import */ var _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../toolboxItem/ToolboxItemListViewLarge */ "Pocx");







var ViewCategory = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ViewCategory, _super);
    function ViewCategory() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ViewCategory.prototype.render = function () {
        var _this = this;
        var groupIndex = Object(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_1__["findIndex"])(this.props.groups, function (group) { return group.groupId === _this.props.view.groupId; });
        var toolboxGroup = this.props.groups[groupIndex];
        if (Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__["isToolboxUIUpdateEnabled"])() && this.props.groups[groupIndex].isLoading) {
            return react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_4__["ToolboxGroupLarge"], { groupName: toolboxGroup.title, hasHeader: false, isLoading: true });
        }
        // tslint:disable-next-line:variable-name
        var ToolboxItem = this.props.isListView
            ? _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_6__["ToolboxItemListViewLarge"]
            : _toolboxItem__WEBPACK_IMPORTED_MODULE_5__["ToolboxItemLarge"];
        var itemViews = toolboxGroup.items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](ToolboxItem, { key: item.id, item: item, onClick: _this.props.onClickItem })); });
        return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_4__["ToolboxGroupLarge"], { groupName: toolboxGroup.title, hasHeader: false, isListView: this.props.isListView }, itemViews));
    };
    return ViewCategory;
}(react__WEBPACK_IMPORTED_MODULE_2__["PureComponent"]));



/***/ }),

/***/ "7A7I":
/*!******************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLarge.module.scss.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxLarge.module.css */ "o44a");
var styles = {
    toolboxLargeContainer: 'au_s_08a7513e',
    modalScrollContent: 'av_s_08a7513e',
    screenReaderAlert: 'aw_s_08a7513e',
    menuCommandBar: 'ax_s_08a7513e',
    fluent: 'f_s_08a7513e',
    selectedItem: 'ay_s_08a7513e',
    commandBarButton: 'az_s_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "7O2j":
/*!****************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewBase.js ***!
  \****************************************************/
/*! exports provided: ToolboxItemListViewBase, onRenderItemContent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemListViewBase", function() { return ToolboxItemListViewBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onRenderItemContent", function() { return onRenderItemContent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ToolboxItemBase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemBase */ "+FXA");
/* harmony import */ var _legacy_lessText__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../legacy/lessText */ "7fMg");
/* harmony import */ var _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ToolboxItemListViewBase.module.scss */ "k5Hx");






function ToolboxItemListViewBase(props) {
    return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_ToolboxItemBase__WEBPACK_IMPORTED_MODULE_3__["ToolboxItemBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { titleLineCount: props.titleLineCount, itemClassName: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].item, props.itemClassName), itemStyles: { paddingTop: 15, paddingBottom: 15, height: 'auto' }, flexBoxClassName: _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].flexBox, iconClassName: _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].icon, titleClassName: _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].title, "data-item-size": 'large', onRenderItemContent: onRenderItemContent })));
}
function onRenderItemContent(props) {
    var memoProps = react__WEBPACK_IMPORTED_MODULE_2__["useMemo"](function () { return ({
        src: props.item.imageSrc,
        alt: props.item.displayName,
        imageFit: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["ImageFit"].contain
    }); }, [props.item.imageSrc, props.item.displayName, _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["ImageFit"].contain]);
    var imageProps = props.item.imageSrc ? memoProps : undefined;
    var description = props.item.description && (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_legacy_lessText__WEBPACK_IMPORTED_MODULE_4__["LessText"], { className: _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].description, text: props.item.description, showTitle: true, lines: 2, omission: '…' }));
    return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].flexBox, props.flexBoxClassName) },
        react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Icon"], { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].icon, props.iconClassName /*{ [styles.disabled]: props.item.disabled }*/), iconName: props.item.msIconName, iconType: props.item.imageSrc ? _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["IconType"].Image : _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["IconType"].Default, imageProps: imageProps }),
        react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: _ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].content },
            react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_legacy_lessText__WEBPACK_IMPORTED_MODULE_4__["LessText"], { text: props.item.displayName, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxItemListViewBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].title, props.titleClassName), showTitle: true, lines: props.titleLineCount, omission: '…' }),
            description)));
}


/***/ }),

/***/ "8gRP":
/*!********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxSection/ToolboxSectionCore.module.css ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".bl_w_08a7513e{height:auto}", ""]);


/***/ }),

/***/ "9iAH":
/*!**********************************************************!*\
  !*** ./lib/toolboxChromeV2/ToolboxChrome.module.scss.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxChrome.module.css */ "LvzQ");
var styles = {
    chrome: 'c_c_08a7513e',
    searchBox: 'e_c_08a7513e',
    fluent: 'f_c_08a7513e',
    farButton: 'g_c_08a7513e',
    fixButtonFocus: 'h_c_08a7513e',
    commandBar: 'i_c_08a7513e',
    content: 'j_c_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "A+bi":
/*!****************************************!*\
  !*** ./lib/toolboxLarge/ViewSearch.js ***!
  \****************************************/
/*! exports provided: ViewSearch, EmptySearchResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewSearch", function() { return ViewSearch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmptySearchResultComponent", function() { return EmptySearchResultComponent; });
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxItem */ "nKzV");
/* harmony import */ var _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxItem/ToolboxItemListViewLarge */ "Pocx");
/* harmony import */ var _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ToolboxLargeStrings.resx */ "T5+N");
var _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_5___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./ToolboxLargeStrings.resx */ "T5+N", 1);
/* harmony import */ var _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ViewSearch.module.scss */ "OKAE");







function ViewSearch(props) {
    if (props.items.length === 0) {
        // Work around to use an empty group to hold the space when search filters out no items.
        // Pending on @todo VSO#414796 for the final search experience.
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].noResultFoundContainer },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_2__["ToolboxGroupLarge"], { groupName: 'empty', hasHeader: false, key: 'toolboxGroup-empty' }),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](EmptySearchResultComponent, null)));
    }
    // tslint:disable-next-line:variable-name
    var ToolboxItem = props.isListView
        ? _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__["ToolboxItemListViewLarge"]
        : _toolboxItem__WEBPACK_IMPORTED_MODULE_3__["ToolboxItemLarge"];
    var itemViews = props.items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](ToolboxItem, { key: item.id, item: item, onClick: props.onClickItem })); });
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_2__["ToolboxGroupLarge"], { groupName: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_5__["ToolboxCategorySearchResults"], hasHeader: false, isListView: props.isListView }, itemViews));
}
function EmptySearchResultComponent() {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].noResultFound },
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__["Icon"], { iconName: 'Search', className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].noResultFoundIcon }),
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].noResultFoundLabelContainer },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].noResultLabel }, _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_5__["NoResultLabel"]),
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: _ViewSearch_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].tryAgainLabel }, _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_5__["TryAgainLabel"]))));
}


/***/ }),

/***/ "AKYj":
/*!**************************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmall.module.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxSmall.module.css */ "zNYN");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "AgJP":
/*!**************************************************************!*\
  !*** ./lib/toolboxSection/ToolboxSectionCore.module.scss.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxSectionCore.module.css */ "SpX9");
var styles = {
    callout: 'bl_w_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "B2XA":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxItem/ToolboxItemListViewSmall.module.css ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ai_n_08a7513e{color:\"[theme:neutralPrimary, default: #323130]\";font-size:32px;width:80px}.ai_n_08a7513e .ms-Image{width:100%;height:100%}.ag_n_08a7513e{font-size:14px}", ""]);


/***/ }),

/***/ "BwFS":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxGroup/ToolboxGroupLarge.module.css ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".t_f_08a7513e{display:-ms-flexbox;display:flex;-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-pack:start;justify-content:flex-start;-ms-flex-align:center;align-items:center}.u_f_08a7513e{width:128px;height:128px}.v_f_08a7513e{-ms-flex-pack:center;justify-content:center}.w_f_08a7513e{width:1024px}.x_f_08a7513e{width:896px}.y_f_08a7513e{width:768px}.z_f_08a7513e{width:640px}.aa_f_08a7513e{width:512px}", ""]);


/***/ }),

/***/ "C6wz":
/*!****************************************************!*\
  !*** ./lib/toolboxChrome/ToolboxChrome.module.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxChrome.module.css */ "naPD");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "C9I6":
/*!***********************************!*\
  !*** ./lib/toolboxLarge/index.js ***!
  \***********************************/
/*! exports provided: ToolboxLarge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxLargeAnimationLayer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxLargeAnimationLayer */ "MRk2");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxLarge", function() { return _ToolboxLargeAnimationLayer__WEBPACK_IMPORTED_MODULE_0__["ToolboxLargeAnimationLayer"]; });




/***/ }),

/***/ "CUwB":
/*!*****************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemLarge.module.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxItemLarge.module.css */ "TxJO");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "DL5L":
/*!*******************************************!*\
  !*** ./lib/toolboxData/GroupStrings.resx ***!
  \*******************************************/
/*! exports provided: ToolboxCategoryTextMediaAndContent, ToolboxCategoryDiscovery, ToolboxCategoryCommunicationAndCollaboration, ToolboxCategoryPlanningAndProcess, ToolboxCategoryBusinessIntelligence, ToolboxCategorySiteTools, ToolboxCategoryConnectors, ToolboxCategoryOther, ToolboxGroupNameFeatured, ToolboxGroupNameMostFrequently, ToolboxGroupNameAlphabetical, ToolboxGroupNameSection, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxCategoryTextMediaAndContent\":\"ToolboxCategoryTextMediaAndContent\",\"ToolboxCategoryDiscovery\":\"ToolboxCategoryDiscovery\",\"ToolboxCategoryCommunicationAndCollaboration\":\"ToolboxCategoryCommunicationAndCollaboration\",\"ToolboxCategoryPlanningAndProcess\":\"ToolboxCategoryPlanningAndProcess\",\"ToolboxCategoryBusinessIntelligence\":\"ToolboxCategoryBusinessIntelligence\",\"ToolboxCategorySiteTools\":\"ToolboxCategorySiteTools\",\"ToolboxCategoryConnectors\":\"ToolboxCategoryConnectors\",\"ToolboxCategoryOther\":\"ToolboxCategoryOther\",\"ToolboxGroupNameFeatured\":\"ToolboxGroupNameFeatured\",\"ToolboxGroupNameMostFrequently\":\"ToolboxGroupNameMostFrequently\",\"ToolboxGroupNameAlphabetical\":\"ToolboxGroupNameAlphabetical\",\"ToolboxGroupNameSection\":\"ToolboxGroupNameSection\"}");

/***/ }),

/***/ "ETZn":
/*!**********************************!*\
  !*** ./lib/toolboxView/index.js ***!
  \**********************************/
/*! exports provided: ViewProvider, ViewConsumer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _View__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./View */ "yE+t");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ViewProvider", function() { return _View__WEBPACK_IMPORTED_MODULE_0__["ViewProvider"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ViewConsumer", function() { return _View__WEBPACK_IMPORTED_MODULE_0__["ViewConsumer"]; });




/***/ }),

/***/ "FSMX":
/*!**************************************************!*\
  !*** ./lib/toolboxError/ToolboxError.module.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxError.module.css */ "JNet");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "GqUw":
/*!******************************************!*\
  !*** ./lib/toolbox/ToolboxItemsLayer.js ***!
  \******************************************/
/*! exports provided: ToolboxItemsLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemsLayer", function() { return ToolboxItemsLayer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _toolboxError__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxError */ "1Ic1");
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxLoading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxLoading */ "NpD7");
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxProviderLayer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ToolboxProviderLayer */ "ntxq");








/**
 * The toolbox items layer to dispatch the state of load the items.
 *
 * - If the items are not loaded, show ToolboxLoading.
 * - If the items are failed to load, show ToolboxError.
 * - If the items are loaded successfully, show Toolbox.
 */
var ToolboxItemsLayer = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxItemsLayer, _super);
    function ToolboxItemsLayer(props) {
        var _this = _super.call(this, props) || this;
        _this._clickItem = function (toolboxItemId, info) {
            var _a;
            if (!_this.state.mapToolboxItemIdToData) {
                // The `props.items` is not available yet, how does click item action come from?
                return;
            }
            var data = _this.state.mapToolboxItemIdToData.get(toolboxItemId);
            if (!data) {
                // It is clicking on an non-existing toolbox item. How does it happen?
                return;
            }
            if (Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__["isToolboxUIUpdateEnabled"])()) {
                (_a = _this.props.toolboxWebPartsManager) === null || _a === void 0 ? void 0 : _a.recordWebPartUsage(toolboxItemId).catch(function (error) {
                    _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_TraceLogger"].logError(ToolboxItemsLayer._logSource, error, 'ToolboxItemsLayer._clickItem');
                });
            }
            // The canvas is modifying the original object. We need to clone the control here.
            // This could be finally fixed after leverage item ID in toolbox click handler.
            _this.props.onClickItem(data, info);
            // Close the toolbox after handling the click item logics.
            _this.props.onCloseToolbox();
        };
        _this.state = _this._getState(props.items);
        return _this;
    }
    ToolboxItemsLayer.prototype.componentDidMount = function () {
        this._markStageToolboxRenderEnd();
    };
    ToolboxItemsLayer.prototype.componentDidUpdate = function () {
        this._markStageToolboxRenderEnd();
    };
    ToolboxItemsLayer.prototype.UNSAFE_componentWillReceiveProps = function (nextProps) {
        if (nextProps.items !== this.props.items) {
            this.setState(this._getState(nextProps.items));
        }
    };
    ToolboxItemsLayer.prototype.render = function () {
        var items = this.state.items;
        if (items === undefined) {
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxLoading__WEBPACK_IMPORTED_MODULE_5__["ToolboxLoading"], { className: '', controller: this.props.controller, calloutTarget: this.props.calloutTarget, calloutDirectionalHint: this.props.calloutDirectionalHint, onDismiss: this.props.onDismiss }));
        }
        else if (Array.isArray(items)) {
            var groups = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__["isToolboxUIUpdateEnabled"])()
                ? Object(_toolboxGroup__WEBPACK_IMPORTED_MODULE_4__["categorizeGroupsWithMfu"])(items, this.props.mostFrequentlyIds, this.props.isMostFrequentlyGroupLoading)
                : Object(_toolboxGroup__WEBPACK_IMPORTED_MODULE_4__["categorizeGroups"])(items, this.props.featuredIds);
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_ToolboxProviderLayer__WEBPACK_IMPORTED_MODULE_7__["ToolboxProviderLayer"], { controller: this.props.controller, items: items, groups: groups, a11yManager: this.props.a11yManager, onCloseToolbox: this.props.onCloseToolbox, calloutTarget: this.props.calloutTarget, calloutDirectionalHint: this.props.calloutDirectionalHint, onDismiss: this.props.onDismiss, onClickItem: this._clickItem, featuredIds: this.props.featuredIds, pageLayoutType: this.props.pageLayoutType }));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxError__WEBPACK_IMPORTED_MODULE_3__["ToolboxError"], { className: '', controller: this.props.controller, message: items.message, a11yManager: this.props.a11yManager, calloutTarget: this.props.calloutTarget, calloutDirectionalHint: this.props.calloutDirectionalHint, onDismiss: this.props.onDismiss }));
        }
    };
    ToolboxItemsLayer.prototype._getState = function (items) {
        var _this = this;
        if (Array.isArray(items)) {
            var sortedItems = items.sort(function (a, b) {
                return a.displayName.localeCompare(b.displayName, _this.props.cultureName);
            });
            return {
                items: sortedItems,
                mapToolboxItemIdToData: new Map(sortedItems.map(function (map) { return [map.id, map.itemData]; }))
            };
        }
        else {
            return {
                items: items,
                mapToolboxItemIdToData: undefined
            };
        }
    };
    ToolboxItemsLayer.prototype._markStageToolboxRenderEnd = function () {
        if (this.props.componentPerfLogger && this.state.items !== undefined) {
            this.props.componentPerfLogger.end('ToolboxRender');
        }
    };
    ToolboxItemsLayer._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogSource"].create('ToolboxOpenLayer');
    return ToolboxItemsLayer;
}(react__WEBPACK_IMPORTED_MODULE_2__["PureComponent"]));



/***/ }),

/***/ "JNet":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxError/ToolboxError.module.css ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".b_b_08a7513e{background-color:\"[theme:errorBackground, default: rgba(232,17,35,.2)]\";font-weight:600;font-size:12px;letter-spacing:1px;padding:0 12px}", ""]);


/***/ }),

/***/ "LcaF":
/*!**************************************!*\
  !*** ./lib/toolboxLarge/ViewHome.js ***!
  \**************************************/
/*! exports provided: ViewHome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewHome", function() { return ViewHome; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxItem */ "nKzV");
/* harmony import */ var _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxItem/ToolboxItemListViewLarge */ "Pocx");
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");






var ViewHome = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ViewHome, _super);
    function ViewHome() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._handleClickSeeAll = function (groupId) {
            _this.props.onSwitchToCategoryView(groupId);
        };
        return _this;
    }
    ViewHome.prototype.render = function () {
        return react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", null, this._renderGroups());
    };
    ViewHome.prototype._renderGroups = function () {
        var _this = this;
        return this.props.groups.map(function (group) {
            return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_2__["ToolboxGroupLarge"], { groupName: group.title, hasHeader: true, key: group.groupId, isListView: _this.props.isListView, 
                // tslint:disable-next-line: react-this-binding-issue
                onClickSeeAll: function () { return _this._handleClickSeeAll(group.groupId); }, isLoading: Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_5__["isToolboxUIUpdateEnabled"])() && group.isLoading }, Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_5__["isToolboxUIUpdateEnabled"])() && group.isLoading ? undefined : _this._renderItems(group.items)));
        });
    };
    ViewHome.prototype._renderItems = function (items) {
        var _this = this;
        // tslint:disable-next-line:variable-name
        var ToolboxItem = this.props.isListView
            ? _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__["ToolboxItemListViewLarge"]
            : _toolboxItem__WEBPACK_IMPORTED_MODULE_3__["ToolboxItemLarge"];
        return items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](ToolboxItem, { key: item.id, item: item, onClick: _this.props.onClickItem })); });
    };
    return ViewHome;
}(react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]));



/***/ }),

/***/ "LvzQ":
/*!******************************************************!*\
  !*** ./lib/toolboxChromeV2/ToolboxChrome.module.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxChrome.module.css */ "PshT");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "MRk2":
/*!********************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLargeAnimationLayer.js ***!
  \********************************************************/
/*! exports provided: ToolboxLargeAnimationLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxLargeAnimationLayer", function() { return ToolboxLargeAnimationLayer; });
/* harmony import */ var _toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../toolboxAnimation */ "Xs01");
/* harmony import */ var _ToolboxLargeSearchLayer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToolboxLargeSearchLayer */ "b4B8");


// tslint:disable-next-line:variable-name
var ToolboxLargeAnimationLayer = Object(_toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__["animation"])(_ToolboxLargeSearchLayer__WEBPACK_IMPORTED_MODULE_1__["ToolboxLargeSearchLayer"], 4 /* Large */);


/***/ }),

/***/ "N/ia":
/*!*************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewSmall.module.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxItemListViewSmall.module.css */ "B2XA");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "N03I":
/*!**************************************!*\
  !*** ./lib/toolboxLarge/ViewSort.js ***!
  \**************************************/
/*! exports provided: ViewSort */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewSort", function() { return ViewSort; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxItem */ "nKzV");
/* harmony import */ var _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxItem/ToolboxItemListViewLarge */ "Pocx");





var ViewSort = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ViewSort, _super);
    function ViewSort() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ViewSort.prototype.render = function () {
        var _this = this;
        // tslint:disable-next-line:variable-name
        var ToolboxItem = this.props.isListView
            ? _toolboxItem_ToolboxItemListViewLarge__WEBPACK_IMPORTED_MODULE_4__["ToolboxItemListViewLarge"]
            : _toolboxItem__WEBPACK_IMPORTED_MODULE_3__["ToolboxItemLarge"];
        var itemViews = this.props.items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](ToolboxItem, { key: item.id, item: item, onClick: _this.props.onClickItem })); });
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_2__["ToolboxGroupLarge"], { groupName: '', hasHeader: false, isListView: this.props.isListView }, itemViews));
    };
    return ViewSort;
}(react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]));



/***/ }),

/***/ "NB1n":
/*!********************************************************!*\
  !*** ./lib/toolboxChrome/ToolboxChrome.module.scss.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxChrome.module.css */ "C6wz");
var styles = {
    chrome: 'c_g_08a7513e',
    searchBox: 'e_g_08a7513e',
    fluent: 'f_g_08a7513e',
    farButton: 'g_g_08a7513e',
    fixButtonFocus: 'h_g_08a7513e',
    commandBar: 'i_g_08a7513e',
    content: 'j_g_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "OKAE":
/*!****************************************************!*\
  !*** ./lib/toolboxLarge/ViewSearch.module.scss.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ViewSearch.module.css */ "SCJu");
var styles = {
    noResultFoundContainer: 'an_p_08a7513e',
    noResultFound: 'ao_p_08a7513e',
    noResultFoundIcon: 'ap_p_08a7513e',
    noResultFoundLabelContainer: 'aq_p_08a7513e',
    noResultLabel: 'ar_p_08a7513e',
    tryAgainLabel: 'as_p_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "Pocx":
/*!*****************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewLarge.js ***!
  \*****************************************************/
/*! exports provided: ToolboxItemListViewLarge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemListViewLarge", function() { return ToolboxItemListViewLarge; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxItemListViewBase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxItemListViewBase */ "7O2j");
/* harmony import */ var _ToolboxItemListViewLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemListViewLarge.module.scss */ "pGsU");




function ToolboxItemListViewLarge(props) {
    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxItemListViewBase__WEBPACK_IMPORTED_MODULE_2__["ToolboxItemListViewBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { iconClassName: _ToolboxItemListViewLarge_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].icon, titleLineCount: 1 }));
}


/***/ }),

/***/ "PshT":
/*!****************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxChromeV2/ToolboxChrome.module.css ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".c_c_08a7513e{height:100%;position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.c_c_08a7513e .e_c_08a7513e{-ms-flex:0 0 auto;flex:0 0 auto;box-sizing:border-box;height:32px;border:none;background-color:\"[theme:neutralLighter, default: #f3f2f1]\";border-radius:2px;margin:12px 12px 0}.c_c_08a7513e .e_c_08a7513e:not(.f_c_08a7513e){border-width:0}.c_c_08a7513e .e_c_08a7513e:after{border:none}.c_c_08a7513e .g_c_08a7513e{box-sizing:border-box;width:32px;height:32px;position:absolute;top:12px}[dir=ltr] .c_c_08a7513e .g_c_08a7513e{right:12px}[dir=rtl] .c_c_08a7513e .g_c_08a7513e{left:12px}.c_c_08a7513e .g_c_08a7513e.h_c_08a7513e{color:\"[theme:neutralSecondary, default: #605e5c]\"}.c_c_08a7513e .g_c_08a7513e:hover.h_c_08a7513e{background-color:transparent;color:\"[theme:themeDarkAlt, default: #106ebe]\"}.c_c_08a7513e .i_c_08a7513e{-ms-flex:0 0 auto;flex:0 0 auto;border-bottom:1px solid;border-color:\"[theme:neutralquaternaryalt, default: #e1dfdd]\"}.c_c_08a7513e .j_c_08a7513e{-ms-flex:1 1 auto;flex:1 1 auto;overflow-y:scroll;height:100%}", ""]);


/***/ }),

/***/ "QVSF":
/*!**************************************!*\
  !*** ./lib/toolboxChromeV2/index.js ***!
  \**************************************/
/*! exports provided: ToolboxChrome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxChrome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxChrome */ "0Tom");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxChrome", function() { return _ToolboxChrome__WEBPACK_IMPORTED_MODULE_0__["ToolboxChrome"]; });




/***/ }),

/***/ "RaMy":
/*!*************************************************!*\
  !*** ./lib/toolboxViewSwitcher/ViewSwitcher.js ***!
  \*************************************************/
/*! exports provided: ViewSwitcher */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewSwitcher", function() { return ViewSwitcher; });
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ViewSwitcher.module.scss */ "no+9");



function ViewSwitcher(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("div", { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__["css"])(_ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].viewSwitcher, props.isListView ? _ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].list : _ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].grid), onClick: props.onClick, "data-is-focusable": true, "aria-label": props.ariaLabel, role: 'button' },
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__["Icon"], { iconName: 'GridViewSmall', className: _ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].gridIcon }),
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_0__["Icon"], { iconName: 'GroupedList', className: _ViewSwitcher_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].listIcon })));
}


/***/ }),

/***/ "SCJu":
/*!************************************************!*\
  !*** ./lib/toolboxLarge/ViewSearch.module.css ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ViewSearch.module.css */ "/U0d");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "SISZ":
/*!********************************************!*\
  !*** ./lib/toolboxChrome/ToolboxChrome.js ***!
  \********************************************/
/*! exports provided: ToolboxChrome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxChrome", function() { return ToolboxChrome; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var office_ui_fabric_react_lib_components_SearchBox_SearchBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/SearchBox/SearchBox */ "Ldz5");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ToolboxChrome.module.scss */ "NB1n");
/* harmony import */ var _ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ToolboxChromeStrings.resx */ "6KRj");
var _ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./ToolboxChromeStrings.resx */ "6KRj", 1);









var ToolboxChrome = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxChrome, _super);
    function ToolboxChrome() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._searchBoxContainer = null; // tslint:disable-line:no-null-keyword
        _this._commandBar = react__WEBPACK_IMPORTED_MODULE_3__["createRef"]();
        _this._setRef = function (instance) {
            _this._searchBoxContainer = instance;
        };
        _this._handleSearchChange = function (event, value) {
            _this.props.onChange(value || '');
        };
        _this._handleEscape = function () {
            if (_this.props.searchQuery) {
                _this.props.onChange('');
            }
            else if (_this.props.onEscape) {
                _this.props.onEscape();
            }
        };
        return _this;
    }
    ToolboxChrome.prototype.componentDidMount = function () {
        var _this = this;
        if (this._searchBoxContainer) {
            var inputDOMNode = react_dom__WEBPACK_IMPORTED_MODULE_4__["findDOMNode"](this._searchBoxContainer);
            if (inputDOMNode && inputDOMNode instanceof Element) {
                var input = inputDOMNode.querySelector('input');
                if (input) {
                    var valueLength = input.value.length;
                    input.setSelectionRange(valueLength, valueLength);
                }
            }
        }
        // This is a workaround to remeasure the command bar width to avoid collapsed button group.
        // Later, we should consumer the animation context for remeasurement and avoid `setTimeout`.
        setTimeout(function () {
            if (_this._commandBar.current) {
                _this._commandBar.current.remeasure();
            }
        }, 300);
    };
    ToolboxChrome.prototype.render = function () {
        var ariaLabel = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_5__["StringHelper"].format(_ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_8__["ToolboxSearchAccessibleLabelTemplate"], this.props.searchQuery ? _ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_8__["ToolboxSearchEscapeAccessibleLabel"] : '');
        var fluentEnabled = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__["isFluentEnabled"])();
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("div", { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(this.props.className, _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].chrome), ref: this._setRef },
            react__WEBPACK_IMPORTED_MODULE_3__["createElement"](office_ui_fabric_react_lib_components_SearchBox_SearchBox__WEBPACK_IMPORTED_MODULE_2__["SearchBox"], { ariaLabel: ariaLabel, placeholder: _ToolboxChromeStrings_resx__WEBPACK_IMPORTED_MODULE_8__["ToolboxSearchLabel"], onChange: this._handleSearchChange, onSearch: this.props.onSearch, onEscape: this._handleEscape, value: this.props.searchQuery, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].searchBox, fluentEnabled && _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].fluent), "data-automation-id": 'toolbox-searchBox' }),
            this._renderCommandBar(),
            react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("div", { className: _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].content, "data-automation-id": 'spPageCanvasLargeToolboxBody' }, this.props.children),
            react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["IconButton"]
            // tslint:disable-next-line:react-tsx-curly-spacing
            , { 
                // tslint:disable-next-line:react-tsx-curly-spacing
                className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].farButton, !Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_6__["isFixButtonFocusStyleKillSwitchActivated"])() && _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].fixButtonFocus), iconProps: this.props.farButton.iconProps, onClick: this.props.farButton.onClick, title: this.props.farButton.title, ariaLabel: this.props.farButton.ariaLabel, ariaDescription: this.props.farButton.ariaDescription, "data-automation-id": 'toolbox-farButton' })));
    };
    ToolboxChrome.prototype._renderCommandBar = function () {
        if (!this.props.commandBar) {
            return null; // tslint:disable-line:no-null-keyword
        }
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["CommandBar"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, this.props.commandBar, { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(this.props.commandBar.className, _ToolboxChrome_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].commandBar), componentRef: this._commandBar })));
    };
    return ToolboxChrome;
}(react__WEBPACK_IMPORTED_MODULE_3__["PureComponent"]));



/***/ }),

/***/ "SpX9":
/*!**********************************************************!*\
  !*** ./lib/toolboxSection/ToolboxSectionCore.module.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxSectionCore.module.css */ "8gRP");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "St2D":
/*!*************************************************!*\
  !*** ./lib/toolboxSection/ToolboxItemsLayer.js ***!
  \*************************************************/
/*! exports provided: ToolboxItemsLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemsLayer", function() { return ToolboxItemsLayer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxSectionCore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxSectionCore */ "k8VM");



var ToolboxItemsLayer = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxItemsLayer, _super);
    function ToolboxItemsLayer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._handleClickItem = function (sectionItemId) {
            var clickedItem = _this.props.items.filter(function (item) { return item.id === sectionItemId; })[0];
            if (!clickedItem) {
                // It is clicking on an non-existing section item. How does it happen?
                return;
            }
            // The canvas is modifying the original object. We need to clone the control here.
            // This could be finally fixed after leverage item ID in toolbox click handler.
            _this.props.onClickItem(clickedItem.itemData);
            // Close the toolbox after handling the click item logics.
            _this.props.onCloseToolbox();
        };
        return _this;
    }
    ToolboxItemsLayer.prototype.componentDidMount = function () {
        this._markStageToolboxRenderEnd();
    };
    ToolboxItemsLayer.prototype.componentDidUpdate = function () {
        this._markStageToolboxRenderEnd();
    };
    ToolboxItemsLayer.prototype.render = function () {
        return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxSectionCore__WEBPACK_IMPORTED_MODULE_2__["ToolboxSectionCore"], { items: this.props.items, a11yManager: this.props.a11yManager, calloutTarget: this.props.calloutTarget, calloutDirectionalHint: this.props.calloutDirectionalHint, onDismiss: this.props.onDismiss, onCloseToolbox: this.props.onCloseToolbox, onClickItem: this._handleClickItem }));
    };
    ToolboxItemsLayer.prototype._markStageToolboxRenderEnd = function () {
        if (this.props.componentPerfLogger) {
            this.props.componentPerfLogger.end('ToolboxRender');
        }
    };
    return ToolboxItemsLayer;
}(react__WEBPACK_IMPORTED_MODULE_1__["PureComponent"]));



/***/ }),

/***/ "T4HN":
/*!********************************************************!*\
  !*** ./lib/toolboxError/ToolboxErrorAnimationLayer.js ***!
  \********************************************************/
/*! exports provided: ToolboxErrorAnimationLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxErrorAnimationLayer", function() { return ToolboxErrorAnimationLayer; });
/* harmony import */ var _toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../toolboxAnimation */ "Xs01");
/* harmony import */ var _ToolboxError__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToolboxError */ "VjZh");


// tslint:disable-next-line:variable-name
var ToolboxErrorAnimationLayer = Object(_toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__["animation"])(_ToolboxError__WEBPACK_IMPORTED_MODULE_1__["ToolboxError"], 2 /* Error */);


/***/ }),

/***/ "T5+N":
/*!***************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLargeStrings.resx ***!
  \***************************************************/
/*! exports provided: ToolboxCategoryAllCategory, ToolboxCategorySortingCategory, ToolboxCategorySearchResults, ToolboxCollapseButtonDescription, NoResultLabel, TryAgainLabel, LargeToolboxAriaTitle, ToolboxCollapseButtonAriaLabel, DropDownMenuAriaLabel, SwitchCategoryAlert, BackButtonAriaLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxCategoryAllCategory\":\"ToolboxCategoryAllCategory\",\"ToolboxCategorySortingCategory\":\"ToolboxCategorySortingCategory\",\"ToolboxCategorySearchResults\":\"ToolboxCategorySearchResults\",\"ToolboxCollapseButtonDescription\":\"ToolboxCollapseButtonDescription\",\"NoResultLabel\":\"NoResultLabel\",\"TryAgainLabel\":\"TryAgainLabel\",\"LargeToolboxAriaTitle\":\"LargeToolboxAriaTitle\",\"ToolboxCollapseButtonAriaLabel\":\"ToolboxCollapseButtonAriaLabel\",\"DropDownMenuAriaLabel\":\"DropDownMenuAriaLabel\",\"SwitchCategoryAlert\":\"SwitchCategoryAlert\",\"BackButtonAriaLabel\":\"BackButtonAriaLabel\"}");

/***/ }),

/***/ "TBAh":
/*!*********************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemSmall.js ***!
  \*********************************************/
/*! exports provided: ToolboxItemSmall */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemSmall", function() { return ToolboxItemSmall; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxItemBase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemBase */ "+FXA");
/* harmony import */ var _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxItemSmall.module.scss */ "ZPLP");





function ToolboxItemSmall(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxItemBase__WEBPACK_IMPORTED_MODULE_3__["ToolboxItemBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { titleLineCount: 2, itemClassName: Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_2__["isToolboxUIUpdateEnabled"])() ? _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].itemUxUpdate : _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].item, itemStyles: { height: 88 }, flexBoxClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].flexBox, iconClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].icon, titleClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].title, "data-item-size": 'small' })));
}


/***/ }),

/***/ "Tr0R":
/*!***************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupStrings.resx ***!
  \***************************************************/
/*! exports provided: ToolboxGroupSeeAllButtonLabel, ToolboxGroupSeeAllButtonAriaLabel, ToolboxGroupAriaLabel, ToolboxGroupListViewAriaLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxGroupSeeAllButtonLabel\":\"ToolboxGroupSeeAllButtonLabel\",\"ToolboxGroupSeeAllButtonAriaLabel\":\"ToolboxGroupSeeAllButtonAriaLabel\",\"ToolboxGroupAriaLabel\":\"ToolboxGroupAriaLabel\",\"ToolboxGroupListViewAriaLabel\":\"ToolboxGroupListViewAriaLabel\"}");

/***/ }),

/***/ "TxJO":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxItem/ToolboxItemLarge.module.css ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ag_m_08a7513e{height:100%;width:100%;border-width:2px}.ah_m_08a7513e{padding:23px 8px 0}.ah_m_08a7513e>*+*{margin-top:8px}.ai_m_08a7513e{width:82px;height:32px;min-height:32px;font-size:32px;line-height:32px}.ak_m_08a7513e{font-size:14px}", ""]);


/***/ }),

/***/ "U6dd":
/*!******************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmall.js ***!
  \******************************************/
/*! exports provided: ALL_BY_CATEGORY_KEY, ALL_A_TO_Z_KEY, ToolboxSmall */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_BY_CATEGORY_KEY", function() { return ALL_BY_CATEGORY_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_A_TO_Z_KEY", function() { return ALL_A_TO_Z_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxSmall", function() { return ToolboxSmall; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _toolboxCallout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxCallout */ "GNkg");
/* harmony import */ var _toolboxChrome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxChrome */ "veAR");
/* harmony import */ var _toolboxChromeV2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../toolboxChromeV2 */ "QVSF");
/* harmony import */ var _toolboxGroup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../toolboxGroup */ "5FlS");
/* harmony import */ var _toolboxItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../toolboxItem */ "nKzV");
/* harmony import */ var _toolboxViewSwitcher__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../toolboxViewSwitcher */ "XYP4");
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _toolboxItem_ToolboxItemListViewSmall__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../toolboxItem/ToolboxItemListViewSmall */ "VUzZ");
/* harmony import */ var _ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ToolboxSmall.module.scss */ "4G67");
/* harmony import */ var _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ToolboxSmallStrings.resx */ "nr2j");
var _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./ToolboxSmallStrings.resx */ "nr2j", 1);














var ALL_BY_CATEGORY_KEY = 'allByCategory';
var ALL_A_TO_Z_KEY = 'allAToZ';
var ToolboxSmall = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxSmall, _super);
    function ToolboxSmall(props) {
        var _this = _super.call(this, props) || this;
        _this._handleClickItem = function (toolboxItemId) {
            _this.props.onClickItem(toolboxItemId, {
                size: 'Small',
                query: _this.props.query
            });
        };
        _this.state = _this._getState(props.items);
        return _this;
    }
    ToolboxSmall.prototype.UNSAFE_componentWillReceiveProps = function (nextProps) {
        if (nextProps.items !== this.props.items) {
            this.setState(this._getState(nextProps.items));
        }
    };
    ToolboxSmall.prototype.render = function () {
        var expandButtonProps = {
            ariaLabel: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxExpandButtonAriaLabel"],
            iconProps: { iconName: 'fullScreen' },
            onClick: this.props.onExpandToolbox,
            title: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxExpandButtonTitle"]
        };
        var commandBarProps = ToolboxSmall.toolboxUIUpdateEnabled
            ? {
                items: this._commandBarItems,
                className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].menuCommandBar)
            }
            : undefined;
        // tslint:disable-next-line:variable-name
        var ToolboxChrome = ToolboxSmall.toolboxUIUpdateEnabled
            ? _toolboxChromeV2__WEBPACK_IMPORTED_MODULE_6__["ToolboxChrome"]
            : _toolboxChrome__WEBPACK_IMPORTED_MODULE_5__["ToolboxChrome"];
        var viewElement = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_10__["isToolboxUIUpdateEnabled"])() ? (this._renderView(ToolboxSmall.toolboxUIUpdateEnabled)) : (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZone"], { direction: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZoneDirection"].horizontal, isCircularNavigation: true }, this._renderView(ToolboxSmall.toolboxUIUpdateEnabled)));
        var toolboxSmallContent = (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](ToolboxChrome, { onSearch: this.props.onFilter, onChange: this.props.onFilterDebounce, onEscape: this.props.onCloseToolbox, searchQuery: this.props.query, farButton: expandButtonProps, className: _ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].calloutContent, commandBar: commandBarProps, items: this._commandBarItems, farItems: this._farCommandBarItems }, viewElement));
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxCallout__WEBPACK_IMPORTED_MODULE_4__["ToolboxCallout"], { onDismiss: this.props.onDismiss, target: this.props.calloutTarget, className: this.props.className, directionalHint: this.props.calloutDirectionalHint }, toolboxSmallContent));
    };
    Object.defineProperty(ToolboxSmall.prototype, "_farCommandBarItems", {
        get: function () {
            var _this = this;
            return [
                {
                    key: 'ViewSwitcher',
                    onRender: function () { return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxViewSwitcher__WEBPACK_IMPORTED_MODULE_9__["ViewSwitcher"], { ariaLabel: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ListGridViewSwitcherAriaLabel"], isListView: _this.props.isListView, onClick: _this.props.toggleListView })); }
                }
            ];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ToolboxSmall.prototype, "_commandBarItems", {
        get: function () {
            var _this = this;
            var _a = this.props.selectedCategory, selectedCategoryKey = _a[0], selectedCategoryName = _a[1];
            var subMenuForGroup = this.props.groups.map(function (group) { return ({
                key: group.groupId,
                name: group.title,
                onClick: _this.props.changeView,
                iconProps: {
                    iconName: group.groupId === selectedCategoryKey ? 'CheckMark' : ''
                }
            }); });
            var subMenuForView = [
                {
                    key: ALL_BY_CATEGORY_KEY,
                    name: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxCategoryAllCategory"],
                    onClick: this.props.changeView,
                    iconProps: {
                        iconName: ALL_BY_CATEGORY_KEY === selectedCategoryKey ? 'CheckMark' : ''
                    }
                },
                {
                    key: ALL_A_TO_Z_KEY,
                    name: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxCategorySortingCategory"],
                    onClick: this.props.changeView,
                    iconProps: {
                        iconName: ALL_A_TO_Z_KEY === selectedCategoryKey ? 'CheckMark' : ''
                    }
                }
            ];
            var commandBarMenus = [
                {
                    key: 'CategoryContextualMenu',
                    name: selectedCategoryName,
                    title: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxSortAndFilterTooltop"],
                    subMenuProps: {
                        directionalHint: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["DirectionalHint"].bottomRightEdge,
                        calloutProps: {
                            calloutMaxHeight: 235
                        },
                        items: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(subMenuForView, [
                            {
                                key: 'CategorySection',
                                itemType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["ContextualMenuItemType"].Section,
                                sectionProps: {
                                    topDivider: true,
                                    items: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])([
                                        {
                                            key: 'CategoryHeader',
                                            itemType: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["ContextualMenuItemType"].Header,
                                            itemProps: {
                                                hasIcons: false
                                            },
                                            text: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxDropdownSubmenuTitle"],
                                            className: _ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].sectionHeader
                                        }
                                    ], subMenuForGroup)
                                }
                            }
                        ])
                    },
                    role: 'navigation',
                    ariaLabel: _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__["StringHelper"].format(_ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["DropDownMenuAriaLabel"], selectedCategoryName),
                    className: _ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].menuCommandBarCategoryName
                }
            ];
            return commandBarMenus;
        },
        enumerable: true,
        configurable: true
    });
    ToolboxSmall.prototype._renderView = function (toolboxUIUpdateEnabled) {
        var _this = this;
        var itemsNotFound = this.state.featuredGroup.items.length === 0 && this.state.mainGroup.items.length === 0;
        var view = this.props.view;
        if (!toolboxUIUpdateEnabled) {
            return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](react__WEBPACK_IMPORTED_MODULE_3__["Fragment"], null,
                this._renderGroup(this.state.featuredGroup),
                this._renderGroup(this.state.mainGroup),
                itemsNotFound && this._itemsNotFound));
        }
        if (this.props.query) {
            var searchResult = this.props.items.length
                ? this._renderGroup({
                    title: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxCategorySearchResults"],
                    groupId: _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxCategorySearchResults"],
                    items: this.props.items
                })
                : this._itemsNotFound;
            return react__WEBPACK_IMPORTED_MODULE_3__["createElement"](react__WEBPACK_IMPORTED_MODULE_3__["Fragment"], null, searchResult);
        }
        if (view.type === "Home" /* Home */) {
            return this.props.groups.map(function (group) { return _this._renderGroup(group); });
        }
        if (view.type === "Sort" /* Sort */) {
            return this._renderGroup(this.state.mainGroup);
        }
        if (view.type === "Category" /* Category */) {
            return this._renderGroup(this.props.groups.filter(function (group) { return group.groupId === view.groupId; })[0]);
        }
        return false;
    };
    ToolboxSmall.prototype._renderGroup = function (group) {
        var _this = this;
        if (Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_10__["isToolboxUIUpdateEnabled"])() && group.isLoading) {
            return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_7__["ToolboxGroupSmall"], { key: group.groupId, groupName: group.title, hasHeader: true },
                react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Spinner"], { styles: { root: { marginTop: 10, marginBottom: 10 } } })));
        }
        if (group.items.length === 0) {
            return false;
        }
        var isListView = ToolboxSmall.toolboxUIUpdateEnabled && this.props.isListView;
        // tslint:disable-next-line:variable-name
        var ToolboxItem = isListView
            ? _toolboxItem_ToolboxItemListViewSmall__WEBPACK_IMPORTED_MODULE_11__["ToolboxItemListViewSmall"]
            : _toolboxItem__WEBPACK_IMPORTED_MODULE_8__["ToolboxItemSmall"];
        var items = group.items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](ToolboxItem, { key: item.id, item: item, onClick: _this._handleClickItem })); });
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxGroup__WEBPACK_IMPORTED_MODULE_7__["ToolboxGroupSmall"], { key: group.groupId, groupName: group.title, hasHeader: true, isListView: isListView }, items));
    };
    Object.defineProperty(ToolboxSmall.prototype, "_itemsNotFound", {
        get: function () {
            return react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("span", { className: _ToolboxSmall_module_scss__WEBPACK_IMPORTED_MODULE_12__["default"].noResults }, _ToolboxSmallStrings_resx__WEBPACK_IMPORTED_MODULE_13__["ToolboxNoItemsFound"]);
        },
        enumerable: true,
        configurable: true
    });
    ToolboxSmall.prototype._getState = function (items) {
        var featuredGroup = Object(_toolboxGroup__WEBPACK_IMPORTED_MODULE_7__["getFeaturedGroup"])(items, this.props.featuredIds);
        var mainGroup = Object(_toolboxGroup__WEBPACK_IMPORTED_MODULE_7__["getAlphabeticalGroup"])(items, this.props.featuredIds);
        return {
            featuredGroup: featuredGroup,
            mainGroup: mainGroup
        };
    };
    ToolboxSmall.toolboxUIUpdateEnabled = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_10__["isToolboxUIUpdateEnabled"])();
    return ToolboxSmall;
}(react__WEBPACK_IMPORTED_MODULE_3__["PureComponent"]));



/***/ }),

/***/ "UAnW":
/*!*****************************************!*\
  !*** ./lib/toolbox/ToolboxSizeLayer.js ***!
  \*****************************************/
/*! exports provided: ToolboxSizeLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxSizeLayer", function() { return ToolboxSizeLayer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ms_sp_telemetry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/sp-telemetry */ "2q6Q");
/* harmony import */ var _ms_sp_telemetry__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ms_sp_telemetry__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _toolboxLarge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxLarge */ "C9I6");
/* harmony import */ var _toolboxSmall__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxSmall */ "msj5");
/**
 * @copyright Microsoft Corporation. All rights reserved.
 */






var ToolboxSizeLayer = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxSizeLayer, _super);
    function ToolboxSizeLayer(props) {
        var _this = _super.call(this, props) || this;
        _this._expandToolbox = function () {
            _ms_sp_telemetry__WEBPACK_IMPORTED_MODULE_2__["_EngagementLogger"].logEventWithLogEntry(new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogEntry"]('Toolbox', 'ExpandToolbox', _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogType"].Event, {
                itemCount: _this.props.items.length.toString()
            }));
            _this.setState({
                size: 'Large'
            });
        };
        _this._collapseToolbox = function () {
            _ms_sp_telemetry__WEBPACK_IMPORTED_MODULE_2__["_EngagementLogger"].logEventWithLogEntry(new _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogEntry"]('Toolbox', 'CollapseToolbox', _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogType"].Event, {
                itemCount: _this.props.items.length.toString()
            }));
            _this.setState({
                size: 'Small'
            });
        };
        _this.state = {
            size: 'Small'
        };
        return _this;
    }
    ToolboxSizeLayer.prototype.render = function () {
        switch (this.state.size) {
            case 'Small':
                return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxSmall__WEBPACK_IMPORTED_MODULE_5__["ToolboxSmall"], { className: '', items: this.props.items, controller: this.props.controller, onExpandToolbox: this._expandToolbox, onCloseToolbox: this.props.onCloseToolbox, calloutTarget: this.props.calloutTarget, calloutDirectionalHint: this.props.calloutDirectionalHint, onDismiss: this.props.onDismiss, onClickItem: this.props.onClickItem, featuredIds: this.props.featuredIds, pageLayoutType: this.props.pageLayoutType, groups: this.props.groups }));
            case 'Large':
                return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_toolboxLarge__WEBPACK_IMPORTED_MODULE_4__["ToolboxLarge"], { className: '', controller: this.props.controller, items: this.props.items, groups: this.props.groups, onCollapseToolbox: this._collapseToolbox, onCloseToolbox: this.props.onCloseToolbox, onClickItem: this.props.onClickItem, a11yManager: this.props.a11yManager, pageLayoutType: this.props.pageLayoutType }));
            default:
                throw new Error('Unknown toolbox mode');
        }
    };
    return ToolboxSizeLayer;
}(react__WEBPACK_IMPORTED_MODULE_3__["PureComponent"]));



/***/ }),

/***/ "VUzZ":
/*!*****************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewSmall.js ***!
  \*****************************************************/
/*! exports provided: ToolboxItemListViewSmall */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemListViewSmall", function() { return ToolboxItemListViewSmall; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxItemListViewBase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxItemListViewBase */ "7O2j");
/* harmony import */ var _ToolboxItemListViewSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemListViewSmall.module.scss */ "pl3/");




function ToolboxItemListViewSmall(props) {
    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxItemListViewBase__WEBPACK_IMPORTED_MODULE_2__["ToolboxItemListViewBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { iconClassName: _ToolboxItemListViewSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].icon, titleLineCount: 1 }));
}


/***/ }),

/***/ "VjZh":
/*!******************************************!*\
  !*** ./lib/toolboxError/ToolboxError.js ***!
  \******************************************/
/*! exports provided: ToolboxError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxError", function() { return ToolboxError; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _toolboxCallout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../toolboxCallout */ "GNkg");
/* harmony import */ var _ToolboxError_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxError.module.scss */ "jVW0");



function ToolboxError(props) {
    props.a11yManager.alert(props.message);
    var toolboxErrorContent = react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("p", { className: _ToolboxError_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].error }, props.message);
    // @todo #241904 Update the UI with design approved error state
    return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_toolboxCallout__WEBPACK_IMPORTED_MODULE_1__["ToolboxCallout"], { className: props.className, onDismiss: props.onDismiss, target: props.calloutTarget, directionalHint: props.calloutDirectionalHint }, toolboxErrorContent));
}


/***/ }),

/***/ "Wako":
/*!**********************************!*\
  !*** ./lib/toolboxData/Group.js ***!
  \**********************************/
/*! exports provided: CONNECTOR_GROUP, OTHER_GROUP, PREDEFINED_GROUPS, FEATURED_GROUP, MOST_FREQUENTLY_GROUP, ALPHABETICAL_GROUP, SECTION_GROUP */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CONNECTOR_GROUP", function() { return CONNECTOR_GROUP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OTHER_GROUP", function() { return OTHER_GROUP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PREDEFINED_GROUPS", function() { return PREDEFINED_GROUPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FEATURED_GROUP", function() { return FEATURED_GROUP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MOST_FREQUENTLY_GROUP", function() { return MOST_FREQUENTLY_GROUP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALPHABETICAL_GROUP", function() { return ALPHABETICAL_GROUP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SECTION_GROUP", function() { return SECTION_GROUP; });
/* harmony import */ var _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./GroupStrings.resx */ "DL5L");
var _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./GroupStrings.resx */ "DL5L", 1);

var CONNECTOR_GROUP = [
    '507ffa9b-29db-4d59-93fe-0e240510f718',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryConnectors"]
];
var OTHER_GROUP = [
    '5c03119e-3074-46fd-976b-c60198311f70',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryOther"]
];
var PREDEFINED_GROUPS = [
    ['cf066440-0614-43d6-98ae-0b31cf14c7c3', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryTextMediaAndContent"]],
    ['1edbd9a8-0bfb-4aa2-9afd-14b8c45dd489', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryDiscovery"]],
    ['75e22ed5-fa14-4829-850a-c890608aca2d', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryCommunicationAndCollaboration"]],
    ['1bc7927e-4a5e-4520-b540-71305c79c20a', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryPlanningAndProcess"]],
    ['4aca9e90-eff5-4fa1-bac7-728f5f157b66', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategoryBusinessIntelligence"]],
    ['070951d7-94da-4db8-b06e-9d581f1f55b1', _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxCategorySiteTools"]],
    CONNECTOR_GROUP,
    OTHER_GROUP
];
var FEATURED_GROUP = [
    'bff4383a-b0d8-4403-ae06-a49d288cda10',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxGroupNameFeatured"]
];
var MOST_FREQUENTLY_GROUP = [
    '6da214a7-3795-429f-b73d-cbe7010c3222',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxGroupNameMostFrequently"]
];
var ALPHABETICAL_GROUP = [
    'cb7d0165-c1a5-4869-b988-840e29071e51',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxGroupNameAlphabetical"]
];
var SECTION_GROUP = [
    '3d729643-8911-485d-8b0e-fc9d4c83acbd',
    _GroupStrings_resx__WEBPACK_IMPORTED_MODULE_0__["ToolboxGroupNameSection"]
];


/***/ }),

/***/ "XYP4":
/*!******************************************!*\
  !*** ./lib/toolboxViewSwitcher/index.js ***!
  \******************************************/
/*! exports provided: ViewSwitcher */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ViewSwitcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ViewSwitcher */ "RaMy");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ViewSwitcher", function() { return _ViewSwitcher__WEBPACK_IMPORTED_MODULE_0__["ViewSwitcher"]; });




/***/ }),

/***/ "XcfF":
/*!******************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupBase.module.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxGroupBase.module.css */ "+zNl");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "Z+Fo":
/*!***************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLargeViewLayer.js ***!
  \***************************************************/
/*! exports provided: ALL_BY_CATEGORY_KEY, ALL_A_TO_Z_KEY, ToolboxLargeViewLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_BY_CATEGORY_KEY", function() { return ALL_BY_CATEGORY_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_A_TO_Z_KEY", function() { return ALL_A_TO_Z_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxLargeViewLayer", function() { return ToolboxLargeViewLayer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-lodash-subset */ "Pk8u");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var office_ui_fabric_react_lib_components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! office-ui-fabric-react/lib/components/Modal/Modal */ "PXOV");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _toolboxChrome__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../toolboxChrome */ "veAR");
/* harmony import */ var _toolboxChromeV2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../toolboxChromeV2 */ "QVSF");
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ViewCategory__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ViewCategory */ "6eS9");
/* harmony import */ var _ViewHome__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ViewHome */ "LcaF");
/* harmony import */ var _ViewSearch__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ViewSearch */ "A+bi");
/* harmony import */ var _ViewSort__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ViewSort */ "N03I");
/* harmony import */ var _ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./ToolboxLarge.module.scss */ "7A7I");
/* harmony import */ var _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ToolboxLargeStrings.resx */ "T5+N");
var _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./ToolboxLargeStrings.resx */ "T5+N", 1);
















var ALL_BY_CATEGORY_KEY = 'allByCategory';
var ALL_A_TO_Z_KEY = 'allAToZ';
var ToolboxLargeViewLayer = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxLargeViewLayer, _super);
    function ToolboxLargeViewLayer(props) {
        var _this = _super.call(this, props) || this;
        _this._handleChange = function (query) {
            return _this.props.onFilterItems(query, /* shouldDebounce */ true, 'Large');
        };
        _this._handleSearch = function (query) {
            return _this.props.onFilterItems(query, /* shouldDebounce */ false, 'Large');
        };
        _this._handleChangeCategoryMenu = function (ev, item) {
            if (!item) {
                return;
            }
            switch (item.key) {
                case ALL_BY_CATEGORY_KEY: {
                    _this._switchView({
                        type: "Home" /* Home */,
                        previousView: _this.view
                    });
                    var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__["StringHelper"].format(_ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["SwitchCategoryAlert"], _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategoryAllCategory"]);
                    _this.props.a11yManager.alert(message);
                    break;
                }
                case ALL_A_TO_Z_KEY: {
                    _this._switchView({
                        type: "Sort" /* Sort */,
                        sortBy: 'alphabet',
                        previousView: _this.view
                    });
                    var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__["StringHelper"].format(_ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["SwitchCategoryAlert"], _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategorySortingCategory"]);
                    _this.props.a11yManager.alert(message);
                    break;
                }
                // Switch to specified category view.
                default: {
                    _this._switchToCategoryView(item.key);
                }
            }
        };
        _this._handleBackClick = function () {
            var switchView = ToolboxLargeViewLayer.toolboxUIUpdateEnabled
                ? _this.props.switchView
                : _this._switchView;
            if (_this.props.query) {
                _this.props.onFilterItems('', /* shouldDebounce */ false);
            }
            else if (_this.view.previousView) {
                switchView(_this.view.previousView);
            }
        };
        _this._switchToCategoryView = function (groupId) {
            if (ToolboxLargeViewLayer.toolboxUIUpdateEnabled) {
                _this.props.switchView({
                    type: "Category" /* Category */,
                    groupId: groupId,
                    previousView: _this.view
                });
            }
            else {
                _this._switchView({
                    type: "Category" /* Category */,
                    groupId: groupId,
                    previousView: _this.view
                });
            }
            var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__["StringHelper"].format(_ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["SwitchCategoryAlert"], _this._getCategoryName(groupId));
            _this.props.a11yManager.alert(message);
        };
        _this._switchView = function (view) {
            // Clear the search query to avoid the search view.
            _this.props.onFilterItems('', /* shouldDebounce */ false);
            if (view.previousView !== undefined && _this._isSameView(view, view.previousView)) {
                // It is possible that, we are switch to a view with `previousView` set to the same view.
                // Concretely, it is search view currently. There is a `previousView` with the search view.
                // The user chooses the same view as the `previousView` from the dropdown menu.
                // So, instead of pushing a new view to history stack, it goes back to `previousView` directly.
                _this.setState({ view: view.previousView });
            }
            else {
                _this.setState({ view: view });
            }
        };
        _this._clickItemInToolboxLarge = function (toolboxItemId) {
            _this.props.onClickItem(toolboxItemId, {
                size: 'Large',
                query: _this.props.query,
                view: _this.view
            });
        };
        _this.state = {
            view: {
                type: "Home" /* Home */,
                previousView: undefined
            }
        };
        return _this;
    }
    ToolboxLargeViewLayer.prototype.render = function () {
        var _a;
        var titleAriaId = Math.random().toString().substr(2);
        var title = _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["LargeToolboxAriaTitle"];
        var collapseButtonProps = {
            iconProps: { iconName: 'BackToWindow' },
            onClick: this.props.onCollapseToolbox,
            title: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCollapseButtonDescription"],
            ariaLabel: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCollapseButtonAriaLabel"],
            ariaDescription: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCollapseButtonDescription"]
        };
        var commandBarProps = {
            items: this._commandBarItems,
            className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].menuCommandBar, Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_9__["isFluentEnabled"])() && _ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].fluent)
        };
        // tslint:disable-next-line:variable-name
        var ToolboxChrome = ToolboxLargeViewLayer.toolboxUIUpdateEnabled
            ? _toolboxChromeV2__WEBPACK_IMPORTED_MODULE_8__["ToolboxChrome"]
            : _toolboxChrome__WEBPACK_IMPORTED_MODULE_7__["ToolboxChrome"];
        return (react__WEBPACK_IMPORTED_MODULE_6__["createElement"](office_ui_fabric_react_lib_components_Modal_Modal__WEBPACK_IMPORTED_MODULE_5__["Modal"], { onDismiss: this.props.onCloseToolbox, containerClassName: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].toolboxLargeContainer, this.props.className), isOpen: true, isBlocking: false, titleAriaId: titleAriaId, scrollableContentClassName: _ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].modalScrollContent },
            react__WEBPACK_IMPORTED_MODULE_6__["createElement"](ToolboxChrome, { searchQuery: this.props.query, farButton: collapseButtonProps, onChange: this._handleChange, onSearch: this._handleSearch, onEscape: this.props.onCloseToolbox, commandBar: commandBarProps, items: (_a = commandBarProps) === null || _a === void 0 ? void 0 : _a.items }, this._toolboxBody),
            react__WEBPACK_IMPORTED_MODULE_6__["createElement"]("p", { id: titleAriaId, className: _ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].screenReaderAlert }, title)));
    };
    Object.defineProperty(ToolboxLargeViewLayer.prototype, "_commandBarItems", {
        get: function () {
            var _a, _b;
            var selectedCategory = ToolboxLargeViewLayer.toolboxUIUpdateEnabled
                ? this.props.selectedCategory
                : this._selectedCategory;
            var handleChangeCategoryMenu = ToolboxLargeViewLayer.toolboxUIUpdateEnabled
                ? this.props.changeView
                : this._handleChangeCategoryMenu;
            var selectedCategoryKey = selectedCategory[0], selectedCategoryName = selectedCategory[1];
            var subMenuForGroup = this.props.groups.map(function (toolboxLargeGroup) {
                var _a;
                return ({
                    key: toolboxLargeGroup.groupId,
                    name: toolboxLargeGroup.title,
                    className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])((_a = {},
                        _a[_ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].selectedItem] = toolboxLargeGroup.groupId === selectedCategoryKey,
                        _a)),
                    onClick: handleChangeCategoryMenu
                });
            });
            var subMenuForView = [
                {
                    key: ALL_BY_CATEGORY_KEY,
                    name: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategoryAllCategory"],
                    className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])((_a = {},
                        _a[_ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].selectedItem] = ALL_BY_CATEGORY_KEY === selectedCategoryKey,
                        _a)),
                    onClick: handleChangeCategoryMenu
                },
                {
                    key: ALL_A_TO_Z_KEY,
                    name: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategorySortingCategory"],
                    className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])((_b = {},
                        _b[_ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].selectedItem] = ALL_A_TO_Z_KEY === selectedCategoryKey,
                        _b)),
                    onClick: handleChangeCategoryMenu
                }
            ];
            var commandBarButtonClassName = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_9__["isFluentEnabled"])() ? _ToolboxLarge_module_scss__WEBPACK_IMPORTED_MODULE_14__["default"].commandBarButton : '';
            var backButton = {
                className: commandBarButtonClassName,
                key: 'BackButton',
                ariaLabel: _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["BackButtonAriaLabel"],
                iconProps: { iconName: 'ChromeBack' },
                disabled: !this.props.query && this.view.previousView === undefined,
                onClick: this._handleBackClick,
                'data-automation-id': 'toolbox-back-button'
            };
            var commandBarMenus = [
                backButton,
                {
                    className: commandBarButtonClassName,
                    key: 'CategoryContextualMenu',
                    name: selectedCategoryName,
                    subMenuProps: {
                        items: subMenuForView.concat(subMenuForGroup),
                        beakWidth: 10,
                        isBeakVisible: true
                    },
                    role: 'navigation',
                    ariaLabel: _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_4__["StringHelper"].format(_ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["DropDownMenuAriaLabel"], selectedCategoryName)
                }
            ];
            return commandBarMenus;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ToolboxLargeViewLayer.prototype, "_selectedCategory", {
        get: function () {
            var selectedCategoryKey;
            var selectedCategoryName;
            if (this.props.query) {
                // For search view, we don't show a corresponding choice but update the title.
                selectedCategoryKey = '';
                selectedCategoryName = _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategorySearchResults"];
            }
            else if (this.view.type === "Home" /* Home */) {
                selectedCategoryKey = ALL_BY_CATEGORY_KEY;
                selectedCategoryName = _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategoryAllCategory"];
            }
            else if (this.view.type === "Sort" /* Sort */) {
                selectedCategoryKey = ALL_A_TO_Z_KEY;
                selectedCategoryName = _ToolboxLargeStrings_resx__WEBPACK_IMPORTED_MODULE_15__["ToolboxCategorySortingCategory"];
            }
            else {
                selectedCategoryKey = this.view.groupId;
                selectedCategoryName = this._getCategoryName(this.view.groupId);
            }
            return [selectedCategoryKey, selectedCategoryName];
        },
        enumerable: true,
        configurable: true
    });
    ToolboxLargeViewLayer.prototype._getCategoryName = function (groupId) {
        var groupIndex = Object(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_3__["findIndex"])(this.props.groups, function (group) { return group.groupId === groupId; });
        if (groupIndex >= 0) {
            return this.props.groups[groupIndex].title;
        }
        else {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_TraceLogger"].logError(ToolboxLargeViewLayer._logSource, new Error("Something went wrong with categorizing groups, group not found by given id: " + groupId));
            return '';
        }
    };
    Object.defineProperty(ToolboxLargeViewLayer.prototype, "_toolboxBody", {
        get: function () {
            var isListView = ToolboxLargeViewLayer.toolboxUIUpdateEnabled && this.props.isListView;
            if (this.props.query) {
                return (react__WEBPACK_IMPORTED_MODULE_6__["createElement"](_ViewSearch__WEBPACK_IMPORTED_MODULE_12__["ViewSearch"], { items: this.props.items, onClickItem: this._clickItemInToolboxLarge, isListView: isListView }));
            }
            switch (this.view.type) {
                case "Home" /* Home */:
                    return (react__WEBPACK_IMPORTED_MODULE_6__["createElement"](_ViewHome__WEBPACK_IMPORTED_MODULE_11__["ViewHome"], { view: this.view, groups: this.props.groups, onClickItem: this._clickItemInToolboxLarge, onSwitchToCategoryView: this._switchToCategoryView, pageLayoutType: this.props.pageLayoutType, isListView: isListView }));
                case "Sort" /* Sort */:
                    return (react__WEBPACK_IMPORTED_MODULE_6__["createElement"](_ViewSort__WEBPACK_IMPORTED_MODULE_13__["ViewSort"], { view: this.view, items: this.props.items, onClickItem: this._clickItemInToolboxLarge, isListView: isListView }));
                case "Category" /* Category */:
                    return (react__WEBPACK_IMPORTED_MODULE_6__["createElement"](_ViewCategory__WEBPACK_IMPORTED_MODULE_10__["ViewCategory"], { view: this.view, groups: this.props.groups, onClickItem: this._clickItemInToolboxLarge, pageLayoutType: this.props.pageLayoutType, isListView: isListView }));
                default: {
                    return null; // tslint:disable-line:no-null-keyword
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    ToolboxLargeViewLayer.prototype._isSameView = function (view1, view2) {
        if (view1.type === "Category" /* Category */ && view2.type === "Category" /* Category */) {
            return view1.groupId === view2.groupId;
        }
        else {
            return view1.type === view2.type;
        }
    };
    Object.defineProperty(ToolboxLargeViewLayer.prototype, "view", {
        get: function () {
            if (ToolboxLargeViewLayer.toolboxUIUpdateEnabled) {
                return this.props.view;
            }
            else {
                return this.state.view;
            }
        },
        enumerable: true,
        configurable: true
    });
    ToolboxLargeViewLayer._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_2__["_LogSource"].create('Toolbox');
    ToolboxLargeViewLayer.toolboxUIUpdateEnabled = Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_9__["isToolboxUIUpdateEnabled"])();
    return ToolboxLargeViewLayer;
}(react__WEBPACK_IMPORTED_MODULE_6__["PureComponent"]));



/***/ }),

/***/ "ZPLP":
/*!*********************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemSmall.module.scss.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxItemSmall.module.css */ "wFRG");
var styles = {
    item: 'ag_q_08a7513e',
    itemUxUpdate: 'at_q_08a7513e',
    flexBox: 'ah_q_08a7513e',
    icon: 'ai_q_08a7513e',
    title: 'ak_q_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "b4B8":
/*!*****************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLargeSearchLayer.js ***!
  \*****************************************************/
/*! exports provided: ToolboxLargeSearchLayer, ToolboxLargeViewLayerV2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxLargeSearchLayer", function() { return ToolboxLargeSearchLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxLargeViewLayerV2", function() { return ToolboxLargeViewLayerV2; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxSearch */ "ZFqg");
/* harmony import */ var _toolboxView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxView */ "ETZn");
/* harmony import */ var _ToolboxLargeViewLayer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxLargeViewLayer */ "Z+Fo");





function ToolboxLargeSearchLayer(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxSearch__WEBPACK_IMPORTED_MODULE_2__["SearchConsumer"], null, function (searchContext) { return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](ToolboxLargeViewLayerV2, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, searchContext)); }));
}
function ToolboxLargeViewLayerV2(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxView__WEBPACK_IMPORTED_MODULE_3__["ViewConsumer"], null, function (viewContext) { return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxLargeViewLayer__WEBPACK_IMPORTED_MODULE_4__["ToolboxLargeViewLayer"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, viewContext)); }));
}


/***/ }),

/***/ "b6WH":
/*!**********************************!*\
  !*** ./lib/toolboxData/index.js ***!
  \**********************************/
/*! exports provided: Group */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Group__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Group */ "Wako");
/* harmony reexport (module object) */ __webpack_require__.d(__webpack_exports__, "Group", function() { return _Group__WEBPACK_IMPORTED_MODULE_0__; });

// tslint:disable-next-line:export-name



/***/ }),

/***/ "el64":
/*!***********************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemSection.js ***!
  \***********************************************/
/*! exports provided: ToolboxItemSection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemSection", function() { return ToolboxItemSection; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ToolboxItemBase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxItemBase */ "+FXA");
/* harmony import */ var _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ToolboxItemSmall.module.scss */ "ZPLP");




function ToolboxItemSection(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxItemBase__WEBPACK_IMPORTED_MODULE_2__["ToolboxItemBase"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { titleLineCount: 2, itemClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].item, itemStyles: { height: 88 }, flexBoxClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].flexBox, iconClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].icon, titleClassName: _ToolboxItemSmall_module_scss__WEBPACK_IMPORTED_MODULE_3__["default"].title })));
}


/***/ }),

/***/ "feLs":
/*!**********************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupBase.js ***!
  \**********************************************/
/*! exports provided: ToolboxGroupBase */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxGroupBase", function() { return ToolboxGroupBase; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ToolboxGroupBase.module.scss */ "ogcG");
/* harmony import */ var _ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ToolboxGroupStrings.resx */ "Tr0R");
var _ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./ToolboxGroupStrings.resx */ "Tr0R", 1);







var ToolboxGroupBase = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxGroupBase, _super);
    function ToolboxGroupBase() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ToolboxGroupBase.prototype.render = function () {
        var sectionAriaLabel = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__["StringHelper"].format(this.props.isListView ? _ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxGroupListViewAriaLabel"] : _ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxGroupAriaLabel"], this.props.groupName);
        return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("section", { "aria-label": sectionAriaLabel, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].toolboxGroup, this.props.isListView && _ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].listView) },
            this._banner,
            this._content,
            this._shouldShowSeeAllButton && this._seeAllButton));
    };
    Object.defineProperty(ToolboxGroupBase.prototype, "_banner", {
        get: function () {
            var headClassName = Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].header, Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_4__["isFluentEnabled"])() && _ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].fluent, this.props.isListView && _ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].listView);
            return this.props.hasHeader && react__WEBPACK_IMPORTED_MODULE_3__["createElement"]("header", { className: headClassName }, this.props.groupName);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ToolboxGroupBase.prototype, "_seeAllButton", {
        get: function () {
            return (react__WEBPACK_IMPORTED_MODULE_3__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["ActionButton"], { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].seeAllButton, Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_4__["isFluentEnabled"])() && _ToolboxGroupBase_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].fluent), styles: { root: { height: 32, position: 'absolute' } }, onClick: this.props.onClickSeeAll, ariaLabel: _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_2__["StringHelper"].format(_ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxGroupSeeAllButtonAriaLabel"], this.props.groupName) }, _ToolboxGroupStrings_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxGroupSeeAllButtonLabel"]));
        },
        enumerable: true,
        configurable: true
    });
    return ToolboxGroupBase;
}(react__WEBPACK_IMPORTED_MODULE_3__["PureComponent"]));



/***/ }),

/***/ "gTvL":
/*!***********************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupLarge.js ***!
  \***********************************************/
/*! exports provided: ToolboxGroupLarge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxGroupLarge", function() { return ToolboxGroupLarge; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxGroupBase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxGroupBase */ "feLs");
/* harmony import */ var _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ToolboxGroupLarge.module.scss */ "0OY+");






var MIN_LARGE_GROUP_COLUMNS = 4;
var RESPONSIVE_BREAK_POINTS_MIN = [
    // 718px = 128(toolboxItemWidth)x5 + 24(toolboxMargin)x2 + 30(in case of scroll bar)
    [718, MIN_LARGE_GROUP_COLUMNS + 1],
    [846, MIN_LARGE_GROUP_COLUMNS + 2],
    [974, MIN_LARGE_GROUP_COLUMNS + 3],
    [1102, MIN_LARGE_GROUP_COLUMNS + 4],
    [Number.MAX_VALUE, MIN_LARGE_GROUP_COLUMNS + 5] // Should never show 9 columns.
];
var ToolboxGroupLarge = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxGroupLarge, _super);
    function ToolboxGroupLarge(props) {
        var _this = _super.call(this, props) || this;
        _this._handleWindowResize = function () {
            if (window.innerWidth) {
                var windowWidth = window.innerWidth;
                if (windowWidth) {
                    _this.setState({ numberOfColumns: _this._calcColumnNumber(windowWidth) });
                }
            }
        };
        _this.state = {
            numberOfColumns: _this._calcColumnNumber(window.innerWidth)
        };
        return _this;
    }
    ToolboxGroupLarge.prototype.componentDidMount = function () {
        window.addEventListener('resize', this._handleWindowResize);
    };
    ToolboxGroupLarge.prototype.componentWillUnmount = function () {
        window.removeEventListener('resize', this._handleWindowResize);
    };
    Object.defineProperty(ToolboxGroupLarge.prototype, "_content", {
        get: function () {
            if (Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__["isToolboxUIUpdateEnabled"])() && this.props.isLoading) {
                return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["Spinner"], { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].flexGroup, this._widthClassName, _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].spinner), styles: { root: { marginTop: 10, marginBottom: 10 } } }));
            }
            if (this.props.isListView) {
                return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZone"], { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].flexGroup, this._widthClassName) }, this.props.children));
            }
            return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZone"], { className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(_ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].flexGroup, this._widthClassName) }, this._responsiveChildren));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ToolboxGroupLarge.prototype, "_shouldShowSeeAllButton", {
        get: function () {
            return (react__WEBPACK_IMPORTED_MODULE_2__["Children"].count(this._responsiveChildren) < react__WEBPACK_IMPORTED_MODULE_2__["Children"].count(this.props.children) &&
                !this.props.isListView);
        },
        enumerable: true,
        configurable: true
    });
    ToolboxGroupLarge.prototype._calcColumnNumber = function (windowWidth) {
        var responsiveIndex = 0;
        while (windowWidth >= RESPONSIVE_BREAK_POINTS_MIN[responsiveIndex][0]) {
            responsiveIndex++;
        }
        return responsiveIndex + MIN_LARGE_GROUP_COLUMNS;
    };
    Object.defineProperty(ToolboxGroupLarge.prototype, "_responsiveChildren", {
        get: function () {
            var _this = this;
            // If see all callback is valid, slice children and render group in one-line mode,
            // otherwise render all children in multiple line.
            var slicedItems = Boolean(this.props.onClickSeeAll)
                ? react__WEBPACK_IMPORTED_MODULE_2__["Children"].toArray(this.props.children).slice(0, this.state.numberOfColumns)
                : react__WEBPACK_IMPORTED_MODULE_2__["Children"].toArray(this.props.children);
            return slicedItems.map(function (child, index) { return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", { className: _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].grid, key: "grid-" + _this._generateKeyFromReactChild(child, index) }, child)); });
        },
        enumerable: true,
        configurable: true
    });
    ToolboxGroupLarge.prototype._generateKeyFromReactChild = function (child, index) {
        if (child) {
            /* tslint:disable-next-line:no-any */
            var elementKey = child.key;
            if (elementKey) {
                return elementKey;
            }
            else {
                return child.toString();
            }
        }
        else {
            return index;
        }
    };
    Object.defineProperty(ToolboxGroupLarge.prototype, "_widthClassName", {
        get: function () {
            switch (this.state.numberOfColumns) {
                case 4: {
                    return _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].fourColumnWide;
                }
                case 5: {
                    return _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].fiveColumnWide;
                }
                case 6: {
                    return _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].sixColumnWide;
                }
                case 7: {
                    return _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].sevenColumnWide;
                }
                default: {
                    return _ToolboxGroupLarge_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].eightColumnWide;
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    return ToolboxGroupLarge;
}(_ToolboxGroupBase__WEBPACK_IMPORTED_MODULE_4__["ToolboxGroupBase"]));



/***/ }),

/***/ "iEpd":
/*!*********************************************************!*\
  !*** ./lib/toolboxViewSwitcher/ViewSwitcher.module.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ViewSwitcher.module.css */ "vYXq");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "iT3i":
/*!*************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewLarge.module.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxItemListViewLarge.module.css */ "pRqP");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "jVW0":
/*!******************************************************!*\
  !*** ./lib/toolboxError/ToolboxError.module.scss.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxError.module.css */ "FSMX");
var styles = {
    error: 'b_b_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "k5Hx":
/*!****************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewBase.module.scss.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxItemListViewBase.module.css */ "6Jn7");
var styles = {
    icon: 'ai_o_08a7513e',
    title: 'ak_o_08a7513e',
    description: 'am_o_08a7513e',
    content: 'j_o_08a7513e',
    item: 'ag_o_08a7513e',
    flexBox: 'ah_o_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "k8VM":
/*!**************************************************!*\
  !*** ./lib/toolboxSection/ToolboxSectionCore.js ***!
  \**************************************************/
/*! exports provided: ToolboxSectionCore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxSectionCore", function() { return ToolboxSectionCore; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/office-ui-fabric-react-bundle */ "KL1q");
/* harmony import */ var _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _toolbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolbox */ "+bKi");
/* harmony import */ var _toolboxCallout_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../toolboxCallout/index */ "GNkg");
/* harmony import */ var _toolboxGroup_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxGroup/index */ "5FlS");
/* harmony import */ var _toolboxItem_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../toolboxItem/index */ "nKzV");
/* harmony import */ var _ToolboxSectionCore_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ToolboxSectionCore.module.scss */ "AgJP");








var ToolboxSectionCore = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxSectionCore, _super);
    function ToolboxSectionCore() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ToolboxSectionCore.prototype.render = function () {
        var toolboxSectionContent = (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZone"], { direction: _microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["FocusZoneDirection"].horizontal, isCircularNavigation: true }, this._renderGroup(Object(_toolboxGroup_index__WEBPACK_IMPORTED_MODULE_5__["getSectionGroup"])(this.props.items))));
        return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxCallout_index__WEBPACK_IMPORTED_MODULE_4__["ToolboxCallout"], { onDismiss: this.props.onCloseToolbox, className: Object(_microsoft_office_ui_fabric_react_bundle__WEBPACK_IMPORTED_MODULE_1__["css"])(this.props.className, _ToolboxSectionCore_module_scss__WEBPACK_IMPORTED_MODULE_7__["default"].callout), target: this.props.calloutTarget, directionalHint: this.props.calloutDirectionalHint, toolboxType: _toolbox__WEBPACK_IMPORTED_MODULE_3__["TOOLBOX_TYPES"].sectionToolbox }, toolboxSectionContent));
    };
    ToolboxSectionCore.prototype._renderGroup = function (group) {
        var _this = this;
        if (group.items.length === 0) {
            return false;
        }
        var items = group.items.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxItem_index__WEBPACK_IMPORTED_MODULE_6__["ToolboxItemSection"], { key: item.id, item: item, onClick: _this.props.onClickItem })); });
        return (react__WEBPACK_IMPORTED_MODULE_2__["createElement"](_toolboxGroup_index__WEBPACK_IMPORTED_MODULE_5__["ToolboxGroupSmall"], { key: group.groupId, groupName: group.title, hasHeader: true }, items));
    };
    return ToolboxSectionCore;
}(react__WEBPACK_IMPORTED_MODULE_2__["PureComponent"]));



/***/ }),

/***/ "msj5":
/*!***********************************!*\
  !*** ./lib/toolboxSmall/index.js ***!
  \***********************************/
/*! exports provided: ToolboxSmall */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxSmallAnimationLayer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxSmallAnimationLayer */ "uxSn");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxSmall", function() { return _ToolboxSmallAnimationLayer__WEBPACK_IMPORTED_MODULE_0__["ToolboxSmallAnimationLayer"]; });




/***/ }),

/***/ "nKzV":
/*!**********************************!*\
  !*** ./lib/toolboxItem/index.js ***!
  \**********************************/
/*! exports provided: ToolboxItemSmall, ToolboxItemLarge, ToolboxItemSection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxItemSmall__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxItemSmall */ "TBAh");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemSmall", function() { return _ToolboxItemSmall__WEBPACK_IMPORTED_MODULE_0__["ToolboxItemSmall"]; });

/* harmony import */ var _ToolboxItemLarge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToolboxItemLarge */ "+ium");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemLarge", function() { return _ToolboxItemLarge__WEBPACK_IMPORTED_MODULE_1__["ToolboxItemLarge"]; });

/* harmony import */ var _ToolboxItemSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ToolboxItemSection */ "el64");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxItemSection", function() { return _ToolboxItemSection__WEBPACK_IMPORTED_MODULE_2__["ToolboxItemSection"]; });






/***/ }),

/***/ "nLsw":
/*!*****************************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmallSearchLayer.js ***!
  \*****************************************************/
/*! exports provided: ToolboxSmallSearchLayer, renderToolboxWithView */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxSmallSearchLayer", function() { return ToolboxSmallSearchLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "renderToolboxWithView", function() { return renderToolboxWithView; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxSearch */ "ZFqg");
/* harmony import */ var _toolboxView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxView */ "ETZn");
/* harmony import */ var _ToolboxSmall__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxSmall */ "U6dd");





function renderToolbox(props, searchContext) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxSmall__WEBPACK_IMPORTED_MODULE_4__["ToolboxSmall"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, { ref: undefined, query: searchContext.query, items: searchContext.items, 
        // tslint:disable-next-line: react-this-binding-issue
        onFilter: function (query) { return searchContext.onFilterItems(query, /* shouldDebounce */ false, 'Small'); }, 
        // tslint:disable-next-line: react-this-binding-issue
        onFilterDebounce: function (query) { return searchContext.onFilterItems(query, /* shouldDebounce */ true, 'Small'); } })));
}
function ToolboxSmallSearchLayer(props) {
    return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxSearch__WEBPACK_IMPORTED_MODULE_2__["SearchConsumer"], null, function (searchContext) { return renderToolboxWithView(props, searchContext); });
}
function renderToolboxWithView(props, searchContext) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxView__WEBPACK_IMPORTED_MODULE_3__["ViewConsumer"], null, function (viewContext) { return renderToolbox(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props), viewContext), searchContext); }));
}


/***/ }),

/***/ "naPD":
/*!**************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxChrome/ToolboxChrome.module.css ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".c_g_08a7513e{height:100%;position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.c_g_08a7513e .e_g_08a7513e{-ms-flex:0 0 auto;flex:0 0 auto;margin-bottom:0;box-sizing:border-box;height:33px;border-bottom:1px solid;border-color:\"[theme:neutrallight, default: #edebe9]\";width:100%}[dir=ltr] .c_g_08a7513e .e_g_08a7513e{padding-right:32px}[dir=rtl] .c_g_08a7513e .e_g_08a7513e{padding-left:32px}.c_g_08a7513e .e_g_08a7513e:not(.f_g_08a7513e){border-width:0}.c_g_08a7513e .e_g_08a7513e:hover{border-color:\"[theme:neutralLight, default: #edebe9]\"}.c_g_08a7513e .g_g_08a7513e{box-sizing:border-box;width:32px;height:32px;position:absolute;top:0}[dir=ltr] .c_g_08a7513e .g_g_08a7513e{right:0}[dir=rtl] .c_g_08a7513e .g_g_08a7513e{left:0}.c_g_08a7513e .g_g_08a7513e.h_g_08a7513e{color:\"[theme:neutralSecondary, default: #605e5c]\"}.c_g_08a7513e .g_g_08a7513e:hover.h_g_08a7513e{background-color:transparent;color:\"[theme:themeDarkAlt, default: #106ebe]\"}.c_g_08a7513e .i_g_08a7513e{-ms-flex:0 0 auto;flex:0 0 auto}.c_g_08a7513e .j_g_08a7513e{-ms-flex:1 1 auto;flex:1 1 auto;overflow-y:scroll;height:100%}", ""]);


/***/ }),

/***/ "no+9":
/*!*************************************************************!*\
  !*** ./lib/toolboxViewSwitcher/ViewSwitcher.module.scss.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ViewSwitcher.module.css */ "iEpd");
var styles = {
    viewSwitcher: 'bh_u_08a7513e',
    gridIcon: 'bi_u_08a7513e',
    listIcon: 'bj_u_08a7513e',
    grid: 'u_u_08a7513e',
    list: 'bk_u_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "nr2j":
/*!***************************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmallStrings.resx ***!
  \***************************************************/
/*! exports provided: ToolboxExpandButtonTitle, ToolboxNoItemsFound, ToolboxExpandButtonAriaLabel, ToolboxDropdownlabel, ToolboxDropdownSubmenuTitle, ToolboxCategoryAllCategory, ToolboxCategorySortingCategory, ToolboxCategorySearchResults, ToolboxSortAndFilterTooltop, DropDownMenuAriaLabel, SwitchCategoryAlert, ListGridViewSwitcherAriaLabel, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxExpandButtonTitle\":\"ToolboxExpandButtonTitle\",\"ToolboxNoItemsFound\":\"ToolboxNoItemsFound\",\"ToolboxExpandButtonAriaLabel\":\"ToolboxExpandButtonAriaLabel\",\"ToolboxDropdownlabel\":\"ToolboxDropdownlabel\",\"ToolboxDropdownSubmenuTitle\":\"ToolboxDropdownSubmenuTitle\",\"ToolboxCategoryAllCategory\":\"ToolboxCategoryAllCategory\",\"ToolboxCategorySortingCategory\":\"ToolboxCategorySortingCategory\",\"ToolboxCategorySearchResults\":\"ToolboxCategorySearchResults\",\"ToolboxSortAndFilterTooltop\":\"ToolboxSortAndFilterTooltop\",\"DropDownMenuAriaLabel\":\"DropDownMenuAriaLabel\",\"SwitchCategoryAlert\":\"SwitchCategoryAlert\",\"ListGridViewSwitcherAriaLabel\":\"ListGridViewSwitcherAriaLabel\"}");

/***/ }),

/***/ "ntxq":
/*!*********************************************!*\
  !*** ./lib/toolbox/ToolboxProviderLayer.js ***!
  \*********************************************/
/*! exports provided: ToolboxProviderLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxProviderLayer", function() { return ToolboxProviderLayer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _toolboxSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolboxSearch */ "ZFqg");
/* harmony import */ var _toolboxView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../toolboxView */ "ETZn");
/* harmony import */ var _ToolboxSizeLayer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxSizeLayer */ "UAnW");





function ToolboxProviderLayer(props) {
    return (react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxSearch__WEBPACK_IMPORTED_MODULE_2__["SearchProvider"], { items: props.items, a11yManager: props.a11yManager },
        react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_toolboxView__WEBPACK_IMPORTED_MODULE_3__["ViewProvider"], { a11yManager: props.a11yManager, groups: props.groups },
            react__WEBPACK_IMPORTED_MODULE_1__["createElement"](_ToolboxSizeLayer__WEBPACK_IMPORTED_MODULE_4__["ToolboxSizeLayer"], Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props)))));
}


/***/ }),

/***/ "o44a":
/*!**************************************************!*\
  !*** ./lib/toolboxLarge/ToolboxLarge.module.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxLarge.module.css */ "uboi");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "ogcG":
/*!**********************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupBase.module.scss.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxGroupBase.module.css */ "XcfF");
var styles = {
    toolboxGroup: 'ab_h_08a7513e',
    listView: 'ac_h_08a7513e',
    header: 'ae_h_08a7513e',
    fluent: 'f_h_08a7513e',
    seeAllButton: 'af_h_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "pGsU":
/*!*****************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewLarge.module.scss.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxItemListViewLarge.module.css */ "iT3i");
var styles = {
    icon: 'ai_l_08a7513e',
    item: 'ag_l_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "pRqP":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxItem/ToolboxItemListViewLarge.module.css ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ai_l_08a7513e{color:\"[theme:neutralPrimary, default: #323130]\";font-size:32px;width:80px}.ai_l_08a7513e .ms-Image{width:100%;height:100%}.ag_l_08a7513e{font-size:14px}", ""]);


/***/ }),

/***/ "pl3/":
/*!*****************************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemListViewSmall.module.scss.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxItemListViewSmall.module.css */ "N/ia");
var styles = {
    icon: 'ai_n_08a7513e',
    item: 'ag_n_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "s7ZS":
/*!*******************************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupLarge.module.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxGroupLarge.module.css */ "BwFS");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "sGpJ":
/*!***********************************!*\
  !*** ./lib/toolboxView/View.resx ***!
  \***********************************/
/*! exports provided: ToolboxCategoryAllCategory, ToolboxCategorySortingCategory, ToolboxCategorySearchResults, SwitchCategoryAlert, SwitchViewAlert, ListViewName, GridViewName, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"ToolboxCategoryAllCategory\":\"ToolboxCategoryAllCategory\",\"ToolboxCategorySortingCategory\":\"ToolboxCategorySortingCategory\",\"ToolboxCategorySearchResults\":\"ToolboxCategorySearchResults\",\"SwitchCategoryAlert\":\"SwitchCategoryAlert\",\"SwitchViewAlert\":\"SwitchViewAlert\",\"ListViewName\":\"ListViewName\",\"GridViewName\":\"GridViewName\"}");

/***/ }),

/***/ "sJc3":
/*!***********************************************!*\
  !*** ./lib/toolboxGroup/ToolboxGroupSmall.js ***!
  \***********************************************/
/*! exports provided: ToolboxGroupSmall */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxGroupSmall", function() { return ToolboxGroupSmall; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! office-ui-fabric-react/lib/FocusZone */ "NMYH");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ToolboxFlightsAndKillSwitches */ "kxuc");
/* harmony import */ var _ToolboxGroupBase__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ToolboxGroupBase */ "feLs");





var ToolboxGroupSmall = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ToolboxGroupSmall, _super);
    function ToolboxGroupSmall() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(ToolboxGroupSmall.prototype, "_content", {
        get: function () {
            if (Object(_ToolboxFlightsAndKillSwitches__WEBPACK_IMPORTED_MODULE_3__["isToolboxUIUpdateEnabled"])()) {
                return react__WEBPACK_IMPORTED_MODULE_2__["createElement"](office_ui_fabric_react_lib_FocusZone__WEBPACK_IMPORTED_MODULE_1__["FocusZone"], null, this.props.children);
            }
            else {
                return react__WEBPACK_IMPORTED_MODULE_2__["createElement"]("div", null, this.props.children);
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ToolboxGroupSmall.prototype, "_shouldShowSeeAllButton", {
        get: function () {
            return false;
        },
        enumerable: true,
        configurable: true
    });
    return ToolboxGroupSmall;
}(_ToolboxGroupBase__WEBPACK_IMPORTED_MODULE_4__["ToolboxGroupBase"]));



/***/ }),

/***/ "uboi":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxLarge/ToolboxLarge.module.css ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".au_s_08a7513e{margin:24px;height:712px;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.av_s_08a7513e{height:100%}.aw_s_08a7513e{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.ax_s_08a7513e .ms-CommandBar{padding:0}.ax_s_08a7513e .ms-CommandBar-primaryCommands{margin:0 4px}.ax_s_08a7513e:not(.f_s_08a7513e){height:40px;background-color:\"[theme:neutralLight, default: #edebe9]\"}.ax_s_08a7513e.f_s_08a7513e{background-color:\"[theme:white, default: #ffffff]\"}.ax_s_08a7513e.f_s_08a7513e .ms-CommandBar{height:60px}.ax_s_08a7513e:not(.f_s_08a7513e) .ms-Button-textContainer{font-size:17px}.ax_s_08a7513e.f_s_08a7513e .ms-Button-textContainer .ms-Button-label{font-size:\"[theme:xLargeFontSize, default: 20px]\";font-weight:\"[theme:xLargeFontWeight, default: 600]\";color:\"[theme:neutralPrimary, default: #323130]\"}.ay_s_08a7513e{font-weight:600;background-color:\"[theme:neutralLight, default: #edebe9]\"}.az_s_08a7513e{background-color:\"[theme:white, default: #ffffff]\"}", ""]);


/***/ }),

/***/ "uxSn":
/*!********************************************************!*\
  !*** ./lib/toolboxSmall/ToolboxSmallAnimationLayer.js ***!
  \********************************************************/
/*! exports provided: ToolboxSmallAnimationLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolboxSmallAnimationLayer", function() { return ToolboxSmallAnimationLayer; });
/* harmony import */ var _toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../toolboxAnimation */ "Xs01");
/* harmony import */ var _ToolboxSmallSearchLayer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ToolboxSmallSearchLayer */ "nLsw");


// tslint:disable-next-line:variable-name
var ToolboxSmallAnimationLayer = Object(_toolboxAnimation__WEBPACK_IMPORTED_MODULE_0__["animation"])(_ToolboxSmallSearchLayer__WEBPACK_IMPORTED_MODULE_1__["ToolboxSmallSearchLayer"], 3 /* Small */);


/***/ }),

/***/ "vYXq":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxViewSwitcher/ViewSwitcher.module.css ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".bh_u_08a7513e{font-size:12px;position:relative;display:-ms-flexbox;display:flex;-ms-flex-pack:justify;justify-content:space-between;-ms-flex-align:center;align-items:center;justify-self:center;-ms-flex-item-align:center;align-self:center;box-sizing:border-box;width:44px;height:20px;margin:0 6px;padding:0 4.5px;cursor:pointer;border-radius:10px;background:\"[theme:white, default: #ffffff]\";-webkit-user-select:none;-ms-user-select:none;user-select:none}.bh_u_08a7513e:focus{outline:0}.bh_u_08a7513e:focus-visible{outline:1px solid #000}.bh_u_08a7513e:before{position:absolute;top:0;width:28px;height:20px;content:\"\";transition:all .2s ease-out;border-radius:10px;background:\"[theme:themeDarkAlt, default: #106ebe]\";box-shadow:0 3.2px 7.2px rgba(0,0,0,.132),0 .6px 1.8px rgba(0,0,0,.108)}.bh_u_08a7513e .bi_u_08a7513e,.bh_u_08a7513e .bj_u_08a7513e{transition:all .1s ease-out}[dir=ltr] .bh_u_08a7513e.u_u_08a7513e:before{left:-3.5px}[dir=rtl] .bh_u_08a7513e.u_u_08a7513e:before{right:-3.5px}.bh_u_08a7513e.u_u_08a7513e .bi_u_08a7513e{z-index:1;color:\"[theme:white, default: #ffffff]\"}[dir=ltr] .bh_u_08a7513e.bk_u_08a7513e:before{left:19.5px}[dir=rtl] .bh_u_08a7513e.bk_u_08a7513e:before{right:19.5px}.bh_u_08a7513e.bk_u_08a7513e .bj_u_08a7513e{z-index:1;color:\"[theme:white, default: #ffffff]\"}", ""]);


/***/ }),

/***/ "veAR":
/*!************************************!*\
  !*** ./lib/toolboxChrome/index.js ***!
  \************************************/
/*! exports provided: ToolboxChrome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxChrome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxChrome */ "SISZ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxChrome", function() { return _ToolboxChrome__WEBPACK_IMPORTED_MODULE_0__["ToolboxChrome"]; });




/***/ }),

/***/ "wFRG":
/*!*****************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemSmall.module.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var content = __webpack_require__(/*! !../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!../../../../common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./ToolboxItemSmall.module.css */ "xI9K");
var loader = __webpack_require__(/*! @microsoft/load-themed-styles */ "jOlS");

if(typeof content === "string") content = [[module.i, content]];

// add the styles to the DOM
for (var i = 0; i < content.length; i++) loader.loadStyles(content[i][1], true);

if(content.locals) module.exports = content.locals;

/***/ }),

/***/ "wNeH":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxItem/ToolboxItemListViewBase.module.css ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ai_o_08a7513e{color:\"[theme:neutralPrimary, default: #323130]\";font-size:22px;width:30px;position:relative;margin:0 20px 0 10px}.ai_o_08a7513e .ms-Image{width:100%;height:100%}.ak_o_08a7513e{-ms-flex:1;flex:1;font-weight:600;font-size:14px;margin-bottom:2px}.am_o_08a7513e{color:#979593;-ms-flex:1;flex:1}.j_o_08a7513e{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;-ms-flex:1;flex:1;text-align:left}.ag_o_08a7513e{height:auto;padding:8px 10px;font-size:12px}.ag_o_08a7513e,.ah_o_08a7513e{display:-ms-flexbox;display:flex;-ms-flex-direction:row;flex-direction:row;width:100%}", ""]);


/***/ }),

/***/ "wPTN":
/*!*************************************!*\
  !*** ./lib/toolboxSection/index.js ***!
  \*************************************/
/*! exports provided: ToolboxSection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ToolboxItemsLayer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ToolboxItemsLayer */ "St2D");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ToolboxSection", function() { return _ToolboxItemsLayer__WEBPACK_IMPORTED_MODULE_0__["ToolboxItemsLayer"]; });

// @todo#680770 create section toolbox animation layer.



/***/ }),

/***/ "x0iz":
/*!*********************************************************!*\
  !*** ./lib/toolboxItem/ToolboxItemLarge.module.scss.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* tslint:disable */
__webpack_require__(/*! ./ToolboxItemLarge.module.css */ "CUwB");
var styles = {
    item: 'ag_m_08a7513e',
    flexBox: 'ah_m_08a7513e',
    icon: 'ai_m_08a7513e',
    title: 'ak_m_08a7513e'
};
/* harmony default export */ __webpack_exports__["default"] = (styles);
/* tslint:enable */ 


/***/ }),

/***/ "xI9K":
/*!***************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxItem/ToolboxItemSmall.module.css ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ag_q_08a7513e{width:33.3%;height:88px}.at_q_08a7513e{width:20%;height:88px}.ah_q_08a7513e{padding:10px 6px 0}.ah_q_08a7513e>*+*{margin-top:10px}.ai_q_08a7513e{width:82px;height:28px;min-height:28px;font-size:28px;line-height:28px}.ak_q_08a7513e{font-size:12px}", ""]);


/***/ }),

/***/ "yE+t":
/*!*********************************!*\
  !*** ./lib/toolboxView/View.js ***!
  \*********************************/
/*! exports provided: ALL_BY_CATEGORY_KEY, ALL_A_TO_Z_KEY, ViewConsumer, ViewProvider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_BY_CATEGORY_KEY", function() { return ALL_BY_CATEGORY_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALL_A_TO_Z_KEY", function() { return ALL_A_TO_Z_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewConsumer", function() { return ViewConsumer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewProvider", function() { return ViewProvider; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "17wl");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-diagnostics */ "ut3N");
/* harmony import */ var _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-lodash-subset */ "Pk8u");
/* harmony import */ var _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ms/odsp-utilities-bundle */ "y88i");
/* harmony import */ var _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _toolboxSearch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../toolboxSearch */ "ZFqg");
/* harmony import */ var _View_resx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./View.resx */ "sGpJ");
var _View_resx__WEBPACK_IMPORTED_MODULE_6___namespace = /*#__PURE__*/__webpack_require__.t(/*! ./View.resx */ "sGpJ", 1);








var ALL_BY_CATEGORY_KEY = 'allByCategory';
var ALL_A_TO_Z_KEY = 'allAToZ';
var context = react__WEBPACK_IMPORTED_MODULE_4__["createContext"]({
    view: {
        type: "Home" /* Home */,
        previousView: undefined
    },
    changeView: _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__["noop"],
    selectedCategory: ['', ''],
    switchView: _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__["noop"],
    isListView: false,
    toggleListView: _microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__["noop"]
});
// tslint:disable-next-line:variable-name
var ViewConsumer = context.Consumer;
var ViewProviderComp = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(ViewProviderComp, _super);
    function ViewProviderComp(props) {
        var _this = _super.call(this, props) || this;
        _this._toggleListView = function () {
            _this.setState({ isListView: !_this.state.isListView });
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_EngagementLogger"].logEvent('View.ToggleButton.Click');
            _this.props.a11yManager.alert(_ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__["StringHelper"].format(_View_resx__WEBPACK_IMPORTED_MODULE_6__["SwitchCategoryAlert"], _this.state.isListView ? _View_resx__WEBPACK_IMPORTED_MODULE_6__["ListViewName"] : _View_resx__WEBPACK_IMPORTED_MODULE_6__["GridViewName"]));
        };
        _this._changeView = function (ev, item) {
            if (!item) {
                return;
            }
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_EngagementLogger"].logEvent("View.ChangeView." + item.key + ".Click");
            switch (item.key) {
                case ALL_BY_CATEGORY_KEY: {
                    _this._switchView({
                        type: "Home" /* Home */,
                        previousView: _this.state.view
                    });
                    var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__["StringHelper"].format(_View_resx__WEBPACK_IMPORTED_MODULE_6__["SwitchCategoryAlert"], _View_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxCategoryAllCategory"]);
                    _this.props.a11yManager.alert(message);
                    break;
                }
                case ALL_A_TO_Z_KEY: {
                    _this._switchView({
                        type: "Sort" /* Sort */,
                        sortBy: 'alphabet',
                        previousView: _this.state.view
                    });
                    var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__["StringHelper"].format(_View_resx__WEBPACK_IMPORTED_MODULE_6__["SwitchCategoryAlert"], _View_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxCategorySortingCategory"]);
                    _this.props.a11yManager.alert(message);
                    break;
                }
                // Switch to specified category view.
                default: {
                    _this._switchToCategoryView(item.key);
                }
            }
        };
        _this._switchToCategoryView = function (groupId) {
            _this._switchView({
                type: "Category" /* Category */,
                groupId: groupId,
                previousView: _this.state.view
            });
            var message = _ms_odsp_utilities_bundle__WEBPACK_IMPORTED_MODULE_3__["StringHelper"].format(_View_resx__WEBPACK_IMPORTED_MODULE_6__["SwitchCategoryAlert"], _this._getCategoryName(groupId));
            _this.props.a11yManager.alert(message);
        };
        _this._switchView = function (view) {
            // Clear the search query to avoid the search view.
            _this.props.onFilterItems('', false);
            if (view.previousView !== undefined && _this._isSameView(view, view.previousView)) {
                // It is possible that, we are switch to a view with `previousView` set to the same view.
                // Concretely, it is search view currently. There is a `previousView` with the search view.
                // The user chooses the same view as the `previousView` from the dropdown menu.
                // So, instead of pushing a new view to history stack, it goes back to `previousView` directly.
                _this.setState({ view: view.previousView });
            }
            else {
                _this.setState({ view: view });
            }
        };
        _this.state = {
            view: {
                type: "Home" /* Home */,
                previousView: undefined
            },
            isListView: false
        };
        return _this;
    }
    ViewProviderComp.prototype.render = function () {
        var viewContext = {
            view: this.state.view,
            changeView: this._changeView,
            selectedCategory: this._selectedCategory,
            switchView: this._switchView,
            isListView: this.state.isListView,
            toggleListView: this._toggleListView
        };
        return react__WEBPACK_IMPORTED_MODULE_4__["createElement"](context.Provider, { value: viewContext }, this.props.children);
    };
    ViewProviderComp.prototype._getCategoryName = function (groupId) {
        var groupIndex = Object(_microsoft_sp_lodash_subset__WEBPACK_IMPORTED_MODULE_2__["findIndex"])(this.props.groups, function (group) { return group.groupId === groupId; });
        if (groupIndex >= 0) {
            return this.props.groups[groupIndex].title;
        }
        else {
            _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_TraceLogger"].logError(ViewProviderComp._logSource, new Error("Something went wrong with categorizing groups, group not found by given id: " + groupId));
            return '';
        }
    };
    ViewProviderComp.prototype._isSameView = function (view1, view2) {
        if (view1.type === "Category" /* Category */ && view2.type === "Category" /* Category */) {
            return view1.groupId === view2.groupId;
        }
        else {
            return view1.type === view2.type;
        }
    };
    Object.defineProperty(ViewProviderComp.prototype, "_selectedCategory", {
        get: function () {
            var selectedCategoryKey;
            var selectedCategoryName;
            if (this.props.query) {
                // For search view, we don't show a corresponding choice but update the title.
                selectedCategoryKey = '';
                selectedCategoryName = _View_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxCategorySearchResults"];
            }
            else if (this.state.view.type === "Home" /* Home */) {
                selectedCategoryKey = ALL_BY_CATEGORY_KEY;
                selectedCategoryName = _View_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxCategoryAllCategory"];
            }
            else if (this.state.view.type === "Sort" /* Sort */) {
                selectedCategoryKey = ALL_A_TO_Z_KEY;
                selectedCategoryName = _View_resx__WEBPACK_IMPORTED_MODULE_6__["ToolboxCategorySortingCategory"];
            }
            else {
                selectedCategoryKey = this.state.view.groupId;
                selectedCategoryName = this._getCategoryName(this.state.view.groupId);
            }
            return [selectedCategoryKey, selectedCategoryName];
        },
        enumerable: true,
        configurable: true
    });
    ViewProviderComp._logSource = _microsoft_sp_diagnostics__WEBPACK_IMPORTED_MODULE_1__["_LogSource"].create('Toolbox');
    return ViewProviderComp;
}(react__WEBPACK_IMPORTED_MODULE_4__["PureComponent"]));
function ViewProvider(props) {
    return (react__WEBPACK_IMPORTED_MODULE_4__["createElement"](_toolboxSearch__WEBPACK_IMPORTED_MODULE_5__["SearchConsumer"], null, function (searchContext) { return react__WEBPACK_IMPORTED_MODULE_4__["createElement"](ViewProviderComp, Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"])({}, props, searchContext)); }));
}


/***/ }),

/***/ "zNYN":
/*!************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** /agent/_work/1/s/common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/cjs.js!/agent/_work/1/s/common/temp/node_modules/.pnpm/postcss-loader@3.0.0/node_modules/postcss-loader/src??postcss!./lib/toolboxSmall/ToolboxSmall.module.css ***!
  \************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../common/temp/node_modules/.pnpm/css-loader@3.2.1_webpack@4.44.2/node_modules/css-loader/dist/runtime/api.js */ "5ADk")(false);
// Module
exports.push([module.i, ".ba_t_08a7513e{-ms-flex-align:center;align-items:center;display:-ms-flexbox;display:flex;font-size:13px;-ms-flex-pack:center;justify-content:center;padding:13px}.bb_t_08a7513e{height:380px}.bc_t_08a7513e{display:inline-block}.bc_t_08a7513e:not(.f_t_08a7513e){padding:0 12px}.bc_t_08a7513e.f_t_08a7513e{padding:0 16px}.ax_t_08a7513e .ms-CommandBar-primaryCommand{-ms-flex-direction:row;flex-direction:row}.ax_t_08a7513e .ms-CommandBar{padding:0}.ax_t_08a7513e .ms-CommandBar-primaryCommand{margin:3px 12px 9px}.ay_t_08a7513e{font-weight:600;background-color:\"[theme:neutralLight, default: #edebe9]\"}.be_t_08a7513e .ms-ContextualMenu-itemText{color:\"[theme:neutralPrimary, default: #323130]\"}.bf_t_08a7513e{font-size:12px}.bg_t_08a7513e{max-width:176px}.bg_t_08a7513e .ms-Button-textContainer{overflow-x:hidden}.bg_t_08a7513e .ms-Button-label{overflow-x:hidden;text-overflow:ellipsis;line-height:normal}", ""]);


/***/ })

}]);
//# sourceMappingURL=chunk.toolbox_[locale].js.map