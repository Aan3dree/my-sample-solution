declare const styles: {
    headerMenu: string;
    headerTitle: string;
    headerPerson: string;
    commandBar: string;
    workbench: string;
    header: string;
    workbenchLayout: string;
    pageContent: string;
};
export default styles;
//# sourceMappingURL=Workbench.module.scss.d.ts.map