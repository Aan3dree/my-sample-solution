declare const styles: {
    clickStop: string;
    clickStopSelected: string;
    navBarItem: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewClickStop.module.scss.d.ts.map