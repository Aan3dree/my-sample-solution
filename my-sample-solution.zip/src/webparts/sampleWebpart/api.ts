import axios from 'axios';

//const axios = require('axios');

const api = axios.create({
    baseURL: 'https://api.tvmaze.com/search/shows?q=marvel'
})

export default api;